## RNA-seq Pipeline
This pipeline is currently under production and is not operational yet as of 10-24-2024. For more information please see the documentation on sharepoint [here](https://collab.lilly.com/:w:/r/sites/LillyOmicsHub/Excelera%20Working%20Docs/Documentation/CLI_Options/Lilly_RNA_Seq_Pipeline.docx?d=wceae28b7a86c40bdab53d8afa0fde9f0&csf=1&web=1&e=zxdcaG)
. Or reach out to Phil Ebert or James Scherschel.  

## Pipeline overview

![pipeline diagram](docs/diagrams/rna-seq_pipeline.jpg)

1. Fqtools QC reports (fastx_quality_stats, kmer report)
2. FASTQ contamination testing (BLASTN)
3. Adapter and quality trimming (cutadapt)
4. Sequence alignment (GSNAP)
5. Alignment statistics generation (samtools flagstat, tlen, dupcount)
6. Count unique and multiply aligned reads in BAM files (samtools tabix, bedtools)
7. Detect contamination in BAM files (BLASTN)
8. Calculates and reports Reads Per Million (RPM) gene-level counts
9. Generates a standardized report for Exons, Junctions, Genes, and Genes + NovelExonGenes

## Repository structure

The repository is structured into the following folders:

* `docs/`: The documentation via Markdown
* `pipeline/`: The Nextflow pipeline

The folder `pipeline/` contains the Nextflow pipeline, which has the following sub-folders:

* `bin/`: The scripts that are used by the pipeline
* `conf/`: Configuration of the pipeline
* `env/`: Dockerfiles for tools used by pipeline
* `lib/`: cfg files used by perl scripts
* `workflows/`: Individual Nextflow processes and workflows
* `output/`: The results of your local runs which includes execution report
* `work/`: The working directory that is used by nextflow if you run locally

## Additional documentation

1. [Installation](docs/installation.md)
2. [Running the pipeline](docs/usage.md)
3. [Pipeline Overview](docs/pipeline_overview.md)