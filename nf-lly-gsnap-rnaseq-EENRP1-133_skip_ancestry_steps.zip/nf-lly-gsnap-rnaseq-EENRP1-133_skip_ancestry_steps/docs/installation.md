# Installation

Install Nextflow:

* [Nextflow](https://www.nextflow.io)
    * Follow [Nextflow documentation](https://www.nextflow.io/docs/latest/getstarted.html#installation)

```{bash}
# Download nextflow executable
curl -s https://get.nextflow.io | bash

# Add nextflow to your ~/.bashrc
export PATH=$PATH:/fsx/home/<Lilly_ID>
```

### Setting up your aws credentials folder

You need to set up your AWS credentials and config file:

1. [AWS Config & Information](https://lilly-confluence.atlassian.net/wiki/spaces/LBOH/pages/1464633065/AWS+Config+Information)
2. Authenticate with MFA
```{bash}
aws-mfa --device arn:aws:iam::255270728588:mfa/<Lilly_ID>
```