# Pipeline Overview

## Input Processing (inputprocessing.nf)

### Simple Batch Separator (JAVA)

SimpleOptimisticBatchSeparator.java processes FASTQ files and try to separate into batch using flowcell or flowcell-lane based on the optimistic assumption that there will be no issues. Sometimes, sets of reads (referred to as "batches") for the same sample library generated from separate sequencing lanes of a next-gen illumina sequencer are written to the same file. To enable detection of variability or other QC concerns, these batches should be separated by using BatchSeparator. All reads are written in standard form regardless of input formatting. These functions are called in the input processing workflow from java_batch_separator.nf. 

The output file names will match one of the following three forms:
for example - input file is "some.fq.gz"
* some__batch_<FLOWCELL>_<LANE>_read<read-number>.fq.gz
* some__batch_<FLOWCELL>_read<read-number>.fq.gz
* some__NOBATCH_read<read-number>.fq.gz


| Parameter                 | Description                                                            |
|---------------------------|------------------------------------------------------------------------|
| `input-fastq-readN.fq.gz` | The input fastq file name MUST end in either .fq.gz or .fastq.gz       |
| `read-number`             | The read number is expected to be either 1 or 2 but may also be 3 or 4 |
| `separation-type`         | The separation-type must be either "flowcell" or "flowcell-lane"       |
| `output-directory`        | The output folder path                                                 |
| `FORCE_WRITE`             | To override the existing output files                                  |


### New samplesheet 

create_samplesheet.py generates samplesheet based on newly generated FASTQ files from batch separation step (above mention).


| Parameter | Description                                              |
|-----------|----------------------------------------------------------|
| `path`    | The path of the output folder from batch separation step |
| `outpath` | The output folder path                                   |


### Fastq Validator (JAVA) 

FastqValidatingProfiler.java processes FASTQ files through the reading and validating the files, identification of apparent batches (based on common read-id-formats and issues), read length distribution (default to 10bp buckets), quality etc. These functions are called in the input processing workflow from javacodes.nf. 

Fastq validation checks the following:
* Checks for a known FASTQ read style (new casava, old casava, ion torrent, etc.)
* Checks sequence and read quality for existence of invalid characters
* Checks for duplicate reads and removes them
* Check for chastity reads and removes them
* If PE checks mates are sorted in the same order and contain the same number of lines 


| Parameter                         | Description                                                                                |
|-----------------------------------|--------------------------------------------------------------------------------------------|
| `-v verbose`                      | Specifies verbose to display detailed output for purposes                                  |
| `-s silent`                       | To operate without emitting any output                                                     |
| `-l log-filename`                 | The process output file                                                                    |
| `-f read1/2.fq.gz`                | The input Fastq file(s), may be specified one to four times based on reads                 |
| `-m md5-checksum`                 | The md5 checksum file(s), may be specified one to four times based on reads                |
| `-b flowcell-lane`                | Specifies the batch separation level                                                       |
| `-B batch-separation-regexs-file` | The tsv file containing regular expressions with named capture groups separated by batches |
| `-t <temp-directory`              | The folder path used for file-backed data structures (default: java.io.tmpdir)             |



## Pre-Processing

### Fqtools

run_fqtools.pl processes FASTQ files through two main bioinformatics tools: fastx_quality_stats and kmer report. This script takes FASTQ files as input, generates quality statistics and k-mer analysis for each file, and then combines the individual results into a final report.

1. Quality Statistics Generation (functions loaded into preprocessing workflow from fqtools_fastx.nf):

    * Uses fastx_quality_stats on each FASTQ file to evaluate the quality scores across all reads.
    * Produces an output file for each FASTQ file, containing detailed statistics such as per-position quality scores, read lengths, and overall quality distributions.

2. K-mer Analysis (functions loaded into preprocessing workflow from fqtools_kmer.nf):

    * Runs a k-mer frequency analysis on each FASTQ file, producing a report with the distribution of k-mers (short, fixed-length sequences) across the dataset.
    * Provides insights into sequence complexity and potential contaminants by identifying common repetitive sequences.

### Contamintation Testing

run_contam_testing.pl is designed to analyze contamination in sequencing datasets by processing FASTQ files through a series of steps, including sequence extraction, BLAST analysis, organism lookup, and reporting. This script is intended to detect and summarize potential contaminants across multiple samples, making it especially useful for quality control in sequencing workflows. The following functions are loaded into the pre-processing workflow from contam_testing.nf: 

1. Sequence Fetching:

    * fq_fetch: Extracts a subset of reads from the input FASTQ file.
    * fetch_sum: Summarizes the count of sequences fetched.

2. BLAST Analysis:

    * blast: Runs a BLAST search of the fetched reads against a specified database, identifying potential contaminants by matching reads to known sequences.

3. Organism Identification and Reporting:

    * org_sum: Looks up organisms associated with the BLAST hits by querying an organism database, summarizing the results to identify species related to the contamination.
    * org_report: Combines individual org_sum reports for each sample into a unified report, simplifying cross-sample comparison.
    * final_org: Aggregates organism content data across all samples, helping to pinpoint significant contaminant organisms across the dataset.

4. Match Summary and Identity Reporting:

    * count_blast_matches: Generates a summary report of BLAST matches that meet certain identity criteria, highlighting sequences of interest.
    * final_id_report: Compiles identity-based BLAST matches across all samples into a consolidated report for easy reference.

5. Homopolymer Analysis:

    * poly_report: Merges homopolymer analysis reports created during the fq_fetch stage into a final report. This helps detect repetitive sequences, which can indicate certain contaminants or low-quality data.

### Scatter and Gather

The scatter-and-gather strategy in the pipeline enables efficient parallel processing by splitting large datasets into smaller chunks, processing them independently, and then merging the results. This iterative process ensures that even failed chunks are resplit and reprocessed in subsequent rounds.

#### Workflow Overview

The workflow consists of the following scatter and gather steps:

1. Define Input Samples:
    * FASTQ files are prepared as input tuples: `(sample_id, fastq1, fastq2, round)`.

2. Read Count Calculation:
    * Module: `COUNT_READS` (functions from count_reads.nf)
    * Counts the number of reads in each input FASTQ file.

3. Initial Splitting:
    * Module: `SPLIT_FASTQ_FILES1`
    * Splits FASTQ files into smaller chunks for parallel processing. Functions imported from module split_fastq_files.nf. 

4. Adapter Trimming:
    * Module: `CUTADAPT` (functions from cutadapt.nf)
    * Removes adapter sequences and low-quality reads from FASTQ files.

5. First Round of Alignment, Generate Statistics and Convert SAM to BAM**:
    * Modules: `RUN_GSNAP1`, `STATS1`, `BAM1` (functions from run_gsnap.nf, generate_alignment_stats.nf, sam_to_bam.nf)
    * Aligns trimmed FASTQ chunks to the reference genome using GSNAP.
    * Alignment statistics are generated, and SAM files are converted to BAM format.

6. Filtering Successful and Failed Chunks from First Round:
    * Successful chunks proceed to generate alignment statistics and BAM files.
    * Failed chunks are resplit for subsequent rounds.

7. Resplit the failed chunks from First Round:
    * Failed chunks are resplit using `SPLIT_FASTQ_FILES2`. (functions imported from module split_fastq_files.nf)

8. Second Round of Alignment, Generate Statistics and Convert SAM to BAM:
    * Modules: `RUN_GSNAP2`, `STATS2`, `BAM2` (functions from run_gsnap.nf, generate_alignment_stats.nf, sam_to_bam.nf)
    * Aligns replitted FASTQ chunks to the reference genome using GSNAP.
    * Alignment statistics are generated, and SAM files are converted to BAM format.

9. Filtering Successful and Failed Chunks from Second Round:
    * Successful chunks proceed to generate alignment statistics and BAM files.
    * Failed chunks are resplit for subsequent rounds.

10. Resplit the failed chunks from Second Round:
    * Failed chunks are resplit using `SPLIT_FASTQ_FILES3`. (functions imported from module split_fastq_files.nf)

11. Third Round of Alignment, Generate Statistics and Convert SAM to BAM:
    * Modules: `RUN_GSNAP3`, `STATS3`, `BAM3` (functions from run_gsnap.nf, generate_alignment_stats.nf, sam_to_bam.nf)
    * Aligns replitted FASTQ chunks to the reference genome using GSNAP.
    * Alignment statistics are generated, and SAM files are converted to BAM format.

12. Gather Results:
    * Modules: `GATHER_BAMS`, `COMBINE_STATS`, `REPORT_FAILED_CHUNKS` ( functions from gather_bams.nf, combine_stats.nf, report_failed_chunks.nf)
    * BAM files are merged, alignment statistics are consolidated, and failed chunk reports are generated.

#### Scatter Modules

##### COUNT_READS

Counts the number of reads in input FASTQ files to determine splitting strategies. Uses `seqkit stats` to compute the number of reads in each FASTQ file. Based on the reads of the input fastq files dynamically calculates no. of chunks for spliting.

1. Script:
   * `count_reads.nf`
2. Input:
   * Tuples of `(sample_id, fastq1, fastq2, round)` (paired-end or single-end FASTQ files).
3. Output:
   * A file with the read count and no. of chunks for each input FASTQ file (`${sample_id_read_counts_chunks.txt`).

##### SPLIT_FASTQ_FILES1, SPLIT_FASTQ_FILES2, SPLIT_FASTQ_FILES3

Splits input FASTQ files into smaller chunks for parallel processing. Uses `seqkit split` to split FASTQ files into smaller files based on read counts and chunking rules. `SPLIT_FASTQ_FILES1` splits FASTQ files for Round 1, `SPLIT_FASTQ_FILES2` handles resplitting of failed chunks after Round 1, `SPLIT_FASTQ_FILES3` handles resplitting of failed chunks after Round 2.

1. Script:
   * `split_fastq_files.nf`
2. Input:
   * Read count file from `COUNT_READS` and the FASTQ files.
3. Output:
   * Split FASTQ files.

| Parameter             | Description                                                                                                 |
|-----------------------|-------------------------------------------------------------------------------------------------------------|
| `initial_chunks`   | Number of initial chunks to create. Used in `SPLIT_FASTQ_FILES1`                    |
| `resplit_chunks` | Number of chunks for second-round resplitting. Used in `SPLIT_FASTQ_FILES2` |
| `resplit_chunks2` | Number of chunks for third-round resplitting. Used in `SPLIT_FASTQ_FILES3`                        |

##### CUTADAPT

Cutadapt(v2.5) is a tool for trimming adapters, filtering low-quality reads, and processing single-end (SE) or paired-end (PE) sequencing data. The process involves two stages of trimming, followed by merging and final output generation. The parameters are customized for stringent adapter removal, quality trimming, and length filtering.
This module runs once, immediately after the first splitting step, to clean up the FASTQ files before alignment.

1. Script:
   * `cutadapt.nf`
2. Input:
   * Split FASTQ files from `SPLIT_FASTQ_FILES1`.
3. Output:
   * Trimmed FASTQ files saved with the `.trimmed.fastq.gz` suffix.

| Parameter          | Description                                                                   |
|------------------------|-----------------------------------------------------------------------------------|
| `-j [threads]`         | Number of threads for parallel processing.                                        |
| `--quality-base=33`    | Assumes base quality score encoding is Phred+33.                                  |
| `-a / -A`              | Specifies adapter sequences to trim for single-end / paired-end reads.            |
| `-q 20`                | Minimum base quality score to retain (Phred).                                     |
| `-n 2`                 | Maximum number of adapter sequences to trim per read.                             |
| `--trim-n`             | Removes terminal unknown bases (N).                                               |
| `-m 20`                | Minimum length of retained reads after trimming.                                  |
| `--max-n=0.2`          | Retain reads with ≤20% ambiguous bases (N).                                       |

##### RUN_GSNAP1, RUN_GSNAP2, RUN_GSNAP3

GSNAP is a powerful aligner used for mapping short RNA-seq or DNA-seq reads to a reference genome or transcriptome. In this workflow, GSNAP is used for aligning paired-end or single-end reads to a reference database, generating a SAM file containing alignment information. The process is highly customizable through a variety of command-line options that influence how the alignments are performed. `RUN_GSNAP1` aligns trimmed FASTQ chunks (first round), RUN_GSNAP2 aligns resplit chunks from `SPLIT_FASTQ_FILES2` and `RUN_GSNAP3` aligns resplit chunks from `SPLIT_FASTQ_FILES3`.

1. Script:
   * `run_gsnap.nf`
2. Input:
   * Trimmed FASTQ files from `CUTADAPT` or resplitting steps (`SPLIT_FASTQ_FILES2`, `SPLIT_FASTQ_FILES3`).
3. Output:
   * SAM file: Generated for aligned reads (`${sample_id}.sam`).
   * Status files: Indicating alignment success or failure.
   * GSNAP logs: Detailed alignment logs for debugging.

| Parameter             | Description                                                                                                 |
|-----------------------|-------------------------------------------------------------------------------------------------------------|
| `batch_mode`   | Controls memory management by processing reads in batches, useful for large-scale data. For parameter "-B"                    |
| `no_splicing` | If set, spliced alignments are not allowed. This is useful when aligning RNA-seq data without intron-exon splicing. For parameter "-N" |
| `quality_protocol` | Specifies the quality protocol for the input reads (e.g., 'sanger', 'illumina'). For parameter "--quality-protocol"                        |
| `max_search`   | The maximum number of candidate alignments to search for each read. For parameter "--maxsearch"                                          |
| `max_paths`     | Specifies the maximum number of alignment paths that can be reported for each read. For parameter "--npaths"                         |
| `enable_gunzip`    | If enabled, gzipped input files are automatically decompressed. For parameter "--gunzip"                                             |
| `multiple_primaries` | Allows multiple primary alignments for a single read, useful for highly repetitive regions. For "--sam-multiple-primaries"               |
| `output_format`   | Output format for parameter "-A" |

##### STATS1, STATS2, STATS3

Generates alignment statistics for successfully aligned chunks as defined in `run_gsnap.pl`. `STATS1` generates alignment statistics for SAM files from `RUN_GSNAP1`, `STATS2` generates alignment statistics for SAM files from `RUN_GSNAP2` and `STATS3` generates alignment statistics for SAM files from `RUN_GSNAP3`.

1. Script:
   * `generate_alignment_stats.nf`
2. Input:
   * SAM files from successful chunks from `RUN_GSNAP`.
   * Input reads from `RUN_GSNAP`.
3. Output:
   * Alignment statistics files.

##### BAM1, BAM2, BAM3

Converts SAM files to BAM format for downstream processing. Uses `samtools` to sort and convert SAM files to BAM format. `BAM1` converts SAM files from `RUN_GSNAP1`, `BAM2` converts SAM files from `RUN_GSNAP2` and `BAM3` converts SAM files from `RUN_GSNAP3`.

1. Script:
   * `sam_to_bam.nf`
2. Input:
   * SAM files from successful chunks from `RUN_GSNAP`.
3. Output:
   * BAM files.

#### Gather Modules

##### GATHER_BAMS

Merges BAM files from all successful chunks into a single BAM file.Iteratively merges BAM files and creates indexes using `samtools`.

1. Script:
   * `gather_bams.nf`
2. Input:
   * BAM files from all successful rounds (`BAM1`, `BAM2`, `BAM3`).
3. Output:
   * Merged BAM file: `${sample_id}_merged.bam`.
   * BAM index file: `${sample_id}_merged.bam.bai`.

| Parameter        | Description                                                                 |
|-----------------------|-----------------------------------------------------------------------------|
| `local_max_mergeable` | Maximum number of BAM files to merge at once.                            |

##### COMBINE_STATS

Aggregates alignment statistics files from all successful chunks into a single alignment statistics file for each sample and also adjusts/recalculates stats as defined in `combine_aln_stats.pl`

1. Script:
   * `combine_stats.nf`
2. Input:
   * Alignment statistics files of successful chunks from all rounds.
3. Output:
   * Unified alignment statistics report (`${sample_id}_combined_alignment_stats.txt`).

##### REPORT_FAILED_CHUNKS

Generates a detailed report of all failed chunks across rounds.

1. Script:
   * `report_failed_chunks.nf`
2. Input:
   * Lists of failed chunks: R1/R2 files, SAM files, GSNAP logs, and status files.
3. Output:
   * Failed Summary report file (`${sample_id}_failed_chunks_summary.txt`).

### PseudoAlignment via Kallisto
 This optional alternative or additional mapper has been added to the pipeline as a comparison with the GSNAP alignment tool to see if counts generated by this tool yields similar results. Kallisto default alignment and abundance calculations are run. Currently only a pregenerated Kallisto index (Homo_sapiens.GRCh38.cdna.all.fa-index) is available. Functions are imported into the pre-processing workflow from the module 'kallisto_test.nf'
 
## Post-Processing

### Bam Stats

run_bamtools.pl is a Perl script designed to execute various BAM file analysis tools on all BAM files within a specified directory. It automates the generation of individual tool reports and combines these outputs into a single comprehensive report for downstream analysis. Functions imported into the post-processing workflow from module bam_stats.nf. 

1. flagstat:
    * Executes samtools flagstat on a BAM file to produce a summary of read alignment statistics.

2. tlen:
    * Generates a fragment length (template length) report for a BAM file.

3. dup_count:
    * Produces a duplicate read count report for a BAM file.

4. combine:
    * Combines individual tool outputs (flagstat, tlen, dup_count, etc.) into a single consolidated report for easier interpretation.

### Counts Generation

run_bam2simple_counts.pl is a Perl script designed to process BAM files and generate read count data for genomic regions. This workflow separates uniquely and multiply aligned reads, counts them, and merges the results into a final summary. Below is an overview of the steps involved. Functions imported into post-processing workflow from module counts_generation.nf. To speed processing, counts generation is split in multiple chromosome and region specific jobs and combined in the merge_results step. Since small samples / fastq files cause some of these counts generation steps to produce blank outputs, if the test profile is specified then counts generation is not split and functions are called from the module counts_generation_test.nf. 

1. Count Unique Reads:

    * count_unique: Counts uniquely aligned reads for specified genomic regions.

2. Setup for Multiple Alignments:

    * setup_multiple: Merges sorted files of multiply aligned reads to group alignments for the same read, preparing them for analysis.

3. Count Multiply Aligned Reads:

    * count_multiple: Analyzes multiply aligned reads and assigns counts based on alignment metrics.

4. Merge Results:

    * merge_results: Produces a single combined counts file for both uniquely and multiply aligned reads.

### Alignment Contamination Testing

run_contam_testing.pl for alignment contamination testing is designed to analyze potential contaminants in RNA sequencing datasets using the same steps and Perl scripts as the contamination testing for FASTQ files. The main difference is that it processes BAM files, utilizing bam_fetch to extract unmapped reads instead of fq_fetch for FASTQ files. The process follows the same sequence of steps, including read fetching, BLAST analysis, organism identification, and reporting, allowing for efficient contamination detection and summarization across multiple samples.

### Region-Based/Hapmap Quantification

The region-based/Hapmap quantification pipeline processes BAM files to generate quantitative coverage information over predefined genomic regions. This process generates various reports summarizing read depth, mapping quality, and final quantification metrics. The Perl script to run region-based quantification is **`run_bam2rgn_quant.pl`**. It also uses **`bam_rgns2quant.pl`**.

1. split
   * Divides the input region file into equal-sized segments.
   * Generates chunked region files that can be processed separately.

2. bam2quant
   * Extracts read counts from BAM files for each predefined region.
   * Applies filters based on:
     - Base Quality (`BQ`)
     - Mapping Quality (`MQ`)
     - Read Depth (`NR`)
   * Outputs region-based quantification data.

3. combine
   * Merges individual quantification outputs into a single final report.
   * Consolidates results across multiple regions and samples.

### Oddity Counts Analysis

The **Oddity Counts Analysis** pipeline processes BAM files to identify and quantify anomalies in RNA-seq data. This pipeline evaluates read distribution patterns, highlighting soft-clipped clusters, improperly paired reads, intergenic reads, and split reads spanning multiple genes or non-genic regions. The Perl script to run this analysis is run_oddity_counts.pl. It also uses data2cdbm.pl and counting_utils.pm.

1. split
   * Divides the BAM file into multiple smaller chunks for efficient processing.
   * Each chunk is stored separately for individual computation.

2. xt_index
   * Creates an index for reads containing XT or SA tags, mapping locations of split alignments.
   * This index is required for identifying fusion events and anomalous splicing.

3. count
   * Identifies and quantifies anomalous reads in the BAM file, including:
     - Clusters of soft-clipped reads (potential breakpoints or fusions).
     - Improperly paired reads (indicative of genomic structural variations).
     - Intergenic read clusters (unexpected read distributions).
     - Reads spanning multiple genes or a gene and a non-genic region**.
     - Multi-mapped reads.
     - Paired-end reads where only one end maps.

4. merge_counts
   * Aggregates individual count files into a final consolidated report.
   * Applies thresholds and clustering to refine results.


### 3' Bias Testing

The 3' bias testing pipeline evaluates read coverage across transcripts to assess potential biases in RNA-seq data. This process generates various reports that summarize raw read distributions, slope density, and final 3' bias metrics. The perl script to run 3p bias testing is run_3p_bias_testing.pl

1. get_gff

    * Extracts a set of transcript descriptions from a GFF file and divides them into chunks for parallel evaluation.

2. count

    * Counts reads at selected positions in a BAM file for a given set of transcripts.

3. sort_counts

    * Sorts a count file by transcript ID.

4. reassort_counts

    * Takes a set of transcript-sorted count files and reorganizes them to create files containing complete datasets for one or more transcripts.

5. slopes

    * Computes linear fits to the log of transcript counts and reports the slope, standard error, and p-value for each fit.

6. combine

    * Combines all individual count files into a final consolidated report.

7. reassort_slopes

    * Reorganizes slope data either by sample or transcript, enabling slope density evaluations across all transcripts for a sample or all samples for a transcript.

8. density

    * Computes slope density from a file of slopes, categorized by either sample or transcript.

9. final_density

    * Combines multiple density files into a single final report.

10. sample_report

    * Reads the sample density file and reports the slope with the maximum density as a measure of overall 3' bias.

### Fingerprinting

#### Assay-to-Fingerprint Mapping for Hapmap Quantification (assay_fingerprint)

The Assay-to-Fingerprint Mapping pipeline processes hapmap quantification files to generate fingerprint identifiers at the assay level. These fingerprints represent allelic variations and read depth distribution at predefined genomic positions. The Perl script to run this process is generateAssay2FingerprintFileForHapmapQuantDir.pl.

1. process_arguments
   * Parses user-provided options for genome build, read depth thresholds, allele imbalance limits, and input directories.
   * Ensures all required files and directories exist before execution.

2. load_fingerprint_definitions
   * Reads a fingerprint definition file containing reference genomic positions.
   * Stores allele and position mappings for later lookup.

3. load_assay_quantification_files
   * Reads an assay-to-quantification file mapping to link each assay with its corresponding quantification data.
   * Ensures all required quantification files are accessible.

4. extract_quantification_data
   * Reads hapmap quantification files for each assay.
   * Extracts allele counts and read depths for fingerprinting positions.
   * Filters out low-depth reads based on user-defined thresholds.

5. generate_fingerprints
   * Converts extracted allele counts into fingerprint strings using base64 encoding.
   * Outputs an assay-to-fingerprint mapping file for downstream analysis.

6. write_output
   * Saves the generated fingerprints to an output file.
   * Ensures correct permissions for shared access.

#### Sample-to-Fingerprint Mapping for Hapmap Quantification (sample_fingerprint and sex_fingerprintX)

The Sample-to-Fingerprint Mapping pipeline processes hapmap quantification files to generate fingerprint identifiers for each sample. These fingerprints are based on allelic imbalances and read depths at predefined genomic positions. The Perl script to run this process is generateSample2FingerprintFileForHapmapQuantDir.pl.

1. process_arguments
   * Parses user-provided options for genome build, read depth thresholds, allele imbalance limits, and input directories.
   * Ensures all required files and directories exist before execution.

2. load_fingerprint_definitions
   * Reads a fingerprint definition file containing reference genomic positions.
   * Stores allele and position mappings for later lookup.

3. map_sample_to_assay
   * Reads sample-to-assay mapping files to associate each sample with its corresponding assays.
   * Extracts valid assay identifiers from provided metadata files.

4. extract_quantification_data
   * Reads hapmap quantification files for each assay.
   * Extracts allele counts and read depths for fingerprinting positions.
   * Filters out low-depth reads based on user-defined thresholds.

5. generate_fingerprints
   * Converts extracted allele counts into fingerprint strings using base64 encoding.
   * Outputs a sample-to-fingerprint mapping file for downstream analysis.

6. write_output
   * Saves the generated fingerprints to an output file.
   * Ensures correct permissions for shared access.

## Reporting

### Report Simple RPM

report_simple_rpm.pl is a script designed to generate a simple RPM (Reads Per Million) gene-level count for genomic datasets. It calculates both unique and total RPMs for each gene to evaluate the impact of multiple gene identifications. Mitochondrial and nuclear counts are computed separately but merged for the final report, ensuring that divergent mitochondrial content does not skew results. The script also supports filtering, rescaling, and customizable outputs to meet specific analysis needs. This function imported into the workflow reporting from module report_simple.nf 

Key Outputs:
* Assay-level RPM: RPM values calculated for each assay.
* Sample-level RPM: RPM values aggregated at the sample level.
* Raw Counts: Gene counts without normalization to RPM.

### Report Combined Counts

report_combined_counts.pl is a Perl script designed to generate a standardized report for statistical analysis of sequencing data. The script produces separate reports for Exons, Junctions, Genes, and Genes + NovelExonGenes, focusing on unambiguous counts. The output provides one column per sample for easy comparative analysis. This function imported into the workflow reporting from module report_counts.nf 

Key Features:
1. Output Customization
    * Generate files for specific genomic features:
        * Exons
        * Junctions
        * Genes
        * Genes + NovelExonGenes
    
2. Data Filtering:
    * Remove counts based on origin, such as:
        * Mitochondrial reads
        * rRNA-derived reads
        * Nuclear reads

3. Normalization and Thresholds:
    * Generate normalized reports summarizing gene expression distributions.
    * Set thresholds to ignore entities with low maximum read counts.

### Combined Oddity Counts Reporting

The Combined Oddity Counts Reporting pipeline processes multiple oddity count files from different samples and generates a structured final report. This script merges overlapping regions, filters out unwanted data, and outputs a standardized report for downstream analysis. The Perl script to run this reporting is report_combined_oddity_counts.pl.

1. process_input_files
   * Reads oddity count files from the input directory.
   * Extracts chromosome, start, stop, event type, gene IDs, and read counts.
   * Maps each sample to a unique index for processing.

2. merge_overlapping_regions
   * Identifies and combines overlapping genomic regions with the same event type.
   * Merges soft-clipped reads, improperly paired reads, and multi-mapped read events.

3. apply_filters
   * Filters out rRNA, mitochondrial (chrM or MT), or nuclear-derived counts if specified by the user.
   * Removes entries below a minimum read count threshold.

4. generate_final_report
   * Produces a final standardized oddity count report.
   * Writes output with genomic location, event type, gene associations, and per-sample counts.
   * Generates a rollup summary report summarizing event occurrences.

5. write_output
   * Sorts and formats the final merged results.
   * Outputs files in a structured, tab-separated format for downstream analysis.

### Sample-Level Sex Inference

The Sample-Level Sex Inference pipeline processes various genomic features, including chromosome X heterozygosity, chromosome Y gene expression, and copy number predictions, to infer the sex of each sample. The Perl script to run this process is generateSampleLevelSexInferenceFile.pl.

1. process_arguments
   * Parses user-provided options for results directory, input files, and output file.
   * Ensures all required files and directories exist before execution.

2. load_chrX_fingerprints
   * Reads chromosome X heterozygosity fingerprints from an input file.
   * Calculates the number of heterozygous and total callable sites per sample.

3. load_chrY_expression
   * Reads sample-level RPM (Reads Per Million) data for chromosome Y genes.
   * Extracts gene counts, detected gene counts, and cumulative RPM values.

4. load_chrY_fingerprints
   * Reads chromosome Y fingerprint data from an input file.
   * Determines the number of callable sites for chromosome Y per sample.

5. load_cnp_gender_predictions
   * Reads copy number pipeline (CNP) gender predictions from an input directory.
   * Extracts gender score and inferred gender classification.

6. infer_sample_sex
   * Integrates evidence from chromosome X heterozygosity, chromosome Y expression, and CNP gender predictions.
   * Assigns a final inferred sex classification based on predefined thresholds.

7. write_output
   * Generates a tab-separated output file with inferred sex predictions.
   * Ensures correct formatting and access permissions.

## QC Testing

### Base Testing

The base testing QC analysis workflow ensures the accuracy and quality of sequencing data by examining base quality scores. It identifies potential issues and generates warnings to maintain high standards for downstream analysis.

1. Steps in the Workflow

    * Base Quality Analysis:
        * base_quality_check: Evaluates base quality scores across all reads to detect potential sequencing errors.

    * QC Warnings and Exclusions:
        * qc_note_warn_processing: Applies standardized QC warning criteria to determine whether samples or assays require further review or exclusion.

2. Parameters and Thresholds

    * Base Quality Metrics:
        * meanNormQualityAbsDeltaWarnGE: 0.015
        * ssePerBaseWarnGE: 0.001
        * meanBaseQualityReadICWarnLE: 40.0
        * fractionalAreaUnderMaxQualityWarnLE: 0.80
        * fractionalAreaUnderMaxQualityNoteLE: 0.84
        * fractionalAreaUnder20WarnLE: 0.95
        * fractionalAreaUnder20NoteLE: 0.99

3. Execution:
    * The workflow is implemented using Perl scripts and executed via command-line arguments. Key script generate_base_quality_note_warn.pl identifies base quality issues and generates warnings.

4. Output:
    * Base Quality Report (assay2baseQualityQCMetrics.txt): Contains base quality statistics
    * Final QC Summary (QC_basequality_results.txt): Summarizes base quality QC results for review.


### Template Lengths

The template lengths QC analysis workflow ensures the accuracy and consistency of sequencing data by assessing template length distributions at the project, sample, and assay levels. It identifies outliers and anomalies to maintain high-quality sequencing results.

1. Steps in the Workflow
    * Template Length Distribution Analysis
        * template_length_distribution: Evaluates template length distributions to identify deviations from expected patterns.
        * Project-Level Analysis:
            * Aggregates all assay template lengths to create a cumulative distribution function (CDF).
            * Compares project-wide template length distribution to an ideal reference distribution.
            * Identifies multiple distribution clusters within a project.
        * Sample-Level Analysis:
            * Compares sample-level template length distributions to project-level distributions.
            * Assesses consistency of assay distributions within the same sample.
        * Assay-Level Analysis:
            * Compares assay template length distributions to expected read lengths.
    * QC Warnings and Exclusions
        * flag_outliers: Identifies assays and samples with abnormal template length distributions.
        * Flags outliers based on statistical deviations from reference distributions.

2. Parameters and Thresholds
    * Template Length Metrics
        * Intra-Sample Assay Distance: Mean = 0.0030, Std Dev = 0.0602
        * Inter-Sample Assay Distance: Mean = 0.0282, Std Dev = 0.0195
        * Project Distance from Ideal: Mean = 0.1070, Std Dev = 0.0227
        * Sample Distance from Ideal: Mean = 0.1164, Std Dev = 0.0338
        * Assay Distance from Ideal: Mean = 0.1151, Std Dev = 0.0259
        * Project Min Bin Fraction: Mean = 0.1055, Std Dev = 0.1058
        * Project Max Bin Fraction: Mean = 0.0599, Std Dev = 0.0411
        * Project Bookend Bin Fraction: Mean = 0.1653, Std Dev = 0.1181
    * Outlier Detection Thresholds
        * Outlier Z-Threshold: 2.575 (Flags ~0.5% of data as outliers)
        * Intra-Sample Distance Threshold: Mean + 1.000 × Std Dev (~16% flagged)
        * Inter-Sample Distance Threshold: Mean + 1.282 × Std Dev (~10% flagged)
        * Inner Bin Read Count Threshold: 2,000 reads
        * Median Sample Template Length Std Dev Threshold: 25.0
        * Minimum Expected Read Length Range to Warn: 10

3. Execution
    * The key script generate_template_length_note_warn.pl assesses template length distributions and flags anomalies.

4. Output   
    * Final QC Summary (QC_tlen_results.txt): Summarizes template length QC results for review.