
# RNA-Seq Pipeline Usage Guide

## Introduction

This guide provides step-by-step instructions for running the RNA-seq pipeline. Before proceeding, ensure you have completed the setup outlined in the [Installation Guide](installation.md).

---

## Required Data

### Sample Sheet

The pipeline requires a sample sheet in a tab-separated file named `sample2fq.txt`. This file lists sample IDs and their corresponding paths to `.fastq.gz` files.

- The samples can be stored locally or in an S3 bucket.
- Ensure the file format is consistent with the example below:

**Sample Sheet Format:**

```{bash}
sample_id   path/to/sample_id_R1.fastq.gz   path/to/sample_id_R2.fastq.gz
```

---

## Running the Pipeline

The RNA-seq pipeline is designed to run on SLURM using Singularity containers or awsbatch with Docker containers.

### **Option 1: Running the Pipeline with Test Profile**

This method is suitable for quick testing using a default subsampled dataset.

#### Steps:

1. Use the `test` profile for the subsampled dataset.
2. Run the pipeline with the following command:

   ```{bash}
   # run with slurm and singularity
   nextflow run /fsx/nf-lly-human-gsnap-rnaseq/repo/pipeline/main.nf -profile test,slurm,singularity --output_dir /path/to/your/output/folder/

   # run with awsbatch and docker
   nextflow run /fsx/nf-lly-human-gsnap-rnaseq/repo/pipeline/main.nf -profile test,awsbatch,docker --output_dir /path/to/your/output/folder/
   ```

---

### **Option 2: Running the Pipeline with Custom Samples**

This method is for running the pipeline with your custom dataset.

#### Steps:

##### Step 1: Create the Sample Sheet

- Define your input data in a sample sheet.
- Replace `/path/to/your_custom_samplesheet.txt` with the path to your custom sample sheet.
- Ensure the sample sheet is formatted like the example below:

**Example:**

```{bash}
SRR3151766   s3://loh-prd-hub/testdata/nf-lly-human-gsnap-rnaseq/SRR3151766_R1.fastq.gz   s3://loh-prd-hub/testdata/nf-lly-human-gsnap-rnaseq/SRR3151766_R2.fastq.gz
```

##### Step 2: Run the Pipeline

Run the pipeline with your custom sample sheet using the following command:

```{bash}
nextflow run /fsx/nf-lly-human-gsnap-rnaseq/repo/pipeline/main.nf -profile slurm,singularity --sample_sheet /path/to/your_custom_samplesheet.txt --output_dir /path/to/your/output/folder/
```

---

## Validate the Configuration

- Test the configuration using a dry run. A dry run is a way to test your pipeline configuration and workflow logic without actually executing any commands or processing any data. It allows you to identify issues in the pipeline setup, such as missing input files, incorrect paths, or misconfigured parameters, before starting the actual analysis.

**Dry Run for Test Profile:**

```{bash}
nextflow run /fsx/nf-lly-human-gsnap-rnaseq/repo/pipeline/main.nf -profile test,slurm,singularity --output_dir /path/to/your/output/folder/ --dry-run
```

**Dry Run for Custom Samples:**

```{bash}
nextflow run /fsx/nf-lly-human-gsnap-rnaseq/repo/pipeline/main.nf -profile slurm,singularity --sample_sheet /path/to/your_custom_samplesheet.txt --output_dir /path/to/your/output/folder/ --dry-run
```

---

## Important Runtime Notes and Error Checking

- **Working Directory and Log file:** The Nextflow working directory and `.nextflow.log` file will be generated in the directory where the pipeline is initiated.
- **Avoid Overwrites:** Do not start multiple Nextflow jobs in the same directory simultaneously, as this can overwrite logs and job status files.

To view logs of previous runs, use:

```bash
nextflow log
```

This command provides a summary of all Nextflow commands executed in the current directory, including runtime details and success or failure status.

---
