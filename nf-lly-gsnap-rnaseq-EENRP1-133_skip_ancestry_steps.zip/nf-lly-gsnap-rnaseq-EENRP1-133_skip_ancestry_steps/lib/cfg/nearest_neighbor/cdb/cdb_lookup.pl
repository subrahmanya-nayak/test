#!/usr/bin/env perl
#===============================================================================
#
#         FILE:  cdb_lookup.pl
#
#        USAGE:  ./cdb_lookup.pl
#
#  DESCRIPTION:  Look up a bunch of keys in a cdb database and dumpt the
#  results.
#
#      OPTIONS:  ---
# REQUIREMENTS:  ---
#         BUGS:  ---
#        NOTES:  ---
#       AUTHOR:  John Calley
#      VERSION:  0.01
#      CREATED:  11/04/08 14:32:39 EST
#     REVISION:  ---
#     REVISION HISTORY:
#   0.10 John Calley 2/17/22
#     --Added -q
#   0.09 John Calley 11/2/18
#     --Removed support for KyotoCabinet
#   0.08 John Calley 3/18/15
#     --Added -l.
#   0.07 John Calley 7/18/13
#     -To increase uniformity with cdb_index.pl switched the cdbindex type
#      determination from command line arguments to the index extension.
#     -Added support for KyotoCabinet indices (thanks very much due to Adam
#     West for this!).
#   0.06 John Calley 6/26/12
#     -output was defaulting to stderr instead of stdout. Fixed this.
#   0.05 John Calley 1/26/11
#     -Added support for indirect indices (using -M).
#   0.04 John Calley and Jeff Arnold 3/16/10
#     -Switched to multi_get to retrieve non-one-one mappings.
#   0.03 John Calley and Jeff Arnold 11/19/09
#     -Fixed a fatal bug that we must have introduced with the last edit.
#   0.02 John Calley 9/3/09
#     -Changed id file input to be via -i and allowed ids on the command
#      line.
#===============================================================================


#TODO
#   Implement a way to dump all content.
use strict;
use warnings FATAL => 'all';

use CDB_File;
use Getopt::Std;
#use KyotoCabinet;
use Compress::Raw::Zlib;


our ($opt_q, $opt_o, $opt_x, $opt_i, $opt_l);

my $usage = <<"END_USAGE";
$0 [-o out] -x idx [-q] [-l #] [-i id_fn] [id1 id2 ...]

[-o out]     Output file. Defaults to stdout.
-x idx       Path to CDB index. Required.
             File extension determines the index type.
                .cdb           --Conventional cdb index
                .icdb          --Index file has offsets into master file which
                                 is identified by having the same name without
                                 the .icdb extension.
                .zcdb          --Conventional cdb index with zlib compressed
                                 values.
                                 NOTE: zcdb is not working right now. Need to look into
                                 this...
[-i id_fn]   Input file of keys, one per line.
[-l #]       For .icdb index, the number of lines to print starting at the
             indicated location. The default is 1.
[-q]         Quiet, don't print ids with no lookups
optional list of ids on the command line.

Look up the indicated keys in the indicated cdb database. Output the key
and the results of the lookup. If there is no match the key will be printed
with nothing else on the line.
Mappings may be multi-valued.
END_USAGE

if (!getopts('o:x:i:l:q')) {
    die "$usage\n\n Illegal arguments.\n";
}
$opt_l ||= 1;

if (!$opt_x) {
    die "$usage\n\n-x is required.\n";
}
my $method;
if ($opt_x =~ m/\.([^.]+)$/) {
    $method = $1;
} else {
    die  "$usage\n"
       . "-o argument must specify indexing method via a legal extension.\n";
}

if ($method eq 'icdb') {
    (my $fn = $opt_x) =~ s/\.icdb//;
    if (!-s $fn) {
        die "$usage\nExpected file $fn. It does not exist.\n";
    }
} elsif ($method ne 'cdb' and $method ne 'zcdb' and $method ne 'kch') {
    die "$usage\n-x argument must specify extension corresponding to one of "
      . "the legal indexing methods.\n";
}

my $db_obj;
my %h;
if ($method ne 'kch') {
    $db_obj = tie %h, 'CDB_File', $opt_x
        or die "Unable to tie to $opt_x. ($!). Stopped";
} else {
    die "KyotoCabinet no longer supported. Stopped";
#    $db_obj = tie %h, 'KyotoCabinet::DB', $opt_x
#        or die "Unable to tie to $opt_x. ($!). Stopped";
}

my @ids = @ARGV;
if ($opt_i) {
    open my $fh, ' < ', $opt_i
      or die "Unable to open file $opt_i for reading ($!). Stopped";
    push @ids, <$fh>;
    close $fh;
}
if (!@ids) {
    die "No ids to look up specified in -i file or on command line.\n";
}

my %missed;
my $out;
if ($opt_o) {
    open $out, ' > ', $opt_o
      or die "Unable to open file $opt_o for writing ($!). Stopped";
}
else {
    $out = *STDOUT;
}

my $mast_fh;
if ($method eq 'icdb') {
    (my $fn = $opt_x) =~ s/\.icdb//;
    open $mast_fh, '<', $fn
       or die "Unable to open $fn for reading ($!). Stopped";
}
my $d;
if ($method eq 'zcdb') {
    $d = new Compress::Raw::Zlib::Inflate()
       or die "Unable to create inflation object ($!). Stopped";
}


foreach my $id (@ids) {
    $id =~ s/^\s+|\s+$//g;
    if ($method eq 'kch') {
        my $res = $h{$id};
        $res =~ s/~~/<<<<<<>>>>>/g; #BAD: relying on this string never appearing.
        $res =~ s/~/\t/g;
        $res =~ s/<<<<<<>>>>>/~/g;
        print {$out} "$id\t$res\n";
    } else {
        my @res = @{$db_obj->multi_get($id)};
        if (!@res) {
            $missed{$id} = 1;
        } elsif ($method eq 'cdb') {
            foreach my $result (@res) {
                print {$out} "$id\t$result\n";
            }
        }
        elsif ($method eq 'icdb') {
            foreach my $pos (@res) {
                seek $mast_fh, $pos, 0 
                   or die "Unable to seek to $pos ($!). Stopped";
                my $cnt = 0;
                while (defined (my $line = <$mast_fh>) and $cnt <= $opt_l) {
                    print {$out} "$line";
                    $cnt++;
                }
            }
        } elsif ($method eq 'zcdb') {
            foreach my $result (@res) {
                my $uncompressed;
                my $status = $d->inflate($result, $uncompressed);
                if ($status == Z_OK) {
                    print {$out} "$id\t$uncompressed\n";
                } else {
                    warn "ZLib inflation error $status on key $id $uncompressed ... \n";
                }
            }
        }
    }
}
if (!$opt_q) {
    foreach my $id (keys %missed) {
        print {$out} "$id\n";
    }
}
