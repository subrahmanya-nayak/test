#!/usr/bin/env perl
use strict;
use warnings FATAL => 'all';

#Revision History:
#  John Calley v 0.02 Mar-27-2007
#     -Modified so that it can read from stdin or a file

#Helper script to read a tab delimited file where the first column
#is a key and the rest of the line is the data and encode it for
#input into cdbmake. This is the same as 12tocdbm except that it
#works when the data has internal tabs.

while (my $line = <>) {
    chomp $line;
    my ($key, $data) = split(/\t/, $line, 2);
    print '+'.length($key) . ',' . length($data) .':' . "${key}->${data}\n";
}
print "\n";
