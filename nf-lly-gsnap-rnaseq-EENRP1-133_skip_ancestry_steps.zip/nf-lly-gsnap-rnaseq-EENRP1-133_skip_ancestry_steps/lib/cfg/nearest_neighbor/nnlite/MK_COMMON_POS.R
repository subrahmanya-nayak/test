#-------
# Input
#-------
args <- unlist(strsplit(unlist(commandArgs()), " "))
n0 <- 3
MODE <- args[n0+1]
FileList1= args[n0+2]
if (MODE=='ONE'|MODE=='One'|MODE=='one') 
{
  FileList2=NULL 
} else 
{
  FileList2=args[n0+3]
}

Header=TRUE

#----------------
# WD and Package
#----------------
WD <- './'
PACKAGE <- '/lrlhps/users/C137551/2013/NN/Nearest_Neighbor/NN2/'

#---------------------
# Predfined functions
#---------------------
setwd(WD)
source(paste(PACKAGE,'Toolbox/general.R', sep=''))

#----------------------------------
# Make quant file on the positions
#----------------------------------
inputfile <- fact.char(read.table(FileList1, header=FALSE))[,1]
if (!is.null(FileList2)) {
   morefile <- fact.char(read.table(FileList2, header=FALSE))[,1]
   inputfile <- c(inputfile, morefile)
}

#chr order
chro = paste("chr", c(1:22, "X", "Y"), sep="")

#first read one file 
rawData <- read.table(file=inputfile[1], sep="\t", header=Header, stringsAsFactors=FALSE, check.names=FALSE)
chr <- rawData[,1]
pos <- rawData[,2]
#


for (i in 2:length(inputfile))
{ 
  id.dr = NULL
  rawData <- read.table(file=inputfile[i], sep="\t", header=Header, stringsAsFactors=FALSE, check.names=FALSE)
  for (j in 1:length(chro)) {
     id <- which(chr==chro[j])
     idraw <- which(rawData[,1]==chro[j])
     if (length(id)>0) {
        pos1 <- pos[id]
        if (length(idraw)>0) {
           posRaw <- rawData[idraw, ]
           mth <- match(pos1, posRaw)
           id.na <- which(is.na(mth))
           if (length(id.na)>0) id.dr <- c(id.dr, id.na)
        } else {
           id.dr = c(id.dr, id)
        }
     }
  } 
  if (!is.null(id.dr)) {
     chr <- chr[-id.dr]
     pos <- pos[-id.dr]
  }
}

POS <- data.frame(chr, pos)
filePos = PosList.csv
write.csv(POS, file="PosList.csv",row.names=FALSE)


