#-------
# Input
#-------
args <- unlist(strsplit(unlist(commandArgs()), " "))
n0 <- 4
PKG <- args[n0]
MODE <- args[n0+1]
FileList1= args[n0+2]
if (MODE=='ONE'|MODE=='One'|MODE=='one') 
{
  FileList2=NULL 
  POSITION=args[n0+3]
  N=as.numeric(args[n0+4])
} else 
{
  FileList2=args[n0+3]
  POSITION=args[n0+4]
  N=as.numeric(args[n0+5])
}

Header=TRUE

#----
# WD
#----
WD <- './'

#---------------------
# Predfined functions
#---------------------
source(paste(PKG, "general.R", sep=""))

#-----
# Dir 
#-----
STORE <- paste('./', 'TEMP/', sep='')
QUANT1 <- paste(STORE, 'Quant1/', sep='')
if (!is.null(FileList2))
{
  QUANT2 <- paste(STORE, 'Quant2/', sep='')
}
LIST <- paste(STORE, 'List/', sep='')

#----------------------------------
# Make quant file on the positions
#----------------------------------
inputfile <- read.table(FileList1, header=FALSE, stringsAsFactors=FALSE, check.names=FALSE)[,1]
filename <- inputfile
for (i in 1:length(filename)) {
    s = unlist(strsplit(inputfile[i], "/"))
    filename[i]=unlist(strsplit(s[length(s)], "_quant.txt"))
}
inputpos <- read.table(POSITION, sep="\t",header=TRUE, stringsAsFactors=FALSE, check.names=FALSE)
chr <- inputpos[,1]
start <- inputpos[,2]

if (N<=length(inputfile))
{
  id.mth = rep(NA, length(chr))
  input <- inputfile[N]
  NAME <- filename[N]
  rawData <- read.table(file=input, sep="\t", header=Header, stringsAsFactors=FALSE, check.names=FALSE)
  file.tabix <- paste(QUANT1, NAME, '.txt', sep='')
  for (j in 1:nrow(inputpos))
  {
     idm <- which(rawData[,1]==chr[j] & rawData[,2]==start[j])
     if (length(idm)>0) id.mth[j] = idm
  } 
  id.mth = fna(id.mth)
  write.table(rawData[id.mth,], file=file.tabix, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
  print(paste(NAME, 'is done!'))
}


if (!is.null(FileList2))
{
  #----------------------------------
  # Make quant file on the positions
  #----------------------------------
  inputfile <- read.table(FileList2, header=FALSE, stringsAsFactors=FALSE, check.names=FALSE)[,1]
  filename <- inputfile
  for (i in 1:length(filename)) {
      s = unlist(strsplit(inputfile[i], "/"))
      filename[i]=unlist(strsplit(s[length(s)], "_quant.txt"))
  }
  if (N<=length(inputfile))
  {
     id.mth = rep(NA, length(chr))
     input <- inputfile[N]
     NAME <- filename[N]
     rawData <- read.table(file=input, sep="\t", header=Header, stringsAsFactors=FALSE, check.names=FALSE)
     file.tabix <- paste(QUANT2, NAME, '.txt', sep='')
     for (j in 1:nrow(inputpos))
     {
        idm <- which(rawData[,1]==chr[j] & rawData[,2]==start[j])
        if (length(idm)>0) id.mth[j] = idm
     } 
     id.mth = fna(id.mth)
     write.table(rawData[id.mth,], file=file.tabix, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
     print(paste(NAME, 'is done!'))
  }
}

#---------------------
# Copy Used Positions 
#---------------------
write.csv(inputpos, file=paste(LIST, 'Position.csv', sep=''), row.names=FALSE)

