##minimal_finalize_wrapper.R
# John Calley 10/3/14
#   Added removal of rows and columns containing NA to avoid crashes in
#   Xiwen's code. Thanks to Dave Airey for providing the critial R code.
# John Calley 9/12/14
#   Fixed a typo that totally screwed things up. Not sure how I missed this
#   earlier.
# John Calley 9/3/14
#   This is a minor rewrite of Xiwen's Finalize.R so that I can call it
#   directly from the command line in the context of the
#   run_nearest_neighbor.pl script.

args <- unlist(strsplit(unlist(commandArgs(TRUE)), " "))
PKG           <- args[1]
distances_fn  <- args[2]
method_str    <- args[3]
mds_2d_prefix <- args[4]
mds_3d_prefix <- args[5]

source(paste(PKG, "general.R", sep=""))

#-----------
# Summarize
#-----------
Tab = read.table(file=distances_fn, header=TRUE, stringsAsFactors=FALSE, check.names=FALSE,sep="\t")
Methods <- unlist(strsplit(method_str, split="_"))
items <- c("NAME_1", "NAME_2", "SIZE", Methods)
Tab = Tab[,items]

#Xiwen has all pairwise comparisons. I did all unique pairwise comparisons
#(don't do A vs.B if we already have B vs A) so we need to make a few changes
#to deal with this. Also, I didn't bother to compute A vs A so fill in 0s for
#these.
for (i in 1:length(Methods)) {
    vname <- unique(c(Tab[,1],Tab[,2]))
    M <- matrix(NA, length(vname), length(vname), dimnames=list(vname, vname))
    for (j in 1:nrow(Tab)) {
        M[Tab[j,1],Tab[j,2]] <- Tab[j,Methods[i]]
        M[Tab[j,2],Tab[j,1]] <- Tab[j,Methods[i]]
    }
    diag(M) <- 0
    #Remove any rows and columns containing missing values
    not_na_rows <- !rowSums(is.na(M))>0
    not_na_cols <- !colSums(is.na(M))>0
    M = M[not_na_rows,not_na_cols, drop=FALSE]
    vname = vname[not_na_rows]

    Tab2D = MDS.2D.Tab(M, label.a=vname)
    write.table(Tab2D, file=paste(mds_2d_prefix, "_", Methods[i], ".txt", sep=""), sep="\t", row.names=FALSE)
    Tab3D = MDS.3D.Tab(M, label.a=vname)
    write.table(Tab3D, file=paste(mds_3d_prefix, "_", Methods[i], ".txt", sep=""), sep="\t", row.names=FALSE)
}
