###For making basic list
LIST <- list()
LIST[[1]]=WD
LIST[[2]]=PACKAGE
LIST[[3]]=BUILD 
LIST[[4]]=NAME
LIST[[5]]=INPUT1
LIST[[6]]=INPUT2
LIST[[7]]=OUTPUT
LIST[[8]]=REPORT
LIST[[9]]=STORE
LIST[[10]]=POSITION
LIST[[11]]=WEIGHT
LIST[[12]]=method.NGS
LIST[[13]]=variant.type
LIST[[14]]=Threshold
LIST[[15]]=pic.format
LIST[[16]]=indel.del
LIST[[17]]=indel.word
LIST[[18]]=col.warning
LIST[[19]]=col.ref
LIST[[20]]=col.ID
LIST[[21]]=col.start
LIST[[22]]=col.end
LIST[[23]]=nucleotides
LIST[[24]]=HEADER


#Directory
Directory <- ''
#PROGRAM NAME
PROGRAM_NAME = '/lrl/indy/data01/software/R/R_latest'
OPTIONS = '--no-save'
RUNFILE=paste(PACKAGE, 'PairedSample/Analysis.R', sep='')
ARG_NOTE = '--args'
FILE_NOTE = '<'
PROJECT_NOTE = 'NN2'
TABLE <- fact.char(proTab(LIST)) 

clusterLine <- write.cluster(TABLE=TABLE, Directory=Directory, PROGRAM_NAME=PROGRAM_NAME, OPTIONS=OPTIONS, RUNFILE=RUNFILE, ARG_NOTE=ARG_NOTE, FILE_NOTE=FILE_NOTE, PROJECT_NOTE=PROJECT_NOTE, Print=FALSE)
