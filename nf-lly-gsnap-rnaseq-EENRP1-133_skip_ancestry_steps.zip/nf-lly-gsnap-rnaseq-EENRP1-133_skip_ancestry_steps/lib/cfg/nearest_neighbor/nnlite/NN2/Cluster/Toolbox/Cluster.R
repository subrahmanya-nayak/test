###write cluster file
write.cluster <- function(TABLE, Directory, PROGRAM_NAME, OPTIONS, RUNFILE, ARG_NOTE, FILE_NOTE, PROJECT_NOTE, Print=TRUE)
{
  if (length(RUNFILE)==1) RUNFILE <- rep(RUNFILE, nrow(TABLE))
  clusterR <- rep('', nrow(TABLE))
  for (i in 1:nrow(TABLE)) clusterR[i] <- paste(PROGRAM_NAME, OPTIONS, ARG_NOTE, paste(TABLE[i,], collapse=' '), FILE_NOTE, RUNFILE[i], sep=' ')
  file.cluster <- paste(Directory, PROJECT_NOTE, '_', 'cluster', '.cmd', sep='')
  if (Print) write.table(clusterR, file=file.cluster, quote=FALSE, sep='', eol='\n', col.names=FALSE, row.names=FALSE) else
  {
    clusterR
  }
}
