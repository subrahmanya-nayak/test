#--------------
# Handle indel
#--------------
id.indel <- which(sh[,col.warning]==indel.word)
if (length(id.indel)>0) 
{
  id.dr <- NULL
  chr.a.indel <- unique(sh[id.indel, 1])
  for (chr.1 in chr.a.indel)
  { 
    id.indel.chr <- which(sh[id.indel, 1]==chr.1)
    id.chr <- which(sh[,1]==chr.1)
    for (jt in 1:length(id.indel.chr))
    {
      id.chr.dr <- which( abs(sh[id.chr,2]-sh[id.indel[id.indel.chr[jt]],2])<=indel.del )
      id.dr <- c(id.dr, id.chr[id.chr.dr])
    }
  }
  id.dr <- unique(id.dr)
  sh[id.dr, col.start:col.end]=NA
}
