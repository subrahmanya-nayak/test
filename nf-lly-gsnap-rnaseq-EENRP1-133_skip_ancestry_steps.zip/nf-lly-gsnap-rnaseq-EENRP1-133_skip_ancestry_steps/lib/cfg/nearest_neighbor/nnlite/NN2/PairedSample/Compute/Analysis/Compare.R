#-------------
# dir setting
#-------------
thd <- Threshold
thd.angle <- round(thd/pi*180)           #For label purpose
dir.pic.dist <- paste(OUTPUT, 'Distance', '_', thd.angle, '/', sep='')
dir.create(dir.pic.dist)
dir.pic.M <- paste(dir.pic.dist, 'More', '/', sep='')
dir.create(dir.pic.M)
dir.data.pro <- paste(dir.table, 'DataPro', '/', sep='')        #Processed data file
dir.M <- paste(dir.table, 'NN', '/', 'MORE', '/', sep='')

#--------------
# basic setting
#--------------
#file.dist <- paste(dir.M, NAME.RT, '_', variant.type, '_', thd, '_', 'NN', '_', 'V', '.csv', sep='')
#tab.dist <- read.csv2(file.dist)
tab.dist <- Dist
n.r <- nrow(tab.dist)
chr.a <- unique(tab.dist[,1])

#-----------
# Weight
#-----------
w <- tab.dist[,'WEIGHT']/sum(tab.dist[,'WEIGHT'])

#----------------------------------
# picture diagnosis (pairwise Cor)
#----------------------------------
if (PlotDiag)
{
file.pic <- paste(dir.pic.M, NAME.RT, '_', variant.type, '_', method.NGS, '.', pic.format, sep='')
if (pic.format=='jpg') jpeg(file=file.pic, width=width/2, height=height, unit='in', res=res)
if (pic.format=='eps') postscript(file=file.pic, width=width/2, height=height, paper="special", horizontal=TRUE)                                                             
#---Picture------------------
pair2(tab.dist[,Dist.Method])
dev.off()
#----------------------------
}

if (thd>0) Threshold.Label=paste(' (', method.quality, '>=', thd.angle, ')', sep='') else Threshold.Label=''
if (cex.min.gw<cex.max.gw)
{
  if (thd==0) dp.label=c('<=', '=', '>=')
  if (thd>0) dp.label=c('=', '=', '>=')
} else
{
  dp.label=c('>=')
}

ylim <- range(tab.dist[,Dist.Method])
ylim <- c(ylim[1], ylim[2]*5/3)
file.pic <- paste(dir.pic.dist,  NAME.RT,  '_', variant.type, '_', method.NGS, '.', pic.format, sep='')
if (pic.format=='jpg') jpeg(file=file.pic, width=width, height=height*2/3, unit='in', res=res)
if (pic.format=='eps') postscript(file=file.pic, width=width, height=height*2/3, paper="special", horizontal=TRUE)
for (i in 1:length(Dist.Method))
{
  if (i==1) new=1 else new=0 
  thetaPlot(chr=tab.dist[,1], pos=tab.dist[,2], theta=tab.dist[,Dist.Method[i]], depth=w, gap=1/3.5, name.depth='WEIGHT', xlab='', ylab=paste('Distance', sep=''), ylim=ylim, new=new, las=2, type='p', lty=lty[i], col=col[i], pch=pch[i], output='Raw', dp.min=dp.min, dp.max=dp.max, cex.min=cex.min.gw, cex.max=cex.max.gw, dp.label=dp.label,
  main=paste(NAME, ' ',  method.NGS, ' ', variant.type, Threshold.Label,  sep=''))
}
legend('topleft', legend=Dist.Method, col=col, pch=pch, ncol=2, bty='n')
dev.off()

