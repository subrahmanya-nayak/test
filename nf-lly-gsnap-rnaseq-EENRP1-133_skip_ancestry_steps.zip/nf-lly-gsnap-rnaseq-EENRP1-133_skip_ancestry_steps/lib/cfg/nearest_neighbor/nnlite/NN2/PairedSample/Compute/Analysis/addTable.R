#---------------------------------
# Make stat table from quantfile
#---------------------------------
num.allele <- rep(0,n)
id.NGS <- col.start:col.end
M.NGS <- sh[,id.NGS]                         #Reads Matrix
M.NGS[M.NGS<Read.Thd]=0
num.call <- apply(M.NGS,1,function(x){sum(x>0)})                                 #Number of 
REMARK[which(num.allele>2)] = 'MULTI_ALLELE!' 
SCORE <- apply(M.NGS, 1, sum)
sh[,id.NGS] <- M.NGS
sh <- data.frame(sh, SCORE, REMARK)