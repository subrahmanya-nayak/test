#---------------
# Cluster Input
#---------------
#args <- unlist(strsplit(unlist(commandArgs()), " "))
#n0 <- 3
#WD <- args[n0+1]
#PACKAGE <- args[n0+2]
BUILD <- as.numeric(args[n0+3])
#NAME.RT <- args[n0+4]
#INPUT.A  <- c(args[n0+5], args[n0+6])
OUTPUT.RT <- args[n0+7]
REPORT <- args[n0+8]
STORE.RT <- args[n0+9]
POSITION <- args[n0+10]
WEIGHT <- args[n0+11]
method.NGS <- args[n0+12]
variant.type <- args[n0+13]
Threshold <- as.numeric(args[n0+14])
pic.format <- args[n0+15]
indel.del <- as.numeric(args[n0+16])
indel.word <- args[n0+17]
col.warning <- as.numeric(args[n0+18])                                             # Warning column, leave 100 if no warning
col.ref <- as.numeric(args[n0+19])                                                 # Reference column
col.ID <- as.numeric(args[n0+20])                                                  # ID SNPs id column
col.start <- as.numeric(args[n0+21])                                               # Reads start column following A, C, G, T
col.end <- as.numeric(args[n0+22])                                                 # Reads end column
nucleotides <- unlist(strsplit(args[n0+23], split='_'))
header.input <-  unlist(strsplit(args[n0+24], split='-'))

#-------------
# dir setting
#-------------
NAME <- unlist(strsplit(NAME.RT, split='---'))
OUTPUT <- OUTPUT.RT
STORE <- STORE.RT
#setwd(WD)
dir.create(OUTPUT, recursive = TRUE)
dir.create(REPORT, recursive = TRUE)
dir.create(STORE, recursive = TRUE)
#PDF <- paste(STORE, 'PDF/', sep='')
#dir.create(PDF)
dir.table <- paste(STORE, 'Table', '/', sep='') 
dir.create(dir.table)
###

#-----------------------
# Predefined functions
#-----------------------
#source(paste(PACKAGE, 'Toolbox/general.R', sep=''))
#sourceDir(paste(PACKAGE, 'Toolbox/', sep=''))

#----------------
# General Input
#----------------
name.a <- c(grab.name(INPUT.A[1]), grab.name(INPUT.A[2]))    # Names for computation tables 
method.quality <- 'coverage'                           
Read.Thd <- 6                                                # Third allele number threshold
Dist.Thd <- 0                                                # Threshold in the distance
Dist.Method <- c('Manh', 'KL', 'HE', 'Chi2')                 # Distance metrics
epsilon <- 1e-10                                             # If zero distance between different sample then add a small value
WriteTab <- FALSE                                            # If tables are generated
WriteDist <- FALSE                                           # If distance table is generated
WriteReport <- FALSE                                         # If the final table is generated
PlotDist <- FALSE                                            # If pictures are generated
PlotDiag <- FALSE                                            # If diagnosis plot (correlation) is generated
chr.order <- paste('chr', c(1:22, 'X', 'Y'), sep='')
header = rep(TRUE,2)
for (i in 1:2) if (header.input[i]=='F') header[i]=FALSE
header.pos <- TRUE

#-----------------
# plot parameters
#-----------------
dp.min=0
dp.max=1
cex.min.gw=0.2                        #Genome wide
cex.max.gw=0.2
lty <- 1:4         
col <- c('blue', 'purple', 'red', 'darkgrey')
pch <- 1:4
width=16   
height = width/2 
res=100

###begin the work
sh.pro <- list()
for (i in 1:2) 
{
  INPUT <- INPUT.A[i]
  name.1 <- name.a[i]
  header.1 <- header[i]
  source(paste(PACKAGE, 'PairedSample/Compute/Analysis/InitialSetup.R', sep=''))           #Basic calculation
  sh.pro[[i]]=sh
}

source(paste(PACKAGE, 'PairedSample/Compute/Analysis/Pairing.R', sep='')) 
sh.p=sh.p

source(paste(PACKAGE, 'PairedSample/Compute/Analysis/NN.R', sep=''))                        #NN calculation 
Dist=Dist

if (PlotDist) source(paste(PACKAGE, 'PairedSample/Compute/Analysis/Compare.R', sep=''))                   #NN plot 
