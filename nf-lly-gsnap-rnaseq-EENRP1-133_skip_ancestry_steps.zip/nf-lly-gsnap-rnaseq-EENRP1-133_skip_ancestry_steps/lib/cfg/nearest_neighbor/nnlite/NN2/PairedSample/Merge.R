#-------
# Start
#-------
METHODS = args[n0+3]
QC = args[n0+4]

#-------------
# Setting Dir
#-------------
dir.table <- paste(STORE, 'Table', '/', sep='') 
dir.NN <- paste(dir.table, 'NN', '/', sep='')

#--------------
# Some paras
#--------------
variant.type = 'All'
thd = 0
Dist.Method = unlist(strsplit(METHODS, split="_"))
Num.NN <- 10

#-------
# Start
#-------
NAMES <- rep('', N)
for (i in 1:N) NAMES[i] = grab.name(INPUTS[i])

#-------------------------------------------
# Calculate the first one and define report
#-------------------------------------------
ia=1
NAME.ONE = NAMES[ia]
file.tab <- paste(dir.NN, NAME.ONE, '_', variant.type, '_', thd, '_', 'NN', '.csv', sep='')
Report.1 <- read.csv2(file.tab)    
Report <- repTab(Report.1, nrow(Report.1)*N)


Summary_name <- data.frame(matrix('', N, length(Dist.Method)*Num.NN))
Summary_dist <- data.frame(matrix(0, N, length(Dist.Method)*Num.NN))
names(Summary_name) <- paste(rep(Dist.Method, each=Num.NN), '_',  rep(1:Num.NN, length(Dist.Method)), '_', 'NAME', sep='')
names(Summary_dist) <- paste(rep(Dist.Method, each=Num.NN), '_',  rep(1:Num.NN, length(Dist.Method)), '_', 'DIST', sep='')
Summary_name <- fact.char(Summary_name)
Summary_dist <- fact.char(Summary_dist)

#-----------------------------
# Merge for all
#-----------------------------
st=ed=0
for (ia in 1:N)
{ 
  st=ed+1
  NAME.ONE <- NAMES[ia]
  file.tab <- paste(dir.NN, NAME.ONE, '_', variant.type, '_', thd, '_', 'NN', '.csv', sep='')
  Report.1 <- read.csv2(file.tab)  
  ed <- st+nrow(Report.1)-1
  Report[st:ed,]=Report.1
  
  for (ja in 1:length(Dist.Method))
  {
    ord <- order(Report.1[,Dist.Method[ja]])
    Summary_name[ia, ((ja-1)*Num.NN+1):(ja*Num.NN)] <- Report.1[ord[1:Num.NN], 2]
    Summary_dist[ia, ((ja-1)*Num.NN+1):(ja*Num.NN)] <- Report.1[ord[1:Num.NN], Dist.Method[ja]]
  }
  print(ia)
}

Summary <- data.frame(Summary_name, Summary_dist)
ncol.sr <- length(Dist.Method)*Num.NN
col.ord <- 1:(2*ncol.sr)
for (io in 1:Num.NN)
{
  col.ord[ (io-1)*(2*length(Dist.Method)) + 1:length(Dist.Method) ] = io+(1:length(Dist.Method)-1)*Num.NN
  col.ord[ (io-1)*(2*length(Dist.Method)) + 1:length(Dist.Method) + length(Dist.Method) ] = ncol.sr + io + (1:length(Dist.Method)-1)*Num.NN
}

Summary <- Summary[,col.ord]
SAMPLE <- NAMES
Summary <- data.frame(SAMPLE, Summary)
Summary <- fact.char(Summary)

file.tab <- paste(REPORT, NAME.ANALYSIS, '_', 'Distance', '_', variant.type, '_', thd, '_', 'NN', '.csv', sep='')
write.csv(Report, file=file.tab, row.names=FALSE)

file.smy <- paste(REPORT, NAME.ANALYSIS, '_', 'Summary', '_', variant.type, '_', thd, '_', 'NN', '_', paste(Dist.Method, collapse='_'), '.csv', sep='')
write.csv(Summary, file=file.smy, row.names=FALSE)


if (QC=='Yes'|QC=='YES')
{
  #----
  # QC 
  #----
  col.dist.st=7
  col.dist.ed=10
  DIST <- Report[,col.dist.st:col.dist.ed] 
  file.pic <- paste(OUTPUT, NAME.ANALYSIS, '_', 'QC.jpg', sep='')
  jpeg(file.pic, width=15, height=15, unit='in', res= 200)
  pair2(DIST)
  dev.off()
}
