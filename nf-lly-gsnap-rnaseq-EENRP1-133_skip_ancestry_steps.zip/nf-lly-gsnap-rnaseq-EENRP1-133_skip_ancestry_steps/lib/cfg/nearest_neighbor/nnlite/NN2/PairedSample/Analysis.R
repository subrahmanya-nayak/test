#----------------------------------
# Cluster Input and make iteration
#----------------------------------
args <- unlist(strsplit(unlist(commandArgs()), " "))
n0 <- 3
WD <- args[n0+1]
PACKAGE <- args[n0+2]
i.ONE <- as.numeric(args[n0+4])
QuantList1 <- args[n0+5]
QuantList2 <- args[n0+6]


#-----------------
# Set working dir
#-----------------
setwd(WD)

#-----------------------
# Predefined functions
#-----------------------
source(paste(PACKAGE, 'Toolbox/general.R', sep=''))
sourceDir(paste(PACKAGE, 'Toolbox/', sep=''))

#-------------------------------------------
# Read List1 file and get left sample name
#-------------------------------------------
List.ONE <- read.table(file=QuantList1, sep='\t', header=FALSE)
INPUTS.ONE <- fact.char(List.ONE)[,1]
NAME.ONE <- grab.name(INPUTS.ONE[i.ONE])
INPUT.ONE <- INPUTS.ONE[i.ONE]

#-------------------------------------------
# Read List2 file and get right sample names
#-------------------------------------------
List <- read.table(file=QuantList2, sep='\t', header=FALSE)
INPUTS <- fact.char(List)[,1]
N <- length(INPUTS)
NAMES <- as.character(sapply(INPUTS, grab.name))

#-------------------------------------------
# Calculate the first one and define report
#-------------------------------------------
ia=1
NAME.TWO <- NAMES[ia]
NAME.RT <- paste(NAME.ONE, NAME.TWO, sep='---')
INPUT.TWO <- INPUTS[ia]
INPUT.A <- c(INPUT.ONE, INPUT.TWO)
source(paste(PACKAGE, 'PairedSample/Analysis_One.R', sep=''))                   
Report <- repTab(report.nn, nrow(report.nn)*N)
print(ia)

#-----------------------------
# Calculate for other sample
#-----------------------------
for (ia in 1:N)
{
  NAME.TWO <- NAMES[ia]
  NAME.RT <- paste(NAME.ONE, NAME.TWO, sep='---')
  INPUT.TWO <- INPUTS[ia]
  INPUT.A <- c(INPUT.ONE, INPUT.TWO)
  source(paste(PACKAGE, 'PairedSample/Analysis_One.R', sep=''))  
  Report[ia,]=report.nn
  print(ia)
}

file.tab <- paste(dir.NN, NAME.ONE, '_', variant.type, '_', thd, '_', 'NN', '.csv', sep='')
write.csv(Report, file.tab, row.names=FALSE)

