chr.a <- unique(sh[,1])
id.mth <- match(chr.order, chr.a)
chr.a <- chr.order[!is.na(id.mth)]
id.a <- 1:nrow(sh)
st=1
for (chr.1 in chr.a)
{ 
  id.1 <- which(sh[,1]==chr.1)
  id.a[st:(st+length(id.1)-1)]=id.1[order(sh[id.1, 2])]
  st <- st+length(id.1)
}
sh <- sh[id.a,]