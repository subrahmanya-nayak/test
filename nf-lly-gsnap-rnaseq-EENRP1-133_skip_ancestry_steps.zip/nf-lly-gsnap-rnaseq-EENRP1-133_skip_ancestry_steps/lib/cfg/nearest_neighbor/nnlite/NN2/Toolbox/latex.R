#--------------
# Pic writer
#--------------
# filename:                   vector of filenames
# width:                      width of each picture
# height:                     height of each picture
# angle:                      angle of picture
# center:                     center or not
# caption:                    caption of picture
# label:                      label of picture
# m:                          number of picture on each row
# space:                      space between pictures on each row
latex.pic <- function(filename, width, height, angle=NULL, center=TRUE, caption=NULL, label=NULL, m=1, space='')
{
  n.pic <- length(filename)
  n <- floor(n.pic/m)
  if (n*m<n.pic) n<-n+1 
  pic <- '\\begin{figure}[htbp]'
  if (center) pic <- c(pic, '\\begin{center}')
  count <- 0
  if (is.null(angle)) pic.option <- paste('\\includegraphics[width=', width, 'in,height=', height, 'in]', sep='') else pic.option <- paste('\\includegraphics[width=', width, 'in,height=', height, 'in, angle=', angle, ']', sep='')
  for (i in 1:n) 
  {
    pic.1 <- NULL
    for (j in 1:m)
    {
      count <- count+1
      if (count<=n.pic)
      pic.1 <- paste(pic.1, space, pic.option, '{', filename[count], '}', sep='')
      if (j==m & i<n) pic.1 <- paste(pic.1, '\\', '\\', sep='')
    } 
    pic <- c(pic, pic.1)
  }
  if (center) pic <- c(pic, '\\end{center}')
  if (!is.null(caption)) 
  {
    caption <- paste('\\caption{', caption, '}', sep='')
    if (!is.null(label)) caption <- paste(caption, '\\label{', label, '}', sep='')
    pic <- c(pic, caption)
  }
  pic <- c(pic, '\\end{figure}')
  pic
}


