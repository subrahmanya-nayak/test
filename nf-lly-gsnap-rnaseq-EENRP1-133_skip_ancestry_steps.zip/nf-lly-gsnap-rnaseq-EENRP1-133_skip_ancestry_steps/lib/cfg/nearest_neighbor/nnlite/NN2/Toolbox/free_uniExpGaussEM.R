uniExpGaussEM <- function(x, init.lambda.l=NULL, min.l=-Inf, init.lambda.r=NULL, max.r=Inf, init.mean, init.var, init.prop, max.iter=20, loglik.tol=0.01, min.prop=0, min.var=0.01, max.var=0.03, max.lambda=1, mean.tol = Inf){
# -------------------------------------------------------------------------------------------------------------------------------------
# Function to estimate the parameters for an Exponential + Gaussian mixture model using the EM algorithm for univariate data. 
# Exponential functions are placed at either 0 or pi/4 or both or none with an optional number of Gaussian's in between. Number of exponential components depends on the input initial value.
# Function is fairly specific to the Loss of Heterozygosity application.
#
# x:			vector of data
# init.lambda.l:	initial estimate of the left exponential distribution parameter. If omitted, left exponential distribution will not exist.
# init.lambda.r:	initial estimate of the right exponential distribution parameter. If omitted, right exponential distribution will not exist.
# min.l           minimum value for left exponential distribution, use for calculating density
# max.r           maximum value for right exponential distribution, use for calculating density
# mean:		vector of initial mean values (length = # Gaussian components in mixture)
# var:		vector of initial variance values (length = # Gaussian components in mixture)
# prop:		vector of initial mixing proportions for each distribution (length = # components in mixture)
# max.iter:		maximum number of iterations to allow
# loglik.tol:	convergence declared when |(loglik[i+1] - loglik[i])| / loglik[i] <= loglik.tol
# min.prop:	      the minimum proportion allowed to be multiple normal distribution.
# min.var:		the minimum Gaussian variance to allow (quick way to avoid Inf likelihood cases with var=0)
# max.var:		maximum allowed variance since we know so much about these data
# max.lambda:	the maximum Exponential lambda to allow (quick way to avoid lambda-->Inf)
# mean.tol:	      the estimated mean must be +/- this tolerance of the initial value since we have a strong prior on this value
#
# Outputs:
# gamma:		matrix of responsibilities for the N data values (rows) and the G Gaussian mixtures (columns)
# lambda:		vector of final lambda estimates
# mean:		final estimate of the mean for each Gaussian component
# var:		final estimate of the variance for each Gaussian component
# prop:		mixing proportions
# loglik:		log likelihood for the model
# BIC:		BIC (note it's written such that you should seek to maximize the BIC)
# num.params:	Number of independent parameters estimated in model
# loglik.hist:	Iteration history of the log likelihood
# --------------------------------------------------------------------------------------------------------------------------------------
  e <- length(c(init.lambda.l, init.lambda.r))
  g <- length(init.mean)				# Number of Gaussian's in mixture
  G <- g + e						# Number of component densities in mixture
  N <- length(x)						# Number of data points
  num.params <- e + g * 2 + (G - 1) 		# Used for BIC, parameter = Exponential paramter + Gaussian parameter + Mixture weight
  est.gamma <- matrix(0, nrow=N, ncol=G)		# Responsibilities
  if (is.null(init.lambda.l)) gstart <- 1 else  # Start column in est.gamma of Gaussian
     gstart <- 2
  est.lambda.l <- init.lambda.l                 # Updated rate estimate of left exponential distributions
  est.lambda.r <- init.lambda.r                 # Updated rate estimate of exponential distributions
  est.mean <- init.mean					# Updated estimate of the g Gaussian means
  est.var <- init.var					# Updated estimate of the g Gaussian variances
  est.prop <- init.prop					# Updated estimate of the G mixing proportions
  est.prop <- est.prop / sum(est.prop)		# Make sure the proportions sum to one
  done.iter <- FALSE					# Boolean to control iterations
  iter.count <- 0						# Iteration counter
  loglik.hist <- rep(NA,max.iter)			# Vector of log likelihood values over the iterations
  log.lik <- 0						# The final log likelihood from iterating (should match last element of loglik.hist)
  BIC <- 0							# The final BIC from iterating
  pi1.x <- x - min.l                            # Transformed x[] to be used for the left-most exponential distribution
  pi2.x <- max.r - x					# Transformed x[] to be used for the right-most exponential distribution

  while (! done.iter){
    # -----------------------------------------------
    # Compute the responsibilities (Expectation Step)
    # -----------------------------------------------
    
    for(i in 1:N){
      gamma.sum=0
      if (!is.null(est.lambda.l)) gamma.sum <- gamma.sum + est.prop[1] * dexp(pi1.x[i], rate=est.lambda.l)
      if (!is.null(est.lambda.r)) gamma.sum <- gamma.sum + est.prop[G] * dexp(pi2.x[i], rate=est.lambda.r)
      if (g > 0){
        for(j in 1:g){
          gamma.sum <- gamma.sum + est.prop[j+gstart-1] * dnorm(x[i], mean=est.mean[j], sd=sqrt(est.var[j]))
        }
      }

      if (!is.null(est.lambda.l)) est.gamma[i,1] <- est.prop[1] * dexp(pi1.x[i], rate=est.lambda.l) / gamma.sum
      if (!is.null(est.lambda.r)) est.gamma[i,G] <- est.prop[G] * dexp(pi2.x[i], rate=est.lambda.r) / gamma.sum
      if (g > 0){
        for (j in 1:g){
          est.gamma[i,j+gstart-1] <- est.prop[j+gstart-1] * dnorm(x[i], mean=est.mean[j], sd=sqrt(est.var[j])) / gamma.sum
        }
      }
    }

    # -------------------------------------------------------------------------------------
    # Compute the weighted means & variances and the mixing proportions (Maximization Step)
    # -------------------------------------------------------------------------------------
    if (!is.null(est.lambda.l)) est.lambda.l <- min(max.lambda, 1 / (sum(est.gamma[,1] * pi1.x) / sum(est.gamma[,1])))
    if (!is.null(est.lambda.r)) est.lambda.r <- min(max.lambda, 1 / (sum(est.gamma[,G] * pi2.x) / sum(est.gamma[,G])))
    if (!is.null(est.lambda.l)) est.prop[1] <- mean(est.gamma[,1])
    if (!is.null(est.lambda.r)) est.prop[G] <- mean(est.gamma[,G])

    if (g > 0){
      for(j in 1:g){
        if (sum(est.gamma[,j+gstart-1]) > 0){
          est.mean[j] <- sum(est.gamma[,j+gstart-1] * x) / sum(est.gamma[,j+gstart-1])
          est.var[j] <-  sum(est.gamma[,j+gstart-1] * (x - est.mean[j])^2) / sum(est.gamma[,j+gstart-1])

          # -----------------------      
          # Bound the mean estimate
          # -----------------------
          if (est.mean[j] < init.mean[j]-mean.tol){
            est.mean[j] <- init.mean[j]-mean.tol
          }
          if (est.mean[j] > init.mean[j] + mean.tol){
            est.mean[j] <-  init.mean[j] + mean.tol         
          }

          # ---------------------------
          # Bound the variance estimate
          # ---------------------------
          if (est.var[j] < min.var){
            est.var[j] <- min.var
          }
          if (est.var[j] > max.var){
            est.var[j] <- max.var
          }

          tmp.prop <- mean(est.gamma[,j+gstart-1])
        }
        else{
          tmp.prop <- 0
        }

        est.prop[j+gstart-1] <- tmp.prop

      } # foreach Gaussian in the middle
    } # if we have Gaussians in the middle
    
    est.prop <- est.prop / sum(est.prop)

    # ---------------------------------
    # Estimate the log likelihood & BIC
    # ---------------------------------

    log.lik <- 0
    for(i in 1:N){
      tmp.sum <- 0
      if (!is.null(est.lambda.l)) tmp.sum <- est.prop[1] * dexp(pi1.x[i], rate=est.lambda.l)
      if (!is.null(est.lambda.r)) tmp.sum <- tmp.sum + est.prop[G] * dexp(pi2.x[i], rate=est.lambda.r)

      if (g >= 1) for (j in 1:g)
      {
        tmp.sum <- tmp.sum + est.prop[j+gstart-1]*dnorm(x[i], mean=est.mean[j], sd=sqrt(est.var[j]))
      }

      log.lik <- log.lik + log(tmp.sum)
    }

    BIC <- 2 * log.lik - num.params * log(N)
    iter.count <- iter.count + 1
    loglik.hist[iter.count] <- log.lik

    # ------------------------
    # Determine if we are done
    # ------------------------
    if (iter.count >= max.iter){
      done.iter <- TRUE
    }
    if (iter.count > 1){
      if ((abs(loglik.hist[iter.count - 1] - loglik.hist[iter.count]) / abs(loglik.hist[iter.count - 1])) <= loglik.tol){
        done.iter <- TRUE
      }
    }
  } # while converging loop

  loglik.hist <- loglik.hist[!is.na(loglik.hist)] 

  if (iter.count >= max.iter) doneEM <- FALSE else doneEM <- TRUE

  #-------------------------
  # Proportion threshold
  #-------------------------

  est.prop.G <- est.prop[gstart:(gstart+g-1)]
  r.G <- est.prop.G/sum(est.prop.G) 
  r.G[r.G<min.prop]=0
  est.prop.G <- r.G/sum(r.G)*sum(est.prop.G)
  est.prop[gstart:(gstart+g-1)] <- est.prop.G             # filter the small Gaussian component
  est.prop <- est.prop / sum(est.prop)
  #---------------------------------------
  # Re-Estimate the log likelihood & BIC
  #---------------------------------------
  log.lik <- 0
  for(i in 1:N){
    tmp.sum <- 0
    if (!is.null(est.lambda.l)) tmp.sum <- est.prop[1] * dexp(pi1.x[i], rate=est.lambda.l)
    if (!is.null(est.lambda.r)) tmp.sum <- tmp.sum + est.prop[G] * dexp(pi2.x[i], rate=est.lambda.r)

    if (g >= 1) for (j in 1:g)
    {
      tmp.sum <- tmp.sum + est.prop[j+gstart-1]*dnorm(x[i], mean=est.mean[j], sd=sqrt(est.var[j]))
    }

    log.lik <- log.lik + log(tmp.sum)
  }

  BIC <- 2 * log.lik - num.params * log(N)
  iter.count <- iter.count + 1
  loglik.hist[iter.count] <- log.lik


  #--------------------------
  # Density function
  #--------------------------
   denfun <- function(xr)            
  {
    if (sum(xr < min.l)>0 | sum(xr > max.r)>0) stop('Error: out of range')
    tmp.sum <- rep(0, length(xr))
    if (!is.null(est.lambda.l)) tmp.sum <- est.prop[1] * dexp(xr-min.l, rate=est.lambda.l)
    if (!is.null(est.lambda.r)) tmp.sum <- tmp.sum + est.prop[G] * dexp(max.r-xr, rate=est.lambda.r)

    if (g >= 1) for (j in 1:g)
    {
      tmp.sum <- tmp.sum + est.prop[j+gstart-1]*dnorm(xr, mean=est.mean[j], sd=sqrt(est.var[j]))
    }
    tmp.sum
  }

  #--------------------------
  # c.d.f function
  #--------------------------
  cdfun <- function(xr)            
  {
    if (sum(xr < min.l)>0 | sum(xr > max.r)>0) stop('Error: out of range')
    tmp.sum <- rep(0, length(xr))
    if (!is.null(est.lambda.l)) tmp.sum <- est.prop[1] * pexp(xr-min.l, rate=est.lambda.l)
    if (!is.null(est.lambda.r)) tmp.sum <- tmp.sum + est.prop[G] * (1-pexp(max.r-xr, rate=est.lambda.r))

    if (g >= 1) for (j in 1:g)
    {
      tmp.sum <- tmp.sum + est.prop[j+gstart-1]*pnorm(xr, mean=est.mean[j], sd=sqrt(est.var[j]))
    }
    tmp.sum
  }

 
  # -------
  # Outputs
  # -------
  out <- list(gamma		=	est.gamma,
              lambda.l		=	est.lambda.l,
              lambda.r        =     est.lambda.r,
              mean		=	est.mean,
              var			=	est.var,
              prop		=	est.prop,
              loglik		=	log.lik,
              BIC			=	BIC,
		  num.params	=	num.params,
              loglik.hist	= 	loglik.hist,
              doneEM          =     doneEM,
              niter           =     iter.count,
              denfun          =     denfun,
              cdfun           =     cdfun)
  out
}