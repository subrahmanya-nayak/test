library(Hmisc)
library(lars)

##quality score
##quality = 'variance', '50_percent'
qscore.temp <- function(a, b, quality='variance') {
  n=a+b
  p.a <- a/n
  p.b <- b/n
  if (quality=='variance') q <- sqrt(n*p.a*p.b)
  if (quality=='50_percent')  q <- prop.test(a,n, 1/2)$p.value
  q
}

##quality score lower tail
##quality = 'lower.tail'

qscore.temp2 <- function(alt, ref, ratio, quality='lower.tail') {
  n=ref+alt
  if (quality=='lower.tail') q <- pbinom(alt, n, ratio)
  q
}

##quality score 
##method = 'wilson', stat='ratio' or 'lower'

qscore <- function(alt, ref, alpha=0.02, method='wilson', stat='lower') 
{
  if (!is.na2(alt) & !is.na2(ref))  
  {
    n=ref+alt
    ci <- binconf(alt, n, alpha=alpha, method=method)
    ci[3]<- min(1, ci[3])
    ci[2] <- max(0, ci[2])
    up.a <- atan(ci[3]/(1-ci[3]))
    lw.a <- atan(ci[2]/(1-ci[2]))
    if (stat=='lower') q=lw.a 
    if (stat=='ratio') q=lw.a/up.a
    q
  }
  else NA
}

####
conf.binom <- function(alt, ref, alpha=0.02, method='wilson') 
{
  if (!is.na2(alt) & !is.na2(ref))  
  {
    n=ref+alt
    ci <- binconf(alt, n, alpha=alpha, method=method)
    ci[3]<- min(1, ci[3])
    ci[2] <- max(0, ci[2])
    up <- ci[3]
    lw <- ci[2]
    est <- ci[1]
    up.theta <- atan(ci[3]/(1-ci[3]))/pi*180
    lw.theta <- atan(ci[2]/(1-ci[2]))/pi*180
    est.theta <- atan(ci[1]/(1-ci[1]))/pi*180
    list(up=up, lw=lw, est=est, up.theta=up.theta, lw.theta=lw.theta, est.theta=est.theta)    
  }
  else NA
}


##num of nonzero
num2 <- function(v)
{
   sum(!v==0,na.rm=TRUE)
}

##num of equal
num.e <- function(v)
{
   ind <- 0
   if (num2(v)==2) if (length(unique(v))==2) ind <- 1
   ind
}


##general calculation
##input should be m by 4 data.frame with name A, C, G, T
cal.locus <- function(tab, ref, quality='variance')
{  
   id.ref <- which(names(tab)==ref)
   m <- 3
   score <- 1:m
   read.alt <- rep('', m)
   num.ref <- tab[,ref]
   num.alt <- 1:m
   remark <- ''
   for (i in 1:3)
   {  
      id.1 <- which(tab[i,]>0)
      id.2 <- setminus(id.1, id.ref)
      if (length(id.2)>=2) 
           {
            remark <- 'check'
            read.alt[i] <- paste(names(tab)[id.2], collapse=', ')
            num.alt[i] <- NA
            score[i] <- NA
           }
      if (length(id.2)==1) 
         {
           num.alt[i] <- tab[i,id.2]
           read.alt[i] <- names(tab)[id.2]
           score[i] <- qscore(num.alt[i], max(num.alt[i], num.ref[i]), quality=quality)
         }
      if (length(id.2)==0) 
         {
           num.alt[i] <- 0
           read.alt[i] <- NA
           score[i] <- 0
         }
   }
   list(alt=read.alt, nref=num.ref, nalt=num.alt, score=score, remark=remark)
}

##general calculation for alt1...alt3 data format
##input should be m by 4 data.frame with ref, alt1, alt2 and alt3
cal.tab <- function(tab, quality='lower.tail', alpha, method, stat)
{  
  id.c <- which(tab[,1]>0 & tab[,2]>0)
  ref.sum <- sum(tab[id.c,1],na.rm=TRUE)
  alt1.sum <- sum(tab[id.c,2], na.rm=TRUE)
  ratio <- alt1.sum/(alt1.sum+ref.sum)
  score <- 1:nrow(tab)
  for (i in 1:nrow(tab)) score[i] <- qscore(tab[i,2], tab[i,1], alpha=alpha, method=method, stat=stat)
  theta <- atan(tab[,2]/tab[,1])
  remark <- rep('', nrow(tab))
  id.r <- which(tab[,3]>0 | tab[,4]>0)
  remark[id.r]='check!'
  list(score=score, theta=theta, remark=remark, ratio=ratio)
}

##Theta plot
##format = pi or degree, input must be in pi format
##if plot for multiple chromosomes, only show chromosome numbers
##if use same size of cex, put any arbitrary number for depth instead of using a vector
##step.loh must be a data.frame, includes at least chr, pvalue and step
thetaPlot <- function(chr, pos, theta, depth, step.loh=NULL, name.depth='', new=1, show=1:length(pos), show.loh.pvalue=TRUE, loh.line.type=1, loh.line.col=c('red', 'blue', 'pink'), loh.line.lwd=2.8, gap=1/3.5, ylim=c(0, 180*3/5), las=1,  xlim = NULL, ylab=NULL, xlab=NULL, main=NULL, type='p', pch=1, col=1, lty=1, dp.min=NULL, dp.med = NULL, dp.max=NULL, cex.min=0.2, cex.max=1.2, output='degree', dp.label=c('<=', '=', '>='),
                         ylab.right=FALSE, ylab2.at=NULL, ylab2=NULL,  pos.legend='topright', cex.legend=0.9, show.legend=TRUE, ncol.legend=3)
{
  if (output=='degree') theta=theta/pi*180
  id.all <- 1:length(pos)
  if (length(show)>0) id.dr <-  id.all[-show] else id.dr <- id.all
  if (length(id.dr)>0) theta[id.dr]=NA

  if (length(col)==1) col <- rep(col, length(theta))
  if (length(pch)==1) pch <- rep(pch, length(theta)) 
  if (is.null(dp.min) | is.null(dp.max)) 
  {
    dp.min <- range(depth, na.rm=TRUE)[1]
    dp.max <- range(depth, na.rm=TRUE)[2]
  }
  depth[depth<dp.min]=dp.min
  depth[depth>dp.max]=dp.max

  if (length(unique(fna(depth)))==1) cex <- rep(cex.min,length(theta))  else cex <- cex.min+(cex.max-cex.min)*(depth-dp.min)/(dp.max-dp.min)
  if (length(unique(fna(chr)))==1) 
  {
    yrange = range(theta, na.rm = TRUE)
    if (is.null(ylim)) 
    {
      ylim = (yrange - mean(yrange))*1.1 + mean(yrange)
    }
    
    if (new==1) plot(pos, theta, xlim=xlim, ylim=ylim, type=type, lty=lty, col=col, pch=pch, cex=cex,  xlab=xlab, ylab=ylab, main=main)    
    if (new==0) points(pos, theta, xlim=xlim, ylim=ylim, type=type, lty=lty, col=col, pch=pch, cex=cex)
    if (ylab.right) axis(4, at=ylab2.at, label=ylab2, las=2)
  
    if (!is.null(step.loh))
    { 
      size <- step.loh[which(step.loh$chr==unique(fna(chr))), 'size']
      if (size>0)
      {
        step <- step.loh[which(step.loh$chr==unique(fna(chr))), 'step']
        if (is.na2(step)) step <- NULL else step <- sort(as.numeric(unlist(strsplit(step, split=', '))))
        step <- c(1, step, length(pos))
        if (!is.na2(step.loh$upper.mean))
        {
          mean.u <- as.numeric(unlist(strsplit(step.loh$upper.mean, split=', ')))/pi*180
          mean.l <- as.numeric(unlist(strsplit(step.loh$lower.mean, split=', ')))/pi*180
        } else mean.u=mean.l=NULL
        for (ist in 2:length(step))
        {
          if (loh.line.type==1 | loh.line.type==3)
          {
            id.st <- step[ist-1]:step[ist] 
            if (is.null(mean.u)) 
            {
              ym1 = ym2 = mean(theta[id.st], na.rm=TRUE)
              col.loh.1 = col.loh.2 = loh.line.col[3]
            } else
            {
              ym1 = mean.u[ist-1]
              ym2 = mean.l[ist-1]
              if (ym1==ym2) col.loh.1 = col.loh.2 = loh.line.col[3] else
              {
                col.loh.1 = loh.line.col[1]
                col.loh.2 = loh.line.col[2]
              }
            }
            abline2(v=c(pos[step[ist-1]], pos[step[ist]]), h=c(ym1, ym1), type='l', lty=1, col=col.loh.1, lwd=loh.line.lwd*2)
            abline2(v=c(pos[step[ist-1]], pos[step[ist]]), h=c(ym2, ym2), type='l', lty=1, col=col.loh.2, lwd=loh.line.lwd*2)
          }
          if (loh.line.type==2 | loh.line.type==3) if (ist<length(step))
          {
            v.1 = (pos[step[ist]]+pos[step[ist]+1])/2
            abline2(v=c(v.1, v.1), h=c(yrange[1], yrange[2]), lty=1, col='purple')         
          }
        }
      }
    }
  }
  if (length(unique(fna(chr)))>1) 
  {
     chr <- as.character(chr)
     N <- length(theta)
     names.chr <- unique(chr)
     n.chrs <- length(names.chr)

     xplot <- NULL
     yplot <- theta
     if (gap<1) gap <- gap*chr.avg(chr, pos)
     start <- 0
     for (i in 1:n.chrs)
     {
       id.1 <- which(chr==names.chr[i])
       xplot <- c(xplot, start+pos[id.1])
       start <- start+gap+pos[id.1[length(id.1)]]
     }
     if (is.null(xlim)) xlim=range(xplot)
     yrange = range(yplot, na.rm = TRUE)
     if (is.null(ylim)) 
     {
       ylim = (yrange - mean(yrange))*1.1 + mean(yrange)
     }

     x.mid <- 1:n.chrs
     for (i in 1:n.chrs) 
     {
       x.1 <- xplot[chr==names.chr[i]]
       x.mid[i] = 1/2*(sum(range(x.1)))
       y.1 <- yplot[chr==names.chr[i]]
       col.1 <- col[chr==names.chr[i]]
       pch.1 <- pch[chr==names.chr[i]]
       cex.1 <- cex[chr==names.chr[i]]
       if (i==1 & new==1) plot(x.1, y.1, xlim=xlim, ylim=ylim, xlab=xlab, ylab=ylab, type=type, lty=lty, main=main, axes = FALSE, col=col.1, pch=pch.1, cex=cex.1) else points(x.1, y.1, type=type, lty=lty, col=col.1, pch=pch.1, cex=cex.1)
       if (ylab.right) axis(4, at=ylab2.at, label=ylab2, las=2)

       if (!is.null(step.loh))
       {
         id.loh.1 <- which(step.loh$chr==names.chr[i])
         size <- step.loh[id.loh.1, 'size']
         if (size>0)
         {
           step <- step.loh[id.loh.1, 'step']
           if (is.na2(step)) step <- NULL else step <- sort(as.numeric(unlist(strsplit(step, split=', '))))
           step <- c(1, step, length(x.1))
           if (!is.na2(step.loh[id.loh.1, 'upper.mean']))
           {
             mean.u <- as.numeric(unlist(strsplit(step.loh[id.loh.1, 'upper.mean'], split=', ')))/pi*180
             mean.l <- as.numeric(unlist(strsplit(step.loh[id.loh.1, 'lower.mean'], split=', ')))/pi*180
           } else mean.u=mean.l=NULL
           for (ist in 2:length(step))
           {
             if (loh.line.type==1 | loh.line.type==3)
             {
               id.st <- step[ist-1]:step[ist] 
               if (is.null(mean.u))
               { 
                 ym1 = ym2 = mean(y.1[id.st], na.rm=TRUE) 
                 col.loh.1 = col.loh.2 = loh.line.col[3]
               } else
               {
                 ym1 = mean.u[ist-1]
                 ym2 = mean.l[ist-1]
                 if (ym1==ym2) col.loh.1 = col.loh.2 = loh.line.col[3] else
                 {
                   col.loh.1 = loh.line.col[1]
                   col.loh.2 = loh.line.col[2]
                 }
               }
               abline2(v=c(x.1[step[ist-1]], x.1[step[ist]]), h=c(ym1, ym1), type='l', lty=1, col=col.loh.1 , lwd=loh.line.lwd)
               abline2(v=c(x.1[step[ist-1]], x.1[step[ist]]), h=c(ym2, ym2), type='l', lty=1, col=col.loh.2, lwd=loh.line.lwd)
             }
             if (loh.line.type==2 | loh.line.type==3) if (ist<length(step))
             {
               v.1 <- (x.1[step[ist]]+x.1[step[ist]+1])/2
               abline2(v=c(v.1, v.1), h=c(yrange[1], yrange[2]), lty=1, col='purple')         
             }
           }
         }
       }    
     }

     if (new==1)
     {
       if ((ylim[1] <=0) & (ylim[2] >= 0)) 
       {
         d.ylim <- (ylim[2] - ylim[1])/5; n1.ylim <- max(1,round(-ylim[1]/d.ylim))+1; n2.ylim <- max(1, round(ylim[2]/d.ylim))+1
         ylabs <- unique(sort(c(seq(ylim[1], 0, length = n1.ylim), seq(0, ylim[2], length = n2.ylim)))) 
       } else ylabs <- seq(ylim[1], ylim[2], length = 6) 
       axis(2, at=ylabs, label = format.num(ylabs))
       axis(1, at = x.mid, las=las, label = names.chr, tick = FALSE)
       if (!is.null(step.loh)) if (show.loh.pvalue) text(x.mid, rep(ylim[1], length(x.mid)), step.loh$LOH, cex=0.9)
    }
  }
  if (show.legend) if (length(unique(fna(depth)))>1 & new==1) 
  {
    if (length(dp.label)==3)
    {
      if (is.null(dp.med)) dp.med=(dp.min+dp.max)/2
      depth.lg <- c(dp.min, dp.med, dp.max)                                
      cex.lg <- c(cex.min, (cex.min+cex.max)/2, cex.max)      
    }
    if (length(dp.label)==1)
    {
      depth.lg <- dp.min                              
      cex.lg <- cex.min      
    }                                 
    col.lg <- unique(col)                                         
    pch.lg <- unique(pch)
    legend(pos.legend, legend=rep(paste(' --- ', name.depth, dp.label,  format.num(depth.lg), ' ',  sep=''), each=length(col.lg)), col=rep(col.lg, length(cex.lg)), pch=rep(pch.lg, length(cex.lg)), pt.cex=rep(cex.lg, each=length(col.lg)), cex=cex.legend, bty='n', ncol=ncol.legend)
  }
}


###gap = % of average of chr length
dist <- function(chr, pos, chr.1, pos.1, gap=1/10) 
{
  if (gap<1) gap <- gap*chr.avg(chr, pos)
  chr.1=as.character(chr.1)
  chr = as.character(chr)
  id.chr <- which(chr==chr.1)
  pos.start <- pos[id.chr[1]]
  chrs <- unique(chr[1:id.chr[1]])
  num.chr <- length(chrs)
  # if first chromosome
  if (num.chr==1) dist <- pos.1-pos.start else {  
    dist <- 0
    for (i in 1:(num.chr-1)) dist=dist+chr.len(chr, pos, chrs[i])+gap
    dist = dist+pos.1-pos.start
  }           
  dist
}

###chr length
chr.len <- function(chr, pos, chr.1)
{
  chr.1=as.character(chr.1)
  chr = as.character(chr)
  id.chr <- which(chr==chr.1)
  pos.start <- pos[id.chr[1]]
  pos.end <- pos[id.chr[length(id.chr)]]
  pos.end-pos.start
} 

###average chr length
chr.avg <- function(chr, pos)
{
  chr = as.character(chr)
  num.chr <- length(unique(chr))
  tl <- 0
  for (chr.1 in unique(chr))
  {
    tl <- tl+chr.len(chr, pos, chr.1)
  }
  tl/num.chr
}

###LOH test, method=KSP, KST, or Normal, if n.perm>1, perform permutation test (only for KS method)
###x = normal y = tumor

test.loh <- function(x,y,method='KST', n.perm=0)
{
  if (n.perm==0)
  {
    if (method=='KSP')
    {
      tt <- ks.test(x,y,alternative = 'less')
      stat <- tt$statistic[[1]]
      p.value <- tt$p.value
    }

    if (method=='KST')
    {
      z <- x-y
      z0 <- c(-abs(z), abs(z))
      tt <- ks.test(z,z0,alternative = 'less')
      stat <- tt$statistic[[1]]
      p.value <- tt$p.value
    }

    if (method=='Normal')
    {
      stat <- mean(x-y)
      sdt <- sqrt(mean((x-y)^2))
      p.value <- 1-pnorm(stat, mean=0, sd=sdt)
    }

    if (method=='Binomial')
    {
      z <- x-y
      num1 <- sum(z>0)  
      n <- length(z)
      stat <- num1/n
      p.value <- 1-pbinom(num1, n, prob=1/2)
    }
  }
  
  if (n.perm>0) 
  {
    perm = diff = 1:n.perm
    for (i in 1:n.perm)
    {
      xt <- x
      yt <- y
      n <- length(x)
      id.swap <- sample(1:n, sample(1:n,1))
      xt[id.swap] <- y[id.swap]
      yt[id.swap] <- x[id.swap]
      diff[i] <- mean(xt-yt)
      if (method=='KST') 
      { 
        zt <- xt-yt
        zt0 <- c(-abs(zt), abs(zt))
        perm[i] <- ks.test(zt, zt0, alternative='less')$statistic[[1]]
      }
      if (method=='KSP') perm[i] <- ks.test(xt,yt, alternative='less')$statistic[[1]]
      if (method=='Normal') perm[i] <- mean(xt-yt)
    }
  }
  if (n.perm==0) list(stat=stat, p.value=p.value) else list(perm=perm, diff=diff)
}


#---------------------------
# Segmentation, full output 
#---------------------------
#                INPUT
# z:                         Input used vector
# pos:                       Input positions w.r.t z (for segment length)
# step:                      Segmentation steps w.r.t z and pos
# digit.right:               Number of digits keeped in the output
# theta.thd:                 Minimum mixture mean difference
# var.ratio.thd:             Maximum allowed variance ratio of the two mixture models
# max.r, init.mean...        Mixture Gaussian Input


segment.auto <- function(z, pos, step, digit.right=3, boost.ratio=0.1, theta.thd=0.1, var.ratio.thd=100, mean.tol=1/12*pi, plot.file=NULL, res=NULL, init.lambda.l=NULL, min.l=0, init.lambda.r=NULL, max.r=pi/2, init.mean1=pi/4, init.var1=0.01, init.mean2=c(pi/8, 3/8*pi), init.var2=c(0.01, 0.01), init.prop1=c(1/6, 2/3, 1/6), init.prop2=c(1/8, 3/8, 3/8, 1/8), mean.center=pi/4, min.prop2=0.25, min.var=0.0001)
{                             
  num.seg <- length(step)+1
  stepBIC1=stepBIC2=mean1=mean2=ploid1=ploid2=rep(NA,num.seg)
  step <- c(1, step, length(z))
  length.loh <- 0           # LOH length
  for (ist in 2:length(step))
  {
    id.st <- step[ist-1]:step[ist] 
    xt <- z[id.st]
    emt1 <- uniExpGaussEM(xt, init.lambda.l=init.lambda.l, min.l=min.l, init.lambda.r=init.lambda.r, max.r=max.r, init.mean=init.mean1, init.var=init.var1,  init.prop=init.prop1, max.iter=20, 
              loglik.tol=0.01, min.prop=0, min.var=min.var, max.var=var(xt), max.lambda=1, mean.tol=mean.tol)   #Single Gaussian Model
    emt2 <- uniExpGaussEM(xt, init.lambda.l=init.lambda.l, min.l=min.l, init.lambda.r=init.lambda.r, max.r=max.r, init.mean=init.mean2, init.var=init.var2, init.prop=init.prop2, mean.center=pi/4, max.iter=20, 
              loglik.tol=0.01, min.prop=min.prop2, min.var=min.var, max.var=var(xt), max.lambda=1, mean.tol=mean.tol)   #Two Gaussian Model
    stepBIC1[ist-1] <- format.num(emt1$BIC, digit.right=digit.right)
    stepBIC2[ist-1] <- format.num(emt2$BIC, digit.right=digit.right)
    var.ratio <- max(emt2$var[2]/emt2$var[1], emt2$var[1]/emt2$var[2]) 
    if (is.null(init.lambda.l)) gstart=1 else gstart=2
    if ((emt1$BIC + abs(emt1$BIC)*boost.ratio) > emt2$BIC | prod(emt2$prop[gstart:(gstart+1)])==0 | abs(emt2$mean[2]-emt2$mean[1])<=theta.thd | var.ratio > var.ratio.thd) mean1[ist-1]=mean2[ist-1]=emt1$mean else 
    {
      mean1[ist-1]=emt2$mean[1]
      mean2[ist-1]=emt2$mean[2]
      length.loh <- length.loh +  pos[step[ist]]-pos[step[ist-1]]
    }
    if (!is.null(plot.file))
    {
      v.file <- strbar(plot.file, '\\.')
      v.file[length(v.file)-1] <- paste(v.file[length(v.file)-1], (ist-1), sep='_')
      file.pic <- paste(v.file, collapse='.')
      mix.plot(xt, emt1, emt2, file.pic, res)
    }
  }
  ploid1 <- tan(mean1)
  ploid2 <- tan(mean2)
  stepBIC1 <- paste(stepBIC1, collapse=', ')
  stepBIC2 <- paste(stepBIC2, collapse=', ') 
  upper.mean <- paste(mean1, collapse=', ')
  lower.mean <- paste(mean2, collapse=', ')         
  upper.ploid <- paste(ploid1, collapse=', ')              
  lower.ploid <- paste(ploid2, collapse=', ')
  list(stepBIC1=stepBIC1, stepBIC2=stepBIC2, upper.mean=upper.mean, lower.mean=lower.mean, upper.ploid=upper.ploid, lower.ploid=lower.ploid, length.loh=length.loh) 
}


#--------------------------------------------------------
# Segmentation, method = 'forward.stagewise' and 'lar'
#--------------------------------------------------------
segmentation <- function(z, method='lar', alpha=0.1, max.steps=10, dist=1/10)
{
  n <- length(z)
  dist <- n*dist
  X <- segMatrix(n)
  step <- unlist(lars(X,z,type=method, max.steps=max.steps)$actions)
  pvalue <- 1:length(step)
  for (i in 1:length(step))
  {
    if (i==1) fit0 <- lm(z~1) else fit0 <- lm(z~X[, step[1:(i-1)]])
    fit1 <- lm(z~X[, step[1:i]])
    pvalue[i] <- anova(fit0,fit1)[2,6]
    if (is.na(pvalue[i])) pvalue[i]=NA
  }
  id <- which(pvalue<=alpha & !is.na(pvalue))
  if (length(id)==0) stepLarge=NA else 
  {
    stepLarge=NULL
    for (j in 1:length(id))
    {
      if (min(abs(step[id[j]]-c(1, stepLarge, n))) > dist) stepLarge <- c(stepLarge, step[id[j]]) 
    }
    if (is.null(stepLarge)) stepLarge=NA
  }
  list(stepLarge=stepLarge, step=step, pvalue=pvalue)
}

#------------------------------
# mixture model diagnosis plot
#------------------------------
mix.plot <- function(x, em1, em2, file, res)
{
  vname <- strbar(file, '\\.')
  pic.format <- vname[length(vname)]
  if (pic.format=='jpg') jpeg(file=file, width=10, height=10, unit='in', res=res)
  if (pic.format=='eps') postscript(file=file, width=10, height=10, paper="special", horizontal=TRUE)
  par(mfrow=c(2,1))
  denfun1 <- em1$denfun
  denfun2 <- em2$denfun
  histpdf(x, denfun1, main=paste('Distribution of single Gaussian model'))
  abline(v=em1$mean, lty=3, col='red')
  legend('topright', paste(c('BIC=', 'Prob=', 'Var='), c(format.num(em1$BIC), paste(format.num(em1$prop), collapse=', '), paste(format.num(em1$var), collapse=', ')), sep=''))
  histpdf(x, denfun2, main=paste('Distribution of mixture Gaussian model'))
  abline(v=em2$mean, lty=3, col='red')
  legend('topright', paste(c('BIC=', 'Prob=', 'Var='), c(format.num(em2$BIC), paste(format.num(em2$prop), collapse=', '), paste(format.num(em2$var), collapse=', ')), sep=''))
  dev.off()
}


###make matrix
segMatrix <- function(n)
{
  X <- matrix(0, (n-1), n)
  X[upper.tri(X)]=1
  X <- t(X)
  X <- apply(X,2,function(a){a-mean(a)})
  X
}

#-------------------------------------
# Genotyping Distance from Quant File
#-------------------------------------
#M.1               --- First Matrix from Quant file
#M.2               --- First Matrix from Quant file
#thd               --- threshold to make a call
#method            --- Distance metric. Manh = Manhatten Distance; KL = Symmetric Kullback Leibler Distance; HE = Hellinger�s Distance; Chi2 = Chi2 Divergence.
Dist.Quant <- function(M.1, M.2, thd, method=c('Manh', 'KL', 'HE', 'Chi2'))
{
  n <- nrow(M.1)
  s1 <- apply(M.1, 1, sum)
  s2 <- apply(M.2, 1, sum)
  P.1 <- M.1/s1
  P.2 <- M.2/s2
  PC <- cbind(P.1, P.2)
  min.p <- min(PC[PC>0])
  DIST <- data.frame(matrix(0,n,length(method)))
  if (sum(method=='Manh'|method=='KL')>0)               #if Manh or KL are computed, first compute Manh Distance
  {
    Manh.v <- apply(abs((P.1>thd) - (P.2>thd)), 1, sum)   #Manhatten Distance, =1 if and only if calling (>=thd) the same allele
    id.s <- which(Manh.v==0)
    id.f <- which(Manh.v>0)
    if (sum(method=='Manh')>0) 
    {
      DIST[,which(method=='Manh')]= as.numeric(Manh.v>0)
    }
  }
  if (sum(method=='KL')>0)
  {
    DIST[,which(method=='KL')] <- apply(PC, 1, KL.MN, ep=0.001)
  }
  if (sum(method=='HE')>0)
  {
    DIST[,which(method=='HE')] <- apply(PC,1,HE.MN)
  }

  if (sum(method=='Chi2')>0)
  {
    DIST[,which(method=='Chi2')] <- apply(PC,1,Chi2.MN)
  }
  names(DIST)=method
  DIST
}

#------------------------------------------------------
# Symmetric KL Divergence for Multinomial Distribution
#------------------------------------------------------
#ep       --- small substitution number for zero probability
#k        --- length of vector
KL.MN <- function(pv, ep = 0.00001, k=4)
{
  p1 <- pv[1:k]
  p2 <- pv[(k+1):(2*k)]
  p1m <- pmax(p1, ep)
  p2m <- pmax(p2, ep)
  1/2*(sum(p1*(log(p1m)-log(p2m))) + sum(p2*(log(p2m)-log(p1m))))
}

#------------------------------------------------------
# Hellinger�s Distance for Multinomial Distribution
#------------------------------------------------------
#HE.MN <- function(pv, k=4)
#{
#  p1 <- pv[1:k]
#  p2 <- pv[(k+1):(2*k)]
#  1-sum(sqrt(p1*p2))
#}

HE.MN <- function(pv, k=4)
{
  p1 <- pv[1:k]
  p2 <- pv[(k+1):(2*k)]
  sqrt(1-sum(sqrt(p1*p2)))
}

#------------------------------------------------------
# Chi-square Divergence for Multinomial Distribution
#------------------------------------------------------
Chi2.MN <- function(pv, k=4, ep=0.000001)
{
  p1 <- pv[1:k]
  p2 <- pv[(k+1):(2*k)]
  1/2*sum((p1-p2)^2/pmax((p1+p2), ep))
}


