library(lattice)
#library(xlsx)

###source a directory
sourceDir <- function(path, trace = TRUE, ...) {
    for (nm in list.files(path, pattern = "\\.[RrSsQq]$")) {
       if(trace) cat(nm,":")           
       source(file.path(path, nm), ...)
       if(trace) cat("\n")
    }
}

fact.char <- function(data) {
for (iData in 1:dim(data)[2]) if (is.factor(data[, iData])) data[,iData] <- as.character(data[,iData])
data
}

read.txt2 <- function(file, header=TRUE) {
   T <- read.table(file=file, header=header) 
   T <- fact.char(T)
   T
}


read.csv2 <- function(file, header=TRUE) {
   T <- read.csv(file=file, header=header) 
   T <- fact.char(T)
   T
}

read.xlsx2 <- function(file, sheetIndex=1, header=TRUE)
{
   T <- read.xlsx(file=file, sheetIndex=sheetIndex, header=header) 
   T <- fact.char(T)
   T
}

col.numeric <- function(data) {
  data <- fact.char(data)
  col <- 1
  while (!is.numeric(data[,col])) col=col+1
  col
}

is.na2 <- function(x){
  is.na(x) | (x == '')
}

##filter na values
fna <- function(x)
{
   id <- which(!is.na2(x))
   x[id]
}


##closest value id
cvi <- function(a, v)
{
  id <- 1:length(a)
  for (ii in 1:length(a)) id[ii] <- which(abs(v-a[ii])==min(abs(v-a[ii]), na.rm=TRUE))[1]
  id
}

##if elements of b is included in a
include <- function(a, b){
   n.list <- length(b) 
   id.l <- list() 
   for (i in 1:n.list) id.l[[i]]=which(a==b[i])
   id <- sort(unique(unlist(id.l)))
   list(id=id, id.list=id.l)
}

###vector match, return row numbers, first input must also be matrix/data.frame
match.v <- function(tab, T, order=TRUE)
{
   m <- nrow(tab)
   id.list <- list()
   for (i in 1:m)
   {
     if (order) id.1 <- which(apply(T, 1, function(x) all(x == tab[i,])))
     else id.1 <- which(apply(T, 1, function(x) all(x %in% tab[i,])))
     id.list[[i]]=id.1
   }
   list(id.list=id.list, id=unlist(id.list))
}

##a minus b
setMinus <- function(a,b)
{
   id.dr <- include(a,b)$id
   if (length(id.dr)>0) a <- a[-id.dr]
   a
}

##common table, only show unique values, label = 'common name', 'first name', 'second name'
setCommon <- function(a, b, label=c(1,0,0))
{
   v <- unique(c(a,b))
   n <- length(v)
   ind <- rep('', n)
   for (i in 1:n)
   {
      if (sum(a==v[i])>0 & sum(b==v[i])>0) ind[i]=label[1] 
         else
         {
            if (sum(a==v[i])>0) ind[i]=label[2] 
                else ind[i]=label[3] 
         }                                                 
   }   
   tab <- data.frame(v,ind)
   names(tab)=c('VALUE', 'IND')
   tab
}


###Product of table
proTab <- function(T)
{
  k <- length(T)
  tab <- data.frame(T[[k]])
  for (i in (k-1):1)
  {
    n.1 <- nrow(tab) 
    n.2 <- length(T[[i]])
    id.1 <- rep(1:n.1, n.2)
    id.2 <- rep(1:n.2, each=n.1)
    tab <- data.frame(T[[i]][id.2], tab[id.1,])
  }
  names(tab) <- paste('V', 1:k, sep='')
  tab
}

###data.frame by repeat, second input is the number of row, Tab must be either numeric or character
repTab <- function(Tab, r)
{
  m <- ncol(Tab)
  New <- data.frame(matrix(NA, r, m))
  k <- min(nrow(Tab), r)
  New[1:k,] <- Tab[1:k,]
  names(New) <- names(Tab)
  New
}

##only show the center nonempty character
str.space <- function(v)
{
   for (i in 1:length(v)) if (!is.na(v[i]))
   {
     str.sp <- unlist(strsplit(v[i], split=''))
     if (length(str.sp)>0) 
     {
       if (sum(str.sp!=' ')>=1)
       {
          id.front <- min(which(str.sp!=' '))
          id.end <- max(which(str.sp!=' '))
          v[i]=paste(str.sp[id.front:id.end], collapse='')
       } else v[i]=''
     }
   }
   v
}

multisub <- function(a, b, value){
   a[include(a, b)$id] = value
   a
}

id.left <- function(x, v){
    dis <- x-v
    dis.pos <- dis[dis>=0]
    which(dis==min(dis.pos))
}


#string split, note that first input should not be vector
strbar <- function(a, split){
   for (i in 1:length(split)) a <- unlist(strsplit(a, split=split[i]))
   a
}

#-----------------
# Grab file name
#-----------------
grab.name <- function(filename)
{ 
  v <- strbar(filename,  '\\.')
  v <- paste(v[-length(v)], collapse='.')
  v <- strbar(v, '/')
  v[length(v)]
}

#---------------------
# Grab file extension
#---------------------
grab.ext <- function(filename)
{ 
  v=strbar(filename,  '\\.')
  v[length(v)]
}



#paste name before extension
paste2 <- function(filename, strplus, sep='') {
    v <- unlist(strsplit(filename, split='\\.'))
    nc <- length(v)
    filename <- paste(v[-nc], collapse='.')
    filename <- paste(filename, strplus, sep=sep)
    filename <- paste(filename, v[nc], sep='.')    
    filename
}

#------------------------
# Get complete file name
#------------------------
# WD:           working directory
# filename:     file path w.r.t WD, start with './'
getDirComplete <- function(WD, filename)
{
  filename <- unlist(strsplit(filename, split=''))
  filename <- paste(filename[-(1:2)], collapse='')
  name.complete <- paste(WD, filename, sep='')
  name.complete
}

#Picture

ma.plot <- function(x,y, pch=1, col=1) {
   M=x-y
   A=(x+y)/2
   xyplot2(A,M)
}

panel.linear <- function(x, y, col.pt='black', col.line='red', bg=NA, pch=par('pch'), cex=1, lty=2, ...) {
    points(x,y,pch=pch, col=col.pt,  cex=cex)
    abline(lm(y~x), col=col.line, lty=lty)  
}

panel.cor <- function(x, y, digits=2, r.benchmark, prefix="", risk.bar =0.01, cex.cor, ...)
{
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(0, 1, 0, 1))
    r <- cor(x, y)
    if (is.null(r.benchmark)) txt <- format.num(r) else 
    {
       if (length(r.benchmark)>=2)
       {
        p.v <- 1-pemp(r, r.benchmark)
        txt <- paste(format.num(r), ' (', format.num(p.v, digit.right=3), ')', sep='')
        if (p.v<=risk.bar) txt=paste('*', txt, sep='')       
       } else 
          {
             txt <- format.num(r)
             if (r>=r.benchmark) txt=paste('*', txt, sep='')  
          }
    }
    txt <- paste(prefix, txt, sep="")
    if(missing(cex.cor)) cex.cor <- 2.2/strwidth(txt)
    text(0.5, 0.5, txt, cex = cex.cor )
}

panel.hist <- function(x, ...)
{
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(usr[1:2], 0, 1.5) )
    h <- hist(x, plot = FALSE)
    breaks <- h$breaks; nB <- length(breaks)
    y <- h$counts; y <- y/max(y)
    rect(breaks[-nB], 0, breaks[-1],  y, col="cyan", ...)
} 

#xlim = 'common' or 'self'
pair2 <- function(data, pch=1, range='self', r.benchmark = NULL, col='black', main=NULL) {
      if (is.numeric(range)) xlim=range else {
          if (range=='common') xlim=range(data,na.rm=TRUE)
          if (range=='self') xlim=NULL      
      }
      pairs(data, xlim=xlim, cex = 1, pch = 1, diag.panel=panel.hist, lower.panel=panel.linear, r.benchmark=r.benchmark, upper.panel=panel.cor, cex.labels = 1,  font.labels=1, main=main)
}


### Two data set, pair wise
pair3 <- function(datax, datay, xrange='self', yrange='self', col='black', main=NULL, pos.legend='topright', cex.legend=0.8){
      if (is.numeric(xrange)) xlim=xrange else {
          if (xrange=='common') xlim=xrange(datax)
          if (xrange=='self') xlim=NULL      
      }
      if (is.numeric(yrange)) ylim=yrange else {
          if (yrange=='common') ylim=yrange(datay)
          if (yrange=='self') ylim=NULL      
      }
      nc <- ncol(datax) 
      nr <- ncol(datay)
      par(mfrow=c(nr, nc))
      for (i in 1:nc) for (j in 1:nr) { 
        plot(datax[,i], datay[,j], xlim=xlim, ylim=ylim, pch=1, main=main, xlab=names(datax)[i], ylab=names(datay)[j]) 
        abline(lm(datay[,j]~datax[,i]), col='red', lty=2)
        legend(pos.legend, legend=format.num(cor(datax[,i], datay[,j], use='pairwise.complete.obs')), cex=cex.legend, bty='n')
      }     
}


xyplot2 <- function(x, y, pch=1, col=1) {
   xyplot(y~x, panel=function(x,y){
       panel.xyplot(x,y, pch=pch, col=col)
       panel.lmline(x,y,lty=2,col='blue')
       panel.loess(x,y,lty=2,col='red')
   })
}

hist1 <- function(x, breaks=25, col.hist='azure', col.a='red', lty.a=1, main=NULL, xlab=NULL, xlim=NULL, ratio=1, show.mean=FALSE, pos.legend='topright', cex.legend=0.8) {
       if (is.null(xlim)) xlim <- range(x, na.rm=TRUE)
       hist.val <- hist(x, breaks=breaks, col=col.hist, xlim=xlim, xlab=xlab, main=main)
       ratio.hi <- max(hist.val$count)/max(hist.val$density)*ratio 
       den.est <- density(x)
       points(den.est$x, den.est$y*ratio.hi, col=col.a, type='l', lty=lty.a)
       legend(pos.legend, legend='estimated density curve', lty=lty.a, col=col.a, bty='n', cex=cex.legend)
}

hist2 <- function(data, method='avg.quantile', breaks=25, col.hist='azure', col.a=rainbow(ncol(data)), lty.a=rep(1,ncol(data)), main=NULL, xlab=NULL, xlim=NULL, ratio=1/2, 
 label.a=rep(NULL,ncol(data)), col.label=rep(1,ncol(data)), xjust=0.7, yjust=0.2, cex.label=rep(0.7,ncol(data)), show.mean=FALSE, pos.legend='topright', cex.legend=0.9, ncol.legend=1) {
   if (is.null(xlim)) xlim <- range(data, na.rm=TRUE)
   if (method=='avg.quantile') avg <- apply(apply(data, 2, sort), 1, mean)
   if (method=='avg.pool') avg <- as.vector(as.matrix(data))
   hist.val <- hist(avg, breaks=breaks, col=col.hist, xlim=xlim, xlab=xlab, main=main)
   if (show.mean) abline(v=mean(as.vector(as.matrix(data))), col='blue', lty=2)
   ratio.hi <- max(hist.val$count)/max(hist.val$density)*ratio 
   for (j in 1:ncol(data)) {
       den.est <- density(data[,j])
       points(den.est$x, den.est$y*ratio.hi, col=col.a[j], type='l', lty=lty.a[j])
       if (!is.null(label.a[j])) {
           id.lab <- which(den.est$y==max(den.est$y))[1]
           legend(den.est$x[id.lab], den.est$y[id.lab]*ratio.hi, legend=format.num(label.a[j]), xjust=xjust, yjust=yjust, text.col=col.label[j], cex=cex.label[j], bty='n')
       }
   }
   legend(pos.legend, legend=names(data), lty=lty.a, col=col.a[1:ncol(data)], ncol=ncol.legend, bty='n', cex=cex.legend)
}


abline2 <- function(v, h, type='l', lty=1, col=1,lwd=1) 
{
   if (length(v)==1) v <- sort(c(0, v))
   if (length(h)==1) h <- sort(c(0, h))
   v <- seq(v[1], v[2], length=100)
   h <- seq(h[1], h[2], length=100)
   points(v, h, type=type, lty=lty, col=col, lwd=lwd) 
}

###comparison histogram, inputs are a vector and comparison points
hist3 <- function(v, pt=mean(v,na.rm=TRUE), breaks=25, col.hist='azure', col.a=rainbow(length(pt)), lty.a=rep(1, length(pt)), main=NULL,sub=NULL, xlab=NULL,ylab='Frequency', xlim=NULL, ratio1=1.1, ratio2=1.15, label.hist = NULL, cex.label=rep(0.8,length(pt)), label.legend='mean',
pos.legend='topright', cex.legend=0.9, ncol.legend=1) 
{
       if (is.null(xlim)) xlim <- range(v, na.rm=TRUE)
       hist.value <- hist(v, breaks=breaks,  plot=FALSE)
       ylim <- c(0, max(hist.value$counts))*1.2
       hist(v, breaks=breaks, col=col.hist, xlim=xlim, ylim=ylim, xlab=xlab, ylab=ylab, main=main, sub=sub)
       for (i in 1:length(pt)) 
         {
            id.1 <- id.left(pt[i], hist.value$breaks)
            y.1 <- max(hist.value$counts)*ratio1
            y.2 <- max(hist.value$counts)*ratio2
            abline2(v=c(pt[i], pt[i]), h=y.1, col=col.a[i], lty=lty.a[i])
            if (!is.null(label.hist)) text(pt[i], y.2, label.hist[i], cex=cex.label) 
         }
       if (!is.null(label.legend)) legend(pos.legend, legend=label.legend, lty=lty.a, col=col.a, ncol=ncol.legend, bty='n', cex=cex.legend)
}


#legend are for different colors of bars and thus must for groups
barplot2 <- function(x, group=NULL, col.default='grey', col.a=rainbow(length(unique(group))), names=x, las=1, cex.names=0.8, label.a=NULL, xlab=NULL, ylab=NULL, ylim=NULL, main=NULL, col.label=rep(1, length(x)), xjust=0.7, yjust=0.2, cex.label=rep(0.8, length(x)), pos.legend='topright', cex.legend=0.9, ncol.legend=1) {
    if (is.null(ylim)) {
             if (min(x)>=0) { 
                      ylim=c(0, max(x)*1.2) 
                            } else { 
                              if (max(x)<=0) ylim=c(min(x)*1.2, 0) else ylim=mean(x)+(range(x)-mean(x))*1.2
                            }
                       }
    if (!is.null(group)) {
         cols <- 1:length(x)
         group.u <- unique(group)
         for (i in 1:length(group.u)) cols[which(group==group.u[i])]=col.a[i]
         barp <- barplot(x, names=names, las=las, col=cols, xlab=xlab, ylab=ylab, ylim=ylim, main=main, cex.names=cex.names)
         legend(pos.legend, legend=group.u, fill=col.a[1:length(group.u)], cex=cex.legend, ncol=ncol.legend,  bty='n')
         if (!is.null(label.a)) for (i in 1:length(x)) {
            if (x[i]<0) yjust=1-yjust
            legend(barp[i,1], x[i], legend=label.a[i], xjust=xjust, yjust=yjust, text.col=col.label[i], cex=cex.label[i], bty='n')
            if (x[i]<0) yjust=1-yjust
         }
    } else {
          barp <- barplot(x, names=names, las=las, col=col.default, xlab=xlab, ylab=ylab,  ylim=ylim, main=main, cex.names=cex.names)
          if (!is.null(label.a)) for (i in 1:length(x)) {
            if (x[i]<0) yjust=1-yjust
            legend(barp[i,1], x[i], legend=label.a[i], xjust=xjust, yjust=yjust, text.col=col.label[i], cex=cex.label[i], bty='n')
            if (x[i]<0) yjust=1-yjust
         }
          }
}



#STATs
pemp <- function(q, x, lower.tail=TRUE){
    p=1:length(q)
    for (i in 1:length(q)) p[i]=sum(x<=q[i], na.rm=TRUE)/length(x) 
    if (!lower.tail) p=1-p  
    p
}

qemp <- function(p, x, larger=FALSE) {
   q=1:length(p)
   for (i in 1:length(p)) {
     id <- floor(p[i]*length(x))
     if (larger & id<(p[i]*length(x))) id=id+1
     if (id>0) q[i]=sort(x)[id] else {
          rng <- range(x)
          q[i]=min(x)-(rng[2]-rng[1])/(length(x)-1)
     }
   }
   q
}


fisher.z <- function(data) {
   nr <- nrow(data)
   nc <- ncol(data)
   corr <- cor(data)
   p.value = z = corr
   for (i in 1:nc) for (j in i:nc)  
     if (j==i) {z[i,j]=NA; p.value[i,j]=0} else{
          z[i,j]=1/2*(log(1+corr[i,j])-log(1-corr[i,j]))
          p.value[i,j]=2*(1-pnorm(abs(z[i,j]),mean=0, sd=1/sqrt(nr-3)))  
     }
   for (i in 2:nc) for (j in 1:(i-1)) {z[i,j]=z[j,i]; p.value[i,j]=p.value[j,i]}
   list(r=corr, z=z, p.value=p.value)
}

#KS distance to data mean or median
KS2 <- function(data, method = 'avg.quantile'){
   nc <- ncol(data)
   if (method=='avg.quantile') avg <- apply(apply(data, 2, sort), 1, mean)
   if (method=='avg.pool') avg <- as.vector(as.matrix(data))
   D=p.value=1:nc
   for (i in 1:nc) {
        KS.1 <- ks.test(data[,i], avg)
        D[i]=KS.1$statistic
        p.value[i]=KS.1$p.value
   } 
  list(D=D, p.value=p.value)
}

#Mahalanobis Distance type 1, normal to value distance
MD1 <- function(data, v=NULL, method='avg.quantile') {
      nc <- ncol(data)
      if (is.null(data)) {
              data <- data.frame(data)
              nc <- ncol(data)
      }
      if (is.null(v)) {
             if (method=='avg.quantile') avg <- apply(apply(data, 2, sort), 1, mean)
             if (method=='avg.pool') avg <- as.vector(as.matrix(data))
             v=mean(avg)
      }
      D <- (apply(data, 2, mean)-v)/apply(data,2, sd)
      p.value <-2*(1-pnorm(abs(D))) 
     list(D=D, p.value=p.value)
}
   

#Others
format.num <- function(a, digit.right=2){
  round(a, digits=digit.right)
}

##use to switch columns when merging the ids
mergeID <- function(st, ed, rp) {
   id.M <- 1:(st-1)
   for (j in st:ed) id.M <- c(id.M, j+(ed-st+1)*(0:(rp-1)))
   id.M
}

remarkTable <- function(tab, col=2, remark=''){
   tab <- fact.char(tab)
   nc <- ncol(tab)
   row.remark <- rep('', nc)
   row.remark[col] = remark
   tab <- rbind(tab, row.remark)
   tab
}

##ID calculator for blocks
id.blk <- function(a, size)
{
  i=floor(a/size)+1
  k=a-(i-1)*size
  list(i=i,k=k)
}

##Multidimensional scaling

MDS.2D <- function(D, label.a, cex.label=0.7, group=NULL, col.a=rainbow(length(unique(group))), xlim=NULL, ylim=NULL, main=NULL, type='n', cex.legend=0.8, ncol.legend=1, pos.legend='topright')
{
   fit <- cmdscale(D, eig=TRUE, k=2) 
   x <- fit$points[,1]
   y <- fit$points[,2]
   if (is.null(xlim) & is.null(ylim)) xlim=ylim=range(x,y,na.rm=TRUE) 
   plot(x, y, xlab="x", ylab="y", xlim=xlim, ylim=ylim, main=main, type=type)
   if (!is.null(group)) 
   {
     cols <- 1:length(x)
     group.u <- unique(group)
     for (i in 1:length(group.u))  
     {
       cols[which(group==group.u[i])]=col.a[i] 
       text(x, y, labels=label.a, cex=cex.label, col=cols) 
       legend(pos.legend, legend=group.u, fill=col.a[1:length(group.u)], cex=cex.legend, ncol=ncol.legend,  bty='n')
     } 
   }
   else text(x, y, labels=label.a, cex=cex.label) 
}

MDS.3D <- function(D, label.a, cex.label=0.7, group=NULL, col.a=rainbow(length(unique(group))), xlim=NULL, ylim=NULL, zlim=NULL, main=NULL, type='n', cex.legend=0.8, ncol.legend=1, phi=15, theta=0, expand=1, pos.legend='topright')
{
   fit <- cmdscale(D, eig=TRUE, k=3) 
   x <- fit$points[,1]
   y <- fit$points[,2]
   z <- fit$points[,3]
   if (is.null(xlim) & is.null(ylim) & is.null(zlim)) xlim=ylim=zlim=range(x,y,z,na.rm=TRUE) 
   plot3d(x, y, z, xlab="x", ylab="y", zlab='z', phi=phi, theta=theta, expand=expand, xlim=xlim, ylim=ylim, zlim=zlim, main=main, type=type)
   if (!is.null(group)) 
   {
     cols <- 1:length(x)
     group.u <- unique(group)
     for (i in 1:length(group.u))  
     {
       cols[which(group==group.u[i])]=col.a[i] 
       text3d(x, y, z, labels=label.a, cex=cex.label, col=cols) 
     } 
   legend(pos.legend, legend=group.u, fill=col.a[1:length(group.u)], cex=cex.legend, ncol=ncol.legend,  bty='n')
   }
   else text3d(x, y, z, labels=label.a, cex=cex.label) 
}

#######Tree based on distance matrix
#######Need R.basic package
TREE.G <- function(D, label.a, method='ward', cex.label=0.7, pch=16, cex.pch=0.1, group=NULL, col.a=rainbow(length(unique(group))), ylim=NULL, main=NULL, ylab='Height', xlab=NULL, cex.legend=0.8, ncol.legend=1, pos.legend='topright')
{
   row.names(D)=label.a
   D <- as.dist(D)
   D.h <- hclust(D, method=method)
   if (!is.null(group)) 
   { 
     cols <- 1:length(label.a)
     group.u <- unique(group)
     for (i in 1:length(group.u))  
     {
       cols[which(group==group.u[i])]=col.a[i] 
     }
   
     colLab <- function(n)
     {
       if(is.leaf(n))
       {
         a <- attributes(n)   
         id <- which(label.a==a$label)[]
         attr(n, "nodePar") <- c(a$nodePar, list(lab.col = cols[id], lab.cex=cex.label, col=cols[id], cex=cex.pch, pch=pch))
       }
       n
     }  

     D.h <- dendrapply(as.dendrogram(D.h), colLab) 
     if (is.null(ylim)) plot(D.h, main=main, ylab=ylab, xlab=xlab)
     else plot(D.h, main=main, ylim=ylim, ylab=ylab, xlab=xlab)
     legend(pos.legend, legend=group.u, fill=col.a[1:length(group.u)], cex=cex.legend, ncol=ncol.legend,  bty='n')
   }
   else
   {
     plot(D.h, main=main, ylim=ylim, cex=cex.label)
   }
}

###cut numbers in small chunks, designed for cluster use, increase a group if not even divide
vector.cut <- function(v, k)
{
  n <- length(v)
  n.c <- floor(n/k) 
  vc <- list()
  for (i in 1:k) vc[[i]] <- v[1:n.c+(i-1)*n.c]
  if (n > k*n.c) vc[[(k+1)]] <- v[(k*n.c+1):n]
  vc
}


#===========================
# histogram and distribution
#===========================
# x      --- input vector
# denfun --- estimated density function
# breaks --- number of breaks in the histogram.  Must be smaller than length of x

histpdf <- function(x, denfun, breaks=21, hist.col="lightskyblue", den.col='red', main=NULL)
{
  rng.x <- range(x)
  x.d <- seq(rng.x[1], rng.x[2], length=50)
  y.d <- denfun(x.d)

  hist.fit <- hist(x, breaks=breaks, col=hist.col)
  x.mids <- hist.fit$mids[hist.fit$mids<=rng.x[2] & hist.fit$mids>=rng.x[1]]
  y.mids <- denfun(x.mids)
  hist.counts <- hist.fit$counts[hist.fit$mids<=rng.x[2] & hist.fit$mids>=rng.x[1]]
  fit.counts <- lm(hist.counts~y.mids-1)                        # fit the scale of the density curve
  scale.density <- as.numeric(fit.counts$coefficients)

  y.d.scaled <- y.d*scale.density
  points(y.d.scaled~x.d, type="l", col=den.col, main=main)
  legend("topleft",paste(format(scale.density,digits=2),"*", "density"), lty=1, col=den.col, bty="n")                     
}