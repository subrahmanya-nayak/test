#-------
# Input
#-------
args <- unlist(strsplit(unlist(commandArgs()), " "))
n0 <- 4
PKG <- args[n0]
MODE <- args[n0+1]
TYPE=args[n0+2]

#-------------------------------------
# Read file location and make cluster
#-------------------------------------
NAME.ANALYSIS <- "NN2"               
WD <- './'
PACKAGE <- paste(PKG, "NN2/", sep="")
HEADER <- 'F-F'

OUTPUT <-  paste('./', 'OUTPUT/',  sep='')
REPORT <- paste('./', 'REPORT/', sep='' )
STORE <- paste('./', 'TEMP/', sep='')

#----------------------------
# WD and Predfined functions
#----------------------------
setwd(WD)
source(paste(PACKAGE,'Toolbox/general.R', sep=''))
sourceDir(paste(PACKAGE, 'Toolbox/', sep=''))
source(paste(PACKAGE, 'Cluster/Toolbox/Cluster.R', sep=''))


#--------
# Files
#--------
LIST <- paste(STORE, 'List/', sep='')

QuantList1 = paste(LIST, 'List1.txt', sep='')
if (MODE=='ONE'|MODE=='One'|MODE=='one') QuantList2 = QuantList1 else QuantList2 = paste(LIST, 'List2.txt', sep='')

POSITION <- paste(LIST, 'Position.csv', sep='')

List1 <- read.table(file=QuantList1, sep='\t', header=FALSE)
INPUTS <- fact.char(List1)[,1]
N <- length(INPUTS)

NN.command <- rep('', N)

if (TYPE=='Setting')
{
  #-------
  # Start
  #-------
  for (i in 1:N)
  {
    NAME <- i
    INPUT1 <- QuantList1
    INPUT2 <- QuantList2
    source(paste(PACKAGE, 'Interface.R', sep=''))
    NN.command[i] <- clusterLine
  }

  Directory <- ''
  PROJECT_NOTE <- 'NN2'
  file.cluster <- paste(Directory, PROJECT_NOTE, '_', 'cluster', '.cmd', sep='')
  write.table(NN.command, file=file.cluster, quote=FALSE, sep='', eol='\n', col.names=FALSE, row.names=FALSE)
}

if (TYPE=='Merge'|TYPE=='MERGE') source(paste(PACKAGE, 'PairedSample/Merge.R', sep=''))
