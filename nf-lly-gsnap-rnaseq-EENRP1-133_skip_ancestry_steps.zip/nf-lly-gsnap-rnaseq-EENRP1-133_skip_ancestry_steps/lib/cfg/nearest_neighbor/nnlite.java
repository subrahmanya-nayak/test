import java.io.*;
import java.lang.*;

//first args is input file, second is output file for index 
class nnlite {
	  static final String RProgram = "/lrlhps/apps/R/R-2.14.1/bin/R";   
    public static void main(String[] args) {
        //String PKG = System.getProperty("user.dir") + "/"; 
        String PKG = new File(nnlite.class.getProtectionDomain().getCodeSource().getLocation().getPath())+ "/nnlite/"; 
        String RRunfile = PKG+"Code.R";  
    	  int i;
    	  String[] Params=new String[5];
        if (args.length<3) {
            System.out.println("Please check the input parameters.");       
        } else {
        	  Params[0] = PKG;
        	  for (i=1;i<4;i++) {
        	  	  Params[i]=args[i-1];
    	      }
    	      if (args.length==3) {
    	      	  Params[4]="HE";
    	      }
    	      if (args.length>3) {
    	      	  Params[4]=args[3];
    	      	  if (args.length>4) {
        	      	  for (i=4;i<args.length;i++) {
    	      	  	      Params[4]=Params[4]+"_"+args[i];
    	          	  }
    	          }
    	      }    	      
    	      PrintWriter writerParams = null;
    	      try {
                writerParams = new PrintWriter(new FileWriter("Params.txt"));
                for (i=0; i<Params.length; i++) {
                     writerParams.println(Params[i]);
                }
            }
            catch (IOException ex) {}
            finally {
                writerParams.close();
            }    	  
    	  
            String[] cmd = {RProgram,  "CMD", "BATCH", "--no-save",  RRunfile}; 
            Runtime rt=Runtime.getRuntime();                             
            try {
                Process process=rt.exec(cmd);
                process.waitFor();
            }  
            catch (IOException e1){}
            catch (InterruptedException e2) {}  // for p.waitFor    	

            //rm 
            String[] cls = {"rm", "Code.Rout"}; 
            rt=Runtime.getRuntime();                             
            try {
                Process process=rt.exec(cls);
                process.waitFor();
            }  
            catch (IOException e1){}
            catch (InterruptedException e2) {}  // for p.waitFor   
            
                                             	
        }
    }
}
