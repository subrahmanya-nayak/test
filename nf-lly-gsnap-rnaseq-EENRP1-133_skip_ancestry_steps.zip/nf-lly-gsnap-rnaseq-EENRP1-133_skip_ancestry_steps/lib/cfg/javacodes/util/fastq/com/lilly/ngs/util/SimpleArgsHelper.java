package com.lilly.ngs.util;

import java.io.*;
import java.util.*;
import java.util.regex.*;



/*

    Simple helper class (somewhat ala perl's GetOpt::Std) to split the args and parse flags and options...
    Recognizes one-character options (with and without values) and "naked" arguments

    Follows GetOpt::Std's simple formatting
      eg "vsa:f:x" will accept -v, -s, and -x flags/switches and a single (string) value is required for -a and -f

    All values go to String arrays to generically allow multiple values to be specified
    "Naked" arguments are added in order to ARGUMENTS_HASH_KEY

*/



public class SimpleArgsHelper
{
    public static final String ARGUMENTS_HASH_KEY = "ARGUMENT_HASH_KEY";
    public static Hashtable<String, ArrayList<String>> parseSimpleOpts(String[] args, String optionsDescription) throws IllegalArgumentException
    {
        Hashtable<String, ArrayList<String>> retVal = new Hashtable<String, ArrayList<String>>();

        //validate optionsDescription and identify options vs flags
        if (optionsDescription == null)
        {
            throw new IllegalArgumentException("optionsDescription cannot be null");
        }
        else if (optionsDescription.length() == 0)
        {
            throw new IllegalArgumentException("optionsDescription cannot be empty");
        }
        else if (!Pattern.matches("^[0-9A-Za-z:]+$", optionsDescription))
        {
            throw new IllegalArgumentException("Specified optionsDescription contained invalid characters");
        }
        ArrayList<String> flags = new ArrayList<String>();
        ArrayList<String> opts = new ArrayList<String>();
        for (int i=0; i<optionsDescription.length(); i++)
        {
            String opt = ""+optionsDescription.charAt(i);
            if (":".equals(opt)) { continue; }
            if (flags.contains(opt) || opts.contains(opt))
            {
                throw new IllegalArgumentException("Duplicated character ("+opt+") found in optionsDescription");
            }
            if (i+1 < optionsDescription.length() && optionsDescription.charAt(i+1) == ':')
            {
                opts.add(opt);
            }
            else
            {
                flags.add(opt);
            }
        }

        //so far, so good...
        //Let's split things up
        ArrayList<String> argsArray = new ArrayList<String>();
        for (int i=0; i<args.length; i++) { argsArray.add(args[i]); }

        int argNbr = 0;
        while (argsArray.size() > 0)
        {
            String arg = argsArray.remove(0); argNbr++;

            //special cases first...  treat as a naked argument ("-" is a common unix alias for stdout...)
            if (arg.length() == 0 || "-".equals(arg) || arg.startsWith("--") || !arg.startsWith("-"))
            {
                if (!retVal.containsKey(ARGUMENTS_HASH_KEY)) { retVal.put(ARGUMENTS_HASH_KEY, new ArrayList<String>()); }
                retVal.get(ARGUMENTS_HASH_KEY).add(arg);
            }
            else //must startWith "-"
            {
                if (arg.length() > 2)
                {
                    String presumedOpt = arg.substring(1,2);
                    String presumedVal = arg.substring(2);
                    if (!opts.contains(presumedOpt))
                    {
                        throw new IllegalArgumentException("Flag -"+presumedOpt+" cannot have a value: "+arg);
                    }
                    else
                    {
                        if (!retVal.containsKey(presumedOpt)) { retVal.put(presumedOpt, new ArrayList<String>()); }
                        retVal.get(presumedOpt).add(presumedVal);
                    }
                }
                else // arg.length() == 2
                {
                    String opt = ""+arg.charAt(1);
                    if (opts.contains(opt))
                    {
                        if (argsArray.size() == 0)
                        {
                            throw new IllegalArgumentException("No value specified for option "+arg);
                        }
                        else
                        {
                            //edge case: for "a:b", cmdline /-a -b/ would makes -b a value of -a...  I guess this is ok
                            // tests for arg/option validity should catch things like this
                            String val = argsArray.remove(0); argNbr++;
                            if (!retVal.containsKey(opt)) { retVal.put(opt, new ArrayList<String>()); }
                            retVal.get(opt).add(val);
                        }
                    }
                    else //flag
                    {
                        if (!retVal.containsKey(opt)) { retVal.put(opt, new ArrayList<String>()); }
                        retVal.get(opt).add("true");
                    }
                }
            }
        }

        return retVal;
    }


    public static boolean canReadFile(String filename, boolean verbose, boolean throwExceptionOnFailure) throws IOException
    {
        String exceptionMessage = null;
        File file = new File(filename);
        if (!file.isFile())
        {
            exceptionMessage = "ERROR: Specified filename is invalid: "+filename;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IllegalArgumentException(exceptionMessage); }
        }
        else if (!file.exists())
        {
            exceptionMessage = "ERROR: Specified file does not exist: "+filename;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IOException(exceptionMessage); }
        }
        else if (!file.canRead())
        {
            try
            {
                exceptionMessage = "ERROR: Cannot read specified file: "+file.getCanonicalPath();
                if (verbose) { System.out.println(exceptionMessage); }
                if (throwExceptionOnFailure) { throw new IOException(exceptionMessage); }
            }
            catch (IOException ioe)
            {
                exceptionMessage = "ERROR: Cannot read specified filename -- inner exception: "+ioe.getMessage();
                if (verbose) { System.out.println(exceptionMessage); }
                if (throwExceptionOnFailure) { throw new IOException(exceptionMessage); }
            }
        }
        return (exceptionMessage == null);
    }


    public static boolean canWriteFile(String filename, boolean verbose, boolean throwExceptionOnFailure) throws IllegalArgumentException, IOException
    {
        String exceptionMessage = null;
        File file = new File(filename);
        if (file.isDirectory())
        {
            exceptionMessage = "ERROR: Specified filename looks like a directory: "+filename;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IllegalArgumentException(exceptionMessage); }
        }
        else if (file.exists() && !file.canWrite())
        {
            try
            {
                exceptionMessage = "ERROR: Cannot write to specified file: "+file.getCanonicalPath();
                if (verbose) { System.out.println(exceptionMessage); }
                if (throwExceptionOnFailure) { throw new IOException(exceptionMessage); }
            }
            catch (IOException ioe)
            {
                exceptionMessage = "ERROR: Cannot write to specified filename -- inner exception: "+ioe.getMessage();
                if (verbose) { System.out.println(exceptionMessage); }
                if (throwExceptionOnFailure) { throw new IOException(exceptionMessage); }
            }
        }
        return (exceptionMessage == null);
    }


    public static boolean canWriteToDirectory(String dirname, boolean verbose, boolean throwExceptionOnFailure) throws IllegalArgumentException, IOException
    {
        String exceptionMessage = null;
        File dir = new File(dirname);
        if (!dir.isDirectory())
        {
            exceptionMessage = "ERROR: Specified temp directory is invalid: "+dirname;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IllegalArgumentException(exceptionMessage); }
        }
        else if (!dir.exists())
        {
            exceptionMessage = "ERROR: Specified temp directory does not exist: "+dirname;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IllegalArgumentException(exceptionMessage); }
        }
        else if (!dir.canRead())
        {
            exceptionMessage = "ERROR: Cannot read specified temp directory: "+dirname;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IOException(exceptionMessage); }
        }
        else if (!dir.canWrite())
        {
            exceptionMessage = "ERROR: Cannot write to specified temp directory: "+dirname;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IOException(exceptionMessage); }
        }
        return (exceptionMessage == null);
    }


    public static boolean isValidMD5(String md5, boolean verbose, boolean throwExceptionOnFailure) throws IllegalArgumentException
    {
        String exceptionMessage = null;
        if (md5.length() != 32)
        {
            exceptionMessage = "ERROR: Specified MD5 checksum is not 32 characters long: "+md5;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IllegalArgumentException(exceptionMessage); }
        }
        else if (!md5.toLowerCase().matches("^[0-9a-z]+$"))
        {
            exceptionMessage = "ERROR: Specified MD5 checksum contains non-alphanumeric characters: "+md5;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IllegalArgumentException(exceptionMessage); }
        }
        else if (!md5.matches("^[0-9a-z]+$"))
        {
            exceptionMessage = "ERROR: Specified MD5 checksum contains uppercase characters: "+md5;
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IllegalArgumentException(exceptionMessage); }
        }
        return (exceptionMessage == null);
    }


    public static boolean isInArray(String str, String[] strArr, boolean verbose, boolean throwExceptionOnFailure) throws IllegalArgumentException
    {
        String exceptionMessage = null;
        boolean found = false;
        for (int i=0; i<strArr.length; i++)
        {
            if (strArr[i].equals(str))
            {
                found = true;
                break;
            }
        }
        if (!found)
        {
            exceptionMessage = "ERROR: Specified string ("+str+") is not in list ("+strArr[0];
            for (int i=1; i<strArr.length; i++)
            {
                exceptionMessage += ","+strArr[i];
            }
            exceptionMessage += ")";
            if (verbose) { System.out.println(exceptionMessage); }
            if (throwExceptionOnFailure) { throw new IllegalArgumentException(exceptionMessage); }
        }
        return (exceptionMessage == null);
    }


    public static ArrayList<String> convertToCanonicalPaths(ArrayList<String> filenames) throws IOException
    {
        ArrayList<String> retVal = new ArrayList<String>();
        for (int i=0; i<filenames.size(); i++)
        {
            retVal.add((new File(filenames.get(i))).getCanonicalPath());
        }
        return retVal;
    }
}