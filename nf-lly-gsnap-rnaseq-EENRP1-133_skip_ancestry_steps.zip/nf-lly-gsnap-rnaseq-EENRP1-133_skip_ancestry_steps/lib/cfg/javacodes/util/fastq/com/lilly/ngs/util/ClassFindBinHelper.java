package com.lilly.ngs.util;

/*

    Simple helper to perform a role similar to FindBin in perl...  Very helpful for resolving paths relative to 

*/

public class ClassFindBinHelper
{
    public static String findPathToClass(String classToFind)
    {
        String path = null;
        try
        {
            ClassLoader classLoader = ClassLoader.getSystemClassLoader();
            Class clazz = classLoader.loadClass(classToFind);
            //String codePath = clazz.getProtectionDomain().getCodeSource().getLocation().getPath();
            String codeFile = clazz.getProtectionDomain().getCodeSource().getLocation().getFile();
            path = codeFile; //note that this might be a jar...
        }
        catch (ClassNotFoundException cnfe)
        {
            //do nothing...
        }
        return path;
    }

    public static String getCallingClassName()
    {
        String callingClassName = (new Throwable()).getStackTrace()[1].getClassName();
        return callingClassName;
    }

    public static void main(String[] args) throws Exception
    {
        if (args.length != 1)
        {
            String currentClass = (new Throwable()).getStackTrace()[0].getClassName();
            System.out.println("SYNTAX: java "+currentClass+" [class-name]");
            if (args.length == 0)
            {
                System.out.println("Defaulting to "+currentClass);
                args = new String[1];
                args[0] = currentClass;
/*
                Throwable throwable = new Throwable();
                StackTraceElement[] stes = throwable.getStackTrace();
                for (int i=0; i<stes.length; i++)
                {
                    System.out.println("Stack depth "+i+" - "+stes[i].getClassName()+"."+stes[i].getMethodName()+" (line: "+stes[i].getLineNumber()+" of "+stes[i].getFileName()+")");
                }
*/
            }
        }
        if (args.length == 1)
        {
            String classToFind = args[0];
            ClassLoader classLoader = ClassLoader.getSystemClassLoader();
            System.out.println(classLoader);
//            Class loadedClass = classLoader.findLoadedClass(classToFind);
//            System.out.println(loadedClass);
//            Class clazz = classLoader.findClass(classToFind);
            Class clazz = classLoader.loadClass(classToFind);
            System.out.println(clazz);
            System.out.println(clazz.getProtectionDomain());
            System.out.println(clazz.getProtectionDomain().getCodeSource());
            System.out.println(clazz.getProtectionDomain().getCodeSource().getLocation());
            System.out.println(clazz.getProtectionDomain().getCodeSource().getLocation().getPath());
            System.out.println(clazz.getProtectionDomain().getCodeSource().getLocation().getFile());
            System.out.println("Reported path to "+classToFind+": "+findPathToClass(classToFind));
        }
    }
}