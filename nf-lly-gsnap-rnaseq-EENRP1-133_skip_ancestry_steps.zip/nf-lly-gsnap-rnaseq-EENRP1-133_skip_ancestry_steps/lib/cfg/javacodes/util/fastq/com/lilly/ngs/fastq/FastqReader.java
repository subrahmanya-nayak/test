package com.lilly.ngs.fastq;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.*;
import java.util.zip.*;
import java.security.MessageDigest;
import java.security.DigestInputStream;
import java.security.NoSuchAlgorithmException;


public class FastqReader
{
    private static SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

    private File fastqFile = null;
    private BufferedInputStream readStream = null;
    private MessageDigest md5Digest = null;
    private String finalMD5digest = null;

    public static int MAX_ALLOWED_READID_LENGTH         = 1024;         // read id length limited to 1kb
    public static int MAX_ALLOWED_READIDLINE_LENGTH     = 65536;        // read id LINE is allowed to be MUCH longer -- 64kb total
    public static int MAX_ALLOWED_READ_LENGTH           = 250000000;    // read length limited to 250mb
    public static int MAX_ALLOWED_SEPARATORLINE_LENGTH  = MAX_ALLOWED_READIDLINE_LENGTH;
    public static int MAX_ALLOWED_QUALITY_LENGTH        = MAX_ALLOWED_READ_LENGTH;
    //we could have 2-4x the associated numbers of characters...


    //----------------------------------------------------------------
    //----------------------------------------------------------------
    //Gotta love a good state machine...
    private static final int STATE_PREREAD                       =  0; //consume @ to start
    //----------------------------------------------------------------
    private static final int STATE_PRE_READID                    =  1; //post @
    private static final int STATE_IN_READID                     =  2;
    private static final int STATE_IN_READID_CR                  =  3;
    private static final int STATE_PRE_READ_DESCRIPTION          =  4; //found id/description delim
    private static final int STATE_PRE_READ_DESCRIPTION_CR       =  5;
    private static final int STATE_IN_READ_DESCRIPTION           =  6;
    private static final int STATE_IN_READ_DESCRIPTION_CR        =  7;
    private static final int STATE_IN_READID_LF                  =  8;
    //----------------------------------------------------------------
    private static final int STATE_IN_NOREAD_CR                  =  9;
    private static final int STATE_IN_NOREAD_LF                  = 10;
    //----------------------------------------------------------------
    private static final int STATE_IN_READ                       = 11;
    private static final int STATE_IN_READ_CR                    = 12;
    private static final int STATE_IN_READ_LF                    = 13;
    private static final int STATE_IN_MULTILINE_READ             = 14;
    private static final int STATE_IN_MULTILINE_READ_CR          = 15;
    private static final int STATE_IN_MULTILINE_READ_LF          = 16;
    //----------------------------------------------------------------
    private static final int STATE_IN_SEPARATOR                  = 17; //post +
    private static final int STATE_IN_SEPARATOR_CR               = 18;
    private static final int STATE_IN_SEP_READID                 = 19;
    private static final int STATE_IN_SEP_READID_CR              = 20;
    private static final int STATE_PRE_SEP_READ_DESCRIPTION      = 21; //found id/desc delim
    private static final int STATE_PRE_SEP_READ_DESCRIPTION_CR   = 22;
    private static final int STATE_IN_SEP_READ_DESCRIPTION       = 23;
    private static final int STATE_IN_SEP_READ_DESCRIPTION_CR    = 24;
    private static final int STATE_IN_SEPARATOR_LF               = 25;
    //----------------------------------------------------------------
    private static final int STATE_IN_NOQUALITY_CR               = 26;
    private static final int STATE_IN_NOQUALITY_LF               = 27;
    private static final int STATE_IN_QUALITY                    = 28;
    private static final int STATE_IN_QUALITY_CR                 = 29;
    private static final int STATE_IN_QUALITY_LF                 = 30;
    private static final int STATE_IN_MULTILINE_QUALITY          = 31;
    private static final int STATE_IN_MULTILINE_QUALITY_CR       = 32;
    private static final int STATE_IN_MULTILINE_QUALITY_LF       = 33;
    //----------------------------------------------------------------
    private static final int STATE_PARSE_ERROR                   = 99;
    private static final int STATE_DONE                          = 34;
    private static final int STATE_PAST_EOF                      = 35;
    private static final int STATE_CLOSED                        = -1;
    //----------------------------------------------------------------
    //----------------------------------------------------------------
    private int state = STATE_PREREAD;


    //characters of special importance
    private static final int CHAR_EOF     =  -1;
    private static final int CHAR_AT      =  64;
    private static final int CHAR_SPACE   =  32;
    private static final int CHAR_BANG    =  33;
    private static final int CHAR_TAB     =   9;
    private static final int CHAR_CR      =  13;
    private static final int CHAR_LF      =  10;
    private static final int CHAR_PLUS    =  43;
    private static final int CHAR_TILDE   = 126;


    private long currentLine = 1; //not-yet-terminated line number
    private int currentLineLength = 0;
    private int currentRead = 1; //not-yet-terminated read number
    private int currentReadIdLength = 0;
    private int currentReadDescriptionLength = 0;
    private int currentReadLength = 0;
    private int expectedQualityLength = 0;
    private int currentSeparatorLineLength = 0;
    private int currentQualityLength = 0;
    private boolean currentReadIncludesLowercase = false;


    //informational counts
    long fqReadIdSpaceDescriptionCount=0;
    long fqReadNoDescriptionCount=0;

    //counts indicating issues that don't quite qualify as errors
    long fqCRLFLineCount=0;
    long fqReadIdTabDescriptionCount=0;
    long fqReadEmptyDescriptionCount=0;
    long fqMultiLineReadCount=0;
    long fqMultiLineQualityCount=0;


    // -- To feed to FastqRead constructor...
    //all sans trailing LF - preserve trailing CR if present
    private StringBuilder rawTitleLine      = new StringBuilder();
    private StringBuilder rawReadBlock      = new StringBuilder();
    private StringBuilder rawSeparatorLine  = new StringBuilder();
    private StringBuilder rawQualityBlock   = new StringBuilder();
    //NOTE: It is TECHNICALLY possible (in an extremely pathological case) to have the
    //      RAW read block and quality block be ~3x the size of the "clean" versions

    //standardized/clean format
    private StringBuilder readId            = new StringBuilder();
    private StringBuilder readDescription   = new StringBuilder();
    private StringBuilder readBlock         = new StringBuilder();
    private final String separatorLine      = "+";
    private StringBuilder qualityBlock      = new StringBuilder();
    //There's roughly a 25% time penalty for keeping both...  And storage...
    //  Could keep just the clean and add flags
    //    -- or --
    //  Just keep the raw and let standardization and validation logic live in FastqRead 
    //A single read should never really be very big and the time isn't that big a deal for a single read...
    //BUT...  Time does add up.  So it's handy to have options for getting reads:
    // 1. Raw
    //    Most useful/performant for validation.  (To test reads, get raw and have the read test itself for cleanliness/standardness)
    // 2. Standardized/clean
    //    Most handy when performing any kind of re-write (batch separation or just standardization)
    // 3. Both...
    //    The I/O is generally the expensive part and converting raw to standard is "cheap", but the parser already could have
    //    generated both forms as the stream was being read (rather than on-demand parsing from raw to standardized).



    public FastqReader(String fastqFilename) throws FileNotFoundException, NoSuchAlgorithmException, IOException
    {
        this.fastqFile = new File(fastqFilename);

        //SHA-{1,224,256,384,512} also available per jdk1.8.0_144/docs/technotes/guides/security/StandardNames.html#MessageDigest
        md5Digest = MessageDigest.getInstance("MD5");

        // removing any of the buffered streams cost at least 10x time
        readStream = new BufferedInputStream(new GZIPInputStream(
                        new BufferedInputStream(new DigestInputStream(
                        new BufferedInputStream(new FileInputStream(fastqFile)), md5Digest))));
    }


    private static String getHexString(byte[] bytes)
    {
        String retVal = null;
        if (bytes == null)
        {
            retVal = null;
        }
        else
        {
            StringBuilder sb = new StringBuilder(2*bytes.length);
            for (int i=0; i<bytes.length; i++)
            {
                sb.append(String.format("%02x",bytes[i]));
            }
            retVal = sb.toString();
        }
        return retVal;
    }


    public void close() throws IOException
    {
        if (state != FastqReader.STATE_CLOSED)
        {
            state = FastqReader.STATE_CLOSED;
            finalMD5digest = getHexString(md5Digest.digest());
            readStream.close();
            readStream = null;
            md5Digest = null;
            fastqFile = null;

            currentLine = currentLineLength = currentRead = currentReadIdLength = 0;
            currentReadDescriptionLength = currentReadLength = expectedQualityLength = 0;
            currentSeparatorLineLength = currentQualityLength = 0;

            rawTitleLine = rawReadBlock = rawSeparatorLine = rawQualityBlock = null;
            readId = readDescription = readBlock = qualityBlock = null;
        }
    }


    public String getFinalMD5()
    {
        return finalMD5digest;
    }


    public FastqRead getNextRawRead() throws IOException
    {
        FastqRead fqRead = null;
        if (state == FastqReader.STATE_CLOSED)
        {
            throw new IllegalStateException("FastqReader has already been closed");
        }

        String parseErrorDetails = null;
        if (state == FastqReader.STATE_DONE)
        {
            state = FastqReader.STATE_PAST_EOF;
        }

        //ELSE...
        characterConsumptionLoop:
        while (state != FastqReader.STATE_DONE &&
               state != FastqReader.STATE_PAST_EOF &&
               state != FastqReader.STATE_PARSE_ERROR)
        {
            int c = readStream.read(); if (c != FastqReader.CHAR_EOF) { currentLineLength++; }
            switch (state)
            {
                case FastqReader.STATE_PREREAD:
                    switch (c)
                    {
                        case FastqReader.CHAR_AT:
                            state = FastqReader.STATE_PRE_READID;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "File was empty?!?";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected read id line start character: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_PRE_READID:
                    //This is a convenient state in which to reset the current "read"
                    // Seeing '@' as the first character on a line is how we get to this state
                    // so clear everything, add the '@', and then handle whatever follows
                    //-------------------------------
                    currentLineLength = currentReadIdLength = 0;
                    currentReadDescriptionLength = currentReadLength = expectedQualityLength = 0;
                    currentSeparatorLineLength = currentQualityLength = 0;
                    currentReadIncludesLowercase = false;
                    //-------------------------------
                    rawTitleLine.setLength(0);
                    rawReadBlock.setLength(0);
                    rawSeparatorLine.setLength(0);
                    rawQualityBlock.setLength(0);
                    //-------------------------------
                    currentLineLength++;
                    rawTitleLine.append('@');
                    //-------------------------------
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate read id character
                        rawTitleLine.append((char)c);
                        currentReadIdLength++;
                        state = FastqReader.STATE_IN_READID;
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> immediately after @ on title line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Read id missing or malformed";
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_READID:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate read id character
                        rawTitleLine.append((char)c);
                        currentReadIdLength++;
                        if (currentReadIdLength > FastqReader.MAX_ALLOWED_READID_LENGTH)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of read id exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READID_LENGTH+")";
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_TAB:
                                rawTitleLine.append((char)c);
                                state = FastqReader.STATE_PRE_READ_DESCRIPTION;
                                fqReadIdTabDescriptionCount++;
                                break;
                            case FastqReader.CHAR_SPACE:
                                rawTitleLine.append((char)c);
                                state = FastqReader.STATE_PRE_READ_DESCRIPTION;
                                fqReadIdSpaceDescriptionCount++;
                                break;
                            case FastqReader.CHAR_CR:
                                rawTitleLine.append((char)c);
                                state = FastqReader.STATE_IN_READID_CR;
                                fqReadNoDescriptionCount++;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_READID_LF;
                                currentLine++; currentLineLength = 0;
                                fqReadNoDescriptionCount++;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> in read id on title line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Found unexpected character in read id: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_READID_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READID_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in title line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_PRE_READ_DESCRIPTION:
                    if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                    {
                        //legitimate read description character
                        rawTitleLine.append((char)c);
                        currentReadDescriptionLength++;
                        state = FastqReader.STATE_IN_READ_DESCRIPTION;
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawTitleLine.append((char)c);
                                state = FastqReader.STATE_PRE_READ_DESCRIPTION_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_READID_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> in read description on title line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Found unexpected character in read description: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_PRE_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READID_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF>";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ_DESCRIPTION:
                    if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                    {
                        //legitimate read description character
                        rawTitleLine.append((char)c);
                        currentReadDescriptionLength++;
                        if (1+currentReadIdLength+1+currentReadDescriptionLength > FastqReader.MAX_ALLOWED_READIDLINE_LENGTH)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of read id line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READIDLINE_LENGTH+")";
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawTitleLine.append((char)c);
                                if (currentReadDescriptionLength == 0) { fqReadEmptyDescriptionCount++; }
                                state = FastqReader.STATE_IN_READ_DESCRIPTION_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                if (currentReadDescriptionLength == 0) { fqReadEmptyDescriptionCount++; }
                                state = FastqReader.STATE_IN_READID_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> in read description";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found in read description: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READID_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in read description";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in read description after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READID_LF:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            rawReadBlock.append((char)c);
                            currentReadLength++;
                            state = FastqReader.STATE_IN_READ;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_CR:
                            rawReadBlock.append((char)c);
                            state = FastqReader.STATE_IN_NOREAD_CR;
                            break;
                        case FastqReader.CHAR_LF:
                            state = FastqReader.STATE_IN_NOREAD_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately before read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character at start of read block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_NOREAD_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_NOREAD_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> at end of empty read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in empty read block after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_NOREAD_LF:
                    switch (c)
                    {
                        case FastqReader.CHAR_PLUS:
                            rawSeparatorLine.append((char)c);
                            state = FastqReader.STATE_IN_SEPARATOR;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after empty read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            rawReadBlock.append((char)c);
                            currentReadLength++;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_CR:
                            rawReadBlock.append((char)c);
                            state = FastqReader.STATE_IN_READ_CR;
                            break;
                        case FastqReader.CHAR_LF:
                            rawReadBlock.append((char)c);         //trim later if not multi-line
                            state = FastqReader.STATE_IN_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character in read line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            rawReadBlock.append((char)c);         //trim later if not multi-line
                            state = FastqReader.STATE_IN_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in read line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ_LF:
                    switch (c)
                    {
                        case CHAR_PLUS:
                            rawReadBlock.setLength(rawReadBlock.length()-1); //trim trailing LF
                            rawSeparatorLine.append((char)c);
                            state = FastqReader.STATE_IN_SEPARATOR;
                            //and now we know the expected quality length
                            expectedQualityLength = currentReadLength;
                            break;
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character -- multiline read
                            fqMultiLineReadCount++;
                            rawReadBlock.append((char)c);
                            currentReadLength++;
                            state = FastqReader.STATE_IN_MULTILINE_READ;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in read block";
                            break;
                        default:    
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_READ:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            rawReadBlock.append((char)c);
                            currentReadLength++;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_CR:
                            rawReadBlock.append((char)c);
                            state = FastqReader.STATE_IN_MULTILINE_READ_CR;
                            break;
                        case FastqReader.CHAR_LF:
                            rawReadBlock.append((char)c); //trim later if trailing
                            state = FastqReader.STATE_IN_MULTILINE_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in multi-line read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found character in multi-line read block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_READ_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            rawReadBlock.append((char)c); //trim later if trailing
                            state = FastqReader.STATE_IN_MULTILINE_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in multi-line read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in read block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_READ_LF:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            rawReadBlock.append((char)c);
                            state = FastqReader.STATE_IN_MULTILINE_READ;
                            currentReadLength++;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case CHAR_PLUS:
                            rawReadBlock.setLength(rawReadBlock.length()-1); //trim trailing LF (since not NOREAD and we found the end)
                            rawSeparatorLine.append((char)c);
                            state = FastqReader.STATE_IN_SEPARATOR;
                            //and now we know the expected quality length
                            expectedQualityLength = currentReadLength;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in multi-line read block";
                            break;
                        default:    
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEPARATOR:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate read id character -- looks like we might have a repeat of the read id (and description)
                        rawSeparatorLine.append((char)c);
                        state = FastqReader.STATE_IN_SEP_READID;
                        //we'll worry about the length during parsing... but @(.+) and +(.+) matching is only warning-worthy since + gets stripped
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawSeparatorLine.append((char)c);
                                state = FastqReader.STATE_IN_SEPARATOR_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_SEPARATOR_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> immediately after + on separator line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Found unexpected character immediately after + on separator line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_SEPARATOR_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> on separator line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READID:
                    //worry about the approx length during parsing... @ and + matching is only warning-worthy since + gets stripped
                    if (currentLineLength > MAX_ALLOWED_SEPARATORLINE_LENGTH)
                    {
                        state = FastqReader.STATE_PARSE_ERROR;
                        parseErrorDetails = "Length of separator line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_SEPARATORLINE_LENGTH+")";
                    }
                    else
                    {
                        if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                        {
                            //legitimate read id character
                            rawSeparatorLine.append((char)c);
                        }
                        else
                        {
                            switch (c)
                            {
                                case FastqReader.CHAR_TAB:
                                case FastqReader.CHAR_SPACE:
                                    rawSeparatorLine.append((char)c);
                                    state = FastqReader.STATE_PRE_SEP_READ_DESCRIPTION;
                                    break;
                                case FastqReader.CHAR_CR:
                                    rawSeparatorLine.append((char)c);
                                    state = FastqReader.STATE_IN_SEP_READID_CR;
                                    break;
                                case FastqReader.CHAR_LF:
                                    state = FastqReader.STATE_IN_SEPARATOR_LF;
                                    currentLine++; currentLineLength = 0;
                                    break;
                                case FastqReader.CHAR_EOF:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected <EOF> in read id on separator line";
                                    break;
                                default:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Found unexpected character in read id on separator line: "+((char)c);
                                    break;
                            }
                        }
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READID_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> on separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_PRE_SEP_READ_DESCRIPTION:
                    //worry about the approx length during parsing... @ and + matching is only warning-worthy since + gets stripped
                    if (currentLineLength > MAX_ALLOWED_SEPARATORLINE_LENGTH)
                    {
                        state = FastqReader.STATE_PARSE_ERROR;
                        parseErrorDetails = "Length of separator line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_SEPARATORLINE_LENGTH+")";
                    }
                    else
                    {
                        if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                        {
                            //legitimate read description character
                            rawSeparatorLine.append((char)c);
                            state = FastqReader.STATE_IN_SEP_READ_DESCRIPTION;
                        }
                        else
                        {
                            switch (c)
                            {
                                case FastqReader.CHAR_CR:
                                    rawSeparatorLine.append((char)c);
                                    state = FastqReader.STATE_PRE_SEP_READ_DESCRIPTION_CR;
                                    break;
                                case FastqReader.CHAR_LF:
                                    state = FastqReader.STATE_IN_SEPARATOR_LF;
                                    currentLine++; currentLineLength = 0;
                                    break;
                                case FastqReader.CHAR_EOF:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected <EOF> in read description on separator line";
                                    break;
                                default:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Found unexpected character in read description on separator line: "+((char)c);
                                    break;
                            }
                        }
                    }
                    break;

                case FastqReader.STATE_PRE_SEP_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> in separator read description but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READ_DESCRIPTION:
                    //worry about the approx length during parsing... @ and + matching is only warning-worthy since + gets stripped
                    if (currentLineLength > MAX_ALLOWED_SEPARATORLINE_LENGTH)
                    {
                        state = FastqReader.STATE_PARSE_ERROR;
                        parseErrorDetails = "Length of separator line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_SEPARATORLINE_LENGTH+")";
                    }
                    else
                    {
                        if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                        {
                            //legitimate read description character
                            rawSeparatorLine.append((char)c);
                        }
                        else
                        {
                            switch (c)
                            {
                                case FastqReader.CHAR_CR:
                                    rawSeparatorLine.append((char)c);
                                    state = FastqReader.STATE_IN_SEP_READ_DESCRIPTION_CR;
                                    break;
                                case FastqReader.CHAR_LF:
                                    state = FastqReader.STATE_IN_SEPARATOR_LF;
                                    currentLine++; currentLineLength = 0;
                                    break;
                                case FastqReader.CHAR_EOF:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected <EOF> in separator line read description";
                                    break;
                                default:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected character found in separator line read description: "+((char)c);
                                    break;
                            }
                        }
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in read description on separator line after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEPARATOR_LF:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate quality character
                        rawQualityBlock.append((char)c);
                        currentQualityLength++;
                        state = FastqReader.STATE_IN_QUALITY;
                        if (currentQualityLength > expectedQualityLength)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of quality was expected to be zero!"; //only way to exceed the expected length here
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawQualityBlock.append((char)c);
                                state = FastqReader.STATE_IN_NOQUALITY_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                rawQualityBlock.append((char)c);
                                state = FastqReader.STATE_IN_NOQUALITY_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> before quality block";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found at start of quality line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_NOQUALITY_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_NOQUALITY_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in empty quality block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in empty quality block after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_NOQUALITY_LF:
                    switch (c)
                    {
                        case FastqReader.CHAR_AT:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                rawQualityBlock.setLength(rawQualityBlock.length()-1); //trim trailing LF
                                currentRead++; //other counters reset via entry to STATE_PRE_READID
                                state = FastqReader.STATE_PRE_READID;
                                break characterConsumptionLoop; //from character-reading while loop
                            }
                            break;
                        case FastqReader.CHAR_EOF:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length at end of file: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                //bit of an edge case, but allowing EOF in place of trailing LF while parsing seems reasonable to me
                                state = FastqReader.STATE_DONE;
                            }
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_QUALITY:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate quality character
                        rawQualityBlock.append((char)c);
                        currentQualityLength++;
                        if (currentQualityLength > expectedQualityLength)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of quality exceeds expected length: >"+expectedQualityLength;
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawQualityBlock.append((char)c);
                                state = FastqReader.STATE_IN_QUALITY_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                rawQualityBlock.append((char)c); //trailing LF trimmed later
                                state = FastqReader.STATE_IN_QUALITY_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                if (currentQualityLength != expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Mismatch between read length and quality length at end of file: "+expectedQualityLength+" != "+currentQualityLength;
                                }
                                else
                                {
                                    //bit of an edge case, but allowing EOF in place of trailing LF while parsing seems reasonable to me
                                    state = FastqReader.STATE_DONE;
                                }
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found in quality line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_QUALITY_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_QUALITY_LF; //need to check for multi-line
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "File ended unexpectedly character after <CR> on quality line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in quality line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_QUALITY_LF:
                    switch (c)
                    {
                        //unusual order here for fall-through
                        case FastqReader.CHAR_EOF:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                //expected case for EOF  :-)
                                rawQualityBlock.setLength(rawQualityBlock.length()-1); //trim trailing LF
                                state = FastqReader.STATE_DONE;
                                currentLine--;
                            }
                            break;
                        case FastqReader.CHAR_AT:
                            if (currentQualityLength == expectedQualityLength)
                            {
                                rawQualityBlock.setLength(rawQualityBlock.length()-1); //trim trailing LF
                                currentRead++; //other counters reset via entry to STATE_PRE_READID
                                state = FastqReader.STATE_PRE_READID;
                                break characterConsumptionLoop; //from character-reading while loop
                            }
                            //else fall through to handle the encountered @ as a quality character
                        default:
                            if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                            {
                                //legitimate quality character -- multi-line
                                rawQualityBlock.append((char)c);
                                currentQualityLength++;
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY;
                                fqMultiLineQualityCount++;
                                if (currentQualityLength > expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Length of quality exceeds expected length: >"+expectedQualityLength;
                                }
                            }
                            else
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found after end of quality line: "+((char)c);
                            }
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_QUALITY:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate quality character
                        rawQualityBlock.append((char)c);
                        currentQualityLength++;
                        if (currentQualityLength > expectedQualityLength)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of quality block exceeds expected length: >"+expectedQualityLength;
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawQualityBlock.append((char)c);
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                rawQualityBlock.append((char)c); //trailing LF trimmed later
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                if (currentQualityLength != expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                                }
                                else
                                {
                                    //edge case...?
                                    state = FastqReader.STATE_DONE;
                                }
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found in quality line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_QUALITY_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_MULTILINE_QUALITY_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "File ended unexpectedly character after <CR> in quality block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in quality block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_QUALITY_LF:
                    switch (c)
                    {
                        case FastqReader.CHAR_EOF:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                //an expected end state
                                rawQualityBlock.setLength(rawQualityBlock.length()-1); //trim trailing LF
                                state = FastqReader.STATE_DONE;
                                currentLine--;
                            }
                            break;
                        case FastqReader.CHAR_AT:
                            if (currentQualityLength == expectedQualityLength)
                            {
                                currentRead++; //other counters reset via entry to STATE_PRE_READID
                                state = FastqReader.STATE_PRE_READID;
                                break characterConsumptionLoop; //from character-reading while loop
                            }
                            //else fall through to handle as a quality character
                        default:
                            if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                            {
                                //legitimate quality character -- multi-line
                                rawQualityBlock.append((char)c);
                                currentQualityLength++;
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY;
                                if (currentQualityLength > expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Length of quality exceeds expected length: >"+expectedQualityLength;
                                }
                            }
                            else
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found after end of quality line: "+((char)c);
                            }
                            break;
                    }
                    break;

                default:
                    state = FastqReader.STATE_PARSE_ERROR;
                    parseErrorDetails = "Found unexpected character for parser state #"+state+": "+((char)c);
                    break;
            }
        }

        //expect one of four states: STATE_PRE_READID, STATE_PARSE_ERROR, STATE_DONE, STATE_PAST_EOF
        // the first and third get a non-null fqRead
        if (state == FastqReader.STATE_PRE_READID || state == FastqReader.STATE_DONE)
        {
            fqRead = new FastqRead( rawTitleLine.toString(),
                                    rawReadBlock.toString(),
                                    rawSeparatorLine.toString(),
                                    rawQualityBlock.toString() );
        }
        else if (state == FastqReader.STATE_PARSE_ERROR)
        {
            throw new IOException(parseErrorDetails);
        }

        return fqRead;
    }


    public FastqRead getNextRead() throws IOException
    {
        FastqRead fqRead = null;
        if (state == FastqReader.STATE_CLOSED)
        {
            throw new IllegalStateException("FastqReader has already been closed");
        }

        String parseErrorDetails = null;
        if (state == FastqReader.STATE_DONE)
        {
            state = FastqReader.STATE_PAST_EOF;
        }

        //ELSE...
        characterConsumptionLoop:
        while (state != FastqReader.STATE_DONE &&
               state != FastqReader.STATE_PAST_EOF &&
               state != FastqReader.STATE_PARSE_ERROR)
        {
            int c = readStream.read(); if (c != FastqReader.CHAR_EOF) { currentLineLength++; }
            switch (state)
            {
                case FastqReader.STATE_PREREAD:
                    switch (c)
                    {
                        case FastqReader.CHAR_AT:
                            state = FastqReader.STATE_PRE_READID;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "File was empty?!?";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected read id line start character: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_PRE_READID:
                    //This is a convenient state in which to reset the current "read"
                    // Seeing '@' as the first character on a line is how we get to this state
                    // so clear everything, add the '@', and then handle whatever follows
                    //-------------------------------
                    currentLineLength = currentReadIdLength = 0;
                    currentReadDescriptionLength = currentReadLength = expectedQualityLength = 0;
                    currentSeparatorLineLength = currentQualityLength = 0;
                    currentReadIncludesLowercase = false;
                    //-------------------------------
                    readId.setLength(0);
                    readDescription.setLength(0);
                    readBlock.setLength(0);
                    qualityBlock.setLength(0);
                    //-------------------------------
                    currentLineLength++;
                    //-------------------------------
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate read id character
                        readId.append((char)c);
                        currentReadIdLength++;
                        state = FastqReader.STATE_IN_READID;
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> immediately after @ on title line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Read id missing or malformed";
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_READID:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate read id character
                        readId.append((char)c); currentReadIdLength++;
                        if (currentReadIdLength > FastqReader.MAX_ALLOWED_READID_LENGTH)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of read id exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READID_LENGTH+")";
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_TAB:
                                state = FastqReader.STATE_PRE_READ_DESCRIPTION;
                                fqReadIdTabDescriptionCount++;
                                break;
                            case FastqReader.CHAR_SPACE:
                                state = FastqReader.STATE_PRE_READ_DESCRIPTION;
                                fqReadIdSpaceDescriptionCount++;
                                break;
                            case FastqReader.CHAR_CR:
                                state = FastqReader.STATE_IN_READID_CR;
                                fqReadNoDescriptionCount++;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_READID_LF;
                                currentLine++; currentLineLength = 0;
                                fqReadNoDescriptionCount++;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> in read id on title line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Found unexpected character in read id: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_READID_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READID_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in title line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_PRE_READ_DESCRIPTION:
                    if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                    {
                        //legitimate read description character
                        readDescription.append((char)c); currentReadDescriptionLength++;
                        state = FastqReader.STATE_IN_READ_DESCRIPTION;
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                state = FastqReader.STATE_PRE_READ_DESCRIPTION_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_READID_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> in read description on title line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Found unexpected character in read description: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_PRE_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READID_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF>";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ_DESCRIPTION:
                    if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                    {
                        //legitimate read description character
                        readDescription.append((char)c); currentReadDescriptionLength++;
                        if (1+currentReadIdLength+1+currentReadDescriptionLength > FastqReader.MAX_ALLOWED_READIDLINE_LENGTH)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of read id line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READIDLINE_LENGTH+")";
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                if (currentReadDescriptionLength == 0) { fqReadEmptyDescriptionCount++; }
                                state = FastqReader.STATE_IN_READ_DESCRIPTION_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                if (currentReadDescriptionLength == 0) { fqReadEmptyDescriptionCount++; }
                                state = FastqReader.STATE_IN_READID_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> in read description";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found in read description: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READID_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in read description";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in read description after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READID_LF:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            readBlock.append((char)c); currentReadLength++;
                            state = FastqReader.STATE_IN_READ;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_CR:
                            state = FastqReader.STATE_IN_NOREAD_CR;
                            break;
                        case FastqReader.CHAR_LF:
                            state = FastqReader.STATE_IN_NOREAD_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately before read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character at start of read block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_NOREAD_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_NOREAD_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> at end of empty read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in empty read block after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_NOREAD_LF:
                    switch (c)
                    {
                        case FastqReader.CHAR_PLUS:
                            state = FastqReader.STATE_IN_SEPARATOR;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after empty read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            readBlock.append((char)c); currentReadLength++;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_CR:
                            state = FastqReader.STATE_IN_READ_CR;
                            break;
                        case FastqReader.CHAR_LF:
                            state = FastqReader.STATE_IN_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character in read line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in read line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ_LF:
                    switch (c)
                    {
                        case CHAR_PLUS:
                            state = FastqReader.STATE_IN_SEPARATOR;
                            //and now we know the expected quality length
                            expectedQualityLength = currentReadLength;
                            break;
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character -- multiline read
                            fqMultiLineReadCount++;
                            readBlock.append((char)c); currentReadLength++;
                            state = FastqReader.STATE_IN_MULTILINE_READ;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in read block";
                            break;
                        default:    
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_READ:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            readBlock.append((char)c); currentReadLength++;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_CR:
                            state = FastqReader.STATE_IN_MULTILINE_READ_CR;
                            break;
                        case FastqReader.CHAR_LF:
                            state = FastqReader.STATE_IN_MULTILINE_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in multi-line read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found character in multi-line read block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_READ_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_MULTILINE_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in multi-line read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in read block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_READ_LF:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            readBlock.append((char)c);
                            state = FastqReader.STATE_IN_MULTILINE_READ;
                            currentReadLength++;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case CHAR_PLUS:
                            state = FastqReader.STATE_IN_SEPARATOR;
                            //and now we know the expected quality length
                            expectedQualityLength = currentReadLength;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in multi-line read block";
                            break;
                        default:    
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEPARATOR:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate read id character -- looks like we might have a repeat of the read id (and description)
                        state = FastqReader.STATE_IN_SEP_READID;
                        //we'll worry about the length during parsing... but @(.+) and +(.+) matching is only warning-worthy since + gets stripped
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                state = FastqReader.STATE_IN_SEPARATOR_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_SEPARATOR_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> immediately after + on separator line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Found unexpected character immediately after + on separator line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_SEPARATOR_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> on separator line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READID:
                    //worry about the approx length during parsing... @ and + matching is only warning-worthy since + gets stripped
                    if (currentLineLength > MAX_ALLOWED_SEPARATORLINE_LENGTH)
                    {
                        state = FastqReader.STATE_PARSE_ERROR;
                        parseErrorDetails = "Length of separator line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_SEPARATORLINE_LENGTH+")";
                    }
                    else
                    {
                        if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                        {
                            //legitimate read id character
                        }
                        else
                        {
                            switch (c)
                            {
                                case FastqReader.CHAR_TAB:
                                case FastqReader.CHAR_SPACE:
                                    state = FastqReader.STATE_PRE_SEP_READ_DESCRIPTION;
                                    break;
                                case FastqReader.CHAR_CR:
                                    state = FastqReader.STATE_IN_SEP_READID_CR;
                                    break;
                                case FastqReader.CHAR_LF:
                                    state = FastqReader.STATE_IN_SEPARATOR_LF;
                                    currentLine++; currentLineLength = 0;
                                    break;
                                case FastqReader.CHAR_EOF:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected <EOF> in read id on separator line";
                                    break;
                                default:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Found unexpected character in read id on separator line: "+((char)c);
                                    break;
                            }
                        }
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READID_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> on separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_PRE_SEP_READ_DESCRIPTION:
                    //worry about the approx length during parsing... @ and + matching is only warning-worthy since + gets stripped
                    if (currentLineLength > MAX_ALLOWED_SEPARATORLINE_LENGTH)
                    {
                        state = FastqReader.STATE_PARSE_ERROR;
                        parseErrorDetails = "Length of separator line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_SEPARATORLINE_LENGTH+")";
                    }
                    else
                    {
                        if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                        {
                            //legitimate read description character
                            state = FastqReader.STATE_IN_SEP_READ_DESCRIPTION;
                        }
                        else
                        {
                            switch (c)
                            {
                                case FastqReader.CHAR_CR:
                                    state = FastqReader.STATE_PRE_SEP_READ_DESCRIPTION_CR;
                                    break;
                                case FastqReader.CHAR_LF:
                                    state = FastqReader.STATE_IN_SEPARATOR_LF;
                                    currentLine++; currentLineLength = 0;
                                    break;
                                case FastqReader.CHAR_EOF:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected <EOF> in read description on separator line";
                                    break;
                                default:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Found unexpected character in read description on separator line: "+((char)c);
                                    break;
                            }
                        }
                    }
                    break;

                case FastqReader.STATE_PRE_SEP_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> in separator read description but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READ_DESCRIPTION:
                    //worry about the approx length during parsing... @ and + matching is only warning-worthy since + gets stripped
                    if (currentLineLength > MAX_ALLOWED_SEPARATORLINE_LENGTH)
                    {
                        state = FastqReader.STATE_PARSE_ERROR;
                        parseErrorDetails = "Length of separator line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_SEPARATORLINE_LENGTH+")";
                    }
                    else
                    {
                        if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                        {
                            //legitimate read description character
                        }
                        else
                        {
                            switch (c)
                            {
                                case FastqReader.CHAR_CR:
                                    state = FastqReader.STATE_IN_SEP_READ_DESCRIPTION_CR;
                                    break;
                                case FastqReader.CHAR_LF:
                                    state = FastqReader.STATE_IN_SEPARATOR_LF;
                                    currentLine++; currentLineLength = 0;
                                    break;
                                case FastqReader.CHAR_EOF:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected <EOF> in separator line read description";
                                    break;
                                default:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected character found in separator line read description: "+((char)c);
                                    break;
                            }
                        }
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in read description on separator line after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEPARATOR_LF:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate quality character
                        qualityBlock.append((char)c); currentQualityLength++;
                        state = FastqReader.STATE_IN_QUALITY;
                        if (currentQualityLength > expectedQualityLength)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of quality was expected to be zero!"; //only way to exceed the expected length here
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                state = FastqReader.STATE_IN_NOQUALITY_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_NOQUALITY_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> before quality block";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found at start of quality line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_NOQUALITY_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_NOQUALITY_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in empty quality block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in empty quality block after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_NOQUALITY_LF:
                    switch (c)
                    {
                        case FastqReader.CHAR_AT:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                currentRead++; //other counters reset via entry to STATE_PRE_READID
                                state = FastqReader.STATE_PRE_READID;
                                break characterConsumptionLoop; //from character-reading while loop
                            }
                            break;
                        case FastqReader.CHAR_EOF:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length at end of file: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                //bit of an edge case, but allowing EOF in place of trailing LF while parsing seems reasonable to me
                                state = FastqReader.STATE_DONE;
                            }
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_QUALITY:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate quality character
                        qualityBlock.append((char)c); currentQualityLength++;
                        if (currentQualityLength > expectedQualityLength)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of quality exceeds expected length: >"+expectedQualityLength;
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                state = FastqReader.STATE_IN_QUALITY_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_QUALITY_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                if (currentQualityLength != expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Mismatch between read length and quality length at end of file: "+expectedQualityLength+" != "+currentQualityLength;
                                }
                                else
                                {
                                    //bit of an edge case, but allowing EOF in place of trailing LF while parsing seems reasonable to me
                                    state = FastqReader.STATE_DONE;
                                }
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found in quality line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_QUALITY_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_QUALITY_LF; //need to check for multi-line
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "File ended unexpectedly character after <CR> on quality line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in quality line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_QUALITY_LF:
                    switch (c)
                    {
                        //unusual order here for fall-through
                        case FastqReader.CHAR_EOF:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                //expected case for EOF  :-)
                                state = FastqReader.STATE_DONE;
                                currentLine--;
                            }
                            break;
                        case FastqReader.CHAR_AT:
                            if (currentQualityLength == expectedQualityLength)
                            {
                                currentRead++; //other counters reset via entry to STATE_PRE_READID
                                state = FastqReader.STATE_PRE_READID;
                                break characterConsumptionLoop; //from character-reading while loop
                            }
                            //else fall through to handle the encountered @ as a quality character
                        default:
                            if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                            {
                                //legitimate quality character -- multi-line
                                qualityBlock.append((char)c); currentQualityLength++;
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY;
                                fqMultiLineQualityCount++;
                                if (currentQualityLength > expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Length of quality exceeds expected length: >"+expectedQualityLength;
                                }
                            }
                            else
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found after end of quality line: "+((char)c);
                            }
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_QUALITY:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate quality character
                        qualityBlock.append((char)c); currentQualityLength++;
                        if (currentQualityLength > expectedQualityLength)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of quality block exceeds expected length: >"+expectedQualityLength;
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                if (currentQualityLength != expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                                }
                                else
                                {
                                    //edge case...?
                                    state = FastqReader.STATE_DONE;
                                }
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found in quality line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_QUALITY_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_MULTILINE_QUALITY_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "File ended unexpectedly character after <CR> in quality block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in quality block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_QUALITY_LF:
                    switch (c)
                    {
                        case FastqReader.CHAR_EOF:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                //an expected end state
                                state = FastqReader.STATE_DONE;
                                currentLine--;
                            }
                            break;
                        case FastqReader.CHAR_AT:
                            if (currentQualityLength == expectedQualityLength)
                            {
                                currentRead++; //other counters reset via entry to STATE_PRE_READID
                                state = FastqReader.STATE_PRE_READID;
                                break characterConsumptionLoop; //from character-reading while loop
                            }
                            //else fall through to handle as a quality character
                        default:
                            if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                            {
                                //legitimate quality character -- multi-line
                                qualityBlock.append((char)c); currentQualityLength++;
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY;
                                if (currentQualityLength > expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Length of quality exceeds expected length: >"+expectedQualityLength;
                                }
                            }
                            else
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found after end of quality line: "+((char)c);
                            }
                            break;
                    }
                    break;

                default:
                    state = FastqReader.STATE_PARSE_ERROR;
                    parseErrorDetails = "Found unexpected character for parser state #"+state+": "+((char)c);
                    break;
            }
        }

        //expect one of four states: STATE_PRE_READID, STATE_PARSE_ERROR, STATE_DONE, STATE_PAST_EOF
        // the first and third get a non-null fqRead
        if (state == FastqReader.STATE_PRE_READID || state == FastqReader.STATE_DONE)
        {
            fqRead = new FastqRead( readId.toString(),
                                    readDescription.toString(),
                                    readBlock.toString(),
                                    separatorLine.toString(),
                                    qualityBlock.toString(), false );
        }
        else if (state == FastqReader.STATE_PARSE_ERROR)
        {
            throw new IOException(parseErrorDetails);
        }

        return fqRead;
    }


    private FastqRead getNextRawAndCleanRead() throws IOException
    {
        FastqRead fqRead = null;
        if (state == FastqReader.STATE_CLOSED)
        {
            throw new IllegalStateException("FastqReader has already been closed");
        }

        String parseErrorDetails = null;
        if (state == FastqReader.STATE_DONE)
        {
            state = FastqReader.STATE_PAST_EOF;
        }

        //ELSE...
        characterConsumptionLoop:
        while (state != FastqReader.STATE_DONE &&
               state != FastqReader.STATE_PAST_EOF &&
               state != FastqReader.STATE_PARSE_ERROR)
        {
            int c = readStream.read(); if (c != FastqReader.CHAR_EOF) { currentLineLength++; }
            switch (state)
            {
                case FastqReader.STATE_PREREAD:
                    switch (c)
                    {
                        case FastqReader.CHAR_AT:
                            state = FastqReader.STATE_PRE_READID;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "File was empty?!?";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected read id line start character: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_PRE_READID:
                    //This is a convenient state in which to reset the current "read"
                    // Seeing '@' as the first character on a line is how we get to this state
                    // so clear everything, add the '@', and then handle whatever follows
                    //-------------------------------
                    currentLineLength = currentReadIdLength = 0;
                    currentReadDescriptionLength = currentReadLength = expectedQualityLength = 0;
                    currentSeparatorLineLength = currentQualityLength = 0;
                    currentReadIncludesLowercase = false;
                    //-------------------------------
                    rawTitleLine.setLength(0);
                    rawReadBlock.setLength(0);
                    rawSeparatorLine.setLength(0);
                    rawQualityBlock.setLength(0);
                    readId.setLength(0);
                    readDescription.setLength(0);
                    readBlock.setLength(0);
                    qualityBlock.setLength(0);
                    //-------------------------------
                    currentLineLength++;
                    rawTitleLine.append('@');
                    //-------------------------------
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate read id character
                        rawTitleLine.append((char)c);
                        readId.append((char)c);
                        currentReadIdLength++;
                        state = FastqReader.STATE_IN_READID;
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> immediately after @ on title line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Read id missing or malformed";
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_READID:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate read id character
                        rawTitleLine.append((char)c);
                        readId.append((char)c); currentReadIdLength++;
                        if (currentReadIdLength > FastqReader.MAX_ALLOWED_READID_LENGTH)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of read id exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READID_LENGTH+")";
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_TAB:
                                rawTitleLine.append((char)c);
                                state = FastqReader.STATE_PRE_READ_DESCRIPTION;
                                fqReadIdTabDescriptionCount++;
                                break;
                            case FastqReader.CHAR_SPACE:
                                rawTitleLine.append((char)c);
                                state = FastqReader.STATE_PRE_READ_DESCRIPTION;
                                fqReadIdSpaceDescriptionCount++;
                                break;
                            case FastqReader.CHAR_CR:
                                rawTitleLine.append((char)c);
                                state = FastqReader.STATE_IN_READID_CR;
                                fqReadNoDescriptionCount++;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_READID_LF;
                                currentLine++; currentLineLength = 0;
                                fqReadNoDescriptionCount++;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> in read id on title line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Found unexpected character in read id: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_READID_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READID_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in title line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_PRE_READ_DESCRIPTION:
                    if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                    {
                        //legitimate read description character
                        rawTitleLine.append((char)c);
                        readDescription.append((char)c); currentReadDescriptionLength++;
                        state = FastqReader.STATE_IN_READ_DESCRIPTION;
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawTitleLine.append((char)c);
                                state = FastqReader.STATE_PRE_READ_DESCRIPTION_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_READID_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> in read description on title line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Found unexpected character in read description: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_PRE_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READID_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF>";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ_DESCRIPTION:
                    if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                    {
                        //legitimate read description character
                        rawTitleLine.append((char)c);
                        readDescription.append((char)c); currentReadDescriptionLength++;
                        if (1+currentReadIdLength+1+currentReadDescriptionLength > FastqReader.MAX_ALLOWED_READIDLINE_LENGTH)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of read id line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READIDLINE_LENGTH+")";
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawTitleLine.append((char)c);
                                if (currentReadDescriptionLength == 0) { fqReadEmptyDescriptionCount++; }
                                state = FastqReader.STATE_IN_READ_DESCRIPTION_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                if (currentReadDescriptionLength == 0) { fqReadEmptyDescriptionCount++; }
                                state = FastqReader.STATE_IN_READID_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> in read description";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found in read description: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_READID_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in read description";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in read description after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READID_LF:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            rawReadBlock.append((char)c);
                            readBlock.append((char)c); currentReadLength++;
                            state = FastqReader.STATE_IN_READ;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_CR:
                            rawReadBlock.append((char)c);
                            state = FastqReader.STATE_IN_NOREAD_CR;
                            break;
                        case FastqReader.CHAR_LF:
                            state = FastqReader.STATE_IN_NOREAD_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately before read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character at start of read block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_NOREAD_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_NOREAD_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> at end of empty read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in empty read block after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_NOREAD_LF:
                    switch (c)
                    {
                        case FastqReader.CHAR_PLUS:
                            rawSeparatorLine.append((char)c);
                            state = FastqReader.STATE_IN_SEPARATOR;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after empty read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            rawReadBlock.append((char)c);
                            readBlock.append((char)c); currentReadLength++;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_CR:
                            rawReadBlock.append((char)c);
                            state = FastqReader.STATE_IN_READ_CR;
                            break;
                        case FastqReader.CHAR_LF:
                            rawReadBlock.append((char)c);         //trim later if not multi-line
                            state = FastqReader.STATE_IN_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character in read line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            rawReadBlock.append((char)c);         //trim later if not multi-line
                            state = FastqReader.STATE_IN_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in read line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_READ_LF:
                    switch (c)
                    {
                        case CHAR_PLUS:
                            rawReadBlock.setLength(rawReadBlock.length()-1); //trim trailing LF
                            rawSeparatorLine.append((char)c);
                            state = FastqReader.STATE_IN_SEPARATOR;
                            //and now we know the expected quality length
                            expectedQualityLength = currentReadLength;
                            break;
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character -- multiline read
                            fqMultiLineReadCount++;
                            rawReadBlock.append((char)c);
                            readBlock.append((char)c); currentReadLength++;
                            state = FastqReader.STATE_IN_MULTILINE_READ;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in read block";
                            break;
                        default:    
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_READ:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            rawReadBlock.append((char)c);
                            readBlock.append((char)c); currentReadLength++;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case FastqReader.CHAR_CR:
                            rawReadBlock.append((char)c);
                            state = FastqReader.STATE_IN_MULTILINE_READ_CR;
                            break;
                        case FastqReader.CHAR_LF:
                            rawReadBlock.append((char)c); //trim later if trailing
                            state = FastqReader.STATE_IN_MULTILINE_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in multi-line read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found character in multi-line read block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_READ_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            rawReadBlock.append((char)c); //trim later if trailing
                            state = FastqReader.STATE_IN_MULTILINE_READ_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in multi-line read block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in read block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_READ_LF:
                    switch (c)
                    {
                        case ((int)'a'): case ((int)'t'): case ((int)'g'): case ((int)'c'): case ((int)'n'):
                            currentReadIncludesLowercase = true;
                        case ((int)'A'): case ((int)'T'): case ((int)'G'): case ((int)'C'): case ((int)'N'):
                            //legitimate read character
                            rawReadBlock.append((char)c);
                            readBlock.append((char)c);
                            state = FastqReader.STATE_IN_MULTILINE_READ;
                            currentReadLength++;
                            if (currentReadLength > FastqReader.MAX_ALLOWED_READ_LENGTH)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Length of read exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_READ_LENGTH+")";
                            }
                            break;
                        case CHAR_PLUS:
                            rawReadBlock.setLength(rawReadBlock.length()-1); //trim trailing LF (since not NOREAD and we found the end)
                            rawSeparatorLine.append((char)c);
                            state = FastqReader.STATE_IN_SEPARATOR;
                            //and now we know the expected quality length
                            expectedQualityLength = currentReadLength;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> in multi-line read block";
                            break;
                        default:    
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEPARATOR:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate read id character -- looks like we might have a repeat of the read id (and description)
                        rawSeparatorLine.append((char)c);
                        state = FastqReader.STATE_IN_SEP_READID;
                        //we'll worry about the length during parsing... but @(.+) and +(.+) matching is only warning-worthy since + gets stripped
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawSeparatorLine.append((char)c);
                                state = FastqReader.STATE_IN_SEPARATOR_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                state = FastqReader.STATE_IN_SEPARATOR_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> immediately after + on separator line";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Found unexpected character immediately after + on separator line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_SEPARATOR_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> on separator line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READID:
                    //worry about the approx length during parsing... @ and + matching is only warning-worthy since + gets stripped
                    if (currentLineLength > MAX_ALLOWED_SEPARATORLINE_LENGTH)
                    {
                        state = FastqReader.STATE_PARSE_ERROR;
                        parseErrorDetails = "Length of separator line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_SEPARATORLINE_LENGTH+")";
                    }
                    else
                    {
                        if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                        {
                            //legitimate read id character
                            rawSeparatorLine.append((char)c);
                        }
                        else
                        {
                            switch (c)
                            {
                                case FastqReader.CHAR_TAB:
                                case FastqReader.CHAR_SPACE:
                                    rawSeparatorLine.append((char)c);
                                    state = FastqReader.STATE_PRE_SEP_READ_DESCRIPTION;
                                    break;
                                case FastqReader.CHAR_CR:
                                    rawSeparatorLine.append((char)c);
                                    state = FastqReader.STATE_IN_SEP_READID_CR;
                                    break;
                                case FastqReader.CHAR_LF:
                                    state = FastqReader.STATE_IN_SEPARATOR_LF;
                                    currentLine++; currentLineLength = 0;
                                    break;
                                case FastqReader.CHAR_EOF:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected <EOF> in read id on separator line";
                                    break;
                                default:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Found unexpected character in read id on separator line: "+((char)c);
                                    break;
                            }
                        }
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READID_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> on separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_PRE_SEP_READ_DESCRIPTION:
                    //worry about the approx length during parsing... @ and + matching is only warning-worthy since + gets stripped
                    if (currentLineLength > MAX_ALLOWED_SEPARATORLINE_LENGTH)
                    {
                        state = FastqReader.STATE_PARSE_ERROR;
                        parseErrorDetails = "Length of separator line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_SEPARATORLINE_LENGTH+")";
                    }
                    else
                    {
                        if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                        {
                            //legitimate read description character
                            rawSeparatorLine.append((char)c);
                            state = FastqReader.STATE_IN_SEP_READ_DESCRIPTION;
                        }
                        else
                        {
                            switch (c)
                            {
                                case FastqReader.CHAR_CR:
                                    rawSeparatorLine.append((char)c);
                                    state = FastqReader.STATE_PRE_SEP_READ_DESCRIPTION_CR;
                                    break;
                                case FastqReader.CHAR_LF:
                                    state = FastqReader.STATE_IN_SEPARATOR_LF;
                                    currentLine++; currentLineLength = 0;
                                    break;
                                case FastqReader.CHAR_EOF:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected <EOF> in read description on separator line";
                                    break;
                                default:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Found unexpected character in read description on separator line: "+((char)c);
                                    break;
                            }
                        }
                    }
                    break;

                case FastqReader.STATE_PRE_SEP_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> immediately after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character after <CR> in separator read description but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READ_DESCRIPTION:
                    //worry about the approx length during parsing... @ and + matching is only warning-worthy since + gets stripped
                    if (currentLineLength > MAX_ALLOWED_SEPARATORLINE_LENGTH)
                    {
                        state = FastqReader.STATE_PARSE_ERROR;
                        parseErrorDetails = "Length of separator line exceded maximum allowed length (len > "+FastqReader.MAX_ALLOWED_SEPARATORLINE_LENGTH+")";
                    }
                    else
                    {
                        if (c == FastqReader.CHAR_TAB || (c >= FastqReader.CHAR_SPACE && c <= FastqReader.CHAR_TILDE))
                        {
                            //legitimate read description character
                            rawSeparatorLine.append((char)c);
                        }
                        else
                        {
                            switch (c)
                            {
                                case FastqReader.CHAR_CR:
                                    rawSeparatorLine.append((char)c);
                                    state = FastqReader.STATE_IN_SEP_READ_DESCRIPTION_CR;
                                    break;
                                case FastqReader.CHAR_LF:
                                    state = FastqReader.STATE_IN_SEPARATOR_LF;
                                    currentLine++; currentLineLength = 0;
                                    break;
                                case FastqReader.CHAR_EOF:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected <EOF> in separator line read description";
                                    break;
                                default:
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Unexpected character found in separator line read description: "+((char)c);
                                    break;
                            }
                        }
                    }
                    break;

                case FastqReader.STATE_IN_SEP_READ_DESCRIPTION_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_SEPARATOR_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> on separator line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in read description on separator line after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_SEPARATOR_LF:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate quality character
                        rawQualityBlock.append((char)c);
                        qualityBlock.append((char)c); currentQualityLength++;
                        state = FastqReader.STATE_IN_QUALITY;
                        if (currentQualityLength > expectedQualityLength)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of quality was expected to be zero!"; //only way to exceed the expected length here
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawQualityBlock.append((char)c);
                                state = FastqReader.STATE_IN_NOQUALITY_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                rawQualityBlock.append((char)c);
                                state = FastqReader.STATE_IN_NOQUALITY_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected <EOF> before quality block";
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found at start of quality line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_NOQUALITY_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_NOQUALITY_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Unexpected <EOF> after <CR> in empty quality block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected <LF> character in empty quality block after <CR> but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_NOQUALITY_LF:
                    switch (c)
                    {
                        case FastqReader.CHAR_AT:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                rawQualityBlock.setLength(rawQualityBlock.length()-1); //trim trailing LF
                                currentRead++; //other counters reset via entry to STATE_PRE_READID
                                state = FastqReader.STATE_PRE_READID;
                                break characterConsumptionLoop; //from character-reading while loop
                            }
                            break;
                        case FastqReader.CHAR_EOF:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length at end of file: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                //bit of an edge case, but allowing EOF in place of trailing LF while parsing seems reasonable to me
                                state = FastqReader.STATE_DONE;
                            }
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Expected + character starting separator line but found: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_QUALITY:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate quality character
                        rawQualityBlock.append((char)c);
                        qualityBlock.append((char)c); currentQualityLength++;
                        if (currentQualityLength > expectedQualityLength)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of quality exceeds expected length: >"+expectedQualityLength;
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawQualityBlock.append((char)c);
                                state = FastqReader.STATE_IN_QUALITY_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                rawQualityBlock.append((char)c); //trailing LF trimmed later
                                state = FastqReader.STATE_IN_QUALITY_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                if (currentQualityLength != expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Mismatch between read length and quality length at end of file: "+expectedQualityLength+" != "+currentQualityLength;
                                }
                                else
                                {
                                    //bit of an edge case, but allowing EOF in place of trailing LF while parsing seems reasonable to me
                                    state = FastqReader.STATE_DONE;
                                }
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found in quality line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_QUALITY_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_QUALITY_LF; //need to check for multi-line
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "File ended unexpectedly character after <CR> on quality line";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in quality line: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_QUALITY_LF:
                    switch (c)
                    {
                        //unusual order here for fall-through
                        case FastqReader.CHAR_EOF:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                //expected case for EOF  :-)
                                rawQualityBlock.setLength(rawQualityBlock.length()-1); //trim trailing LF
                                state = FastqReader.STATE_DONE;
                                currentLine--;
                            }
                            break;
                        case FastqReader.CHAR_AT:
                            if (currentQualityLength == expectedQualityLength)
                            {
                                rawQualityBlock.setLength(rawQualityBlock.length()-1); //trim trailing LF
                                currentRead++; //other counters reset via entry to STATE_PRE_READID
                                state = FastqReader.STATE_PRE_READID;
                                break characterConsumptionLoop; //from character-reading while loop
                            }
                            //else fall through to handle the encountered @ as a quality character
                        default:
                            if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                            {
                                //legitimate quality character -- multi-line
                                rawQualityBlock.append((char)c);
                                qualityBlock.append((char)c); currentQualityLength++;
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY;
                                fqMultiLineQualityCount++;
                                if (currentQualityLength > expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Length of quality exceeds expected length: >"+expectedQualityLength;
                                }
                            }
                            else
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found after end of quality line: "+((char)c);
                            }
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_QUALITY:
                    if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                    {
                        //legitimate quality character
                        rawQualityBlock.append((char)c);
                        qualityBlock.append((char)c); currentQualityLength++;
                        if (currentQualityLength > expectedQualityLength)
                        {
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Length of quality block exceeds expected length: >"+expectedQualityLength;
                        }
                    }
                    else
                    {
                        switch (c)
                        {
                            case FastqReader.CHAR_CR:
                                rawQualityBlock.append((char)c);
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY_CR;
                                break;
                            case FastqReader.CHAR_LF:
                                rawQualityBlock.append((char)c); //trailing LF trimmed later
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY_LF;
                                currentLine++; currentLineLength = 0;
                                break;
                            case FastqReader.CHAR_EOF:
                                if (currentQualityLength != expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                                }
                                else
                                {
                                    //edge case...?
                                    state = FastqReader.STATE_DONE;
                                }
                                break;
                            default:
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found in quality line: "+((char)c);
                                break;
                        }
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_QUALITY_CR:
                    switch (c)
                    {
                        case FastqReader.CHAR_LF:
                            fqCRLFLineCount++;
                            state = FastqReader.STATE_IN_MULTILINE_QUALITY_LF;
                            currentLine++; currentLineLength = 0;
                            break;
                        case FastqReader.CHAR_EOF:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "File ended unexpectedly character after <CR> in quality block";
                            break;
                        default:
                            state = FastqReader.STATE_PARSE_ERROR;
                            parseErrorDetails = "Found unexpected character after <CR> in quality block: "+((char)c);
                            break;
                    }
                    break;

                case FastqReader.STATE_IN_MULTILINE_QUALITY_LF:
                    switch (c)
                    {
                        case FastqReader.CHAR_EOF:
                            if (currentQualityLength != expectedQualityLength)
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Mismatch between read length and quality length: "+expectedQualityLength+" != "+currentQualityLength;
                            }
                            else
                            {
                                //an expected end state
                                rawQualityBlock.setLength(rawQualityBlock.length()-1); //trim trailing LF
                                state = FastqReader.STATE_DONE;
                                currentLine--;
                            }
                            break;
                        case FastqReader.CHAR_AT:
                            if (currentQualityLength == expectedQualityLength)
                            {
                                currentRead++; //other counters reset via entry to STATE_PRE_READID
                                state = FastqReader.STATE_PRE_READID;
                                break characterConsumptionLoop; //from character-reading while loop
                            }
                            //else fall through to handle as a quality character
                        default:
                            if (c >= FastqReader.CHAR_BANG && c <= FastqReader.CHAR_TILDE)
                            {
                                //legitimate quality character -- multi-line
                                rawQualityBlock.append((char)c);
                                qualityBlock.append((char)c); currentQualityLength++;
                                state = FastqReader.STATE_IN_MULTILINE_QUALITY;
                                if (currentQualityLength > expectedQualityLength)
                                {
                                    state = FastqReader.STATE_PARSE_ERROR;
                                    parseErrorDetails = "Length of quality exceeds expected length: >"+expectedQualityLength;
                                }
                            }
                            else
                            {
                                state = FastqReader.STATE_PARSE_ERROR;
                                parseErrorDetails = "Unexpected character found after end of quality line: "+((char)c);
                            }
                            break;
                    }
                    break;

                default:
                    state = FastqReader.STATE_PARSE_ERROR;
                    parseErrorDetails = "Found unexpected character for parser state #"+state+": "+((char)c);
                    break;
            }
        }

        //expect one of four states: STATE_PRE_READID, STATE_PARSE_ERROR, STATE_DONE, STATE_PAST_EOF
        // the first and third get a non-null fqRead
        if (state == FastqReader.STATE_PRE_READID || state == FastqReader.STATE_DONE)
        {
            fqRead = new FastqRead( rawTitleLine.toString(), readId.toString(), readDescription.toString(),
                                    rawReadBlock.toString(), readBlock.toString().toUpperCase(),
                                    rawSeparatorLine.toString(), separatorLine,
                                    rawQualityBlock.toString(), qualityBlock.toString(),
                                    false );
        }
        else if (state == FastqReader.STATE_PARSE_ERROR)
        {
            throw new IOException(parseErrorDetails);
        }

        return fqRead;
    }



    public long getNextLineNumber()
    {
        return currentLine;
    }

    public long getNextReadNumber()
    {
        return currentRead;
    }


    public File getFile()
    {
        return fastqFile;
    }


    public static void main(String[] args) throws Exception
    {
        if (args == null || args.length < 1 ||
            (args.length == 2
                              && !"raw_and_clean".equals(args[1].toLowerCase())
                              && !"raw".equals(args[1].toLowerCase())
                              && !"clean".equals(args[1].toLowerCase())
                              && !"all_three".equals(args[1].toLowerCase())
            ))
        {
            System.out.println("SYNTAX: java com.lilly.ngs.fastq.FastqReader <fastq-file> [raw_and_clean|raw|clean|all_three]");
            System.out.println("        For testing purposes, this main() simply reports timing and the line and read counts.");
        }
        else
        {
            File fqFile = new File(args[0]);
            if (!fqFile.exists())
            {
                System.out.println("Fastq file does not exist: "+args[0]);
            }
            else if (!fqFile.canRead())
            {
                System.out.println("Fastq file exists but cannot be read: "+args[0]);
            }
            else
            {
              FastqReader fqReader = null;
              try
              {
                if (args.length == 1 || args[1].toLowerCase().equals("raw_and_clean") || args[1].toLowerCase().equals("all_three"))
                {
                    System.out.println("Timing raw_and_clean reading...");

                    Date date = new Date();
                    long ms0 = date.getTime();
                    System.out.println("Start: "+df.format(date));
                    fqReader = new FastqReader(args[0]);
                    FastqRead fqRead;
                    while ((fqRead = fqReader.getNextRawAndCleanRead()) != null)
                    {
                        /* do nothing */
                    }
                    System.out.println("Line count: "+fqReader.currentLine+" ; Read count: "+fqReader.currentRead);
                    long readCount = fqReader.currentRead;
                    fqReader.close();
                    date = new Date();
                    long ms1 = date.getTime();
                    System.out.println("Done: "+df.format(date));
                    System.out.println("Rate: "+(((ms1-ms0)/(1.0*readCount/1000000))/1000.0)+"s per million reads (raw_and_clean)");
                    System.out.println();
                }

                if (args.length == 2 && (args[1].toLowerCase().equals("raw") || args[1].toLowerCase().equals("all_three")))
                {
                    System.out.println("Timing raw reading...");

                    Date date = new Date();
                    long ms0 = date.getTime();
                    System.out.println("Start: "+df.format(date));
                    fqReader = new FastqReader(args[0]);
                    FastqRead fqRead;
                    while ((fqRead = fqReader.getNextRawRead()) != null)
                    {
                        /* do nothing */
                    }
                    System.out.println("Line count: "+fqReader.currentLine+" ; Read count: "+fqReader.currentRead);
                    long readCount = fqReader.currentRead;
                    fqReader.close();
                    date = new Date();
                    long ms1 = date.getTime();
                    System.out.println("Done: "+df.format(date));
                    System.out.println("Rate: "+(((ms1-ms0)/(1.0*readCount/1000000))/1000.0)+"s per million reads (raw)");
                    System.out.println();
                }

                if (args.length == 2 && (args[1].toLowerCase().equals("clean") || args[1].toLowerCase().equals("all_three")))
                {
                    System.out.println("Timing clean reading...");

                    Date date = new Date();
                    long ms0 = date.getTime();
                    System.out.println("Start: "+df.format(date));
                    fqReader = new FastqReader(args[0]);
                    FastqRead fqRead;
                    while ((fqRead = fqReader.getNextRead()) != null)
                    {
                        /* do nothing */
                    }
                    System.out.println("Line count: "+fqReader.currentLine+" ; Read count: "+fqReader.currentRead);
                    long readCount = fqReader.currentRead;
                    fqReader.close();
                    date = new Date();
                    long ms1 = date.getTime();
                    System.out.println("Done: "+df.format(date));
                    System.out.println("Rate: "+(((ms1-ms0)/(1.0*readCount/1000000))/1000.0)+"s per million reads (clean)");
                    System.out.println();
                }
              }
              catch (IOException exFromReader)
              {
                  throw new IOException("FastqReader threw exception at/near line #"+fqReader.currentLine+" / read #"+fqReader.currentRead, exFromReader);
              }
            }
        }
    }
}
