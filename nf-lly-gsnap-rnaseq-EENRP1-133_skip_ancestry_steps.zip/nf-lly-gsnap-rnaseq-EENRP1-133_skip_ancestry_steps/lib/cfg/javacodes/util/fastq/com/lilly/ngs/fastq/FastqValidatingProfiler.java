package com.lilly.ngs.fastq;

import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import java.text.SimpleDateFormat;
import com.lilly.ngs.util.*;


public class FastqValidatingProfiler
{
    /*
        Fastq validation/profiling needs to include:
        1. reading and validating the (compressed) input fastq(s)
        2. computation of MD5s to report/validate
        3. Identification of apparent batches (based on common read-id-formats and issues)

        For single-end, #1 needs to include:
         - verification of unix-style end-of-line (LF character only)
         - expected record structure (four-line block; @, ..., +, ...)
         - unique read ids
         - "reasonable" base quality distribution
         - base and base quality line lengths match
         - consistent read name for @ and + (strip read name from + for legacy CoTS compliance) 
        For paired-end (and more fastqs), additionally needs to include:
         - verification that read 1 and read 2 names match (strip trailing "/1" and "/2" if present)
         - "Creative massage" identification checks:
            + verification that bases are not identical, reversed, or reverse-complemented
            + similar verification for quality scores...

        Profiling will include the basics:
         - Batch count (flowcell-lane/flowcell)
         - Per batch
            + read length distribution (default to 10bp buckets; 0-9, 10-19, ..., 500+)
            + quality

    */

    private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

    private static int MAX_BATCH_COUNT = 100;
    private static long MAX_READID_REPEATS_TO_REPORT = 100;
    private static long MAX_READID_CONFLICTS_TO_REPORT = 100;

    private static int READ_LENGTH_BIN_SIZE = 10;  /////
    private static int READ_LENGTH_BIN_COUNT = 51; //Bins 0-9, 10-19, ..., 480-489, 490-499, 500+

    private static final String optionsDescription = "vsl:f:m:t:b:B:";
    private static boolean verbose = true;
    private static PrintStream logStream = System.out; //might be replaced with a PrintStream to a log file...
    private static String default_t = System.getProperty("java.io.tmpdir");
    private static String default_b = "flowcell-lane";
    private static String classpathRelativeBatchRegexsPath = "DefaultBatchSeparationRegexs.txt";
    private static String default_B = null; //(new File(ClassFindBinHelper.findPathToClass(ClassFindBinHelper.getCallingClassName())+classpathRelativeBatchRegexsPath)).getCanonicalPath();


    private static void printSyntaxMessage() throws IOException
    {
        default_B = 
            (new File(ClassFindBinHelper.findPathToClass(ClassFindBinHelper.getCallingClassName())+classpathRelativeBatchRegexsPath)).getCanonicalPath();

        System.out.println("SYNTAX: java "+ClassFindBinHelper.getCallingClassName());
        System.out.println("             [-v|-s|-l <log-filename>] -f <read1.fq.gz> [-m <md5-checksum>] [-f <read2.fq.gz> [-m <md5-checksum>] [...]]");
        System.out.println("             [-t <temp-directory>] [-b <flowcell-lane|flowcell>] [-B <batch-separation-regexs-file>]");
        System.out.println();
        System.out.println("        This class performs basic validation and profiling on a set of one or more gzip-compressed fastq files.");
        System.out.println("        The fastq inputs are verified to contain valid gzip format data, and the data therein are verified to be in");
        System.out.println("        a reasonable/parse-able FASTQ format with unique read ids in matched order across the fastq files.");
        System.out.println("        In typical usage, you MUST specify a non-default JVM heap size (using -Xms and -Xmx) to avoid excessive temp dir use.");
        System.out.println("        Assuming a typical average read id length of ~50 characters and read depth of 50M reads, \"-Xms5G -Xmx5G\" is acceptable.");
        System.out.println("        (This will result in six temp files of ~8.4M sorted read ids. If you specify \"-Xms30G -Xmx30G\", it'd all fit in memory.)");
//        System.out.println("        Additional checks include:");
//        System.out.println("            Read 1/2 sequence comparisons (checks for same/reversed/complemented/reverse-complemented sequence)");
//        System.out.println("            All quality characters identical in a read");
        System.out.println();
        System.out.println("        Option details:");
        System.out.println("            -v/-s/-l verbose/silent/logfile");
        System.out.println("               Specifies where to send basic timing and other details and success/failure info (default: verbose/stdout)");
        System.out.println("            -f may be specified one to four times");
        System.out.println("            -m may be specified one to four times also (count may not exceed the number of fastq files specified)");
        System.out.println("                 The number of md5 checksum arguments does NOT need to match the number of fastq files.");
        System.out.println("                 Specifying an empty string as the md5 checksum argument will result in the md5 checksum being calculated and reported.");
        System.out.println("                 Disagreement between a specified (non-empty-string) md5 checksum and a calculaed checksum is an error.");
        System.out.println("            -t used for file-backed data structures (default: java.io.tmpdir - currently "+default_t);
        System.out.println("                                                     /node/scratch is recommended on HPC for performance reasons)");
        System.out.println("            -b specifies the batch separation level (default: "+default_b+")");
        System.out.println("            -B accepts a simple tsv file containing regular expressions with named capture groups for parsing batch information out of");
        System.out.println("               read title lines.  All regexs are assumed to match distinct sets of read title lines and will be dynamically reordered.");
        System.out.println("               The first match for each read title will be used.");
        System.out.println("               This defaults to "+default_B);
        System.out.println();
    }


    private static Hashtable<String, ArrayList<String>> validateArgs(String[] args) throws IllegalArgumentException, IOException
    {
        Hashtable<String, ArrayList<String>> parsedArgs = SimpleArgsHelper.parseSimpleOpts(args, optionsDescription);
        boolean badArgs = false;

        //required no "naked" args
        if (parsedArgs.containsKey(SimpleArgsHelper.ARGUMENTS_HASH_KEY))
        {
            badArgs = true;
            ArrayList<String> valArr = parsedArgs.get(SimpleArgsHelper.ARGUMENTS_HASH_KEY);
            for (int i=0; i<valArr.size(); i++)
            {
                System.out.println("ERROR: Unexpected argument: "+parsedArgs.get(SimpleArgsHelper.ARGUMENTS_HASH_KEY).get(i));
            }    
        }

        // -l, -f, -m, -t, -b, -B
        int fqCount = 0;
        int md5Count = 0;
        if (parsedArgs.containsKey("l")) { ArrayList<String> valArr = parsedArgs.get("l"); badArgs = !SimpleArgsHelper.canWriteFile(valArr.get(valArr.size()-1), true, false) || badArgs; }
        if (parsedArgs.containsKey("f")) { ArrayList<String> valArr = parsedArgs.get("f"); fqCount=valArr.size(); for (int i=0; i<valArr.size(); i++) { badArgs = !SimpleArgsHelper.canReadFile(valArr.get(i), true, false) || badArgs; } }
        if (parsedArgs.containsKey("m")) { ArrayList<String> valArr = parsedArgs.get("m"); md5Count=valArr.size(); for (int i=0; i<valArr.size(); i++) { if (valArr.get(i).equals("")) { continue; } badArgs = !SimpleArgsHelper.isValidMD5(valArr.get(i), true, false) || badArgs; } }
        if (parsedArgs.containsKey("t")) { ArrayList<String> valArr = parsedArgs.get("t"); badArgs = !SimpleArgsHelper.canWriteToDirectory(valArr.get(valArr.size()-1), true, false) || badArgs; }
        if (parsedArgs.containsKey("b")) { ArrayList<String> valArr = parsedArgs.get("b"); badArgs = !SimpleArgsHelper.isInArray(valArr.get(valArr.size()-1), new String[]{"flowcell-lane", "flowcell"}, true, false) || badArgs; }
        if (parsedArgs.containsKey("B")) { ArrayList<String> valArr = parsedArgs.get("B"); badArgs = !SimpleArgsHelper.canReadFile(valArr.get(valArr.size()-1), true, false) || badArgs; }

        //other arg constraints...
        if (fqCount < 1) { badArgs=true; System.out.println("ERROR: At least one gzip-compressed fastq file must be specified."); }
        if (fqCount > 4) { badArgs=true; System.out.println("ERROR: No more than four gzip-compressed fastq files may be specified."); }
        if (md5Count > fqCount) { badArgs=true; System.out.println("ERROR: No more MD5 checksums may be specified than gzip-compressed fastq files"); }

        if (badArgs) { parsedArgs = null; }
        return parsedArgs;
    }



    public static void main(String[] args) throws Exception  //TODO: handle all unhandled exceptions to give more helpful error messages...?
    {
        default_B = 
            (new File(ClassFindBinHelper.findPathToClass(ClassFindBinHelper.getCallingClassName())+classpathRelativeBatchRegexsPath)).getCanonicalPath();

        Hashtable<String, ArrayList<String>> parsedArgs = (args.length == 0)?null:validateArgs(args);
        if (parsedArgs == null)
        {
            printSyntaxMessage();
            if (args.length > 0) { System.exit(1); }
        }
        else
        {
            //unpack the args...
            // vsl:f:m:t:b:B:
            String logfilename = null;
            if (parsedArgs.containsKey("l"))
            {
                verbose = true;
                ArrayList<String> valArr = parsedArgs.get("l");
                logfilename = valArr.get(valArr.size()-1);
                logStream = new PrintStream(logfilename);
            } else if (parsedArgs.containsKey("s"))
            {
                verbose = false;
            }
            else
            {
                //keep default verbose to stdout
            }
            if (verbose) { logStream.println("INFO: Started at "+dateTimeFormat.format(new Date())); }
            if (logfilename != null) { logStream.println("INFO: Logging to "+(new File(logfilename)).getCanonicalPath()); }

            if (verbose) { logStream.println("INFO: Unpacking validated arguments..."); }
            ArrayList<String> fqFilenames = SimpleArgsHelper.convertToCanonicalPaths(parsedArgs.get("f"));
            ArrayList<String> md5s = (!parsedArgs.containsKey("m"))?null:parsedArgs.get("m");
            String tmpIoDirname = ((parsedArgs.get("t") == null)?(new File(default_t)):(new File(parsedArgs.get("t").get(parsedArgs.get("t").size()-1)))).getCanonicalPath();
            String batchSeparationType = (parsedArgs.get("b") == null)?default_b:parsedArgs.get("b").get(parsedArgs.get("b").size()-1);
            String batchSepRegexsFilename = ((parsedArgs.get("B") == null)?(new File(default_B)):(new File(parsedArgs.get("B").get(parsedArgs.get("B").size()-1)))).getCanonicalPath();
            if (verbose) { logStream.println("INFO: Unpacked arguments"); }

            if (verbose)
            {
                for (int i=0; i<fqFilenames.size(); i++)
                {
                    logStream.println("INFO: Arguments specified fastq file read"+(i+1)+":"+fqFilenames.get(i));
                }
            }

            //instantiate these here to exercise the arg/default
            SimpleFileBackedReadIdList readIdList = new SimpleFileBackedReadIdList(tmpIoDirname);

            //load up the regexs file...  And prune if appropriate
            int batchSeparationTypeInt = (("flowcell-lane".equals(batchSeparationType))?1:2);
            NamedGroupRegexHelper regexHelper = new NamedGroupRegexHelper(batchSepRegexsFilename, 1);
            ArrayList<Pattern> batchInfoRegexs = regexHelper.getPatternsMatchingNamedGroupsSet(((batchSeparationTypeInt==1)?new String[]{"FLOWCELL","LANE"}:new String[]{"FLOWCELL"}));
            regexHelper.setPatterns(batchInfoRegexs);

            //bookkeeping
            int fqCount = fqFilenames.size();
            FastqReader[] fqReaderArr = new FastqReader[fqCount];
            boolean[] foundInvalidReadArr = new boolean[fqCount];
            boolean[] foundNonstandardRawArr = new boolean[fqCount];
            FastqRead[] fqReadArr = new FastqRead[fqCount]; //null --> eof/read-failure
            String[] readIdArr = new String[fqCount];
            String[] readTitleArr = new String[fqCount];
            boolean[] brokenZipArr = new boolean[fqCount];
            boolean[] earlyEofReportedArr = new boolean[fqCount];

            boolean atLeastOneInvalidRead = false;
            boolean atLeastOneBrokenZip = false;

            boolean atLeastOneError = false;
            boolean atLeastOneWarning = false;
            boolean standardizationRequiredForAtLeastOneFq = false;
            boolean batchSeparationIndicated = false;

            long readIdConflictCount = 0;
            long readIdRepeatCount = 0;
            boolean readIdSuffixingFoundAtLeastOnce = false;
            boolean readCountConflict = false;
            boolean exceededBatchCountLimit = false;

            boolean[] md5checkFailure = new boolean[fqCount];

            boolean foundInMemReadIdRepeat = false;
            boolean foundRepeatInReadIdChunkFiles = false;


            //batch-related
            // since we require that the readIds match across files, we do not need per-fastq batch counts and read lengths and quality scores tallies
            TreeMap<String,Integer> batchStringToIdx = new TreeMap<String,Integer>();
            //rather than pre-allocate these, we'll add as batches are encountered
            long[][] fqBatchReadCounts = new long[fqCount][MAX_BATCH_COUNT];
            long[][][] fqBatchReadLengthBinTallies = new long[fqCount][MAX_BATCH_COUNT][]; //READ_LENGTH_BIN_COUNT
            long[][][] fqBatchBaseQualityTallies = new long[fqCount][MAX_BATCH_COUNT][];   //!-~ is 33-126, so 94


            //our goal is characterization/profiling only...  Once we know the issues/complexity, we can act as directed according to what ever we've found
            int readIdRefFqIdx = 0; //detect ALL validation issues that we can despite the extra complexity
            for (int i=0; i<fqFilenames.size(); i++)
            {
                FastqReader fqReader = new FastqReader(fqFilenames.get(i));
                fqReaderArr[i] = fqReader;
            }

            if (verbose) { logStream.println("INFO: Beginning read loop at "+dateTimeFormat.format(new Date())); }
            long pass=0;
            while (1==1) //fastq set reading loop...
            {
                pass++;
                //next read from each fastq...
                //  Note that fqReadArr[j] should be null in all cases of "cannot read from reader j anymore"
                int fqEofThisPassCount = 0;
                for (int i=0; i<fqCount; i++)
                {
                    //want report all errors we can to avoid having to run this repeatedly for the same 1-4 fastq files
                    if (pass > 1 && fqReadArr[i] == null) { continue; } //if this reader is already "done", skip it.  We'll break when they're all done
                    try
                    {
                        fqReadArr[i] = fqReaderArr[i].getNextRawRead();
                    }
                    catch (EOFException eofException)
                    {
                        atLeastOneError = true;
                        logStream.println("ERROR: Found unexpected end of ZLIB input stream in read"+(i+1)+":"+fqFilenames.get(i)+" on or after line #"+fqReaderArr[i].getNextLineNumber());
                        earlyEofReportedArr[i] = true;
                        brokenZipArr[i] = true;
                        atLeastOneBrokenZip = true;

                        fqReadArr[i] = null;
                    }
                    catch (IOException ioException)
                    {
                        atLeastOneError = true;
                        logStream.println("ERROR: Encountered a parsing/format error in read"+(i+1)+":"+fqFilenames.get(i)+" on or after line #"+fqReaderArr[i].getNextLineNumber()+" (Details: "+ioException.getMessage()+")");
                        earlyEofReportedArr[i] = true;
                        foundInvalidReadArr[i] = true;
                        atLeastOneInvalidRead = true;

                        fqReadArr[i] = null;
                    }

                    //more ways to be done with the current reader...
                    if (fqReadArr[i] != null)
                    {
                        //read counts are tallied in the FastqReaders...
                        readIdArr[i] = fqReadArr[i].getReadId();
                        readTitleArr[i] = fqReadArr[i].getReadTitleLine();

                        if (!fqReadArr[i].isValid())
                        {
                            //shouldn't be possible...  Should have thrown an exception during parsing if this were the case
                            atLeastOneError = true;
                            logStream.println("ERROR: Found invalid read in read"+(i+1)+":"+fqFilenames.get(i)+" near line #"+(fqReaderArr[i].getNextLineNumber()-4)+": "+FastqRead.getFirstValidityErrorMessage(fqReadArr[i]));
                            fqReadArr[i] = null; //signal to stop reading this stream
                            foundInvalidReadArr[i] = true;
                            atLeastOneInvalidRead = true;
                        }
                        else if (!fqReadArr[i].isInStandardForm())
                        {
                            atLeastOneWarning = true;
                            if (!foundNonstandardRawArr[i])
                            {
                                logStream.println("WARNING: Found read in non-standard form in read"+(i+1)+":"+fqFilenames.get(i)+" near line #"+(fqReaderArr[i].getNextLineNumber()-4)+": "+FastqRead.getFirstRawNonStandardErrorMessage(fqReadArr[i])+" (This will be the only such warnings for this file.)");
                                standardizationRequiredForAtLeastOneFq = true;
                                foundNonstandardRawArr[i] = true;
                            }
                        }
                    }

                    if (fqReadArr[i] == null)
                    {
                        fqEofThisPassCount++;
                        //since fqReadArr[i] == null...
                        readIdArr[i] = null;
                        readTitleArr[i] = null;
                    }
                }
                //...next read from each fastq

                //all better be eof if one is!
                boolean allEof = false;
                if (fqEofThisPassCount>0)
                {
                    
                    if (fqEofThisPassCount == fqCount) //hope they all end together, but it might not be true...
                    {
                        allEof = true;
                    }
                    else
                    {
                        atLeastOneError = true;
                        allEof = true;
                        for (int i=0; i<fqCount; i++)
                        {
                            if (fqReadArr[i] != null)
                            {
                                allEof = false;
                            }
                            else if (!earlyEofReportedArr[i]) //&& fqReadArr[i] == null
                            {
                                logStream.println("ERROR: Encountered EOF at inconsistent numbers of reads across fastq files -- read"+(i+1)+":"+fqFilenames.get(i)+" ended at read #"+fqReaderArr[i].getNextReadNumber());
                                earlyEofReportedArr[i] = true;
                                if (readIdRefFqIdx == i)
                                {
                                    //try to find a new authority for readIds / distinct batches...
                                    while (readIdRefFqIdx != -1)
                                    {
                                        readIdRefFqIdx++;
                                        if (readIdRefFqIdx >= fqCount)
                                        {
                                            readIdRefFqIdx = -1; //should only be possible if they've all hit eof
                                        }
                                        else if (fqReadArr[readIdRefFqIdx] != null)
                                        {
                                            //looks like we found our new authority...  But it isn't good that it had to move
                                            atLeastOneWarning = true;
                                            logStream.println("WARNING: Due to differing read counts across the fastqs, batch-related info and read id uniqueness checking may be inaccurate.");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (allEof)
                {
                    //all out of reader-/read-level things to check
                    break; //so let's exit from the reading loop
                }

                //verify readId match across fqFiles -- kinda assume WLoG that PE is "normal"
                boolean readIdConflict = false;
                for (int i=0; i<fqCount; i++)
                {
                    if (i==readIdRefFqIdx) { continue; }
                    if (fqReadArr[i] == null) { continue; }
                    readIdConflict = !readIdArr[readIdRefFqIdx].equals(readIdArr[i]);
                    if (readIdConflict)
                    {
                        //do not consider this an error yet...
                        break;
                    }
                }
                //  special case handling for suffixing
                if (readIdConflict)
                {
                    boolean readIdSuffixingFound = true; //since this is potentially recoverable, assume true till proven otherwise...
                    String[] readIdSansSuffixArr = new String[fqCount];
                    for (int i=0; i<fqCount; i++)
                    {
                        if (fqReadArr[i] == null) { continue; }
                        String expectedSuffix = "/"+(i+1); //if present...
                        if (readIdArr[i].endsWith(expectedSuffix))
                        {
                            readIdSansSuffixArr[i] = readIdArr[i].substring(0,readIdArr[i].length()-expectedSuffix.length());
                        }
                        else
                        {
                            readIdSansSuffixArr[i] = readIdArr[i];
                        }
                    }
                    boolean allConflictsSavedBySuffixTrim = true;
                    for (int i=0; i<fqCount; i++)
                    {
                        if (i==readIdRefFqIdx) { continue; }
                        if (fqReadArr[i] == null) { continue; }
                        if (!readIdSansSuffixArr[readIdRefFqIdx].equals(readIdSansSuffixArr[i]))
                        {
                            allConflictsSavedBySuffixTrim = false;
                            atLeastOneError = true;
                            readIdConflictCount++;
                            if (readIdConflictCount <= MAX_READID_CONFLICTS_TO_REPORT)
                            {
                                logStream.println("ERROR: Found readId conflict -- readId "+readIdArr[i]+" in read"+(i+1)+":"+fqFilenames.get(i)+" near line #"+(fqReaderArr[i].getNextLineNumber()-4)+
                                                   " does not match readId "+readIdArr[readIdRefFqIdx]+" in read"+(readIdRefFqIdx+1)+":"+fqFilenames.get(readIdRefFqIdx)+" near line #"+(fqReaderArr[readIdRefFqIdx].getNextLineNumber()-4));
                                if (readIdConflictCount == MAX_READID_CONFLICTS_TO_REPORT)
                                {
                                    logStream.println("WARNING: Future readId conflicts will not be reported");
                                }
                            }
                        }
                    }
                    readIdConflict = !allConflictsSavedBySuffixTrim;
                    readIdSuffixingFound = allConflictsSavedBySuffixTrim;
                    if (readIdSuffixingFound)
                    {
                        if (!readIdSuffixingFoundAtLeastOnce) //i.e., not previously found
                        {
                            readIdSuffixingFoundAtLeastOnce = true;
                            atLeastOneWarning = true;
                            logStream.print("WARNING: Found readIds with numeric suffixing -- base readId "+readIdSansSuffixArr[readIdRefFqIdx]+
                                            " found as readId "+readIdArr[readIdRefFqIdx]+" in read"+(readIdRefFqIdx+1)+":"+fqFilenames.get(readIdRefFqIdx)+" near line #"+(fqReaderArr[readIdRefFqIdx].getNextLineNumber()-4));
                            for (int i=0; i<fqCount; i++)
                            {
                                if (readIdRefFqIdx==i) { continue; }
                                if (readIdArr[i] != null)
                                {
                                    logStream.print(" vs as readId "+readIdArr[i]+" in read"+(i+1)+":"+fqFilenames.get(i)+" near line #"+(fqReaderArr[i].getNextLineNumber()-4));
                                }
                                else
                                {
                                    logStream.print(" vs not having appeared before EOF in read"+(i+1)+":"+fqFilenames.get(i)+" near line #"+(fqReaderArr[i].getNextLineNumber()-4));
                                }
                            }
                            logStream.println(" (Numeric suffixes are always trimmed, and this will only be reported once.)");
                        }
                        //should be safe to strip suffixing
                        for (int i=0; i<fqCount; i++)
                        {
                            if (fqReadArr[i] != null)
                            {
                                fqReadArr[i].setReadId(readIdSansSuffixArr[i]);
                            }
                        }
                    }
                }

                //only test uniqueness of readIds from ONE fq since they must match across fqs (excluding potential suffixes like '/1' and '/2' that we'll trim with a warning)
                //in case of an early EOF in one of the fqs, the source of readId might bounce across fqs...  We'll keep testing it since we can at least try...
                if (readIdRefFqIdx != -1) //should always be true...  Really, we'd hope this is always 0
                {
                    //To match logic in SimpleOptimisticBatchSeparator, always trim trailing /1 /2 /3 /4 from readIds
                    // Only weird cases like read1.fq and read2.fq both having suffixes and being concatentated together would be expected to cause issues
                    // but, regardless, this is 
                    String trimmedReadId = readIdArr[readIdRefFqIdx].replaceAll("/[1-4]$","");
                    Long previousInMemOccurenceLine = readIdList.addReadIdOrReportInMemoryCollision(trimmedReadId, (fqReaderArr[readIdRefFqIdx].getNextLineNumber()-4));
                    if (previousInMemOccurenceLine != null)
                    {
                        foundInMemReadIdRepeat  = true;
                        readIdRepeatCount++;
                        if (readIdRepeatCount <= MAX_READID_REPEATS_TO_REPORT)
                        {
                            if (readIdRefFqIdx == 0)
                            {
                                logStream.println("ERROR: Encountered readId collision (repeated readId) -- readId \""+trimmedReadId+"\" near line #"+previousInMemOccurenceLine+
                                                  " repeated near line #"+(fqReaderArr[readIdRefFqIdx].getNextLineNumber()-4)+" in read"+(readIdRefFqIdx+1)+":"+fqFilenames.get(readIdRefFqIdx));
                                atLeastOneError = true;
                            }
                            else
                            {
                                logStream.println("WARNING: Encountered readId collision (repeated readId) -- readId \""+trimmedReadId+"\" near line #"+previousInMemOccurenceLine+
                                                  " (of a shorter fastq file) repeated near line #"+(fqReaderArr[readIdRefFqIdx].getNextLineNumber()-4)+" in read"+(readIdRefFqIdx+1)+":"+fqFilenames.get(readIdRefFqIdx));
                                atLeastOneWarning = true;
                            }
                            if (readIdRepeatCount == MAX_READID_REPEATS_TO_REPORT)
                            {
                                logStream.println("WARNING: No future readId collisions will be reported.");
                            }
                        }
                    }
                }


                //Check for the need to batch separate
                // and batch-level tallies to tally
                if (readIdRefFqIdx != -1)
                {
                    //identify batches and output files...  The logic of this varies with the fqOutputPattern, so use the pattern helper
                    // Not sure I like the way this is working out in practice...  Fun idea, but it feels like it needs some refinement (or a special FastqBatch helper/class)
                    // Anyway...  Generate an output filename to group reads into batches
                    Hashtable<String, String> batchInfo = regexHelper.findFirstMatch(readTitleArr[readIdRefFqIdx]);
                    String batchString = ((batchInfo == null)?"__NOBATCH":"__batch_"+batchInfo.get("FLOWCELL")+((batchSeparationTypeInt==1)?"_"+batchInfo.get("LANE"):""));
                    if (!exceededBatchCountLimit && !batchStringToIdx.containsKey(batchString))
                    {
                        if (batchStringToIdx.keySet().size() < MAX_BATCH_COUNT)
                        {
                            if (verbose)
                            {
                                logStream.println("INFO: Found new/default batch ("+batchString+") in read title line \""+readTitleArr[readIdRefFqIdx]+"\" in read"+(readIdRefFqIdx+1)+":"+fqFilenames.get(readIdRefFqIdx)+" near line #"+(fqReaderArr[readIdRefFqIdx].getNextLineNumber()-4));
                            }

                            //use the next idx for the new batch
                            int idx = batchStringToIdx.keySet().size();
                            batchStringToIdx.put(batchString,idx);

                            for (int i=0; i<fqCount; i++)
                            {
                                if (fqReadArr[i] != null)
                                {
                                    //already allocated fqBatchReadCounts[i][idx]
                                    fqBatchReadLengthBinTallies[i][idx] = new long[READ_LENGTH_BIN_COUNT];
                                    fqBatchBaseQualityTallies[i][idx] = new long[94]; //!-~ is 33-126, so 126-32 --> 94 bins
                                }
                            }
                        }
                        else
                        {
                            atLeastOneError = true;
                            exceededBatchCountLimit = true;
                            logStream.println("ERROR: Exceeded the maximum expected number of batches (additional batches will be ignored) -- More than "+MAX_BATCH_COUNT+" batches found in read"+(readIdRefFqIdx+1)+":"+fqFilenames.get(readIdRefFqIdx));
                        }
                    }
                    if (batchStringToIdx.containsKey(batchString))
                    {
                        int idx = batchStringToIdx.get(batchString);

                        for (int i=0; i<fqCount; i++)
                        {
                            if (fqReadArr[i] != null)
                            {
                                fqBatchReadCounts[i][idx] = fqBatchReadCounts[i][idx]+1;

                                int readLengthBinIdx = fqReadArr[i].getReadBlock().length()/READ_LENGTH_BIN_SIZE;
                                if (readLengthBinIdx >= READ_LENGTH_BIN_COUNT) { readLengthBinIdx = READ_LENGTH_BIN_COUNT-1; }
                                fqBatchReadLengthBinTallies[i][idx][readLengthBinIdx] = fqBatchReadLengthBinTallies[i][idx][readLengthBinIdx]+1;

                                String qualityBlock = fqReadArr[i].getQualityBlock();
                                for (int j=0; j<qualityBlock.length(); j++)
                                {
                                    int qualityIdx = ((int)qualityBlock.charAt(j))-33; //33 <---> !
                                    fqBatchBaseQualityTallies[i][idx][qualityIdx] = fqBatchBaseQualityTallies[i][idx][qualityIdx]+1;
                                }
                            }
                        }
                    }
                }


            } //...fastq set reading loop
            if (verbose) { logStream.println("INFO: Exited read loop at "+dateTimeFormat.format(new Date())); }
            boolean allEofTogether = true;
            for (int i=1; i<fqCount; i++)
            {
                if (fqReaderArr[0].getNextReadNumber() != fqReaderArr[i].getNextReadNumber())
                {
                    allEofTogether = false;
                    break;
                }
            }

            if (verbose) { logStream.println("INFO: Starting post-read-loop checks at "+dateTimeFormat.format(new Date())); }
            for (int i=0; i<fqCount; i++)
            {
                String currentFqFilePath = fqFilenames.get(i);

                //line and read counts
                if (verbose)
                {
                    long lineCount = fqReaderArr[i].getNextLineNumber();
                    long readCount = fqReaderArr[i].getNextReadNumber();
                    logStream.println("INFO: Found "+lineCount+" line(s) / "+readCount+" read(s) in "+currentFqFilePath);
                    for (int j=0; j<fqBatchReadCounts[i].length; j++)
                    {
                        if (fqBatchReadCounts[i][j] == 0) { break; }
                        logStream.println("INFO: Found "+fqBatchReadCounts[i][j]+" read(s) in batch #"+(j+1)+" (in order of appearance) in "+currentFqFilePath);
                    }
                }

                //close reader (to finalize checksums and free a small amount of resources)
                fqReaderArr[i].close();

                //md5...
                if (md5s != null && md5s.size()>i)
                {
                    if (foundInvalidReadArr[i])
                    {
                        logStream.println("ERROR: Cannot calculate MD5 checksum for read"+(i+1)+":"+currentFqFilePath+" -- reading terminated on a malformed read");
                    }
                    else if (brokenZipArr[i])
                    {
                        logStream.println("ERROR: Cannot calculate MD5 checksum for read"+(i+1)+":"+currentFqFilePath+" -- reading terminated due to an apparently corrupted zip file");
                    }
                    else
                    {
                        String md5Digest = fqReaderArr[i].getFinalMD5();
                        if (md5s.get(i) == null || md5s.get(i).length() == 0)
                        {
                            if (verbose) { logStream.println("INFO: MD5 checksum for read"+(i+1)+":"+currentFqFilePath+" was "+md5Digest); }
                        }
                        else if (!md5Digest.equals(md5s.get(i)))
                        {
                            atLeastOneError = true;
                            logStream.println("ERROR: MD5 checksum mismatch for read"+(i+1)+":"+currentFqFilePath+" -- actual: "+md5Digest+" / expected: "+md5s.get(i));
                            md5checkFailure[i] = true;
                        }
                        else
                        {
                            if (verbose) { logStream.println("INFO: Good MD5 checksum match for read"+(i+1)+":"+currentFqFilePath+" -- actual/expected: "+md5Digest); }
                        }
                    }
                }
                else
                {
                    String md5Digest = fqReaderArr[i].getFinalMD5();
                    if (verbose) { logStream.println("INFO: MD5 checksum match for read"+(i+1)+":"+currentFqFilePath+" -- actual: "+md5Digest); }
                }

                //report batch counts...
                if (batchStringToIdx.keySet().size() > 1)
                {
                    batchSeparationIndicated = true;
                    logStream.println("WARNING: Batch separation indicated for read"+(i+1)+":"+currentFqFilePath+" -- found "+batchStringToIdx.keySet().size()+" distinct batches");
                    atLeastOneWarning = true;
                }
            }

            //check for readId collision in the "chunk files" (unless we've already hit the reporting limit for readId repeats)
            if (readIdRepeatCount < MAX_READID_REPEATS_TO_REPORT)
            {
                String repeatReadIdInfo = null;
                try
                {
                    repeatReadIdInfo = readIdList.findRepeatInfoForFirstRepeatedReadId();
                    if (repeatReadIdInfo != null)
                    {
                        atLeastOneError = true;
                        foundRepeatInReadIdChunkFiles = true;
                        if (allEofTogether)
                        {
                            logStream.println("ERROR: Encountered duplicate readId during exhaustive uniqueness check for read1:"+fqFilenames.get(0)+" -- "+repeatReadIdInfo.replace("\t"," on lines "));
                        }
                        else
                        {
                            logStream.println("ERROR: Encountered at least one probable duplicate readId during exhaustive uniqueness check across the set of input fastq files: "+repeatReadIdInfo.split("\t")[0]);
                        }
                    }
                }
                catch (IOException ioe)
                {
                    atLeastOneError = true;
                    logStream.println("ERROR: Unexpected failure while trying to perform exhaustive readId uniqueness check -- "+ioe.getMessage());
                }
            }

            //done with checks...
            int exitStatus = 0;
            if (verbose) { logStream.println("INFO: Finished post-read-loop checks at "+dateTimeFormat.format(new Date())); }
            if (atLeastOneError)
            {
                //already reported...  And we're done until someone fixes either files or args...
                logStream.println("ERROR: Manual correction of some kind required.  See ERROR "+((atLeastOneWarning)?"and WARNING ":"")+"messages above");
                exitStatus = 1;
            }
            else if (atLeastOneWarning)
            {
                //a non-zero exit status is all the "message" that DAGMAN and John's scatter-gather need
                logStream.println("WARNING:"+
                    ((batchSeparationIndicated)?" Batch separation and standardization required.":((standardizationRequiredForAtLeastOneFq)?" Standardization is required.":" Action is required."))
                    +"  See WARNING messages above.");  //
                exitStatus = 0;
            }
            else
            {
                logStream.println("INFO: No issues detected");
            }
            if (verbose) { logStream.println("INFO: Done at "+dateTimeFormat.format(new Date())); }

            if (parsedArgs.containsKey("l")) { logStream.close(); }
            System.exit(exitStatus);
        }
        
    }
}
