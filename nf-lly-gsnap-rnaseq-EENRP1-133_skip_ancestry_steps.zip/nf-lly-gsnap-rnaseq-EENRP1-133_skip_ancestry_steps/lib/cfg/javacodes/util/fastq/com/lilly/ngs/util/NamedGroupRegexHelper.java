package com.lilly.ngs.util;

import java.io.*;
import java.util.*;
import java.util.regex.*;

/*

    Simple helper class to load a file of regexs and identify named groups in them.
    Four major functions:
    1. Load regexs from (the specified column of) a delimited file
    2. Identify the named groups in each regex
    3. Provide the list of patterns on request (if requested, filtered by a list of required named groups)
    4. For a given target string and a list of Patterns, return a Hashtable<String,String> of named group captures from the first matched regex

*/



public class NamedGroupRegexHelper
{
    private String regexsFilePath;
    private ArrayList<Pattern> loadedRegexs;
    private static Pattern namedCaptureGroupPattern = Pattern.compile("[(][?]<([A-Za-z][0-9A-Za-z]*)>"); //this might not be perfect, but it should be close enough to usefully reduce the regex set to test
    private ArrayList<ArrayList<String>> groupNamesFoundInLoadedRegexs;


    private NamedGroupRegexHelper()
    {
    }


    private NamedGroupRegexHelper(String regexsFilePath) throws IOException, PatternSyntaxException
    {
        this(regexsFilePath, "\t", 0, 0, true);
    }


//    public NamedGroupRegexHelper(String regexsFilePath, int regexColumnIdx) throws IOException, PatternSyntaxException
//    {
//        this(regexsFilePath, "\t", regexColumnIdx, 0, true);
//    }


    public NamedGroupRegexHelper(String regexsFilePath, int regexColumnIdx) throws IOException, PatternSyntaxException
    {
        String delimiter="\t"; int headerLinesToSkip=0; boolean skipLinesThatStartWithPound=true;

        //load up the regexs file...
        this.regexsFilePath = (new File(regexsFilePath)).getCanonicalPath();
        loadedRegexs = new ArrayList<Pattern>();
        BufferedReader br = new BufferedReader(new FileReader(regexsFilePath));
        String line;
        int lineNbr = 0;
        while ((line = br.readLine()) != null)
        {
            lineNbr++;
            if (lineNbr <= headerLinesToSkip) { continue; }
            if (line.length() > 0)
            {
                if (skipLinesThatStartWithPound && line.charAt(0) == '#') { continue; }
                String[] fields = line.split(delimiter);
                if (fields.length <= regexColumnIdx)
                {
                    throw new IOException("Found too few fields on line #"+lineNbr+" of "+(new File(regexsFilePath)).getCanonicalPath());
                }
                else
                {
                    try
                    {
                        Pattern newPattern = Pattern.compile(fields[regexColumnIdx]);
                        loadedRegexs.add(newPattern); //might be duplicates...  Really does not matter enough to bother trying to report duplicates
                    }
                    catch (PatternSyntaxException pse)
                    {
                        throw new PatternSyntaxException("Invalid regular expression on line #"+lineNbr+" of "+(new File(regexsFilePath)).getCanonicalPath()+"\n"+pse.getDescription(),
                                                         pse.getPattern(), pse.getIndex());
                    }
                }
            }
        }
        br.close();
        br = null;

        //now find the named groups
        groupNamesFoundInLoadedRegexs = findGroupNamesInPatterns(loadedRegexs);
    }


    public NamedGroupRegexHelper(String regexsFilePath, String delimiter, int regexColumnIdx, int headerLinesToSkip, boolean skipLinesThatStartWithPound) throws IOException, PatternSyntaxException
    {
        //load up the regexs file...
        this.regexsFilePath = (new File(regexsFilePath)).getCanonicalPath();
        loadedRegexs = new ArrayList<Pattern>();
        BufferedReader br = new BufferedReader(new FileReader(regexsFilePath));
        String line;
        int lineNbr = 0;
        while ((line = br.readLine()) != null)
        {
            lineNbr++;
            if (lineNbr <= headerLinesToSkip) { continue; }
            if (line.length() > 0)
            {
                if (skipLinesThatStartWithPound && line.charAt(0) == '#') { continue; }
                String[] fields = line.split(delimiter);
                if (fields.length <= regexColumnIdx)
                {
                    throw new IOException("Found too few fields on line #"+lineNbr+" of "+(new File(regexsFilePath)).getCanonicalPath());
                }
                else
                {
                    try
                    {
                        Pattern newPattern = Pattern.compile(fields[regexColumnIdx]);
                        loadedRegexs.add(newPattern); //might be duplicates...  Really does not matter enough to bother trying to report duplicates
                    }
                    catch (PatternSyntaxException pse)
                    {
                        throw new PatternSyntaxException("Invalid regular expression on line #"+lineNbr+" of "+(new File(regexsFilePath)).getCanonicalPath()+"\n"+pse.getDescription(),
                                                         pse.getPattern(), pse.getIndex());
                    }
                }
            }
        }
        br.close();
        br = null;

        //now find the named groups
        groupNamesFoundInLoadedRegexs = findGroupNamesInPatterns(loadedRegexs);
    }


    public static ArrayList<ArrayList<String>> findGroupNamesInPatterns(ArrayList<Pattern> patterns)
    {
        ArrayList<ArrayList<String>> groupNamesFoundInPatterns = new ArrayList<ArrayList<String>>();
        for (int i=0; i<patterns.size(); i++)
        {
            ArrayList<String> groupNamesFoundInCurrentRegex = new ArrayList<String>();
            groupNamesFoundInPatterns.add(groupNamesFoundInCurrentRegex);

            Matcher m = namedCaptureGroupPattern.matcher(patterns.get(i).pattern());
            int startOffset = 0;
            while (m.find(startOffset))
            {
                String name = m.group(1);
                groupNamesFoundInCurrentRegex.add(name);
                startOffset = m.end(1);
            }
        }
        return groupNamesFoundInPatterns;
    }


    public String getCanonicalFilePath()
    {
        return regexsFilePath;
    }


    public ArrayList<Pattern> getAllPatterns()
    {
        ArrayList<Pattern> allPatterns = new ArrayList<Pattern>(loadedRegexs);
        return allPatterns;
    }


    public void setPatterns(ArrayList<Pattern> patterns)
    {
        loadedRegexs = patterns;
        regexsFilePath = null;
        groupNamesFoundInLoadedRegexs = findGroupNamesInPatterns(loadedRegexs);
    }


    public ArrayList<Pattern> getPatternsMatchingNamedGroupsSet(String[] requiredNames)
    {
        ArrayList<Pattern> matchedPatterns = new ArrayList<Pattern>();
        for (int i=0; i<groupNamesFoundInLoadedRegexs.size(); i++)
        {
            boolean allRequiredNamesFound = true;
            for (int j=0; j<requiredNames.length; j++)
            {
                if (!groupNamesFoundInLoadedRegexs.get(i).contains(requiredNames[j]))
                {
                    allRequiredNamesFound = false;
                    break;
                }
            }
            if (allRequiredNamesFound)
            {
                matchedPatterns.add(loadedRegexs.get(i));
            }
        }
        return matchedPatterns;
    }


    public ArrayList<Pattern> getPatternsMatchingNamedGroupsSet(ArrayList<String> requiredNames)
    {
        return getPatternsMatchingNamedGroupsSet(requiredNames.toArray(new String[]{}));
    }


    public Hashtable<String, String> findFirstMatch(String target)
    {
        Hashtable<String, String> matchGroupVals = null;
        for (int i=0; i<loadedRegexs.size(); i++)
        {
            Matcher m = loadedRegexs.get(i).matcher(target);
            if (m.find())
            {
                matchGroupVals = new Hashtable<String, String>();
                for (int j=0; j<groupNamesFoundInLoadedRegexs.get(i).size(); j++)
                {
                    matchGroupVals.put(groupNamesFoundInLoadedRegexs.get(i).get(j), m.group(groupNamesFoundInLoadedRegexs.get(i).get(j)));
                }
                break;
            }
        }
        return matchGroupVals;
    }


    public static void main(String[] args) throws Exception
    {
        if (args.length < 2 || args.length > 3)
        {
            System.out.println("SYNTAX: java "+ClassFindBinHelper.getCallingClassName()+" <tab-delim-regex-file> <regex-column-idx> [test-string]");
            System.out.println("        This main() is a simple test of loading the regex file and, optionally, testing the test-string for a matching regex.");
            System.out.println("        The NamedGroupRegexHelper(String,int) constructor is used for these simple tests...");
        }
        else
        {
            NamedGroupRegexHelper regexHelper = new NamedGroupRegexHelper(args[0], Integer.parseInt(args[1]));
            System.out.println("Loaded "+regexHelper.getAllPatterns().size()+" regex(s) loaded from "+regexHelper.getCanonicalFilePath());
            System.out.println("Group names found by regex:");
            for (int i=0; i<regexHelper.groupNamesFoundInLoadedRegexs.size(); i++)
            {
                System.out.println("    Named groups found in pattern #"+(i+1)+": "+regexHelper.loadedRegexs.get(i));
                for (int j=0; j<regexHelper.groupNamesFoundInLoadedRegexs.get(i).size(); j++)
                {
                    System.out.println("        "+regexHelper.groupNamesFoundInLoadedRegexs.get(i).get(j));
                }
            }
            System.out.println("Filtering regexs...");
            ArrayList<Pattern> filteredRegexs = regexHelper.getPatternsMatchingNamedGroupsSet(new String[]{"FLOWCELL"});
            System.out.println("Re-setting regexs with the even numbered ones removed...");
            for (int i=filteredRegexs.size()-1; i>=0; i--)
            {
                if (i%2==0) { continue; }
                filteredRegexs.remove(i);
            }
            System.out.println("Remaining regex count="+filteredRegexs.size());
            regexHelper.setPatterns(filteredRegexs);
            System.out.println("Group names found by regex:");
            for (int i=0; i<regexHelper.groupNamesFoundInLoadedRegexs.size(); i++)
            {
                System.out.println("    Named groups found in pattern #"+(i+1)+": "+regexHelper.loadedRegexs.get(i));
                for (int j=0; j<regexHelper.groupNamesFoundInLoadedRegexs.get(i).size(); j++)
                {
                    System.out.println("        "+regexHelper.groupNamesFoundInLoadedRegexs.get(i).get(j));
                }
            }
            if (args.length == 3)
            {
                Hashtable<String, String> hash = regexHelper.findFirstMatch(args[2]);
                if (hash == null)
                {
                    System.out.println("No match for "+args[2]);
                }
                else
                {
                    System.out.println("Match for \""+args[2]+"\":");
                    for (Enumeration<String> keys = hash.keys(); keys.hasMoreElements(); )
                    {
                        String key = keys.nextElement();
                        System.out.println("    "+key+"  -->  "+hash.get(key));
                    }
                }
            }
        }
    }
}
