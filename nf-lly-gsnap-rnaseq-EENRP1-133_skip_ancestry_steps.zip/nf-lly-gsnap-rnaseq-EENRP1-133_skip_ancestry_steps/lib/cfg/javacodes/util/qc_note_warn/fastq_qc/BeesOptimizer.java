import java.util.*;


public class BeesOptimizer
{
    public static boolean DEBUG = false;
    public static int SCOUT_COUNT = 5;

    public int TREESET_CAPACITY = 100;
    TreeSet<double[]> headFitResults;
    //Each array will hold the following (in order as specified):
    //  SumOfSquares and then the ordered parameter set


    public BeesOptimizer()
    {
        headFitResults = new TreeSet<double[]>(new Comparator<double[]>() {
                                                    public int compare(double[] o1, double[] o2) {
                                                        int result = Double.compare(o1[0], o2[0]);
                                                        return result;
                                                    }
                                                });
    }

    private boolean areEqual(double[] arrayA, double[] arrayB)
    {
        boolean retVal = !(arrayA == null || arrayB == null);
        if (retVal && arrayA.length == arrayB.length)
        {
            for (int i=0; i<arrayA.length; i++)
            {
                if (arrayA[i] != arrayB[i])
                {
                    retVal = false;
                    break;
                }
            }
        }
        return retVal;
    }

    public double calculateSSE(double[] actuals, double[] predictions)
    {
        double sse = 0.0;
        for (int i=0; i<actuals.length; i++)
        {
            double diff = actuals[i]-predictions[i];
            sse += diff*diff;
        }
        return sse;
    }

    //Returns the SSE and parameters at the best encountered fit
    public double[] fit(
            MultiparametricFunction mpf,
            double[] initialParameters,
            double[][] parameterBounds,
            double[] xValues, double[] yValues,
            double precision, int rounds, int iterationsPerRound)
    {
        if (DEBUG) { System.out.println("Starting fit..."); }
        double[] initialFitResult = new double[initialParameters.length+1];
        int pointCount = xValues.length;

        double[] initialYPredictions = mpf.evaluate(initialParameters, xValues);
        initialFitResult[0] = calculateSSE(yValues, initialYPredictions);
        System.arraycopy(initialParameters, 0, initialFitResult, 1, initialParameters.length);
        headFitResults.add(initialFitResult);

        //armed with the initial guesses and bounds, start trying to do better...
        for (int j=0; j<rounds; j++)
        {
            double[] startingFirst = headFitResults.first();
            sendWorkerBees(mpf, SCOUT_COUNT, parameterBounds, xValues, yValues, precision, iterationsPerRound);

            double[] first = headFitResults.first();
            if (DEBUG)
            {
                System.out.println("BeesOptimizer (precision: "+precision+"; iterations/round: "+iterationsPerRound+") results from pass #"+(j+1)+" (of at most "+rounds+"):");
                System.out.print("        Best: "+ first[0]);
                for (int i=1; i<first.length; i++)
                {
                    System.out.print("\t"+first[i]);
                }
                System.out.println();
            }

            double percentDiff;
            boolean significantlyBetter = (Math.abs(2.0*(startingFirst[0]-first[0])/(startingFirst[0]+first[0])) > precision);
            boolean trivialChanges = true;
            if (DEBUG) System.out.print("Percent diff:");
            for (int i=0; i<first.length; i++)
            {
                percentDiff = Math.abs(2.0*(startingFirst[i]-first[i])/(startingFirst[i]+first[i]));
                if (DEBUG) System.out.print("\t"+percentDiff);
                if (percentDiff >= precision)
                {
                    trivialChanges = false;
                }
            }
            if (DEBUG) System.out.println();
            if (!significantlyBetter
                // && trivialChanges
               )
            {
                break;
            }
        }

        double[] bestSeenFitResult = headFitResults.first();
        headFitResults.clear();

        return bestSeenFitResult;
    }
    
    private boolean sendWorkerBees(
            MultiparametricFunction mpf,
            int numberOfScouts,
            double[][] parameterBounds,
            double[] xValues, double[] yValues,
            double precision, int swarmCount)
    {
        boolean foundBetter = false;
        int parameterCount = parameterBounds.length;

        //set the step size such that a best-seen could walk the full range
        // in the first step (actual +/- steps will be constrained by param bounds)
        //and decay step size each iteration exponentially such that the last
        // swarm is spread at most +/- the specified precision
        double[] first = headFitResults.first();
        double[] bestParams = new double[parameterCount];
        System.arraycopy(first, 1, bestParams, 0, parameterCount);
        double[] stepSizes = new double[parameterCount];
        for (int i=0; i<parameterBounds.length; i++)
        {
            stepSizes[i] = (parameterBounds[i][1]-parameterBounds[i][0])/2.0; //ok... only HALF the full range
        }

        double currentSSE, bestSSE;
        int runningNoImprovementCount = -1;
        boolean improvedThisStep;

        //Each "swarm"/step will consist of 3**(number of parameters) "bees"/paramsets
        for (int swarmNbr = 1; swarmNbr<=swarmCount; swarmNbr++)
        {
            ArrayList<double[]> bestSeenList = new ArrayList<double[]>(numberOfScouts);
            Iterator<double[]> iterator = headFitResults.iterator();
            for (int i=0; i<numberOfScouts; i++)
            {
                if (iterator.hasNext())
                {
                    bestSeenList.add(iterator.next());
                }
                else
                {
                    break;
                }
            }
            iterator = null;

            improvedThisStep = false;
            runningNoImprovementCount++;
            for (double[] seedParamsFit : bestSeenList)
            {
                bestSSE = seedParamsFit[0];
                System.arraycopy(seedParamsFit, 1, bestParams, 0, parameterCount);

                //jitter the params
                double[][] toFit = new double[(int)Math.pow(3,bestParams.length)][parameterCount];
                int idx = 0, soFar;

                //the seed in the center...
                toFit[idx++] = bestParams.clone();

                //jitter each point in parameter space about the "best"(s)
                for (int p=0; p<parameterCount; p++)
                {
                    soFar = idx;
                    for (int i=0; i<soFar; i++)
                    {
                        double stepSize;

                        //jitter p-
                        toFit[idx] = toFit[i].clone();
                        stepSize = toFit[i][p]-parameterBounds[p][0];
                        stepSize = (stepSize <= stepSizes[p])?stepSize:stepSizes[p];
                        toFit[idx][p] -= Math.random()*stepSize;
                        idx++;

                        //jitter p+
                        toFit[idx] = toFit[i].clone();
                        stepSize = parameterBounds[p][1]-toFit[i][p];
                        stepSize = (stepSize <= stepSizes[p])?stepSize:stepSizes[p];
                        toFit[idx][p] += Math.random()*stepSize;
                        idx++;
                    }
                }

                //already tested the seed, so skip it and try the others
                for (int i=1; i<toFit.length; i++)
                {
                    double[] params = toFit[i];
                    double[] yPredictions = mpf.evaluate(params, xValues);
                    currentSSE = calculateSSE(yValues, yPredictions);

                    if (!Double.isNaN(currentSSE) && !Double.isInfinite(currentSSE))
                    {
                        if (currentSSE < bestSSE)
                        {
                            improvedThisStep = true;
                            bestSSE = currentSSE;
                            foundBetter = true;
                        }

                        double[] fitResult = new double[parameterCount+1];
                        fitResult[0] = currentSSE;
                        System.arraycopy(params,0,fitResult,1,parameterCount);
                        headFitResults.add(fitResult);
                        if (headFitResults.size() > TREESET_CAPACITY)
                        {
                            headFitResults.pollLast();
                        }
                    }
                }
            }

            //tighten the swarms in the next step
            //if (DEBUG) { System.out.print("Step size:\t"+swarmNbr); }
            for (int p=0; p<parameterCount; p++)
            {
                double R = (parameterBounds[p][1]-parameterBounds[p][0])/2.0;
                stepSizes[p] = R*Math.exp(swarmNbr*Math.log(precision/R)/swarmCount);
                //if (DEBUG) { System.out.print("\t"+stepSizes[p]); }
            }
            //if (DEBUG) { System.out.println(); }

            if (improvedThisStep)
            {
                runningNoImprovementCount = -1;
            }
            else
            {
                runningNoImprovementCount++;
            }
        }
        return foundBetter;
    }

}

