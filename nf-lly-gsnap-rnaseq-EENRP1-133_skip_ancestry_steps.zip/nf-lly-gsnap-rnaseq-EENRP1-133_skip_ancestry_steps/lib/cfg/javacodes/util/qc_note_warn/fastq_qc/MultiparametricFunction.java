public interface MultiparametricFunction
{
    public double[][] getParameterBounds();
    public double[] getDefaultInitialParameters();
    public double[] estimateInitialParameters(double[] xValues, double[] yValues);
    public double[] evaluate(double[] parameters, double[] xValues);
}
