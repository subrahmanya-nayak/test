import java.io.*;

public class NormalizedBaseQualityModel implements MultiparametricFunction
{
    public static boolean DEBUG = false;
    public static int PARAMETER_COUNT = 6;

    //For initial parameter estimation
    public double PRECISION = 1e-4;
    public int ITERATIONS = 10;
    public int ROUNDS = 10;

    //MultiparametricFunction:
    /*
        The model:
                      y=A*B*C
          initial rise: A = 1/(1+EXP(-ku*(x-xu)))
    linear degradation: B = (y1-y0)*x+y0
            final fall: C = 1-1/(1+EXP(-kd*(x-xd)))
    */
    public double[][] getParameterBounds()
    {
        double[][] parameterBounds = new double[][] {
                                                        {0.0, 100.0},       //1 ku
                                                        {-1.0, 2.0},        //2 xu
                                                        {0.0, 2.0},         //3 y0 -- point (0, y0) to define line
                                                        {0.0, 2.0},         //4 y1 -- point (1, y1) to define line
                                                        {0.0, 100.0},       //5 kd
                                                        {-1.0, 2.0}         //6 xd
                                                    };
        return parameterBounds;
    }

    public double[] getDefaultInitialParameters()
    {
        //totally arbitrary initial parameters chosen because they made a "pretty" curve
        return new double[] {30.0, -0.01, 1.0, 0.9, 30.0, 1.1};
    }

    public double[] estimateInitialParameters(double[] xValues, double[] yValues)
    {
        double[] initialParameters = getDefaultInitialParameters();

        if (xValues == null || yValues == null || xValues.length != yValues.length)
        {
            throw new IllegalArgumentException("x and y vectors must both be specified and of equal length");
        }
        for (int i=0; i<xValues.length; i++)
        {
            if (xValues[i]<0 || xValues[i]>1 || yValues[i]<0 || yValues[i]>1)
            {
                throw new IllegalArgumentException("x and y values are required to be in [0.0, 1.0]");
            }
            if (i>0 && xValues[i]<=xValues[i-1])
            {
                throw new IllegalArgumentException("x values are required to monotonically increase");
            }
        }

        //split the xy points into three x ranges
        //  20% / 60% / 20%
        //use these subregions to generate the initial estimates
        int b1 = xValues.length/5;    //boundary #1
        int b2 = xValues.length*4/5;  //boundary #2

        //"linear region"
        if (b2-b1 > 1)
        {
            int n = b2-b1;
            double sumX = 0.0, sumY = 0.0, sumXY = 0.0, sumXX = 0.0;
            for (int i=b1; i<=b2; i++)
            {
                sumX += xValues[i];
                sumY += yValues[i];
                sumXY += xValues[i]*yValues[i];
                sumXX += xValues[i]*xValues[i];
            }
            //slope and intercept...
            double denom = n*sumXX-sumX*sumX;
            if (denom == 0.0)
            {
                //leave the default initial parameters in place
            }
            else
            {
                double slope = (n*sumXY-sumX*sumY)/denom;
                double yIntercept = (sumY*sumXX-sumX*sumXY)/denom;
                initialParameters[2] = yIntercept;          //(0, y0)
                initialParameters[3] = slope+yIntercept;    //(1, y1)
            }
        }
        else
        {
            //leave the default initial parameters in place
        }

        //"initial rise"
        if (b1 > 1)
        {
            TwoParameterLogisticModel riseModel = new TwoParameterLogisticModel();
            double[] riseXValues = new double[b1]; System.arraycopy(xValues, 0, riseXValues, 0, b1);
            double[] riseYValues = new double[b1]; System.arraycopy(yValues, 0, riseYValues, 0, b1);
            BeesOptimizer optimizer = new BeesOptimizer();
            double[] riseFitResult = optimizer.fit(riseModel, riseModel.estimateInitialParameters(riseXValues, riseYValues), riseModel.getParameterBounds(), riseXValues, riseYValues, PRECISION, ITERATIONS, ROUNDS);
            initialParameters[0] = riseFitResult[1];
            initialParameters[1] = riseFitResult[2];
        }
        else
        {
            //leave the default ku,xu
        }

        //"final drop"
        if (xValues.length-b2 > 1)
        {
            TwoParameterLogisticModel dropModel = new TwoParameterLogisticModel();
            double[] dropXValues = new double[b1]; System.arraycopy(xValues, 0, dropXValues, 0, b1);
            double[] dropYValues = new double[b1]; System.arraycopy(yValues, 0, dropYValues, 0, b1);
            BeesOptimizer optimizer = new BeesOptimizer();
            double[] dropFitResult = optimizer.fit(dropModel, dropModel.estimateInitialParameters(dropXValues, dropYValues), dropModel.getParameterBounds(), dropXValues, dropYValues, PRECISION, ITERATIONS, ROUNDS);
            initialParameters[4] = dropFitResult[1];
            initialParameters[5] = dropFitResult[2];
        }
        else
        {
            //leave the default kd,xd
        }

        return initialParameters;
    }

    public double[] evaluate(double[] parameters, double[] xValues)
    {
        if (parameters.length != PARAMETER_COUNT)
        {
            throw new IllegalArgumentException("Unexpected number of parameters -- Received "+parameters.length+"; expected "+PARAMETER_COUNT);
        }

        /*
            The model:
                          y=A*B*C
              initial rise: A = 1/(1+EXP(-ku*(x-xu)))
        linear degradation: B = (y1-y0)*x+y0
                final fall: C = 1-1/(1+EXP(-kd*(x-xd)))
        */
        double ku, xu, y0, y1, kd, xd;
        ku = parameters[0];
        xu = parameters[1];
        y0 = parameters[2];
        y1 = parameters[3];
        kd = parameters[4];
        xd = parameters[5];

        double[] results = new double[xValues.length];
        double m = y1-y0;
        for (int i=0; i<xValues.length; i++)
        {
            double x = xValues[i];
            double A = 1.0/(1.0+Math.exp(-ku*(x-xu)));
            double B = m*x+y0;
            double C = 1.0-1.0/(1.0+Math.exp(-kd*(x-xd)));
            results[i] = A*B*C;
        }
        return results;
    }

}

