#!/bin/env perl

#
#===============================================================================
#
#         FILE:  generate3pBiasQCMetrics.pl
#
#  DESCRIPTION:
#                Goal:  Wrapper and helper for generating 3p bias QC metrics
#                       
#
#        FILES:  ---
#         BUGS:  ---
#        NOTES:  ---
#       AUTHOR:  James E Scherschel (jes), <js@lilly.com>
#      COMPANY:  Eli Lilly & Co.
#      VERSION:  1.0
#      CREATED:  ---
#     REVISION:  ---
# Revision History:
#   0.04 John Calley 2/11/2020
#     --Changed group name from bioinfo to bioinfo-=unxgds due to recent ldap
#     change
#   0.03 John Calley 1/24/2020
#     --Changed location of java executable since the HPC team moved it.
#   0.02 James Scherschel 7/12/2018
#     --Tweaked output file and directory creation, chown, and chmod
#   0.01 James Scherschel 4/18/2018
#     --Initial check-in...
#===============================================================================

use strict;
use warnings FATAL => 'all'; # FATAL => 'all';
use Getopt::Std;
use File::Basename;

use FindBin;


our %opts; #v/s:verbose/silent; r:results-root-dir; i:input-file; o:output-file; j:java-executable; t:thread-count
getopts('vsr:i:o:j:t:', \%opts);


#defaults
my $verbose = 0;
my $resultsRootDir = '.';
my $ifile = './fastq_QC/combined_fastx.txt';
my $ofile = './expression_qc/fastq/assay2baseQualityQCMetrics.txt';
my $javaExecutable = '/usr/bin/java';
my $javaClassDir = $FindBin::Bin;
my $threadCount = 50;


sub areValidArgs
{
    my $validArgs = (@ARGV == 0 and (0+(keys %opts))>0)?1:0;

    if ($validArgs == 1)
    {
        my $resultsRootDir = $resultsRootDir;
        if (exists $opts{'r'})
        {
            if (-d $opts{'r'})
            {
                if (-r $opts{'r'})
                {
                    $resultsRootDir = $opts{'r'};
                }
                else
                {
                    warn "Cannot read directory: $opts{'r'} \n";
                    $validArgs = 0;
                }
            }
            else
            {
                warn "Not a directory: $opts{'r'} \n";
                $validArgs = 0;
            }
        }

        if ($validArgs == 1)
        {
            if (exists $opts{'i'})
            {
                if ($opts{'i'} =~ /^\.\//)
                {
                    if (not -r $resultsRootDir.$opts{'i'})
                    {
                        warn "Cannot read specified input file: $resultsRootDir$opts{'i'}\n";
                        $validArgs = 0;
                    }
                }
                else
                {
                    if (not -r $opts{'i'})
                    {
                        warn "Cannot read specified input file: $opts{'i'}\n";
                        $validArgs = 0;
                    }
                }
            }
            else
            {
                if (not -r $resultsRootDir.'/'.$ifile)
                {
                    warn "Cannot read input file: ".$resultsRootDir.'/'.$ifile."\n";
                    $validArgs = 0;
                }
            }
        }

        if (exists $opts{'j'} and not -r $opts{'j'})
        {
            warn "Cannot find specified java executable: $opts{'j'}\n";
            $validArgs = 0;
        }

        if (exists $opts{'t'} and ($opts{'t'} !~ /^\d+$/ or $opts{'t'} < 1))
        {
            warn "Invalid thread-count specified: $opts{'t'}\n";
            $validArgs = 0;
        }
    }
    return $validArgs;
}


if (@ARGV != 0 or areValidArgs() != 1)
{
    die "\n".
        "SYNTAX:  perl $0 [-v] [-s] [-r <results-root-dir>] [-i <combined-fastx-file>] [-o <base-quality-metrics-output-file>] [-j <java-executable>] [-t <thread-count>]\n".
        "\n".
        "        Options:\n".
        "            -s specifies \"silent\" ".(($verbose==0)?'(default: silent)':'')."\n".
        "            -v specifies \"verbose\" and supersedes -s ".(($verbose==1)?'(default: verbose)':'')."\n".
        "            -r results root directory (default: $resultsRootDir) \n".
        "            -i combined fastx file (default: $ifile) \n".
        "            -o output QC metrics file (default: $ofile) \n".
        "            -j java executable (default: $javaExecutable) \n".
        "            -t curve-fitting thread count (default: $threadCount) \n".
        "\n".
        "        Notes:\n".
        "            At least one option must be set. \n".
        "            -i/-o will be treated as relative to <results-root-directory> if it matches /^\\.\\// \n".
        "\n";
}


#Applying params over defaults...
if (exists $opts{'r'}) { $resultsRootDir = $opts{'r'}; }
if ($resultsRootDir !~ /\/$/) { $resultsRootDir = $resultsRootDir.'/'; }
if (exists $opts{'i'}) { $ifile = $opts{'i'}; }
if ($ifile =~ /^\.\//) { $ifile = $resultsRootDir.$ifile; }
if (exists $opts{'o'}) { $ofile = $opts{'o'}; }
if ($ofile =~ /^\.\//) { $ofile = $resultsRootDir.$ofile; }
if (exists $opts{'j'}) { $javaExecutable = $opts{'j'}; }
if (exists $opts{'s'}) { $verbose = 0; }
if (exists $opts{'v'}) { $verbose = 1; }
if (exists $opts{'t'}) { $threadCount = 0+$opts{'t'}; }


#create directories and set permissions...
my $outputDir = dirname($ofile);
if (not -d $outputDir)
{
    my @nonexistentDirs = ($outputDir);
    while (not -d $nonexistentDirs[0])
    {
        unshift @nonexistentDirs, dirname($nonexistentDirs[0]);
    }
    shift @nonexistentDirs;
    foreach my $dirToCreate (@nonexistentDirs)
    {
        system "mkdir ".(($verbose == 1)?'-v':'')." $dirToCreate";
        system "chown ".(($verbose == 1)?'-v':'')." :bioinfo-unxgds $dirToCreate";
        system "chmod ".(($verbose == 1)?'-v':'')." 775 $dirToCreate";
    }
}
die("Output directory does not exist or is not writeable: $outputDir \n") if (not -d $outputDir or not -w $outputDir);


#call the java calculator
my $cmd = $javaExecutable.' -cp '.$javaClassDir.' BaseQualityQCCalculator '.$ifile.' '.$ofile.' '.$threadCount.' -1 -1';
if ($verbose == 1) { print "Executing: $cmd \n"; }
system $cmd;


#final output file permissions set
system 'chown '.(($verbose == 1)?'-v ':'').':bioinfo-unxgds '.$ofile;
system 'chmod '.(($verbose == 1)?'-v ':'').'664 '.$ofile;





