package counting_utils;
#
#===============================================================================
#
#         FILE:  counting_utils.pm
#
#  DESCRIPTION:  Utility functions for gene and feature counting.
#                Currently there is a lot of duplicated code in the various
#                counting scripts. This is a place to put things that can be
#                shared.
#        FILES:  ---
#         BUGS:  ---
#        NOTES:  ---
#       AUTHOR:  John Calley (jnc), <calley_john_n@lilly.com>
#      COMPANY:  Eli Lilly & Co.
#      VERSION:  1.0
#      CREATED:  3/9/16
#     REVISION:  ---
# Revision History:
# 0.06 John Calley 3/14/19
#   --Attempted to make the $seq argument to identify_aln_rgns optional by
#   protecting all uses with the conditional operator.
# 0.05 John Calley 1/15/18
#   --More work on speeding up simple special cases. Splitting out the N and S
#   containing cases with index before doing the slower pattern matches.
#   --Overall the optimizations done here and in version 0.04 took a test case
#   from 30sec to 7sec. This case only had intron containing cigar strings. I
#   believe the general case will be sped up significantly more.
# 0.04 John Calley 1/12/18
#   --Commented out the DEBUG warns because they are actually taking a
#   moderate amount of time when this is profiled.
#   --Did some work to pull out the common simple CIGAR strings for
#   identify_aln_rgns and special case them. Tested the results extensively
#   for start, stop coords but wasn't easily able to verify that the final
#   returned value (sequence) was correct. I believe it to be so (of course).
# 0.03 John Calley 4/20/16
#   --Fixed a problem with handling 'D' in complex cigar strings.
# 0.02 John Calley 3/29/16
#   --Fixed an irritating bug in soft-clipped handling in identify_aln_rgns.
#   I've fixed the same bug in other contexts several times.
#===============================================================================

require Exporter;
@ISA       = qw(Exporter);
@EXPORT    = qw();
@EXPORT_OK = qw(
  identify_aln_rgns
);

use strict;
use warnings;
use Carp;

my $DEBUG;

BEGIN {
    $DEBUG = 0;
}

#Identify the set of genomic regions covered by this read alignment. There may
#be several due to 'N' intron skips We don't separate into multiple regions
#based on simple insertions or deletions.
sub identify_aln_rgns {
    my ($chr, $start, $cigar, $seq) = @_;

    #if ($DEBUG) {
    #    warn "identify_aln_rgns: $chr, $start, $cigar\n";
    #}
    my $seq_start = 0;
    my @rgns;

    #Get rid of S at the end because it cannot affect us
    #Except that when we return the sequence for the final region we need to
    #leave any soft-clipped sequence out. Guarding with fast index limits the
    #slower pattern match to cigars with an 'S'
    if (index($cigar, 'S') != -1 and $cigar =~ s/(\d+)S$//) {
        $seq = $seq?substr($seq, 0, -$1):'';
    }

    #Most common CIGAR strings in a sample RNASeq BAM files are:
    #   MS,SM,MNM,MNMS,MNMNM,M
    #after removing final S the most common patterns are:
    #(Numbers roughly scaled to highest = 1)
    #   M(1), SM(.6), MNM(.4), MNMNM(.3), SMNM(.26)
    #We do some work to peal off common simple cases and handle them faster.
    my $recognized_special_case = 0;
    if (index($cigar, 'N') != -1) {
        ##Intron containing special cases
        if (index($cigar, 'S') == -1) {
            #Have intron, no soft-clipping
            if ($cigar =~ m/^(\d+)M(\d+)N(\d+)M$/) {
                my ($match1_len, $intron_len, $match2_len) = ($1, $2, $3);
                my $stop1  = $start + $match1_len - 1;
                my $start2 = $stop1 + $intron_len + 1;
                my $stop2  = $start2 + $match2_len - 1;
                @rgns = (
                    [ $chr, $start, $stop1, ($seq?substr($seq, 0, $match1_len):'') ],
                    [ $chr, $start2, $stop2, ($seq?substr($seq, $match1_len):'') ]
                );
                $recognized_special_case = 1;
            }
            elsif ($cigar =~ m/^(\d+)M(\d+)N(\d+)M(\d+)N(\d+)M$/) {
                my (
                    $match1_len,  $intron1_len, $match2_len,
                    $intron2_len, $match3_len
                ) = ($1, $2, $3, $4, $5);
                my $stop1  = $start + $match1_len - 1;
                my $start2 = $stop1 + $intron1_len + 1;
                my $stop2  = $start2 + $match2_len - 1;
                my $start3 = $stop2 + $intron2_len + 1;
                my $stop3  = $start3 + $match3_len - 1;
                @rgns = (
                    [ $chr, $start, $stop1, ($seq?substr($seq, 0, $match1_len):'') ],
                    [
                        $chr, $start2,
                        $stop2, ($seq?substr($seq, $match1_len, $match2_len):'')
                    ],
                    [
                        $chr, $start3, $stop3,
                        ($seq?substr($seq, $match1_len + $match2_len, $match3_len):'')
                    ]
                );
                $recognized_special_case = 1;
            }
        }
            else {
               #Have intron and soft-clipping
                if ($cigar =~ m/^(\d+)S(\d+)M(\d+)N(\d+)M$/) {
                    my ($soft_len, $match1_len, $intron_len, $match2_len) =
                      ($1, $2, $3, $4);
                    $seq = ($seq?substr($seq, $soft_len):'');
                    my $stop1  = $start + $match1_len - 1;
                    my $start2 = $stop1 + $intron_len + 1;
                    my $stop2  = $start2 + $match2_len - 1;
                    @rgns = (
                        [ $chr, $start, $stop1, ($seq?substr($seq, 0, $match1_len):'') ],
                        [ $chr, $start2, $stop2, ($seq?substr($seq, $match1_len):'') ]
                    );
                    $recognized_special_case = 1;
                }
                elsif ($cigar =~ m/^(\d+)S(\d+)M(\d+)N(\d+)M(\d+)N(\d+)M$/) {
                    my (
                        $soft_len,   $match1_len,  $intron1_len,
                        $match2_len, $intron2_len, $match3_len
                    ) = ($1, $2, $3, $4, $5, $6);
                    $seq = $seq?substr($seq, $soft_len):'';
                    my $stop1  = $start + $match1_len - 1;
                    my $start2 = $stop1 + $intron1_len + 1;
                    my $stop2  = $start2 + $match2_len - 1;
                    my $start3 = $stop2 + $intron2_len + 1;
                    my $stop3  = $start3 + $match3_len - 1;
                    @rgns = (
                        [ $chr, $start, $stop1, ($seq?substr($seq, 0, $match1_len):'') ],
                        [
                            $chr, $start2,
                            $stop2, ($seq?substr($seq, $match1_len, $match2_len):'')
                        ],
                        [
                            $chr, $start3, $stop3,
                            ($seq?substr($seq, $match1_len + $match2_len, $match3_len):'')
                        ]
                    );
                    $recognized_special_case = 1;
                }
            }
    }
    else {
        #Non-intron special cases
        if (index($cigar, 'S') == -1) {
            #No soft-clipping
            if ($cigar =~ m/^(\d+)M$/) {

                my $stop = $start + $1 - 1;

                #warn "simpleM($cigar): rgn $chr $start $stop\n" if ($DEBUG);
                @rgns = [ $chr, $start, $stop, $seq ];
                $recognized_special_case = 1;
            }
        } else {
            #Have soft-clipping
            if ($cigar =~ m/^(\d+)S(\d+)M$/) {
                my ($soft_len, $match_len) = ($1, $2);
                $seq = $seq?substr($seq, $soft_len):'';
                my $stop = $start + $match_len - 1;
                @rgns = [ $chr, $start, $stop, $seq ];
                $recognized_special_case = 1;
            }
        }
    }
    if (!$recognized_special_case) {
        #Fall back on the general CIGAR recognition code
        $cigar =~ s/\d+H//;    #There can never be two 'H' regions?
        foreach my $simple_cigar (split(/(\d+N)/, $cigar)) {

            #    warn "simple_cigar is $simple_cigar\n" if ($DEBUG);
            if ($simple_cigar =~ m/^(\d+)M$/) {
                my $stop = $start + $1 - 1;

#warn "simpleM_in_complex($cigar,$simple_cigar): rgn $chr $start $stop\n" if ($DEBUG);
                push @rgns,
                  [
                    $chr, $start,
                    $start + $1 - 1, ($seq?substr($seq, $seq_start, $1):'')
                  ];
                $start     += $1;
                $seq_start += $1;
            }
            elsif ($simple_cigar =~ m/(\d+)N/) {
                $start += $1;

  #                warn "$1 intron, incrementing genomic start\n" if ($DEBUG);
            }
            else {
                my $genomic_len = 0;
                my $seq_len     = 0;
                ##Not sure how to deal with 'P'. Apparently this is common in
                #assembly BAMs which we've never dealt with so far.
                while ($simple_cigar =~ m/(\d+)([MIDSP=X])/g) {
                    my ($len, $op) = ($1, $2);
                    if ($op eq 'M' or $op eq '=' or $op eq 'X') {
                        $genomic_len += $len;
                        $seq_len     += $len;
                    }
                    elsif ($op eq 'S') {

                   #S at the beginning of a region the alignment start doesn't
                   #change but we need to skip some of the sequence.
                   #S at the end we've already removed.  S in the middle never
                   #happens.
                        $seq_start += $len;
                    }
                    elsif ($op eq 'I') {

                        #this does not change the alignment length along the
                        #reference, but does change the sequence length
                        $seq_len += $len;
                    }
                    elsif ($op eq 'D') {

                        #We skip the genomic region that is deleted in the
                        #read
                        $genomic_len += $len;
                    }
                }
                my $stop = $start + $genomic_len - 1;

#warn "nonsimple_in_complex($cigar,$simple_cigar): rgn $chr $start $stop\n" if ($DEBUG);
                push @rgns,
                  [ $chr, $start, $stop, ($seq?substr($seq, $seq_start, $seq_len):'') ];
                $start     += $genomic_len;
                $seq_start += $seq_len;
            }
        }
    }

    #warn "NumRgns=", (scalar @rgns), "\n" if ($DEBUG);
    return @rgns;
}

1;
