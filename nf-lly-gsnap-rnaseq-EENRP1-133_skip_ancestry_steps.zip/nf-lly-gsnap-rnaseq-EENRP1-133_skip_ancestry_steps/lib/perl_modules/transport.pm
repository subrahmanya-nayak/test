package transport;
#
#===============================================================================
#
#         FILE:  transport.pm
#
#  DESCRIPTION:  General remote<->local file transport utilities. Originally
#  written to abstract use of S3 vs NFS. Now primarily used to make local
#  copies of reference data on an execute node. 
#
#        FILES:  ---
#         BUGS:  ---
#        NOTES:  ---
#       AUTHOR:  John Calley (jnc), <calley_john_n@lilly.com>
#      COMPANY:  Eli Lilly & Co.
#      VERSION:  1.0
#      CREATED:  12/28/14 07:38:12 EST
#     REVISION:  ---
# Revision History:
#    0.06 3/23/15 John Calley
#       --Added -u to rsync. I think we were possibly always transfering
#       because we updated the mod date on the destination files to protect
#       them from the /node/scratch cleaner and then they differed by date so
#       we updated.
#    0.05 3/18/15 John Calley
#       --Explicitly checked to see if we have write access to the lock file
#       before we try to create it and die if we don't.
#    0.04 3/17/15 John Calley
#       --Fixed a bug with identifying the process when the lock file has
#         disappeared (due to being deleted by another thread).
#    0.03 2/19/15 John Calley
#       --Attempted to fix a long standing problem with a lock file written by
#       a no longer running process.
#    0.02 12/28/14 John Calley
#       --This has existed for several years in multiple copies in individual
#       scripts. This is the first time I've isolated it nto it's own module.
#===============================================================================

require Exporter;
@ISA       = qw(Exporter);
@EXPORT    = qw();
@EXPORT_OK = qw(
   general_copy
   general_shared_copy
   general_file_size
);

use strict;
use warnings;
use Fcntl;
use File::Path qw(mkpath);

########We're not actually using the s3 stuff at the moment so I'm being lazy
#and not defining this stuff. If we revive it we probably want to use a
#different tool than s3cmd anyway.
my $num_s3_tries;
my $s3cmd_bin;
my $s3cmd_cfg;
BEGIN {
    $num_s3_tries = 3;
    $s3cmd_bin = '';
    $s3cmd_cfg = '';
}

#S3 Abstraction Layer
# Given a local or an S3 address, move a file between locations
# or query the file size.
# NOTE: No wild cards allowed, but if a <from> pathname ends in '/', all files in
# that directory are copied.
# NOTE: This may NOT work if both <from> and <to> are S3 locations! Untested.
#If $recur is true the copy will recursively copy all sub-directories.
sub general_copy {
    my ($from, $to, $recur) = @_;

    return if ($from eq $to);
    my $from_s3 = 0;
    if ($from =~ m/^S3:/i) {
        $from_s3 = 1;
    }

    my $to_s3 = 0;
    if ($to =~ m/^S3:/i) {
        $to_s3 = 1;
    }

    if (!$from_s3 and !$to_s3) {
        my $opt = '';
        $opt = '-r' if ($recur);
        if ($from =~ m/\/$/) {
            foreach my $fn (glob("$from/*")) {
                my $cmd = "cp $opt $fn $to";
                (system($cmd) == 0)
                  or die "Copy $opt $fn to $to failed ($!). Stopped";
            }
        }
        else {
            my $cmd = "cp $opt $from $to";
            (system($cmd) == 0)
              or die "Copy $opt $from to $to failed ($!). Stopped";
        }
    }
    elsif ($from_s3 and $to_s3) {
        my $opt = '';
        $opt = '--recursive' if ($recur);
        my $cmd = "$s3cmd_bin cp -c $s3cmd_cfg --no-progress $opt $from $to";
        (system($cmd) == 0)
          or die "S3 copy $opt from $from to $to failed ($!). Stopped";
    }
    elsif ($from_s3) {

        #from S3, to local
        my $opt = '';
        $opt = '--recursive' if ($recur);
        my $cmd =
          "$s3cmd_bin -c $s3cmd_cfg --force --no-progress get $opt $from $to";
        my $tries = $num_s3_tries;
        my $err;
        while ($tries) {
            (system($cmd) == 0)
              or $err = $!;
            if (!$err and -s $to) {
                last;
            }
            else {
                $tries--;
            }
        }
        if ($err or !-s $to) {
            die "S3 get $opt from $from to $to failed $num_s3_tries times "
              . "($err). Command was $cmd. Stopped";
        }
    }
    else {

        #Must be from local, to S3
        my $opt = '';
        $opt = '--recursive' if ($recur);
        my $cmd = "$s3cmd_bin -c $s3cmd_cfg --no-progress put $opt $from $to";
        my $tries = $num_s3_tries;
        my $err;
        my $fs;

      #We can check that the file is non-zero in size if it's not a directory.
      #Chris and Andrew suggest that I do this. Not sure what to do it it is
      #a directory though, for now we just believe the error message.
        while ($tries) {
            (system($cmd) == 0)
              or $err = $!;
            $fs = ($to =~ m{/$} or general_file_size($to));
            if (!$err and $fs) {
                last;
            }
            else {
                $tries--;
            }
        }
        if ($err or !$fs) {
            if (!$err) {
                $err = "Zero length file at $to";
            }
            die "S3 put from $from to $to failed $num_s3_tries times ($err)."
              . "Command is $cmd. Stopped";
        }
    }
}

#general_shared_copy is conceptually similar to general_copy but it takes care
#of two issues that arise if the file(s) we want copied are to be local copies
#that will be shared between tasks.
#It can only be used for copying from a remote location (either S3 or NFS) to
#a local location.
#This process is intrinsically recursive.
#It takes care of the following:
#    Not copying a file that we already have locally (implemented by s3cmd
#       sync or rsync)
#    Potential race conditions that can arise when two different tasks are
#       trying to copy over the same shared file.
#    $timeout is the maximum time in minutes to wait for another process to complete the
#    copy before giving up and failing. The default is 10.
sub general_shared_copy {
    my ($from, $to, $timeout) = @_;

    $timeout ||= 10;

    my $from_s3 = 0;
    if ($from =~ m/^S3:/i) {
        $from_s3 = 1;
    }

    if ($to =~ m/^S3:/i) {
        die
          "general_shared_copy only goes from remote to local file systems.  "
          . "Stopped";
    }

   #reserve_copy checks to see if anyone else is copying. If so it waits (up
   #to $timeout minutes) for the other process to finish.
   #We derive a tag for this copy operation as follows:
   #   If $to is a file_name we use it.
   #   If $to is a directory we use the last element of the $from name.
   #   The tag_files are stored in the same directory as $to so there is a
   #   remote possibility of a file name clash...
   #Note that this will return with permission to copy even if the file has
   #just been copied by another process. This is because we may want to check
   #it for and update via the sync process. The assumption is that the sync is
   #quick when files are identical. Alternatively we could add some sort of
   #'trust if the file is no older than N minutes' parameter?
    my $tag_fn;
    if (-d $to) {
        my $tag = $from;
        $tag =~ s/\/$//;
        $tag =~ s/.*\///;
        $tag_fn = "$to/${tag}_lock";
    }
    else {
        $tag_fn = "${to}_lock";
    }
    reserve_copy($tag_fn, $timeout);

    if ($from_s3) {

        #from S3, to local. Use s3cmd sync
        my $cmd   = "$s3cmd_bin -c $s3cmd_cfg --no-progress sync $from $to";
        my $tries = $num_s3_tries;
        my $err;
        while ($tries) {
            (system($cmd) == 0)
              or $err = $!;
            if (!$err and -s $to) {
                last;
            }
            else {
                $tries--;
            }
        }
        if ($err or !-s $to) {
            finish_copy($tag_fn, 0);
            die "S3 sync from $from to $to failed $num_s3_tries times ($err)."
              . "Stopped";
        }
    }
    else {

        #Must be NFS to local, use rsync
        my $cmd = "rsync --recursive --copy-links --archive --no-t -p -u --chmod=oug=rwX $from $to";

        #warn "rsync cmd is $cmd\n";
        if (system($cmd) != 0) {
            finish_copy($tag_fn, 0);
            my $host = `hostname`;
            chomp $host;
            die "$cmd failed ($!). Stopped (on $host) ";
        }
    }

    #Register a successful copy.
    finish_copy($tag_fn, 1);

}

#Attempt to reserve the tag_fn lock. If successful, return. If unsuccessful,
#because another process is in the process of copying, wait until it finishes
#and then return. Die if the timeout is exceeded.
#Procedure:
#   See if a file called $tag_fn exists.
#      If it does, wait until the timeout for the file to disappear. If it
#         does dissapear, return. If the timeout is exceeded, die.
#      If it does not, create it and write our process id into the file. Wait
#         for 5 seconds. If the file still contains our process ID we're
#         good. return. If the file contains a different process ID revert to
#         waiting for it to disappear (just as though it had been there from
#         the beginning).
#   Note that there may still be a race condition if the file contains
#   interleaved digits from two different process ids. In this case, both
#   processes will time out and fail. This is OK as long as it is rare.
#   There are some other similar race conditions here. Again, I think their
#   impact will be minimal.
#NOTE: I know there is a rare deadlock condition in here. 3/20/13 I saw an
#example of this. Two processes running on the same machine, both slept for
#over 12 hours before I killed them. One strace looked like this:
#    strace -p 10336
#    Process 10336 attached - interrupt to quit
#    restart_syscall(<... resuming interrupted call ...>
#    ) = 0
#    stat("/node/scratch/ref_data/RepDB_lock", {st_mode=S_IFREG|0644, st_size=5, ...}) = 0
#    rt_sigprocmask(SIG_BLOCK, [CHLD], [], 8) = 0
#    rt_sigaction(SIGCHLD, NULL, {SIG_DFL, [], 0}, 8) = 0
#    rt_sigprocmask(SIG_SETMASK, [], NULL, 8) = 0
#    nanosleep({30, 0}, {30, 0})             = 0
#    stat("/node/scratch/ref_data/RepDB_lock", {st_mode=S_IFREG|0644, st_size=5, ...}) = 0
#    rt_sigprocmask(SIG_BLOCK, [CHLD], [], 8) = 0
#    rt_sigaction(SIGCHLD, NULL, {SIG_DFL, [], 0}, 8) = 0
#    rt_sigprocmask(SIG_SETMASK, [], NULL, 8) = 0
#    nanosleep({30, 0}, {30, 0})             = 0
#    stat("/node/scratch/ref_data/RepDB_lock", {st_mode=S_IFREG|0644, st_size=5, ...}) = 0
#    rt_sigprocmask(SIG_BLOCK, [CHLD], [], 8) = 0
#    rt_sigaction(SIGCHLD, NULL, {SIG_DFL, [], 0}, 8) = 0
#    rt_sigprocmask(SIG_SETMASK, [], NULL, 8) = 0
#    nanosleep({30, 0}, quit
#     <unfinished ...>
#    Process 10336 detached
#I've run many 1000s of times previously and never seen this so I think it's
#rare. I believe this is a deadlock between two processes going around the
#outer while look in reserve_copy. I added the $tries mechanism to limit the
#times around the loop. Hopefully this will fix the problem.
#

sub reserve_copy {
    my ($tag_fn, $timeout_min) = @_;

    my $tries = 10;
    #We must make this lock file world writable since other users may be
    #running at the same time.
    my $old_mask = umask 0000;
    (my $tag_dn = $tag_fn) =~ s/\/[^\/]+$//;
    if (!-d $tag_dn) {
        mkpath($tag_dn);
    }
    if (!-w $tag_dn) {
        my $host = `hostname`;
        chomp $host;
        die "No write access to create $tag_dn on $host. Stopped";
    }

    while ($tries) {
        $tries--;
        if (!-e $tag_fn and sysopen (my $ofh, $tag_fn, O_CREAT|O_WRONLY, 0666)) {

            print {$ofh} "$$\n";
            close $ofh;
            umask $old_mask;

            sleep(5);

            #If we still have our pid in the file then it's our job to do the
            #copying
            my $pid = `cat $tag_fn`;
            chomp $pid;

            #return if we got the job.
            return if ($$ == $pid);
        }

        #If the file already exists or we couldn't open it for writing, or it
        #has a different PID, this is because another process is working on
        #the same copy.  Keep waiting for it to disappear up to timeout
        #minutes seconds and see if it exists. If it disappears, try to
        #reserve it again.
        sleep(30);

        #See if the process that wrote the lock file is still running. If it
        #isn't, we need to get rid of the lock file. Clearly something bad
        #must have happened to that process and we need to start over.
        my $pid;
        if (-e $tag_fn) {
            $pid = `cat $tag_fn`;
            chomp $pid;
        }
        my $ps_result = '';
        if ($pid) {
           $ps_result = `/bin/ps --no-headers -p $pid`;
           $ps_result =~ s/\s+$//;
        }
        if (!$ps_result) {
            #No ps result, process no longer exists.
            unlink $tag_fn;
        }

        while (-e $tag_fn and ((-M _) * 24 * 60 < $timeout_min)) {
            sleep(30);
        }
        if (-e $tag_fn) {
            my $host = `hostname`;
            chomp $host;
            die "Failed to reserve copy for $tag_fn with timeout of $timeout_min minutes (on $host).\n";
        }
    }
    if (!$tries) {
        my $host = `hostname`;
        chomp $host;
        die "Failed to reserve copy for $tag_fn. Apparently in infinite competition with another process (on $host).\n";
    }
}

sub finish_copy {
    my ($tag_fn, $success) = @_;

    unlink $tag_fn;
}

#Return file size of a local file or an S3 stored file.
sub general_file_size {
    my $fn = shift;

    my $fs;
    if ($fn =~ m/^S3:/i) {
        my $cmd   = "$s3cmd_bin -c $s3cmd_cfg --no-progress ls $fn";
        my $tries = $num_s3_tries;
        my $res;
        while ($tries) {
            $res = `$cmd`;
            if ($res and !$!) {
                last;
            }
            else {
                $tries--;
            }
        }
        chomp $res;
        my ($date, $time, $size, $nm) = split(/\s+/, $res);
        $fs = $size;
    }
    else {
        $fs = -s $fn;
    }
    return $fs;
}
1;
