package qc_warn_util;
#
#===============================================================================
#
#         FILE:  qc_warn_util.pm
#
#  DESCRIPTION:  Utility functions for qc_note_warn scripts
#        FILES:  ---
#         BUGS:  ---
#        NOTES:  ---
#       AUTHOR:  John Calley (jnc), <calley_john_n@lilly.com>
#      COMPANY:  Eli Lilly & Co.
#      VERSION:  1.0
#      CREATED:  11/28/18
#     REVISION:  ---
# Revision History:
# 0.06 John Calley 12/14/2022
#    --Modified to allow initial_processing to check for multiple output files
#    instead of just one.
# 0.05 John Calley 7/31/2019
#    --Changed failure to identify a project type to a warning (instead of
#    being fatal). Easiest fix to allow processing of TEMPUS projects. I think
#    this is OK because we're separately checking that the input data we need
#    is available.
# 0.04 John Calley  and McKenzie 1/23/2019
#    --Fixed a bug that was not properly processing multiple organisms.
# 0.03 John Calley 12/7/2018
#   --Fixed a bug in oputput directory climbing
# 0.02 John Calley 12/6/2018
#   -Got smarter about evaluating writability for output files in non-existent
#   directories.
#   -exported output_writable
#===============================================================================

require Exporter;
@ISA       = qw(Exporter);
@EXPORT    = qw();
@EXPORT_OK = qw(
  initial_processing
  $default_usage
  newer_inputs
  output_writable
);

use strict;
use warnings;
use Carp;
use FindBin;
use lib "$FindBin::Bin/../../lib";
use meta_data qw(get_assay2sample get_meta);
use projects qw(get_project_type read_manifest);
use Cwd qw(abs_path);

my $DEBUG;
our $default_usage;

BEGIN {
    $DEBUG = 0;
   
    $default_usage = <<"END_USAGE";
$0 [-t] [-f] [-v] [-p] <results_dir>
[-t]     --Run in test mode. Check to see if it makes sense/is possible to run the script.
           Write one of the following to stdout:
              UpToDate         --output is newer than inputs. There's no reason to run.
              NotRunnable<tab><Reason>  --The script cannot or should not run for reasons 
                                          described by the Reason string after the tab character.
                                          Reasons include:CannotWriteResults,InappropriateProject,
                                          MissingInputFiles(listed)
              Runnable         --Script can and should be run.
[-p]     --Print to stdout a space delimited list of the project types for which this script 
           is not appropriate. Results dir is not required for -p.
[-f]     --Force the script to run and update all final and intermediate results.
[-v]     --Report progress info.

<results_dir> A valid genomic results directory.

Default behavior is to 'do the right thing'. Update if possible and
appropriate. Do nothing if there is nothing to be done. Fail if it appears
that an update is needed and appropriate but it cannot be accomplished for
some reason.
END_USAGE

}#END BEGIN

#Standard initial argument processing for qc_note_warn scripts
#  $rdn                    -Results directory, required.
#  $exclude_ptypes_lref    -reference to list of project types the script
#                           cannot run on. May be empty or undefined.
#  $input_fns_lref         -reference to list of files which will be needed as
#                           input. Modification dates earler than output will
#                           specify that we don't need to re-run. Lack of file
#                           or lack of read access will produce a NotRunnable
#                           status. May be undefined to avoid this test.
#  $ofn                    -path to final output file.
#                           Lack of write access will lead to NotRunnable
#                           status.
#                          -Instead of a path, may be a reference to a list of
#                          paths if there is more than one possible output
#                          file
#  $verbose                -If true, be chatty
#  $a2s_href               -Reference to hash that will contain an assay to
#                           sample mapping. If not defined we won't require
#                           that this exist.
#  $s2m_href               -Reference to hash that will contain sample to
#                           metadata mapping. If not defined we won't require
#                           that this exist.
#  $a2m_href               -Reference to hash that will contain assay to
#                           metadata mapping. May be undefined.
#  $org_lref               -Optional ref to list of legal organisms (as
#                           recorded in the project manifest).
#Returned value is a list with two values:
#      the status string after default processing.
#      benign (0 if this is a failure that should always be reported as fatal,
#              1 if this is benign and should just be ignored and no results produced)
sub initial_processing {
    my ($rdn, $exclude_ptypes_lref, 
        $input_fns_lref, $ofn_or_lref, $verbose,
        $a2s_href, $s2m_href, $a2m_href, $org_lref) = @_; 

    my $status = 'Runnable';
    my $benign = 1;
    my $p_type = get_project_type($rdn);
    if (!$p_type) {
        warn "Unable to identify project type from $rdn. Proceeding at risk.";
    }
    my @ofns;
    if (ref $ofn_or_lref) {
        push @ofns, @$ofn_or_lref;
    } else {
        push @ofns, $ofn_or_lref;
    }

    if (!$s2m_href) {
        get_assay2sample($rdn, $a2s_href);
    } else {
        eval { get_meta($rdn, $a2s_href, $s2m_href, $a2m_href, verbose => $verbose) };
    }
    if ($org_lref) {
        # Set Organism to "Human" without checking manifest
        my $organism = "Human";
    }
    #     my %man;
    #     read_manifest($rdn, \%man);
    #     my $found = 0;
    #     foreach my $org (@$org_lref) {
    #         if (lc($org) eq lc($man{Organism})) {
    #             $found = 1;
    #             last;
    #         }
    #     }
    #     if (!$found) {
    #         $status = "NotRunnable\tInappropriateOrganism($man{Organism})";
    #         return ($status, $benign);
    #     }
    # }


    my %exclude_ptypes;
    foreach my $pt (@$exclude_ptypes_lref) {
        $exclude_ptypes{$pt} = 1;
    }

    if ($exclude_ptypes{$p_type}) {
        $status = "NotRunnable\tInappropriateProject($p_type)";
    }
    else {
        my @all_in_mod;
        my @in_missing;
        foreach my $fn (@$input_fns_lref) {
            if (!-s $fn or !-r $fn) {
                push @in_missing, $fn;
            }
            else {
                push @all_in_mod, -M $fn;
            }
        }
        my @all_out_mod;
        my @out_missing;
        foreach my $fn (@ofns) {
            if (!-s $fn or !-r $fn) {
                push @out_missing, $fn;
            }
            else {
                push @all_out_mod, -M $fn;
            }
        }
        if (@in_missing) {
            $status =
            "NotRunnable\tMissingInputFiles(" . join(',', @in_missing) . ')';
            #This is a benign problem.
        }
        else {
            my $latest_input = (sort { $a <=> $b } @all_in_mod)[0];
            my $earliest_output;
            if (!@out_missing) {
                $earliest_output = (sort { $b <=> $a } @all_out_mod)[0];
            }
            if (!@out_missing and $earliest_output  <= $latest_input) {
                $status = 'UpToDate';
            }
            else {
                if (!%$a2s_href) {
                    $status = "NotRunnable\tMissingAssay2Sample";
                }
                if ($s2m_href and !%$s2m_href) {
                    $status = "NotRunnable\tMissingMetaData";
                }
            }
        }
    }

    my $unwritable;
    foreach my $one_ofn (@ofns) {
        if (!output_writable($one_ofn)) {
            $unwritable = $one_ofn;
            last;
        }
    }
    if ( $status =~ m/^Runnable/ and $unwritable) {
        $status = "NotRunnable\tCannotWriteResults($unwritable)";
        $benign = 0;
    }

    return ($status, $benign);
}

#If any one of the input files is newer than any one of the output files or if
#any of the output files do not exist, return TRUE. Otherwise, return FALSE
#(0).
#If an input file is missing it is ignored.
sub newer_inputs {
    my ($in_fns_lref, $out_fns_lref) = @_;

    if (!@$in_fns_lref or !@$out_fns_lref) {
        croak "Empty input or output file set for newer_inputs call.";
    }

    my @all_in_mod;
    foreach my $fn (@$in_fns_lref) {
        if (-s $fn) {
            push @all_in_mod, -M _;
        }
    }
    my (@out_missing, @all_out_mod);
    foreach my $fn (@$out_fns_lref) {
        if (!-s $fn) {
            push @out_missing, $fn;
        } else {
            push @all_out_mod, -M _;
        }
    }
    if (@out_missing) {
        return 1;
    } 
    if (!@all_in_mod) {
        #No input files exist, we call this not being newer than the
        #output.
        return 0;
    }
    else {
        my $latest_input = (sort { $a <=> $b } @all_in_mod)[0];
        my $earliest_output = (sort { $b <=> $a } @all_out_mod)[0];
        if ($latest_input < $earliest_output) {
            #The latest input is newer than the earliest output
            return 1;
        }
        return 0;
    }
}

#Check to see if an output file is writable
#The only truly accurate way to determine if a file can be written is
#to actually try to write it. This would require, however, that we
#potentially create any intermediate directories that might not exist
#at the moment. This seems like an unexpected side-effect that it
#would be best to avoid, however. Instead, we're just going to walk up
#the directory tree to see if the first available directory is
#writable and if so, call things OK.
sub output_writable {
    my $ofn = shift;

    (my $odn = $ofn) =~ s/\/[^\/]+$//;
    $odn ||= '.';

    if (-s $ofn and -w _) {
        #Doesn't handle ACLs but nothing else does either...
        return 1;
    } elsif (-w $odn) {
        return 1;
    } else {
        my $appears_writable = 0;
        my $cur_dn = $odn;
        while (!-d $cur_dn) {
            $cur_dn =~ s/\/[^\/]+$//;
        }
        if (-w $cur_dn) {
            $appears_writable = 1;
        }
        return $appears_writable;
    }
}
1;
