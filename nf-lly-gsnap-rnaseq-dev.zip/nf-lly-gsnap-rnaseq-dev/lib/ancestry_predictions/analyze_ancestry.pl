#!/usr/bin/env perl
#Revision History:
# John Calley 10/14/22
#    --Switched the default location of 1K genomes data from /lrlhps/data to
#    /lrlhps/genomics/prod/genome_projects/resources/sources to facilitate AWS
#    migration
use strict;
use warnings FATAL => 'all';
use Getopt::Std;
#use Getopt::Long;
use FindBin;


#Goal:  Identify bi-allelic SNPs anticipated to be maximally informative in scoring individuals
#       against known populations (as defined by allele freqs across a large number of loci).
#       Score based on information entropy of the possible partitions.
#       Produce data and parameter files appropriate as input to STRUCTURE
#       Invoke STRUCTURE
my $startTime = time().'-'.rand();


my %opts; #m:mads; f:min allele freq; c: SNP count; -v verbose-0/1; -p: population allele freqs directory; -a assay2info file; -q sample2qfn file; -t temp directory
getopt('mfcvpaqt', \%opts);


#**********************************************************
#******************** Begin Parameters ********************
#**********************************************************
#how "quietly" to run...  Default values result in a "silent" run.
my $tempDir = './';
my $verbose = 0;
my $writePositionEntropyFile = 0;
my $writePerPopROCdata = 1;     #only applies if a position entropy file is being written
my $writePartitionProbData = 1; #only applies if a position entropy file is being written
my $writePairwisePopIC = 1;     #only applies if a position entropy file is being written
my $writeSampleLevelATGCCounts = 0;
my $writeAlleleComparisonFile = 0;
my $positionEntropyFilename = $tempDir.'positional_entropy-'.$startTime.'.txt';
my $sampleLevelATGCCountsFilename = $tempDir.'sample_level_ATGC_counts-'.$startTime.'.txt';
my $alleleComparisonFilename = $tempDir.'allele_freq_comparison-'.$startTime.'.txt';

#which experiment?
my $experimentResultsRoot = '.';
if (@ARGV > 0)
{
    $experimentResultsRoot = $ARGV[0];
}
else
{
    die "SYNTAX: perl analyze_ancestry.pl [-m mads] [-f min allele freq] [-c SNP count] [-v verbosity-0_1] [-a <assay2info file>] [-q <sample2qfn file>] [-p <pop allele freqs dir>] [-t <temp/output dir>] <experiment-results-root-dir>\n".
        "        Ancestry temp and results files are written to the temp/output dir.\n".
        "        By default, ./meta_data/assay2info.txt is used to obtain sample-to-assay\n".
        "                and ./hapmap_quant/sample2qfn.txt is used to obtain assay-to-qfn data\n";
}
my $quantDir = $experimentResultsRoot.'/hapmap_quant/'; #must end in /
my $experimentTalliesFilename = 'position_report.txt';
my $quantFilenameRegex = '^.+_quant\.txt$'; #if not using assay2info mapping, capture group $1 must provide a value to use as the sample id
my $useAssay2InfoMapping = 1;
my $assay2infoFilename = $experimentResultsRoot.'/meta_data/assay2info.txt';
my $assay2quantFilename = $experimentResultsRoot.'/hapmap_quant/sample2qfn.txt';


#which populations?
my $refPopDir = '/lrlhps/genomics/prod/genome_projects/resources/sources/calley_annotation_data/Scherschel_1KGenomes'; if ($refPopDir !~ /\/$/) { $refPopDir .= '/'; }
my $refPopDataRegex = 'HapMap3-minimalColumns-allele_freqs_(chr\d+)_(u?[A-Z]{3}).b\d{2}_1000g_20140910.txt'; #<---\  capture group $2 and
my @refPops = split(',','uAFR,EUR,AMR,SAS,EAS'); #<---------------------------------------------------------------/  $refPops[] need to match

#how to exclude potentially noisy/redundant (but otherwise informative) SNPs
my $useMADFilter = 1;
my $madsToKeep = 4.5; #this shaves positions that might too unduly influence scoring; 4.5*MAD is approx 3*stdev
my $minOAF = 0.01; #in all populations
my $minRAF = 0.01; #in all populations
my $minDistanceBetweenSNPs = 1000000; #1mb -- 20kb to 300kb is considered the limits of LD, so this is pretty conservative
my $minSamplesCoveragePercent = 10.0; # variant must be present in at least 10.0% of "Samples"(/assays) to be considered

#how many SNPs to keep?
my $snpCutoffMode = 2; #0 -- exhaustion, 1 -- precision, 2 -- count, 3 -- earliest, 4 -- latest
my $desiredPrecision = 1e-12; # [0, 1] where 0 --> exhaustion
my $desiredSNPCount = 5000;
my $notEnoughSnpsBehavior = 1; #0 -- continue; 1 -- warn; 2 -- die

#weight entropy based on coverage or not?  Probably best to always leave this on to ensure that estimates of the number of loci required are pessimistic
my $useCoverageWeighting = 1;


#cut off for deciding homozygous vs heterozygous...  Only care about the one or two most prevalent reads at a given locus for a given sample
my $homozygousCutoffPercent = 80.0; #assume that if the most common base called has >= 80% of the total, then homozygous (else hetero)


#STRUCTURE-related
my $generateStructureInput = 1; #or die
my $invokeStructure = 1; #or die
my $structureBinaryLocation = 'ancestry_predictions/structure-2.3.4/structure';
my $structureMainparamsFilename = $tempDir.'structure.mainparams-'.$startTime;
my $structureExtraparamsFilename = $tempDir.'structure.extraparams-'.$startTime;
my $structureInputFilename = $tempDir.'structure.infile-'.$startTime;
my $structureSampleIdMappingFilename = $tempDir.'structure.sampleIdMapping-'.$startTime;
my $structureOutputFilename = $tempDir.'structure.outfile-'.$startTime;
my $structureLogFilename = $tempDir.'structure.log-'.$startTime;
#should be able to automatically set burn-in and num-reps to appropriate values
# based on number of (real) individuals and loci...  Need more data points, but
# the following have been more than sufficient good for all runs to date
my $structureBurnIn  = 3000;
my $structureNumReps = 6000;

#**********************************************************
#******************** End Parameters **********************
#**********************************************************

if (exists $opts{'t'})
{
    $tempDir = $opts{'t'};
    if ($tempDir !~ /\/$/) { $tempDir = $tempDir.'/'; }
    $positionEntropyFilename = $tempDir.'positional_entropy-'.$startTime.'.txt';
    $sampleLevelATGCCountsFilename = $tempDir.'sample_level_ATGC_counts-'.$startTime.'.txt';
    $alleleComparisonFilename = $tempDir.'allele_freq_comparison-'.$startTime.'.txt';
    $structureMainparamsFilename = $tempDir.'structure.mainparams-'.$startTime;
    $structureExtraparamsFilename = $tempDir.'structure.extraparams-'.$startTime;
    $structureInputFilename = $tempDir.'structure.infile-'.$startTime;
    $structureSampleIdMappingFilename = $tempDir.'structure.sampleIdMapping-'.$startTime;
    $structureOutputFilename = $tempDir.'structure.outfile-'.$startTime;
    $structureLogFilename = $tempDir.'structure.log-'.$startTime;
}
if (exists($opts{'m'})) { if ($opts{'m'} == 0) { $useMADFilter=0; $madsToKeep=100; } else { $useMADFilter=1; $madsToKeep=$opts{'m'}; } }
if (exists($opts{'f'})) { $minRAF = $minOAF = $opts{'f'}; }
if (exists($opts{'c'})) { if ($opts{'c'} == 0) { $snpCutoffMode=0; $desiredSNPCount=6000000000; } else { $snpCutoffMode=2; $desiredSNPCount=$opts{'c'}; } }
if (exists($opts{'v'})) { $verbose = $opts{'v'}; }
if (exists($opts{'p'})) { $refPopDir = $opts{'p'}; print "Using reference population allele frequency data from $refPopDir\n"; }
if (exists $opts{'a'})
{
    if ($opts{'a'} =~ /^\.\//)
    {
        $assay2infoFilename = $experimentResultsRoot.'/'.$opts{'a'};
    }
    else
    {
        $assay2infoFilename = $opts{'a'};
    }
}
if (exists $opts{'q'})
{
    if ($opts{'q'} =~ /^\.\//)
    {
        $assay2quantFilename = $experimentResultsRoot.'/'.$opts{'q'};
    }
    else
    {
        $assay2quantFilename = $opts{'q'};
    }
}


#****************************************************************
#******************** Parameter Validation **********************
#****************************************************************

if (@refPops < 2)
{
    die "Must specify at least two reference population popcodes.\n";
}

#****************************************************************
#****************** End Parameter Validation ********************
#****************************************************************


if ($verbose) { print "\nStarting at time() = ".$startTime."\n"; }


#load positions of interest for the experiment
my %position2coveragePercent;
my $position;
my $discardLowCoverageCount = 0;
if (-r $quantDir.$experimentTalliesFilename)
{
    open(IFH, $quantDir.$experimentTalliesFilename) or die('Could not read '.$quantDir.$experimentTalliesFilename."...\n");
    {
        if ($verbose) { print "\n".'Loading tally of occurrence data from '.$quantDir.$experimentTalliesFilename."...\n"; }
        my $headerLine = readline(IFH);
        while(<IFH>)
        {
            s/\s+$//;
            my @fields = split("\t");
            if ($fields[0] eq 'Samples/CoveredVar')
            {
                $position = $fields[1];
                if ($fields[4] < $minSamplesCoveragePercent)
                {
                    $discardLowCoverageCount++;
                }
                else
                {
                    $position2coveragePercent{$position} = $fields[4]/100.0;
                }
            }
        }
        close(IFH);
        if ($verbose)
        {
            print 'Kept '.keys(%position2coveragePercent).' positions from '.$experimentTalliesFilename."\n";
            print 'Discarded '.$discardLowCoverageCount." due to low percent samples covered (<$minSamplesCoveragePercent%)\n";
        }
    }
}
else
{
    warn 'Could not read '.$quantDir.$experimentTalliesFilename." -- generating coverage estimate...  (Hard minimum sample coverage limit will NOT be applied!) \n";
    opendir(DH, $quantDir) or die("Could not read $quantDir \n");
    my @files = readdir(DH);
    @files = sort {$a cmp $b} @files;
    closedir(DH);
    my $assayCount = 0;
    foreach my $file (@files)
    {
        if ($file =~ /_quant\.txt$/)
        {
            $assayCount++;
            $file = $quantDir.$file;
            open(IFH, $file) or die("Could not read quant file: $file \n");
            while(<IFH>)
            {
                if (/^chr/)
                {
                    my @arr = split(/\t/, $_, 3);
                    my $chrPos = $arr[0].':'.$arr[1];
                    if (not exists $position2coveragePercent{$chrPos})
                    {
                        $position2coveragePercent{$chrPos} = 1;
                    }
                    else
                    {
                        $position2coveragePercent{$chrPos}++;
                    }
                }
            }
            close(IFH);
        }
    }
    if ($assayCount == 0)
    {
        die("No *_quant.txt files found in $quantDir \n");
    }
    foreach my $chrPos (keys %position2coveragePercent)
    {
        $position2coveragePercent{$chrPos} /= $assayCount;
    }
}


# Load data for reference populations at positions present in quant files for the current experiment
if ($verbose) { print "\n".'Intersecting with population-specific allele frequency data (in '.$refPopDir.') for: '.join(', ',@refPops)."\n"; }

opendir(DH, $refPopDir);
my @refPopDirFilenames = readdir(DH);
@refPopDirFilenames = sort @refPopDirFilenames;
close(DH);

my %pop2order;  for (my $idx=0; $idx<@refPops; $idx++) { $pop2order{$refPops[$idx]} = $idx+1; }
my %position2rs_id;
my %position2refPopRefAllele;
my %position2refPopOthAllele;
my %position2refPopOtherCount;
my %position2refPopTotalCount;
my $filename;
my $fileCount = 0;
foreach $filename (@refPopDirFilenames)
{
    if ($filename =~ $refPopDataRegex)
    {
        my $chr = $1;
        my $pop = $2;

        if ($pop2order{$pop})
        {
            my $popIdx = $pop2order{$pop}-1;

            $fileCount++;
            $filename = $refPopDir.$filename;
            if ($verbose) { print 'Intersecting with '.$filename."...\n"; }

            my $seen=0;
            my $kept=0;
            open(IFH, $filename) or die('Could not read '.$filename."\n");
            my $headerLine = readline(IFH);
            while(<IFH>)
            {
                $seen++;

                s/\s+$//;
                my @fields = split("\t");
                $position = 'chr'.$fields[1].':'.$fields[2];
                if ($position2coveragePercent{$position})
                {
                    $kept++;
                    $position2rs_id{$position} = $fields[0];
                    $position2refPopRefAllele{$position}[$popIdx] = $fields[3];
                    $position2refPopOthAllele{$position}[$popIdx] = $fields[4];
                    $position2refPopOtherCount{$position}[$popIdx] = $fields[5];
                    $position2refPopTotalCount{$position}[$popIdx] = $fields[6];
                }
            }
            close(IFH);
            if ($verbose) { print 'Processed -- '.$kept.' of '.$seen." in intersection.\n"; }
        }
    }
}
if ($fileCount == 0)
{
    die "Failed to find population-specific allele frequency data files matching $refPopDataRegex in $refPopDir\n";
}


# Calculate information entropy for the partitions for each position
my $noInfoPP = 1.0/@refPops;
my $scaleFactor = 1.0/@refPops/log(2);    #log(2) <--> only bi-allelic SNPs considered
my $noInfoPairwiseIE = log(2); #since each of the 2 (bi-allelic) contributions will be scaled by $pairwiseScaleFactor, make this log(2) --> (log(2) + log(2))*$pairwiseScaleFactor = 1 --> it's a full bit of noise -- no info
my $pairwiseScaleFactor = 1.0/2.0/log(2); #log(2) <--> only bi-allelic SNPs considered
if ($verbose) { print "\nCalculating partition information entropy for ".keys(%position2refPopOtherCount)." SNPs found in intersection...\n"; }
my %position2entropy;
my %position2ppgra;
my %position2ppgoa;
my $discardCountRAF = 0;
my $discardCountOAF = 0;
my $inconsistentAllelesCount = 0;

foreach $position (keys(%position2refPopOtherCount))
{
    my $refAllele = $position2refPopRefAllele{$position}[0];
    my $othAllele = $position2refPopOthAllele{$position}[0];
    my $consistentAlleles = 1;
    my $satisfiesOAFmin = 1;
    my $satisfiesRAFmin = 1;
    my @rafs;
    my @oafs;
    my $sum_rafs = 0.0;
    my $sum_oafs = 0.0;
    for (my $idx=0; $idx<@refPops; $idx++)
    {
        if ($refAllele ne $position2refPopRefAllele{$position}[$idx])
        {
            $consistentAlleles = 0;
            last;
        }
        if ($othAllele ne $position2refPopOthAllele{$position}[$idx])
        {
            $consistentAlleles = 0;
            last;
        }
    
        my $oaf = $position2refPopOtherCount{$position}[$idx]/
                  $position2refPopTotalCount{$position}[$idx]; #should be safe to assume total>0
        $oafs[$idx] = $oaf;

        my $raf = 1.0 - $oaf; 
        $rafs[$idx] = $raf;

        if ($oaf < $minOAF)
        {
            $satisfiesOAFmin = 0;
            last;
        }
        if ($raf < $minRAF)
        {
            $satisfiesRAFmin = 0;
            last;
        }

        $sum_rafs += $raf;
        $sum_oafs += $oaf;
    }

    if (!$consistentAlleles)
    {
        $inconsistentAllelesCount++;
        next;
    }
    if (!$satisfiesOAFmin)
    {
        $discardCountOAF++;
        next;
    }
    if (!$satisfiesRAFmin)
    {
        $discardCountRAF++;
        next;
    }

    my $cumm_entropy = 0.0;
    for (my $idx=0; $idx<@refPops; $idx++)
    {
        my $currentPop_raf = $rafs[$idx];
        my $currentPop_oaf = $oafs[$idx];

        my $ppgra;
        if ($sum_rafs > 0)
        {
            $ppgra = $currentPop_raf/$sum_rafs;
        }
        else
        {
            $ppgra = $noInfoPP;  #no information to be extracted from this (bi-allelic) SNP --> maximum entropy
        }
        if ($ppgra == 0.0 || $ppgra == 1.0)
        {
            #no contribution to entropy -- ie, VERY informative
        }
        else
        {
            $cumm_entropy += -$ppgra*log($ppgra); #natural log; scale at the end
        }

        my $ppgoa;
        if ($sum_oafs > 0)
        {
            $ppgoa = $currentPop_oaf/$sum_oafs;
        }
        else
        {
            $ppgoa = $noInfoPP;  #no information to be extracted from this (bi-allelic) SNP --> maximum entropy
        }
        if ($ppgoa == 0.0 || $ppgoa == 1.0)
        {
            #no contribution to entropy -- ie, VERY informative
        }
        else
        {
            $cumm_entropy += -$ppgoa*log($ppgoa); #natural log; scale at the end
        }

        $position2ppgra{$position}[$idx] = $ppgra;
        $position2ppgoa{$position}[$idx] = $ppgoa;
    }

    my $scaled_cumm_entropy = $cumm_entropy*$scaleFactor; #must be scaled for weighting and makes inter-run values comparable

    #weight based on coverage?
    if ($useCoverageWeighting)
    {
        $scaled_cumm_entropy = $scaled_cumm_entropy**$position2coveragePercent{$position}; #pushes values toward 1.0
    }
    $position2entropy{$position} = $scaled_cumm_entropy;
}
if ($verbose)
{
    print "Calculated partition information entropy for SNPs found in intersection.\n";
    print "Discarded ".$inconsistentAllelesCount." SNP(s) due to inconsistent ref/other alleles specified across populations.\n";
    print "Discarded ".$discardCountRAF." SNP(s) due to allele frequencies below the RAF threshold (<".($minRAF*100.0)."%).\n";
    print "Discarded ".$discardCountOAF." SNP(s) due to allele frequencies below the OAF threshold (<".($minOAF*100.0)."%).\n";
}

#the list of positions of potential interest
my @positions = keys(%position2entropy);
if ($verbose)
{
    print ''.(0+@positions)." SNP(s) have made it this far...\n";
}


#sort positions by and filter to +/- $madsToKeep*MAD
if ($useMADFilter)
{
    if ($verbose) { print "\nTrimming positions based on ".$madsToKeep."*MAD filtering of PPGxA values...\n"; }

    #find the median
    my @ppgxa;
    foreach $position (@positions)
    {
        for (my $i=0; $i<@refPops; $i++)
        {
            push @ppgxa, $position2ppgra{$position}[$i];
            push @ppgxa, $position2ppgoa{$position}[$i];
        }
    }
    @ppgxa = sort { $a <=> $b } @ppgxa;
    my $median = $ppgxa[@ppgxa/2];

    #find the MAD
    my @deviationsFromMedian;
    foreach $position (@positions)
    {
        for (my $i=0; $i<@refPops; $i++)
        {
            push @deviationsFromMedian, abs($position2ppgra{$position}[$i]-$median);
            push @deviationsFromMedian, abs($position2ppgoa{$position}[$i]-$median);
        }
    }
    my @sortedDeviationsFromMedian = sort { $a <=> $b } @deviationsFromMedian;
    my $mad = $sortedDeviationsFromMedian[@sortedDeviationsFromMedian/2];

    #4.5MAD --> 99.7% (3stdev)
    my $discardCountMADTrim = 0;
    my @positionsWithinMADRange;
    foreach $position (@positions)
    {
        my $discardPosition = 0;
        for (my $i=0; $i<@refPops; $i++)
        {
            if (abs($position2ppgra{$position}[$i]-$median) > $madsToKeep*$mad)
            {
                $discardPosition = 1;
            }
            elsif (abs($position2ppgoa{$position}[$i]-$median) > $madsToKeep*$mad)
            {
                $discardPosition = 1;
            }
        }
        if ($discardPosition)
        {
            $discardCountMADTrim++;
        }
        else
        {
            push @positionsWithinMADRange, $position;
        }
    }

    @positions = @positionsWithinMADRange;
    if ($verbose) { print "Discarded ".$discardCountMADTrim." due to ".$madsToKeep."*MAD filter.\n"; }
}


#sort and filter by LD
if ($verbose) { print "\nSorting to find SNPS anticipated to be maximally informative...\n"; }
@positions = sort { $position2entropy{$a} <=> $position2entropy{$b} } @positions;
if ($verbose) { print "Sorted SNPs by entropy.\n"; }

if ($verbose) { print "\nFiltering to ensure LD (ie, at least $minDistanceBetweenSNPs bases between SNPs)...\n"; }
my $discardCountLD = 0;
my %chr2chrPositions;
my @ldFilteredPositions;
foreach $position (@positions)
{
    my $satisfiesMinDistanceBetweenSNPs = 1;
    my @positionFields = split(':', substr($position, 3));
    my $chrNbr = $positionFields[0];
    my $chrPosition = $positionFields[1];
    foreach my $keptChrPosition (@{$chr2chrPositions{$chrNbr}})
    {
        if (abs($chrPosition - $keptChrPosition) < $minDistanceBetweenSNPs)
        {
            $satisfiesMinDistanceBetweenSNPs = 0;
            last;
        }
    }
    if ($satisfiesMinDistanceBetweenSNPs)
    {
        push @ldFilteredPositions, $position;
    }
    else
    {
        $discardCountLD++;
    }
}
if ($verbose) { print 'Removed '.$discardCountLD." SNPs.\n"; }

if ($writePositionEntropyFile)
{
    if ($verbose) { print "\nWriting sorted and filtered SNPs to ".$positionEntropyFilename." ...\n"; }
    open(OFH, '>'.$positionEntropyFilename);
    print OFH "Chromosome\tPosition\tSNPNumber\tEntropy";
}

my @cummOptimisticProbs; #store as (1-population prob) -- start all 1s
my @cummPessimisticProbs; #store as (1-population prob) -- start all 1s
for (my $idx=0; $idx<@refPops; $idx++)
{
    $cummOptimisticProbs[$idx] = 1.0;
    $cummPessimisticProbs[$idx] = 1.0;
}
my $runningMaxOptOverMinPess = 1.0;

my @pairwisePopCummIC;
if ($writePositionEntropyFile)
{
    if ($writePerPopROCdata)
    {
        print OFH "\tEntropyTier";
        for (my $idx=0; $idx<@refPops; $idx++)
        {
            my $refPop = $refPops[$idx];
            print OFH "\tOptimisticIs$refPop\tPessimisticIs$refPop";
        }
    }
    if ($writePartitionProbData)
    {
        for (my $idx=0; $idx<@refPops; $idx++)
        {
            my $refPop = $refPops[$idx];
            print OFH "\tPPGRAfor$refPop\tPPGAAfor$refPop";
        }
    }
    if ($writePairwisePopIC)
    {
        for (my $idxA=0; $idxA+1<@refPops; $idxA++)
        {
            my $refPopA = $refPops[$idxA];
            for (my $idxB=$idxA+1; $idxB<@refPops; $idxB++)
            {
                my $refPopB = $refPops[$idxB];
                print OFH "\tIC_$refPopA-$refPopB\tCummIC_$refPopA-$refPopB";
                push @pairwisePopCummIC, 0.0;
            }
        }
    }
    print OFH "\tMostPessimistic\tMaxOpt/MinPess\tCoverage\n";
}
my $entropyTier=0;
my $entropyTierEntropy=0;
my $snpCount = 0;
my $reachedSnpCutoff = 0;
foreach $position (@ldFilteredPositions)
{
    $snpCount++;

    my $currentEntropy = $position2entropy{$position};
    if ($entropyTierEntropy < $currentEntropy)
    {
        $entropyTierEntropy = $currentEntropy;
        $entropyTier++;
    }

    my $mostPessimisticPopProb = 0.0;
    my $maxOptimisticProb = 0.0;
    my $minPessimisticProb = 1.0;
    for (my $idx=0; $idx<@refPops; $idx++)
    {
        my $maxp = $position2ppgra{$position}[$idx];
        my $minp = $position2ppgoa{$position}[$idx];
        if ($minp > $maxp)
        {
            $maxp = $position2ppgoa{$position}[$idx];
            $minp = $position2ppgra{$position}[$idx];
        }

        #weight based on coverage
        if ($useCoverageWeighting)
        {
            $maxp = $maxp**(1.0/$position2coveragePercent{$position}); #push toward 0 so that the cumm stays closer to 1
            $minp = $minp**(1.0/$position2coveragePercent{$position}); #push toward 0 so that the cumm stays closer to 1
        }

        my $optimisticProb = (1.0 - $maxp);
        my $pessimisticProb = (1.0 - $minp);
        $cummOptimisticProbs[$idx] *= $optimisticProb;
        $cummPessimisticProbs[$idx] *= $pessimisticProb;
        
        if ($mostPessimisticPopProb < $cummPessimisticProbs[$idx])
        {
            $mostPessimisticPopProb = $cummPessimisticProbs[$idx];
        }

        if ($minPessimisticProb > $pessimisticProb)
        {
            $minPessimisticProb = $pessimisticProb;
        }
        if ($maxOptimisticProb < $optimisticProb)
        {
            $maxOptimisticProb = $optimisticProb;
        }
    }
    $runningMaxOptOverMinPess *= ($maxOptimisticProb / $minPessimisticProb);

    if ($writePositionEntropyFile)
    {
        #head of minimal columns
        print OFH join("\t",split(':',substr($position,3)))."\t".$snpCount."\t".$currentEntropy;

        #for ROC
        if ($writePerPopROCdata)
        {
            print OFH "\t".$entropyTier;
            for (my $idx=0; $idx<@refPops; $idx++)
            {
                print OFH "\t".(1.0-$cummOptimisticProbs[$idx])."\t".(1.0-$cummPessimisticProbs[$idx]);
            }
        }

        #for partition probabilities
        if ($writePartitionProbData)
        {
            for (my $idx=0; $idx<@refPops; $idx++)
            {
                print OFH "\t".$position2ppgra{$position}[$idx]."\t".$position2ppgoa{$position}[$idx];
            }
        }

        #for population pair-wise IC details...
        if ($writePairwisePopIC)
        {
            my $pairIdx = -1;
            for (my $idxA=0; $idxA+1<@refPops; $idxA++)
            {
                for (my $idxB=$idxA+1; $idxB<@refPops; $idxB++)
                {
                    $pairIdx++;

                    my $raABPartitionIE = $noInfoPairwiseIE; #till proven otherwise...
                    my $raDenom = $position2ppgra{$position}[$idxA]+$position2ppgra{$position}[$idxB];
                    if ($raDenom > 0.0)
                    {
                        my $raABPartitionProb = $position2ppgra{$position}[$idxA] / $raDenom; 
                        if ($raABPartitionProb > 0.0 && $raABPartitionProb < 1.0)
                        {
                            $raABPartitionIE = -$raABPartitionProb*log($raABPartitionProb) +
                                               -(1.0-$raABPartitionProb)*log(1.0-$raABPartitionProb);
                        }
                    }

                    my $oaABPartitionIE = $noInfoPairwiseIE; #till proven otherwise...
                    my $oaDenom = $position2ppgoa{$position}[$idxA]+$position2ppgoa{$position}[$idxB];
                    if ($oaDenom > 0.0)
                    {
                        my $oaABPartitionProb = $position2ppgoa{$position}[$idxA] / $oaDenom; 
                        if ($oaABPartitionProb > 0.0 && $oaABPartitionProb < 1.0)
                        {
                            $oaABPartitionIE = -$oaABPartitionProb*log($oaABPartitionProb) +
                                               -(1.0-$oaABPartitionProb)*log(1.0-$oaABPartitionProb);
                        }
                    }

                    my $pairIC = 1.0 - (($raABPartitionIE + $oaABPartitionIE) * $pairwiseScaleFactor);
                    $pairwisePopCummIC[$pairIdx] += $pairIC;

                    print OFH "\t$pairIC\t$pairwisePopCummIC[$pairIdx]";
                }
            }
        }

        #the tail of minimal columns
        print OFH "\t".(1.0-$mostPessimisticPopProb)."\t".$runningMaxOptOverMinPess."\t".$position2coveragePercent{$position}."\n";
    }
    
    # $snpCutoffMode: #0 -- exhaustion, 1 -- precision, 2 -- count, 3 -- earliest, 4 -- latest
    if ($snpCutoffMode == 0)
    {
        #give it everything we see
    }
    elsif ($snpCutoffMode == 1) #precision
    {
        if ($runningMaxOptOverMinPess <= $desiredPrecision)
        {
            if ($verbose) { print 'Reached cutoff: Anticipate expected precision level ('.$runningMaxOptOverMinPess.' <= '.$desiredPrecision.') with '.$snpCount." SNPs.\n"; }
            $reachedSnpCutoff = 1;
            last;
        }
    }
    elsif ($snpCutoffMode == 2) #count
    {
        if ($snpCount >= $desiredSNPCount)
        {
            if ($verbose) { print 'Reached cutoff: Anticipate precision level '.$runningMaxOptOverMinPess.' with '.$snpCount." SNPs.\n"; }
            $reachedSnpCutoff = 1;
            last;
        }
    }
    elsif ($snpCutoffMode == 3) #either
    {
        if ($runningMaxOptOverMinPess <= $desiredPrecision && $snpCount >= $desiredSNPCount)
        {
            if ($verbose) { print 'Reached cutoff: Both anticipate expected precision level ('.$runningMaxOptOverMinPess.' <= '.$desiredPrecision.') and '.$snpCount." SNPs.\n"; }
            $reachedSnpCutoff = 1;
            last;
        }
        if ($runningMaxOptOverMinPess <= $desiredPrecision)
        {
            if ($verbose) { print 'Reached cutoff: Anticipate expected precision level ('.$runningMaxOptOverMinPess.' <= '.$desiredPrecision.') with '.$snpCount." SNPs.\n"; }
            $reachedSnpCutoff = 1;
            last;
        }
        if ($snpCount >= $desiredSNPCount)
        {
            if ($verbose) { print 'Reached cutoff: Anticipate precision level '.$runningMaxOptOverMinPess.' with '.$snpCount." SNPs.\n"; }
            $reachedSnpCutoff = 1;
            last;
        }
    }
    elsif ($snpCutoffMode == 4) #both
    {
        if ($runningMaxOptOverMinPess <= $desiredPrecision && $snpCount >= $desiredSNPCount)
        {
            if ($verbose) { print 'Reached cutoff: Anticipate expected precision level ('.$runningMaxOptOverMinPess.' <= '.$desiredPrecision.') and '.$snpCount.' >= '.$desiredSNPCount." SNPs.\n"; }
            $reachedSnpCutoff = 1;
            last;
        }
    }
}
close(OFH);
if ($verbose)
{
    if ($writePositionEntropyFile)
    {
        print "Wrote $snpCount sorted SNPs".(($writePerPopROCdata)?' (and per-population ROC data)':'').".\n\n";
    }
    else
    {
        print "Identified $snpCount SNPs anticipated to be most informative.\n\n";
    }
}
if ($snpCutoffMode != 0 && $reachedSnpCutoff == 0)
{
    if ($notEnoughSnpsBehavior == 0)
    {
        if ($verbose) { print "Desired SNP cutoff not reached.\n"; }
    }
    elsif ($notEnoughSnpsBehavior == 1)
    {
        warn "Desired SNP cutoff not reached.\n";
    }
    elsif ($notEnoughSnpsBehavior == 2)
    {
        die "Desired SNP cutoff not reached.\n";
    }
}

#now that the SNPs of interest have been identified, load ATGC read counts per individual from the quant files
my %sampleId2position2ATGCCounts;

# we'll need a quick way to identify the SNPs of interest...
my %positionsToFeedToStructure;
for (my $i=0; $i<$snpCount; $i++)
{
    $positionsToFeedToStructure{$ldFilteredPositions[$i]} = 1;
}

# reading the individual assay-level quant files...
if ($verbose) { print "\n"; }
opendir(DH, $quantDir);
my @filenames = readdir(DH);
@filenames = sort @filenames;
close(DH);

my %assayId2sampleId = (); #store as a hash -- we'll expect to find a file matching $assayId.'_quant.txt'
my %qfn2assayId = (); #unless we have to use ./hapmap_quant/sample2qfn.txt to make the connection...
if ($useAssay2InfoMapping)
{
    open(IFH, $assay2infoFilename) or die('Could not read '.$assay2infoFilename);
    my $headerLine = readline(IFH);
    #if the first two columns are: AssayID and SampleID (in that order), then ignore...  If not, add to the mapping
    if (lc($headerLine) !~ /^assay.?id\tsample.?id/)
    {
        $headerLine =~ s/\s+$//;
        my @fields = split("\t", $headerLine);
        my $sampleId = $fields[1];
        my $assayId = $fields[0];
        $assayId2sampleId{$assayId} = $sampleId;
    }
    while (<IFH>)
    {
        s/\s+$//;
        my @fields = split("\t", $_);
        my $sampleId = $fields[1];
        my $assayId = $fields[0];
        $assayId2sampleId{$assayId} = $sampleId;
    }
    close(IFH);

    open(IFH, $assay2quantFilename) or die('Could not read '.$assay2quantFilename);
    #presume that the first two columns are: AssayID and quant file name (in that order)
    while (<IFH>)
    {
        s/\s+$//;
        my @fields = split("\t", $_);
        my $qfn = $fields[1];
        my $assayId = $fields[0];
        $qfn2assayId{$qfn} = $assayId;
    }
    close(IFH);
}

#reuse $filename from earlier
my $currentSample;
my $sampleFileCount=0; #for use when NOT using an assay2info mapping file
foreach $filename (@filenames)
{
    if ($useAssay2InfoMapping)
    {
        if ($filename =~ /^(.+)_quant\.txt$/)
        {
            my $assayId = $1;
            if (not exists $assayId2sampleId{$assayId})
            {
                if (exists $qfn2assayId{$filename})
                {
                    $assayId = $qfn2assayId{$filename};
                }
            }
            if (exists($assayId2sampleId{$assayId}))
            {
                my $sampleId = $assayId2sampleId{$assayId};

                open(IFH, $quantDir.$filename) or die('Could not read '.$quantDir.$filename."\n");
                if ($verbose) { print 'Loading ATGC counts of interest for '.$sampleId.' from '.$quantDir.$filename." ...\n"; }
                my $headerLine = readline(IFH);
                while(<IFH>)
                {
                    #no need to chomp -- we don't need the last column anyway
                    my @fields = split("\t");
                    #quant files have A,G,T,C in 6,7,8,9
                    my $position = $fields[0].':'.$fields[1];
                    if ($positionsToFeedToStructure{$position})
                    {
                        $sampleId2position2ATGCCounts{$sampleId}{$position}[0] += $fields[6];
                        $sampleId2position2ATGCCounts{$sampleId}{$position}[1] += $fields[8];
                        $sampleId2position2ATGCCounts{$sampleId}{$position}[2] += $fields[7];
                        $sampleId2position2ATGCCounts{$sampleId}{$position}[3] += $fields[9];
                    }
                }
                close(IFH);
                
                #file to match the assay was found, so cross it off the list
                # I'm sure there's a better way to do this, but I'm also sure that I'm not going to fight with it
                $assayId2sampleId{$assayId} = 'quant file found';
            }
            else
            {
                die('Did not find sample information for '.$quantDir.$filename);
            }
        }
    }
    else
    {
        if ($filename =~ $quantFilenameRegex)
        {
            $sampleFileCount++;
            my $sampleId = $1;
            open(IFH, $quantDir.$filename) or die('Could not read '.$quantDir.$filename."\n");
            if ($verbose) { print 'Loading ATGC counts of interest for '.$sampleId.' from '.$quantDir.$filename." ...\n"; }
            my $headerLine = readline(IFH);
            while(<IFH>)
            {
                #no need to chomp -- we don't need the last column anyway
                my @fields = split("\t");
                #quant files have A,G,T,C in 6,7,8,9
                my $position = $fields[0].':'.$fields[1];
                if ($positionsToFeedToStructure{$position})
                {
                    $sampleId2position2ATGCCounts{$sampleId}{$position}[0] += $fields[6];
                    $sampleId2position2ATGCCounts{$sampleId}{$position}[1] += $fields[8];
                    $sampleId2position2ATGCCounts{$sampleId}{$position}[2] += $fields[7];
                    $sampleId2position2ATGCCounts{$sampleId}{$position}[3] += $fields[9];
                }
            }
            close(IFH);
        }
    }
}
if ($useAssay2InfoMapping)
{
    my @assayIdsFromAssay2Info = keys(%assayId2sampleId);
    @assayIdsFromAssay2Info = sort @assayIdsFromAssay2Info;
    my @assayIdsSansQuantFiles;
    foreach my $assayId (@assayIdsFromAssay2Info)
    {
        if ($assayId2sampleId{$assayId} ne 'quant file found')
        {
            push @assayIdsSansQuantFiles, $assayId;
        }
    }
    if (@assayIdsSansQuantFiles > 0)
    {
        die("Failed to find quant files for the following assays: \n".join("\n",@assayIdsSansQuantFiles)."\n");
    }
}
else
{
    if ($verbose) { print 'Loaded base counts from '.$sampleFileCount." file(s).\n"; }
    if ($sampleFileCount == 0) { die("No sample files found!\n"); }
}
if ($verbose) { print "Done loading base counts for all samples.\n"; }

#we'll need the sample ids later...
my @sampleIds = keys(%sampleId2position2ATGCCounts);
@sampleIds = sort @sampleIds;

#output the counts for sanity and debug...
if ($writeSampleLevelATGCCounts)
{
    if ($verbose) { print 'Writing sample-level base counts to '.$sampleLevelATGCCountsFilename." ...\n"; }
    open(OFH, '>'.$sampleLevelATGCCountsFilename);
    print OFH "Sample\tPosition\tA\tT\tG\tC\tATGCTotal\tPercent1\tPercent2\tPercent3\tPercent4\n";
    foreach my $sampleId (@sampleIds)
    {
        foreach my $position (keys %{$sampleId2position2ATGCCounts{$sampleId}})
        {
            my $A = $sampleId2position2ATGCCounts{$sampleId}{$position}[0];
            my $T = $sampleId2position2ATGCCounts{$sampleId}{$position}[1];
            my $G = $sampleId2position2ATGCCounts{$sampleId}{$position}[2];
            my $C = $sampleId2position2ATGCCounts{$sampleId}{$position}[3];
            my $atgcTotal = $A+$T+$G+$C;
            $atgcTotal = ($atgcTotal == 0)?1:$atgcTotal;
            my @percents = ($A/$atgcTotal*100.0, $T/$atgcTotal*100.0, $G/$atgcTotal*100.0, $C/$atgcTotal*100.0); 
            @percents = sort { $b <=> $a } @percents;
            print OFH $sampleId."\t".$position."\t".$A."\t".$T."\t".$G."\t".$C."\t".$atgcTotal;
            print OFH "\t".join("\t", @percents)."\n";
        }
    }
    close(OFH);
    if ($verbose) { print 'Done writing sample-level base counts to '.$sampleLevelATGCCountsFilename." .\n"; }
}







#output a file of allele frequencies (per ref pop and assay-sample) at the LD-filtered SNPs
# Position,Sample,Sample_RAF,"ref_pop1"_RAF,"ref_pop2"_RAF, ...
# NOTE:  Sample_RAF only has THREE values: 0.0, 0.5, 1.0 -- based on whether it was called homoRef/hetero/homoOther
#        To be informative, "self-declared race" information must be added elsewhere manually and
#        values for samples aggregate (by "self-declared race") elsewhere...
if ($writeAlleleComparisonFile)
{
    if ($verbose) { print 'Writing '.$alleleComparisonFilename." ...\n"; }
    open(OFH, '>'.$alleleComparisonFilename);
    print OFH "Position\tAssay-Sample\tSample_RAF";
    foreach my $refPop (@refPops)
    {
        print OFH "\t".$refPop."_RAF";
    }
    print OFH "\n";
    foreach my $position (@ldFilteredPositions)
    {
        foreach my $sampleId (keys %sampleId2position2ATGCCounts)
        {
            if ($sampleId2position2ATGCCounts{$sampleId}{$position})
            {
                my $A = $sampleId2position2ATGCCounts{$sampleId}{$position}[0];
                my $T = $sampleId2position2ATGCCounts{$sampleId}{$position}[1];
                my $G = $sampleId2position2ATGCCounts{$sampleId}{$position}[2];
                my $C = $sampleId2position2ATGCCounts{$sampleId}{$position}[3];
                my $atgcTotal = $A+$T+$G+$C;

                if ($atgcTotal > 0)
                {
                    #ok...  The following is kinda fugly, but it handles the 100-0 and 50-50 edge cases
                    my @atgcPercents = (
                        $A/$atgcTotal*100.0,
                        $T/$atgcTotal*100.0,
                        $G/$atgcTotal*100.0,
                        $C/$atgcTotal*100.0);
                    my $primaryPercent = 0;
                    my $primaryIdx;
                    for (my $j=0; $j<4; $j++)
                    {
                        if ($atgcPercents[$j] > $primaryPercent)
                        {
                            $primaryPercent = $atgcPercents[$j];
                            $primaryIdx = $j;
                        }
                    }
                    my $primaryAllele = substr('ATGC', $primaryIdx, 1);
                    
                    my $secondaryAllele;
                    if ($primaryPercent >= $homozygousCutoffPercent || $primaryPercent == 100.0) #defensive check...
                    {
                        $secondaryAllele = $primaryAllele;
                    }
                    else
                    {
                        $atgcPercents[$primaryIdx] = 0;
                        my $secondaryPercent = 0;
                        my $secondaryIdx;
                        for (my $j=0; $j<4; $j++)
                        {
                            if ($atgcPercents[$j] > $secondaryPercent)
                            {
                                $secondaryPercent = $atgcPercents[$j];
                                $secondaryIdx = $j;
                            }
                        }
                        $secondaryAllele = substr('ATGC', $secondaryIdx, 1);
                    }

                    my $refAllele = $position2refPopRefAllele{$position}[0]; #already ensured to be same for all ref pops
                    my $othAllele = $position2refPopOthAllele{$position}[0]; #already ensured to be same for all ref pops
                    if (($primaryAllele   eq $refAllele || $primaryAllele   eq $othAllele) &&
                        ($secondaryAllele eq $refAllele || $secondaryAllele eq $othAllele))
                    {
                        #looks like a "keeper"
                        my $sampleRAF = (($primaryAllele eq $refAllele)?0.5:0.0)+
                                        (($secondaryAllele eq $refAllele)?0.5:0.0);
                        print OFH $position."\t".$sampleId."\t".$sampleRAF;
                        for (my $i=0; $i<@refPops; $i++)
                        {
                            my $refPopRAF = 1.0 - ($position2refPopOtherCount{$position}[$i] / $position2refPopTotalCount{$position}[$i]);
                            print OFH "\t".$refPopRAF;
                        }
                        print OFH "\n";
                    }
                }
            }
        }
    }
    close(OFH);
    if ($verbose) { print 'Done writing '.$alleleComparisonFilename."\n"; }
}




if ($generateStructureInput)
{
    if ($verbose) { print "\nGenerating STRUCTURE input files...\n"; }
}
else
{
    die("\nTerminated before generating STRUCTURE input file.\n");
}







#generate input data file for STRUCTURE
if ($verbose) { print "\n"; }
open(OFH, '>'.$structureInputFilename);
my $structureMissingValue = -1;
my $structureRefAlleleValue = 0;
my $structureOthAlleleValue = 1;
# Columns:  Label, PopulationIdx, UsePopulationInfoFlag, Locus1 .. LocusN
#  One row of Locus IDs -- properly offset
print OFH "\t\t";
for (my $i=0; $i<$snpCount; $i++)
{
    my $rs_id = $position2rs_id{$ldFilteredPositions[$i]};
    print OFH "\t".$rs_id;
}
print OFH "\n";
#  And now the data rows...
#   Synthetic individuals (to set population-specific allele frequencies) first
#
#  NOTE: To potentially address the "small n" problem,
#        write an extra 10 synthetic individuals from each ref pop
#        if n<10*refPopCount
my $syntheticIndividualCount = 0;
my @savedSyntheticIndividuals = ();
for (my $i=0; $i<@refPops; $i++)
{
    my $maxTotalCount=0;
    for (my $j=0; $j<$snpCount; $j++)
    {
        my $position = $ldFilteredPositions[$j];
        my $snpPopTotalCount = $position2refPopTotalCount{$position}[$i];
        if ($maxTotalCount < $snpPopTotalCount)
        {
            $maxTotalCount = $snpPopTotalCount;
        }
    }
    $syntheticIndividualCount += $maxTotalCount;
    if ($verbose)
    {
        print 'Writing '.$maxTotalCount.' synthetic individuals for reference population '.$refPops[$i].' to ';
        print $structureInputFilename.' to set allele frequencies in STRUCTURE...'."\n";
    }

    my @snpOtherCountsForMaxTotalCount;
    for (my $j=0; $j<$snpCount; $j++)
    {
        my $position = $ldFilteredPositions[$j];
        my $snpPopOtherCount = $position2refPopOtherCount{$position}[$i];
        my $snpPopTotalCount = $position2refPopTotalCount{$position}[$i];
        if ($snpPopTotalCount == $maxTotalCount)
        {
            push @snpOtherCountsForMaxTotalCount, $snpPopOtherCount;
        }
        else
        {
            my $rescaledOtherCount = ($maxTotalCount*$snpPopOtherCount/$snpPopTotalCount);
            push @snpOtherCountsForMaxTotalCount, $rescaledOtherCount;
            if ($verbose && ($snpPopOtherCount/$snpPopTotalCount) != ($rescaledOtherCount/$maxTotalCount))
            {
                print 'Warning: Rescaled the "other" allele frequency at '.$position;
                print ' ('.$position2rs_id{$position}.')';
                print ' from '.($snpPopOtherCount/$snpPopTotalCount);
                print ' to '.($rescaledOtherCount/$maxTotalCount)."\n";
            }
        }
    }
    
    #based on the STRUCTURE docs (and our choice of models), there should be no linkage between loci, so
    #it should be safe to have runs of other and then ref alleles (rather than shuffling)  Not true though.
    if ($verbose) { print 'Shuffling alleles...'."\n"; }
    my @allelesForAllSNPs;
    for (my $j=0; $j<@snpOtherCountsForMaxTotalCount; $j++)
    {
        #make and populate the array of available alleles to spread across individuals
        my @alleles;
        for (my $k=0; $k<$maxTotalCount*2; $k++)  #2x since we're expecting diploid data...
        {
            push @alleles, (($k<2*$snpOtherCountsForMaxTotalCount[$j])?$structureOthAlleleValue:$structureRefAlleleValue);
        }
        #shuffle them
        my @shuffledAlleles;
        while (@alleles>0)
        {
            push @shuffledAlleles, splice(@alleles,rand()*@alleles,1);
        }
        $allelesForAllSNPs[$j] = \@shuffledAlleles;
    }
    if ($verbose) { print "Alleles shuffled.\n"; }

    for (my $j=0; $j<$maxTotalCount; $j++)
    {
        for (my $m=0; $m<2; $m++) #since we're expecting diploid data...
        {
            print OFH $refPops[$i].'_'.$j."\t".($i+1)."\t1"; #STRUCTURE requires population ids be 1..N
            for (my $k=0; $k<@snpOtherCountsForMaxTotalCount; $k++)
            {
                print OFH "\t".$allelesForAllSNPs[$k][2*$j+$m];
            }
            print OFH "\n";
        }
    }
    if ($verbose) { print 'Wrote shuffled synthetics for '.$refPops[$i].".\n"; }

    if (@sampleIds < 10*@refPops)
    {
        my $padUnknownSyntheticCount = (($maxTotalCount<10)?$maxTotalCount:10);
        for (my $j=0; $j<$padUnknownSyntheticCount; $j++)
        {
            for (my $m=0; $m<2; $m++) #since we're expecting diploid data...
            {
                print OFH 'pad'.$refPops[$i].'_'.$j."\t".$structureMissingValue."\t0";
                for (my $k=0; $k<@snpOtherCountsForMaxTotalCount; $k++)
                {
                    print OFH "\t".$allelesForAllSNPs[$k][2*$j+$m];
                }
                print OFH "\n";
            }
        }
        $syntheticIndividualCount += $padUnknownSyntheticCount;
        if ($verbose) { print 'Padded "n" with '.$padUnknownSyntheticCount.' "unknown" synthetic individuals from '.$refPops[$i].".\n"; }
    }
}
if ($verbose) { print 'Wrote a total of '.$syntheticIndividualCount." synthetic individuals.\n"; }

#   Real individuals
#   (still Columns:  Label, PopulationIdx, UsePopulationInfoFlag, Locus1 .. LocusN)
#   -- There appears to be an 11-character limit on the sample labels, so make a mapping file too...
open (OFH2, '>'.$structureSampleIdMappingFilename) or die('Could not write '.$structureSampleIdMappingFilename."\n");
print OFH2 "OriginalSampleId\tStructureSampleId\n";
my $realIndividualCount = 0;
for (my $sampleIdx=0; $sampleIdx < @sampleIds; $sampleIdx++)
{
    my $sampleId = $sampleIds[$sampleIdx];
    my $structureSampleId = sprintf '%lx', $sampleIdx;
    while (length($structureSampleId) < 7)
    {
        $structureSampleId = '0'.$structureSampleId;
    }
    $structureSampleId = 'UNK_'.$structureSampleId;
    print OFH2 $sampleId."\t".$structureSampleId."\n";

    my @allelesByPosition;
    for (my $i=0; $i<$snpCount; $i++)
    {
        my $alleleValuesAssigned = 0;

        my $position = $ldFilteredPositions[$i];
        if ($sampleId2position2ATGCCounts{$sampleId}{$position})
        {
            my $A = $sampleId2position2ATGCCounts{$sampleId}{$position}[0];
            my $T = $sampleId2position2ATGCCounts{$sampleId}{$position}[1];
            my $G = $sampleId2position2ATGCCounts{$sampleId}{$position}[2];
            my $C = $sampleId2position2ATGCCounts{$sampleId}{$position}[3];
            my $atgcTotal = $A+$T+$G+$C;

            if ($atgcTotal > 0)
            {
                #ok...  The following is kinda fugly, but it handles the 100-0 and 50-50 edge cases
                my @atgcPercents = (
                    $A/$atgcTotal*100.0,
                    $T/$atgcTotal*100.0,
                    $G/$atgcTotal*100.0,
                    $C/$atgcTotal*100.0);
                my $primaryPercent = 0;
                my $primaryIdx;
                for (my $j=0; $j<4; $j++)
                {
                    if ($atgcPercents[$j] > $primaryPercent)
                    {
                        $primaryPercent = $atgcPercents[$j];
                        $primaryIdx = $j;
                    }
                }
                my $primaryAllele = substr('ATGC', $primaryIdx, 1);
                
                my $secondaryAllele;
                if ($primaryPercent >= $homozygousCutoffPercent || $primaryPercent == 100.0) #defensive check...
                {
                    $secondaryAllele = $primaryAllele;
                }
                else
                {
                    $atgcPercents[$primaryIdx] = 0;
                    my $secondaryPercent = 0;
                    my $secondaryIdx;
                    for (my $j=0; $j<4; $j++)
                    {
                        if ($atgcPercents[$j] > $secondaryPercent)
                        {
                            $secondaryPercent = $atgcPercents[$j];
                            $secondaryIdx = $j;
                        }
                    }
                    $secondaryAllele = substr('ATGC', $secondaryIdx, 1);
                }

                my $refAllele = $position2refPopRefAllele{$position}[0]; #should be same for all ref pops
                my $othAllele = $position2refPopOthAllele{$position}[0]; #should be same for all ref pops
                if (($primaryAllele   eq $refAllele || $primaryAllele   eq $othAllele) &&
                    ($secondaryAllele eq $refAllele || $secondaryAllele eq $othAllele))
                {
                    $allelesByPosition[$i][0] = (($primaryAllele eq $refAllele)?$structureRefAlleleValue:$structureOthAlleleValue);
                    $allelesByPosition[$i][1] = (($secondaryAllele eq $refAllele)?$structureRefAlleleValue:$structureOthAlleleValue);
                    $alleleValuesAssigned = 1;
                }
                else
                {
                    #Looks like a novel variant so exclude this position for this sample
                    print 'Sample '.$sampleId.' / Position '.$position.' -- Expected '.$refAllele.'/'.$othAllele.' but found '.$primaryAllele.$secondaryAllele."\n";
                }
            }
        }

        if (!$alleleValuesAssigned)
        {
            $allelesByPosition[$i][0] = $structureMissingValue;
            $allelesByPosition[$i][1] = $structureMissingValue;
        }
    }

    for (my $m=0; $m<2; $m++) #diploid...
    {
        print OFH $structureSampleId."\t".$structureMissingValue."\t0";
        for (my $i=0; $i<$snpCount; $i++)
        {
            print OFH "\t".$allelesByPosition[$i][$m];
        }
        print OFH "\n";
    }
}
$realIndividualCount = @sampleIds;
if ($verbose) { print 'Wrote a total of '.$realIndividualCount." real individuals.\n"; }
close(OFH);
close(OFH2);
if ($verbose) { print 'Wrote '.$structureInputFilename."\n"; }


#args specific to this run of ancestry analysis
my $ancestryAnalysisArgs = <<AAArgsEnd;
\$startTime = $startTime
\$verbose = $verbose 
\$writePositionEntropyFile = $writePositionEntropyFile 
\$writePerPopROCdata = $writePerPopROCdata #only applies if a position entropy file is being written
\$writePartitionProbData = $writePartitionProbData #only applies if a position entropy file is being written
\$positionEntropyFilename = $positionEntropyFilename 
\$writeSampleLevelATGCCounts = $writeSampleLevelATGCCounts 
\$sampleLevelATGCCountsFilename = $sampleLevelATGCCountsFilename 
\$writeAlleleComparisonFile = $writeAlleleComparisonFile 
\$alleleComparisonFilename = $alleleComparisonFilename 
\$quantDir = $quantDir #must end in /
\$experimentTalliesFilename = $experimentTalliesFilename 
\$useAssay2InfoMapping = $useAssay2InfoMapping 
\$assay2infoFilename = $assay2infoFilename 
\$quantFilenameRegex = $quantFilenameRegex #if not using assay2info mapping, capture group \$1 must provide a value to use as the sample id
\$refPopDir = $refPopDir #must end in /
\$refPopDataRegex = $refPopDataRegex #capture group \$1 and \$refPops[] (in the next line) need to match
\@refPops @refPops
\$minOAF = $minOAF #in all populations
\$minRAF = $minRAF #in all populations
\$minDistanceBetweenSNPs = $minDistanceBetweenSNPs 
\$minSamplesCoveragePercent = $minSamplesCoveragePercent 
\$snpCutoffMode = $snpCutoffMode #0 -- exhaustion, 1 -- precision, 2 -- count, 3 -- earliest, 4 -- latest
\$desiredPrecision = $desiredPrecision # [0, 1] where 0 --> exhaustion
\$desiredSNPCount = $desiredSNPCount 
\$notEnoughSnpsBehavior = $notEnoughSnpsBehavior #0 -- continue; 1 -- warn; 2 -- die
\$useCoverageWeighting = $useCoverageWeighting #should always be 1 to gently up-weight based on coverage
\$useMADFilter = $useMADFilter 
\$madsToKeep = $madsToKeep 
\$homozygousCutoffPercent = $homozygousCutoffPercent 
\$structureBinaryLocation = $structureBinaryLocation 
\$structureSampleIdMappingFilename = $structureSampleIdMappingFilename 
AAArgsEnd
print "\n\nAncestry Analysis Parameters:\n".$ancestryAnalysisArgs."\n\n";


#generate parameter files for STRUCTURE
open(OFH, '>'.$structureMainparamsFilename);
print OFH 'Basic Program Parameters'."\n";
print OFH '#define MAXPOPS    '.@refPops.'      // (int) number of populations assumed'."\n";
print OFH 'Population codes specified: '.join(', ',@refPops)."\n";

print OFH '#define BURNIN    '.$structureBurnIn.'   // (int) length of burnin period'."\n";
print OFH '#define NUMREPS   '.$structureNumReps.'   // (int) number of MCMC reps after burnin'."\n";
print OFH 'Input/Output files'."\n";
print OFH '#define INFILE   '.$structureInputFilename.'   // (str) name of input data file'."\n";
print OFH '#define OUTFILE  '.$structureOutputFilename.'  //(str) name of output data file'."\n";
print OFH 'Data file format'."\n";
print OFH '#define NUMINDS    '.($syntheticIndividualCount+$realIndividualCount).'    // (int) number of diploid individuals in data file'."\n";
print OFH '#define NUMLOCI    '.$snpCount.'    // (int) number of loci in data file'."\n";
print OFH '#define PLOIDY       2    // (int) ploidy of data'."\n";
print OFH '#define MISSING     '.$structureMissingValue.'    // (int) value given to missing genotype data'."\n";
print OFH '#define ONEROWPERIND 0    // (B) store data for individuals in a single line'."\n";
print OFH 'Types of data present'."\n";
print OFH '#define LABEL     1     // (B) Input file contains individual labels'."\n";
print OFH '#define POPDATA   1     // (B) Input file contains a population identifier'."\n";
print OFH '#define POPFLAG   1     // (B) Input file contains a flag which says'."\n"; 
print OFH '                              whether to use popinfo when USEPOPINFO==1'."\n";
print OFH '#define LOCDATA   0     // (B) Input file contains a location identifier'."\n";
print OFH ''."\n";
print OFH '#define PHENOTYPE 0     // (B) Input file contains phenotype information'."\n";
print OFH '#define EXTRACOLS 0     // (int) Number of additional columns of data'."\n"; 
print OFH '                             before the genotype data start.'."\n";
print OFH '#define MARKERNAMES      1  // (B) data file contains row of marker names'."\n";
print OFH '#define RECESSIVEALLELES 0  // (B) data file contains dominant markers (eg AFLPs)'."\n";
print OFH '                            // and a row to indicate which alleles are recessive'."\n";
print OFH '#define MAPDISTANCES     0  // (B) data file contains row of map distances'."\n"; 
print OFH '                            // between loci'."\n";
print OFH 'Advanced data file options'."\n";
print OFH '#define PHASED           0 // (B) Data are in correct phase (relevant for linkage model only)'."\n";
print OFH '#define PHASEINFO        0 // (B) the data for each individual contains a line'."\n";
print OFH '                                  indicating phase (linkage model)'."\n";
print OFH '#define MARKOVPHASE      0 // (B) the phase info follows a Markov model.'."\n";
print OFH '#define NOTAMBIGUOUS  -999 // (int) for use in some analyses of polyploid data'."\n";
close(OFH);

open(OFH, '>'.$structureExtraparamsFilename);
print OFH '#define NOADMIX          0'."\n";
print OFH '#define LINKAGE          0'."\n";
print OFH '#define USEPOPINFO       1'."\n";
print OFH '#define GENSBACK         0'."\n";
print OFH '#define PFROMPOPFLAGONLY 1'."\n";
print OFH '#define PRINTNET         1'."\n";
print OFH '#define PRINTQSUM        1'."\n";
close(OFH);


#invoke STRUCTURE? -- info for now...  No spawning of multiple threads at this point.
my $structureCommand = $structureBinaryLocation.' -m '.$structureMainparamsFilename.' -e '.$structureExtraparamsFilename.' -o '.$structureOutputFilename.' > '.$structureLogFilename;
if ($verbose)
{
    print "\nHead of ".$structureMainparamsFilename.":\n";
    open(IFH, $structureMainparamsFilename);
    for (my $i=0; $i<11; $i++)
    {
        my $line = readline(IFH);
        print $line;
    }
    close(IFH);
}
if ($invokeStructure)
{
    if ($verbose) { print "\nInvoking STRUCTURE ( at time() = ".time()." ) via: ".$structureCommand."\n\n"; }
    system $structureCommand;
}
else
{
    die("\nInvoke STRUCTURE via: ".$structureCommand."\n\n");
}

if ($verbose) { print "\nDone at time() = ".time()."\n"; }

