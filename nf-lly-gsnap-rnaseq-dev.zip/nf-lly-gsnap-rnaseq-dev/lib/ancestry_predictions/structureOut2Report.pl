use strict;
use warnings FATAL => 'all';

if (@ARGV != 1 and @ARGV != 2)
{
    print "SYNTAX: perl structureOut2Report.pl <structure-output-file> [original-to-structure-sample-id-mapping-file]\n";
    print "        -- OR --\n";
    print "        perl structureOut2Report.pl <start-time-for-both-structure-output-file-and-original-to-structure-sample-id-mapping-file>\n";
}
else
{
    if (@ARGV == 1)
    {
        if ($ARGV[0] =~ /^\d+(-\d+)?$/)
        {
            #remap the args
            my $startTime = $ARGV[0];
            $ARGV[0] = 'structure.outfile-'.$startTime.'_f';
            $ARGV[1] = 'structure.sampleIdMapping-'.$startTime;
        }
    }

    #load id mapping if needed
    my $remapIds = (@ARGV == 2);
    my %structureId2originalId;
    if ($remapIds)
    {
        open(IFH2, $ARGV[1]) or die('Could not read '.$ARGV[1]);
        my $header = readline(IFH2);
        while(<IFH2>)
        {
            chomp;
            my @fields = split("\t");
            $structureId2originalId{$fields[1]} = $fields[0];
        }
        close(IFH2);
    }

    #######################################
    #one sweep to get the expected popcount and extract pop labels
    my @popLabels;
    my $ifilename = $ARGV[0];
    open(IFH, $ifilename) or die('Could not read '.$ifilename);
    my $popCount;
    while(<IFH>)
    {
        if (/^   (\d+) populations assumed$/)
        {
            $popCount = $1;
            last;
        }
    }
    
    #build row-matching regexs
    my $dataRowParseRegex1 = '^[ ]*\d+[ ]+([^ ]+)[ ]+\((\d+)\)[ ]+(\d+)[ ]+\:[ ]+(\d\.\d+)[ ]+\|[ ]*'; #through the pipe after the highest-scoring group
    my $dataRowParseRegex2 = '^[ ]*\d+[ ]+([^ ]+)[ ]+\((\d+)\)[ ]+-1[ ]+\:[ ]+(\d\.\d+)[ ]+';
    for (my $i=1; $i<$popCount; $i++)
    {
        $dataRowParseRegex1 .= 'Pop[ ]+(\d+)\:[ ]+(\d\.\d+)[ ]*\|[ ]*';
        $dataRowParseRegex2 .= '(\d\.\d+)[ ]+';
    }
    $dataRowParseRegex1 .= '$';
    $dataRowParseRegex2 .= '$';

    while(<IFH>)
    {
        my $line = $_;
        if ( $line =~ $dataRowParseRegex1 )
        {
            my @sampleLabelComponents = split('_',$1);
            my $popLabel = $sampleLabelComponents[0];
            if (@popLabels == 0 or $popLabels[@popLabels-1] ne $popLabel)
            {
                push @popLabels, $popLabel;
            }
        }
        ##Thanks to the "small n" padding, we might encounter "unknown" synthetics (pad rows) interspersed with the "known" pop synthetics
        #elsif ( $line =~ $dataRowParseRegex2 )
        #{
        #    last;
        #}
    }

    close(IFH);
    if ($popCount == @popLabels)
    {
        print 'Found '.(0+@popLabels).' population labels: |'.join('|',@popLabels)."|\n";
    }
    else
    {
        die('Found wrong number of population labels -- expected '.$popCount.' but found '.(0+@popLabels).': |'.join('|',@popLabels)."|\n");
    }

    #######################################
    #one sweep to get the data of interest
    my $ofilename = $ifilename.'.txt';
    open(IFH, $ifilename) or die('Could not read '.$ifilename);

    open(OFH, '>'.$ofilename) or die('Could not write '.$ofilename);
    print OFH "SampleLabel\tMissingPercent";

    for (my $i=0; $i<$popCount; $i++)
    {
        print OFH "\t".$popLabels[$i];
    }
    print OFH "\tBestMatch\n";


    my $unknownCount = 0;
    my $alphaLine = 'No alpha value found in '.$ifilename.' !';
    my $alphaValue = 99.999; #anything greater than or equal to 0.1000 is FAILED (instead of SUCCEEDED)
    while(<IFH>)
    {
        my $line = $_;
        if ( $line =~ $dataRowParseRegex2 )
        {
            $unknownCount++;
            my $label = $1;
            my $percentMissingAlleles = $2;

            if ($remapIds)
            {
	    	if (not exists $structureId2originalId{$label})
		{
	            if ($label =~ /^pad.+_\d+$/)
		    {
		    	next; #skip "small n" padding
		    }
		    else
		    {
                        warn "Failed to remap label $label\n";
		    }
		}
		else
		{
                    $label = $structureId2originalId{$label};
		}
            }

            print OFH $label."\t".$percentMissingAlleles;
            my $score;
            my $bestScore=0;
            my $bestIdx;
            for (my $i=0; $i<$popCount; $i++)
            {
                $score = eval('$'.(3+$i));
                print OFH "\t".$score;
                if ($bestScore < $score)
                {
                    $bestScore = $score;
                    $bestIdx = $i;
                }
            }
            print OFH "\t".$popLabels[$bestIdx]."\n";
        }
        elsif ( $line =~ /^Mean value of alpha.+[=] (\d+\.\d+)/ )
        {
            $alphaLine = $line;
            $alphaValue = $1;
        }
    }

    close(IFH);
    close(OFH);

    print 'Done writing '.$ofilename.' -- Unknowns: '.$unknownCount."\n";

    $ofilename = $ifilename.'-ancestry_results_status.txt';
    open(OFH, '>'.$ofilename) or die('Could not write '.$ofilename);
    print OFH (($alphaValue<0.1000)?"SUCCEEDED":"FAILED"),"\t",$alphaLine,"\n";
    close(OFH);
    print 'Wrote run status summary to '.$ofilename."\n";
}
