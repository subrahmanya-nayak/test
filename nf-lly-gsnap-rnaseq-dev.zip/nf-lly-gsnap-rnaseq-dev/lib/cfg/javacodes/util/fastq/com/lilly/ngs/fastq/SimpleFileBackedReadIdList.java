package com.lilly.ngs.fastq;

/**
    The purpose of this util class is "simple"...  The naive approach to detecting duplicate read ids is to create a(n in-mem)
    hash/dictionary and wait for a key to be reused.  That's fine if you have a few thousand or maybe even a few hundred thousand,
    but it hits practical mem limits when you have tens to hundreds of millions.  The unix way would be to extract, sort, count
    uniq, sort by count, and then check the top of the stream for duplicates.
    
    Take a dead simple approach here...  Store the read id and line number in mem until <high-mem-consumption-condition>/<done-reading>
    On high-mem: Write sorted read ids (with line numbers) to a temp file, clear in-mem data structures, and do it all again till done reading
    When <done-reading>,
      No temp file:  already done!
      Temp files:
        open file handles to all tmp files and, ala insertion-sort, look at the "next" read id in each to watch for
        repeats. Dequeue the first read id (sort order), check, repeat...  When we're out of read ids to pop, we're out of the woods.  :-)
*/

    /*
        Runtime runtime = Runtime.getRuntime();
        System.out.println("  Max mem: "+runtime.maxMemory());
        System.out.println("Total mem: "+runtime.totalMemory());
        System.out.println(" Free mem: "+runtime.freeMemory());
    */


import java.util.*;
import java.io.*;


public class SimpleFileBackedReadIdList
{
    private TreeMap<String, Long> treemap = new TreeMap<String, Long>();

    private boolean autoDeleteTempFiles = true;
    private File tempDirectory = new File(System.getProperty("java.io.tmpdir"));
    private ArrayList<File> tempFiles = new ArrayList<File>();

    private long inMemReadCount = 0;  //not sure I want to trust that treemap.keySet().size() won't need non-trivial head room...
    private int readCountTrigger = 0; //rely on memory trigger if <= 0 (prefered mode!!!)

    private static Runtime runtime = Runtime.getRuntime();
    //try 1gb -- not really sure how much head room is needed to perform the I/O
    private long freeMemoryTrigger = 1*1024*1024*1024;


    public SimpleFileBackedReadIdList()
    {
    }

    public SimpleFileBackedReadIdList(String tempDirectory) throws IllegalArgumentException
    {
        this.tempDirectory = new File(tempDirectory);
        if (!this.tempDirectory.isDirectory()) { throw new IllegalArgumentException("Specified temp directory is not a directory: "+tempDirectory); }
        if (!this.tempDirectory.canRead())     { throw new IllegalArgumentException("Specified temp directory is not read-able: "+tempDirectory); }
        if (!this.tempDirectory.canWrite())    { throw new IllegalArgumentException("Specified temp directory is not write-able: "+tempDirectory); }
    }


    public Long addReadIdOrReportInMemoryCollision(String readId, long lineNumber) throws IOException
    {
        Long previousOccurenceLineNumber = null;
        if (treemap.containsKey(readId))
        {
            previousOccurenceLineNumber = treemap.get(readId);
        }
        else
        {
            treemap.put(readId, lineNumber);
            inMemReadCount++;
            persistChunkIfPrudent();
        }
        return previousOccurenceLineNumber;
    }


    public int getTempFileCount()
    {
        return tempFiles.size();
    }


    private void persistChunkIfPrudent() throws IOException
    {
        if ((readCountTrigger > 0 && inMemReadCount >= readCountTrigger) ||
            (SimpleFileBackedReadIdList.runtime.freeMemory() <= freeMemoryTrigger))
        {
            persistChunk();
        }
    }

    private void persistChunk() throws IOException
    {
        File newTempFile = File.createTempFile("ReadIdLocationChunk_", ".txt", tempDirectory);
        if (autoDeleteTempFiles) { newTempFile.deleteOnExit(); }
        tempFiles.add(newTempFile);

        BufferedWriter bw = new BufferedWriter(new FileWriter(newTempFile));
        Iterator<String> keyIterator = treemap.navigableKeySet().iterator();
        while (keyIterator.hasNext())
        {
            String readId = keyIterator.next();
            bw.write(readId);
            bw.write("\t");
            String lineNumberString = treemap.get(readId).toString();
            bw.write(lineNumberString);
            bw.write("\n");
        }
        treemap.clear();
        inMemReadCount = 0;
        bw.flush();
        bw.close();
        bw = null;

        runtime.gc();
    }


    public String findRepeatInfoForFirstRepeatedReadId() throws IOException
    {
        int tempFileCount = getTempFileCount();
        if (tempFileCount == 0)
        {
            //all the read ids fit in memory
            treemap = null;
            return null;
        }
        else
        {
            //simplify minimally by persisting all to file
            // also helps avoid potential mem issues by clearing the treemap to gain some head room
            if (inMemReadCount > 0)
            {
                persistChunk();
            }

            //open handles to all the temp files
            // and grab head from each (noting min read id for subsequent use...)
            String currentMinReadId = null;
            ArrayList<BufferedReader> brs = new ArrayList<BufferedReader>(tempFileCount);
            ArrayList<String> brsHeadReadId = new ArrayList<String>(tempFileCount);
            ArrayList<String> brsHeadReadLocation = new ArrayList<String>(tempFileCount);
            for (int i=0; i<getTempFileCount(); i++)
            {
                BufferedReader br = new BufferedReader(new FileReader(tempFiles.get(i)));
                brs.add(br);
                String line = br.readLine();
                String[] fields = line.split("\t");
                brsHeadReadId.add(fields[0]);
                brsHeadReadLocation.add(fields[1]);
                if (currentMinReadId == null || currentMinReadId.compareTo(fields[0]) > 0)
                {
                    currentMinReadId = fields[0];
                }
            }

            //count and consume for each currentMinReadId
            ArrayList<String> currentReadIdLocations = new ArrayList<String>(tempFileCount);
            while (brs.size() > 0)
            {
                currentReadIdLocations.clear();
                String nextMinReadId = null;
                for (int i=0; i<brs.size() && i>=0; i++)
                {
                    String currentFileHeadReadId = brsHeadReadId.get(i);
                    if (currentFileHeadReadId.equals(currentMinReadId))
                    {
                        currentReadIdLocations.add(brsHeadReadLocation.get(i));
                        //could break here if (currentReadIdLocations > 1) but it costs about the same to check all chunks
                        String line = brs.get(i).readLine();
                        if (line == null)
                        {
                            brs.get(i).close();
                            brs.remove(i);
                            brsHeadReadId.remove(i);
                            brsHeadReadLocation.remove(i);
                            i--;
                        }
                        else
                        {
                            String[] fields = line.split("\t");
                            brsHeadReadId.set(i, fields[0]);
                            brsHeadReadLocation.set(i, fields[1]);
                            if (nextMinReadId == null || nextMinReadId.compareTo(fields[0]) > 0)
                            {
                                nextMinReadId = fields[0];
                            }
                        }
                    }
                    else
                    {
                        if (nextMinReadId == null || nextMinReadId.compareTo(currentFileHeadReadId) > 0)
                        {
                            nextMinReadId = currentFileHeadReadId;
                        }
                    }
                }
                if (currentReadIdLocations.size() > 1)
                {
                    StringBuilder sb = new StringBuilder(currentMinReadId);
                    sb.append("\t");
                    sb.append(currentReadIdLocations.get(0).toString());
                    for (int i=1; i<currentReadIdLocations.size(); i++)
                    {
                        sb.append(",");
                        sb.append(currentReadIdLocations.get(i).toString());
                    }
                    return sb.toString();
                }
                currentMinReadId = nextMinReadId;
            }

            //exhausted -- apparently no collisions
            return null;
        }
    }


    public static void main(String[] args) throws Exception
    {
        if (args.length < 2)
        {
            System.out.println("SYNTAX: java SimpleFileBackedReadIdList <chunk-file1> <chunk-file2> [...]");
            System.out.println("        This main() is a simple test of the chunk-file reading logic.  Lines in the chunk files match /^[^\\t]+\\t[1-9][0-9]*$/");
        }
        else
        {
            SimpleFileBackedReadIdList readIds = new SimpleFileBackedReadIdList();
            for (int i=0; i<args.length; i++)
            {
                readIds.tempFiles.add(new File(args[i]));
            }
            String result = readIds.findRepeatInfoForFirstRepeatedReadId();
            if (result == null)
            {
                System.out.println("No collisions detected.");
            }
            else
            {
                System.out.println(result);
            }
        }
    }
}
