package com.lilly.ngs.fastq;

import java.util.regex.*;


/*
  -- From /lrlhps/apps/rnaseq/util/general_single_cell/prep_usual_fq.pl 2022-08-15 --
    my @read_id_reg_exes = (
        '^@[^:]+:\d+:(?<F>[^:]+):(?<L>\d+):\d+:\d+:\d+\s*',              #Current Illumina
        '^@\wRR\S+\s+[^:]+:\d+:(?<F>[^:]+):(?<L>\d+):\d+:\d+:\d+\s*',    #Current Illumina, after SRA
        '^@(?<F>[^:]+):(?<L>\d+):\d+:\d+\s*',                            #old Illumina
        '^@\wRR\S+\s+(?<F>[^:]+):(?<L>\d+):\d+:\d+\s*',                  #old Illumina, after sra
    );
*/

public class FastqRead
{
    private String rawTitleLine = null;
    private String readId = null;
    private String readDescription = null;
    private String rawReadBlock = null;
    private String readBlock = null;
    private String rawSeparatorLine = null;
    private String separatorLine = null;
    private String rawQualityBlock = null;
    private String qualityBlock = null;
    private boolean validityTested = false;
    private boolean validationPassed = false;
    private String firstValidationError = null;


    private static Pattern rawTitleLineParsingPattern  = Pattern.compile("^@([!-~]+)([ \\t]([\\t -~]*))?[\\r]?$");
    private static Pattern readIdPattern            = Pattern.compile("^[!-~]+$");
    private static Pattern readDescriptionPattern   = Pattern.compile("^[ \\t!-~]+$");
    private static Pattern readBlockPattern         = Pattern.compile("^[ATGCN]*$");
    private static Pattern qualityBlockPattern      = Pattern.compile("^[!-~]*$");



    //if fed raw only, only try to clean/validate on demand
    public FastqRead( String rawTitleLine,
                      String rawReadBlock,
                      String rawSeparatorLine,
                      String rawQualityBlock )
    {
        this.rawTitleLine = rawTitleLine;
        this.rawReadBlock = rawReadBlock;
        this.rawSeparatorLine = rawSeparatorLine;
        this.rawQualityBlock = rawQualityBlock;
    }


    //validate by default
    public FastqRead( String readId, String readDescription,
                      String readBlock,
                      String separatorLine,
                      String qualityBlock) throws IllegalArgumentException
    {
        this.rawTitleLine = "@"+readId+((readDescription == null)?"":" "+readDescription);
        this.readId = readId;
        this.readDescription = readDescription;
        this.rawReadBlock = this.readBlock = readBlock;
        this.rawSeparatorLine = this.separatorLine = separatorLine;
        this.rawQualityBlock = this.qualityBlock = qualityBlock;
        FastqRead.throwIfInvalid(this);
    }


    //but allow avoiding validation for performance if/when appropriate...
    public FastqRead( String readId, String readDescription,
                      String readBlock,
                      String separatorLine,
                      String qualityBlock,
                      boolean validate) throws IllegalArgumentException
    {
        this.rawTitleLine = "@"+readId+((readDescription == null)?"":" "+readDescription);
        this.readId = readId;
        this.readDescription = readDescription;
        this.rawReadBlock = this.readBlock = readBlock;
        this.rawSeparatorLine = this.separatorLine = separatorLine;
        this.rawQualityBlock = this.qualityBlock = qualityBlock;

        if (validate)
        {
            FastqRead.throwIfInvalid(this);
        }
    }


    //allow setting both raw and clean; validate...
    public FastqRead( String rawTitleLine, String readId, String readDescription,
                      String rawReadBlock, String readBlock,
                      String rawSeparatorLine, String separatorLine,
                      String rawQualityBlock , String qualityBlock) throws IllegalArgumentException
    {
        this.rawTitleLine = rawTitleLine;
        this.rawReadBlock = rawReadBlock;
        this.rawSeparatorLine = rawSeparatorLine;
        this.rawQualityBlock = rawQualityBlock;

        if (readId == null)           { throw new IllegalArgumentException( "readId cannot be null" );          }
        //(readDescription == null) is ok
        if (readBlock == null)        { throw new IllegalArgumentException( "readBlock cannot be null" );       }
        if (separatorLine == null)    { throw new IllegalArgumentException( "separatorLine cannot be null" );   }
        if (qualityBlock == null)     { throw new IllegalArgumentException( "qualityBlock cannot be null" );    }

        this.getReadId(); //populates both readId and readDescription from rawTitleLine
        //this.getReadDescription();
        if (!readId.equals(this.readId)) { throw new IllegalArgumentException("Raw readId and readId conflict"); }
        if (!readDescription.equals(this.readDescription)) { throw new IllegalArgumentException("Raw readDescription and readDescription conflict"); }

        this.getReadBlock();
        if (!readBlock.equals(this.readBlock)) { throw new IllegalArgumentException("Raw readBlock and readBlock conflict"); }

        this.getSeparatorLine();
        if (!"+".equals(this.separatorLine)) { throw new IllegalArgumentException("Malformed raw separatorLine"); }
        if (!"+".equals(separatorLine))      { throw new IllegalArgumentException("Malformed separatorLine"); }

        this.getQualityBlock();
        if (!qualityBlock.equals(this.qualityBlock)) { throw new IllegalArgumentException("Raw qualityBlock and qualityBlock conflict"); }

        //any additional test...  (like read-vs-quality length check)
        //  yeah, yeah...  This results in double testing.  That's part of the price of this constructor.
        FastqRead.throwIfInvalid(this);
    }


    //allow setting both raw and clean; validation optional...
    public FastqRead( String rawTitleLine, String readId, String readDescription,
                      String rawReadBlock, String readBlock,
                      String rawSeparatorLine, String separatorLine,
                      String rawQualityBlock , String qualityBlock,
                      boolean validate) throws IllegalArgumentException
    {
        this.rawTitleLine = rawTitleLine;
        this.rawReadBlock = rawReadBlock;
        this.rawSeparatorLine = rawSeparatorLine;
        this.rawQualityBlock = rawQualityBlock;

        if (validate)
        {
            if (readId == null)           { throw new IllegalArgumentException( "readId cannot be null" );          }
            //(readDescription == null) is ok
            if (readBlock == null)        { throw new IllegalArgumentException( "readBlock cannot be null" );       }
            if (separatorLine == null)    { throw new IllegalArgumentException( "separatorLine cannot be null" );   }
            if (qualityBlock == null)     { throw new IllegalArgumentException( "qualityBlock cannot be null" );    }

            this.getReadId(); //populates both readId and readDescription from rawTitleLine
            //this.getReadDescription();
            if (!readId.equals(this.readId)) { throw new IllegalArgumentException("Raw readId and readId conflict"); }
            if (!readDescription.equals(this.readDescription)) { throw new IllegalArgumentException("Raw readDescription and readDescription conflict"); }

            this.getReadBlock();
            if (!readBlock.equals(this.readBlock)) { throw new IllegalArgumentException("Raw readBlock and readBlock conflict"); }

            this.getSeparatorLine();
            if (!"+".equals(this.separatorLine)) { throw new IllegalArgumentException("Malformed raw separatorLine"); }
            if (!"+".equals(separatorLine))      { throw new IllegalArgumentException("Malformed separatorLine"); }

            this.getQualityBlock();
            if (!qualityBlock.equals(this.qualityBlock)) { throw new IllegalArgumentException("Raw qualityBlock and qualityBlock conflict"); }

            //any additional test...  (like read-vs-quality length check)
            //  yeah, yeah...  This results in double testing.  That's part of the price of this constructor.
            FastqRead.throwIfInvalid(this);
        }

        //making it this far should mean we're good
        this.readId = readId;
        this.readDescription = readDescription;
        this.readBlock = readBlock;
        this.separatorLine = separatorLine;
        this.qualityBlock = qualityBlock;
    }


    private static void throwIfInvalid(FastqRead fastqRead) throws IllegalArgumentException
    {
        if (fastqRead.validationPassed)
        {
            /* looked good when last checked apparently */
        }
        else if (!fastqRead.validityTested)
        {
            String firstValidationError = FastqRead.getFirstValidityErrorMessage(fastqRead);
            if (firstValidationError != null)
            {
                fastqRead.firstValidationError = firstValidationError;
                throw new IllegalArgumentException(firstValidationError);
            }
        }
        else if (fastqRead.firstValidationError != null)
        {
            throw new IllegalArgumentException(fastqRead.firstValidationError);
        }
        /* else it must be ok */
    }

    public static String getFirstValidityErrorMessage(FastqRead fastqRead)
    {
        //don't worry about thread safety for now...
        //return a string for the first encountered validation error
        fastqRead.validityTested = true;
    
        //jit parse raw to clean if required...
        if (fastqRead.readId == null || fastqRead.readDescription == null)
        {
            fastqRead.getReadId(); //populates both -- readDescription might stay null
            //fastqRead.getReadDescription();
        }
        if (fastqRead.readBlock == null)
        {
            fastqRead.getReadBlock();
        }
        if (fastqRead.separatorLine == null)
        {
            fastqRead.getSeparatorLine();
        }
        if (fastqRead.qualityBlock == null)
        {
            fastqRead.getQualityBlock();
        }

        //basic validation...
        if (fastqRead.readId == null)           { return "readId cannot be null";          }
        //(fastqRead.readDescription == null) is ok
        if (fastqRead.readBlock == null)        { return "readBlock cannot be null";       }
        if (fastqRead.separatorLine == null)    { return "separatorLine cannot be null";   }
        if (fastqRead.qualityBlock == null)     { return "qualityBlock cannot be null";    }

        //regex tests for readId, readDescription, readBlock, and qualityBlock
        if (!readIdPattern.matcher(fastqRead.readId).matches())                     { return "Malformed readId";          }
        if (fastqRead.readDescription != null &&
            !readDescriptionPattern.matcher(fastqRead.readDescription).matches())   { return "Malformed readDescription"; }
        if (!readBlockPattern.matcher(fastqRead.readBlock).matches())               { return "Malformed readBlock";       }
        if (!"+".equals(fastqRead.separatorLine))                                   { return "Malformed separatorLine";   }
        if (!qualityBlockPattern.matcher(fastqRead.qualityBlock).matches())         { return "Malformed qualityBlock";    }

        //length comparison for readBlock and qualityBlock
        if (fastqRead.readBlock.length() != fastqRead.qualityBlock.length()) { return "Read block and quality block must be the same length"; }

        //ignore the raws since there is not currently any way to unknowingly make them conflict
        
        fastqRead.validationPassed = true;

        //null --> successful validation
        return null;
    }

    public String getFirstValidityErrorMessage()
    {
        return FastqRead.getFirstValidityErrorMessage(this);
    }

    public boolean isValid()
    {
        if (!validityTested)
        {
            firstValidationError = getFirstValidityErrorMessage(this);
            validationPassed = (firstValidationError == null);
        }
        return validationPassed;
    }


    public static String getFirstRawNonStandardErrorMessage(FastqRead fastqRead)
    {
        //test "clean" version -- generates clean/standard form if absent
        String errorMessage = FastqRead.getFirstValidityErrorMessage(fastqRead);

        //then add tests to ensure raw matches clean
        if (errorMessage == null)
        {
            if (fastqRead.readDescription == null)
            {
                if (!fastqRead.rawTitleLine.equals("@"+fastqRead.readId))
                {
                    errorMessage = "Title line is not in standard form";
                }
            }
            else
            {
                if (!fastqRead.rawTitleLine.equals("@"+fastqRead.readId+" "+fastqRead.readDescription))
                {
                    errorMessage = "Title line is not in standard form";
                }
            }
        }
        if (errorMessage == null)
        {
            if (!fastqRead.rawReadBlock.equals(fastqRead.readBlock))
            {
                errorMessage = "Read block is not in standard form";
            }
        }
        if (errorMessage == null)
        {
            if (!fastqRead.rawSeparatorLine.equals(fastqRead.separatorLine))
            {
                errorMessage = "Separator line is not in standard form";
            }
        }
        if (errorMessage == null)
        {
            if (!fastqRead.rawQualityBlock.equals(fastqRead.qualityBlock))
            {
                errorMessage = "Quality block is not in standard form";
            }
        }

        return errorMessage;
    }

    public String getFirstRawNonStandardErrorMessage()
    {
        return FastqRead.getFirstRawNonStandardErrorMessage(this);
    }

    public boolean isInStandardForm()
    {
        return (FastqRead.getFirstRawNonStandardErrorMessage(this) == null);
    }
    

    public String getRawTitleLine()     { return rawTitleLine;      }
    public String getRawReadBlock()     { return rawReadBlock;      }
    public String getRawSeparatorLine() { return rawSeparatorLine;  }
    public String getRawQualityBlock()  { return rawQualityBlock;   }


    public String getReadTitleLine()
    {
        return "@"+readId+((readDescription == null)?"":" "+readDescription);
    }

    public String getReadId()
    {
        if (readId == null && rawTitleLine != null)
        {
            Matcher m = rawTitleLineParsingPattern.matcher(rawTitleLine);
            if (m.matches())
            {
                readId = m.group(1);
                readDescription = m.group(3); //might return null and that is allowed
            }
        }
        return readId;
    }


    public String getReadDescription()
    {
        if (readDescription == null && rawTitleLine != null)
        {
            Matcher m = rawTitleLineParsingPattern.matcher(rawTitleLine);
            if (m.matches())
            {
                readId = m.group(1);
                readDescription = m.group(3); //might return null and that is allowed
            }
        }
        return readDescription;
    }


    public String getReadBlock()
    {
        if (readBlock == null && rawReadBlock != null)
        {
            readBlock = rawReadBlock.toUpperCase().replaceAll("[^ATGCN]","");
        }
        return readBlock;
    }


    public String getSeparatorLine()
    {
        if (separatorLine == null && rawSeparatorLine != null && rawSeparatorLine.startsWith("+"))
        {
            separatorLine = "+";
        }
        return separatorLine;
    }


    public String getQualityBlock()
    {
        if (qualityBlock == null && rawQualityBlock != null)
        {
            qualityBlock = rawQualityBlock.replaceAll("[^!-~]","");
        }
        return qualityBlock;
    }


    public void setReadId(String newReadId)
    {
        readId = ((newReadId == null)?"":newReadId);
    }


    public void setReadBlock(String newReadBlock)
    {
        readBlock = ((newReadBlock == null)?"":newReadBlock);
    }


    public void setQualityBlock(String newQualityBlock)
    {
        qualityBlock = ((newQualityBlock == null)?"":newQualityBlock);
    }


    public String toString()
    {
        return getReadTitleLine()+"\n"+getReadBlock()+"\n+\n"+getQualityBlock()+"\n";
    }
}
