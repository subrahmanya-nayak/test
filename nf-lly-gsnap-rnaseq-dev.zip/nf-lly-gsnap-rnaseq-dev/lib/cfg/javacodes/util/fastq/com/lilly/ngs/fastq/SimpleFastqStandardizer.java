package com.lilly.ngs.fastq;

import java.io.*;
import java.security.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import com.lilly.ngs.util.*;



/*
    TODO: optional param to specify the filename suffix to strip (/\.f(ast)?q\.gz$/)
    TODO: optional param to set regex to strip from readIds (currently always /\/[1-4]$/)
*/



public class SimpleFastqStandardizer
{
    public static boolean areValidArgs(String[] args)
    {
        boolean validArgs = (args.length == 2); //till proven otherwise
        if (validArgs)
        {
            //try
            {
                File fqFile = new File(args[0]);
                if (!fqFile.isFile())
                {
                    validArgs = false;
                    System.out.println("ERROR: Specified fastq file is invalid: "+args[0]);
                }
                else if (!fqFile.exists())
                {
                    validArgs = false;
                    System.out.println("ERROR: Specified fastq file does not exist: "+args[0]);
                }
                else if (!fqFile.canRead())
                {
                    validArgs = false;
                    try
                    {
                        System.out.println("ERROR: Cannot read specified fastq file: "+fqFile.getCanonicalPath());
                    }
                    catch (IOException ioe)
                    {
                        System.out.println("ERROR: Cannot read specified fastq file -- inner exception: "+ioe.getMessage());
                    }
                }
                else if (!args[0].endsWith(".fq.gz") && !args[0].endsWith(".fastq.gz"))
                {
                    validArgs = false;
                    System.out.println("ERROR: Specified fastq filename ends neither with .fq.gz nor .fastq.gz: "+args[0]);
                }
            }
        }
        return validArgs;
    }


    private static String batchRegexsFilepath = null;
    private static String batchRegexsFilepathEnvVarName = "batchsep.regexs.absfilepath";

    public static void printSyntaxMessage()
    {
        System.out.println("SYNTAX: java "+ClassFindBinHelper.getCallingClassName()+" <input-.fq.gz> <output-.fq.gz>");
        System.out.println("        This simple utility immediately starts trying to read from the gzipped input fastq file and write a gzipped output fastq file.");
        System.out.println("        The input fastq file name MUST end in either .fq.gz or .fastq.gz");
        System.out.println();
        System.out.println("        All reads are written in standard form regardless of input formatting quirks:");
        System.out.println("            Four lines per read, read id and description separated by a space, any trailing <CR> characters trimmed, and only a + on the separator line");
        System.out.println("        If present, trailing suffixes (/1, /2, /3, or /4) will be trimmed from read ids");
        System.out.println();
    }


    public static void main(String[] args) throws Exception
    {
        batchRegexsFilepath = (new File(ClassFindBinHelper.findPathToClass(ClassFindBinHelper.getCallingClassName())+"DefaultBatchSeparationRegexs.txt")).getCanonicalPath();
        if (!areValidArgs(args))
        {
            printSyntaxMessage();
            System.exit(1);
        }
        else
        {
            batchRegexsFilepath = (System.getProperty(batchRegexsFilepathEnvVarName) == null)?batchRegexsFilepath:System.getProperty(batchRegexsFilepathEnvVarName);

            File ifqFile = new File(args[0]);
            File ofqFile = new File(args[1]);

            //open input file...
            FastqReader fqReader = new FastqReader(ifqFile.getCanonicalPath());
            FastqRead fqRead = null;
            // And the output file
            if (ofqFile.exists())
            {
                throw new IOException("Output file exists and will not be overwritten: "+ofqFile.getCanonicalPath());
            }
            BufferedWriter fqWriter = new BufferedWriter( new OutputStreamWriter(
                                                              new BufferedOutputStream(
                                                                  new GZIPOutputStream(
                                                                      new BufferedOutputStream(
                                                                          new FileOutputStream(ofqFile.getCanonicalPath()))))));

            try
            {
                while (1==1) //read reading loop...
                {
                    fqRead = fqReader.getNextRead();
                    if (fqRead == null)
                    {
                        //done reading
                        break;
                    }
                    else
                    {
                        //have a read from the fq
                        //  trim /1 /2 /3 /4 if found
                        String readId = fqRead.getReadId();
                        String trimmedReadId = readId.replaceAll("/[1-4]$","");
                        if (readId.length() != trimmedReadId.length())
                        {
                            fqRead.setReadId(trimmedReadId);
                        }

                        fqWriter.write(fqRead.toString());
                    }
                } //...read reading loop

                //looks like we're done...
                fqReader.close();
                fqWriter.close();
            }
            catch (Exception ex)
            {
                System.out.println("ERROR: An unexpected exception occurred");

                //try to clean up...
                try{ fqReader.close(); } catch (Exception ex2) {}
                try{ fqWriter.close(); } catch (Exception ex2) {}
                try { ofqFile.delete(); } catch (Exception ex2) {}

                throw ex; //which sets a non-zero exit status
            }
        }
    }
}
