package com.lilly.ngs.fastq;

import java.io.*;
import java.security.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import com.lilly.ngs.util.*;



/*
    TODO: optional param to specify the filename suffix to strip (/\.f(ast)?q\.gz$/)
    TODO: optional param to set regex to strip from readIds (currently always /\/[1-4]$/)
*/



public class SimpleOptimisticBatchSeparator
{
    public static boolean areValidArgs(String[] args)
    {
        boolean validArgs = (args.length == 4 || args.length == 5); //till proven otherwise
        if (validArgs)
        {
            //try
            {
                File fqFile = new File(args[0]);
                if (!fqFile.isFile())
                {
                    validArgs = false;
                    System.out.println("ERROR: Specified fastq file is invalid: "+args[0]);
                }
                else if (!fqFile.exists())
                {
                    validArgs = false;
                    System.out.println("ERROR: Specified fastq file does not exist: "+args[0]);
                }
                else if (!fqFile.canRead())
                {
                    validArgs = false;
                    try
                    {
                        System.out.println("ERROR: Cannot read specified fastq file: "+fqFile.getCanonicalPath());
                    }
                    catch (IOException ioe)
                    {
                        System.out.println("ERROR: Cannot read specified fastq file -- inner exception: "+ioe.getMessage());
                    }
                }
                else if (!args[0].endsWith(".fq.gz") && !args[0].endsWith(".fastq.gz"))
                {
                    validArgs = false;
                    System.out.println("ERROR: Specified fastq filename ends neither with .fq.gz nor .fastq.gz: "+args[0]);
                }
            }
            if (!"1".equals(args[1]) && !"2".equals(args[1]) && !"3".equals(args[1]) && !"4".equals(args[1]))
            {
                validArgs = false;
                System.out.println("ERROR: Invalid read number: "+args[1]);
            }
            if (!args[2].equals("flowcell") && !args[2].equals("flowcell-lane"))
            {
                validArgs = false;
                System.out.println("ERROR: Invalid separation type: "+args[2]);
            }
            //try
            {
                File outputDir = new File(args[3]);
                if (!outputDir.isDirectory())
                {
                    validArgs = false;
                    System.out.println("ERROR: Specified output directory is invalid: "+args[3]);
                }
                else if (!outputDir.exists())
                {
                    validArgs = false;
                    System.out.println("ERROR: Specified output directory does not exist: "+args[3]);
                }
                else if (!outputDir.canWrite())
                {
                    validArgs = false;
                    try
                    {
                        System.out.println("ERROR: Cannot write to specified output directory: "+outputDir.getCanonicalPath());
                    }
                    catch (IOException ioe)
                    {
                        System.out.println("ERROR: Cannot write to specified output directory -- inner exception: "+ioe.getMessage());
                    }
                }
            }
            if (args.length == 5)
            {
                if (!"FORCE_WRITE".equals(args[4]))
                {
                    validArgs = false;
                    System.out.println("ERROR: Found "+args[4]+" but expected FORCE_WRITE");
                }
            }
        }
        return validArgs;
    }


    private static String batchRegexsFilepath = null;
    private static String batchRegexsFilepathEnvVarName = "batchsep.regexs.absfilepath";

    public static void printSyntaxMessage()
    {
        System.out.println("SYNTAX: java "+ClassFindBinHelper.getCallingClassName()+" <input-fastq-readN.fq.gz> <read-number> <separation-type> <output-directory> [FORCE_WRITE]");
        System.out.println("        This simple utility immediately starts trying to batch separate the gzipped input fastq file, based on the optimistic assumption that there will be no issues");
        System.out.println("        The input fastq file name MUST end in either .fq.gz or .fastq.gz");
        System.out.println("        The read number is expected to be either 1 or 2 but may also be 3 or 4");
        System.out.println("        The separation-type must be either \"flowcell\" or \"flowcell-lane\"  (typically, \"flowcell-lane\")");
        System.out.println();
        System.out.println("        NOTE: Reading the fastq file forces verification that the gzip file is intact and that each read is complete and properly formatted");
        System.out.println("              No other validation of any kind is performed, but, without FORCE_WRITE, attempting to open existing output files will throw an exception!");
        System.out.println();
        System.out.println("        Batch information extraction regexs will be read from "+batchRegexsFilepath);
        System.out.println("        (Set environment variable "+batchRegexsFilepathEnvVarName+" to override)");
        System.out.println();
        System.out.println("        For \"some.fq.gz\", output file names will match one of the following three forms:");
        System.out.println("            some__batch_<FLOWCELL>_<LANE>_read<read-number>.fq.gz");
        System.out.println("            some__batch_<FLOWCELL>_read<read-number>.fq.gz");
        System.out.println("            some__NOBATCH_read<read-number>.fq.gz");
        System.out.println();
        System.out.println("        All reads are written in standard form regardless of input formatting quirks:");
        System.out.println("            Four lines per read, read id and description separated by a space, any trailing <CR> characters trimmed, and only a + on the separator line");
        System.out.println("        If present, trailing suffixes (/1, /2, /3, or /4) will be trimmed from read ids");
        System.out.println();
    }


    public static void main(String[] args) throws Exception
    {
        batchRegexsFilepath = (new File(ClassFindBinHelper.findPathToClass(ClassFindBinHelper.getCallingClassName())+"DefaultBatchSeparationRegexs.txt")).getCanonicalPath();
        if (!areValidArgs(args))
        {
            printSyntaxMessage();
            System.exit(1);
        }
        else
        {
            batchRegexsFilepath = (System.getProperty(batchRegexsFilepathEnvVarName) == null)?batchRegexsFilepath:System.getProperty(batchRegexsFilepathEnvVarName);

            File fqFile = new File(args[0]);
            String readNbr = args[1];
            String batchSeparationType = args[2];
            File outputDir = new File(args[3]);
            boolean forceWrite = ( args.length==5 && "FORCE_WRITE".equals(args[4]) );

            //load up the regexs file...
            int batchSeparationTypeInt = (("flowcell-lane".equals(batchSeparationType))?1:2);
            NamedGroupRegexHelper regexHelper = new NamedGroupRegexHelper(batchRegexsFilepath, 1);
            ArrayList<Pattern> batchInfoRegexs = regexHelper.getPatternsMatchingNamedGroupsSet(((batchSeparationTypeInt==1)?new String[]{"FLOWCELL","LANE"}:new String[]{"FLOWCELL"}));
            regexHelper = null;


            /////////////////////////////////////////////////////////////////////////
            //so far, so good...
            /////////////////////////////////////////////////////////////////////////


            //open input file...
            FastqReader fqReader = new FastqReader(fqFile.getCanonicalPath());
            FastqRead fqRead = null;
            // and prep for output files...  hash on batch to output fq.gz
            String ofileNamePrefix = (outputDir.getAbsolutePath()+File.separator+fqFile.getName()).replaceAll("\\.f(ast)?q\\.gz$","");
            ArrayList<String> ofileNames = new ArrayList<String>(); //in case of an exception, make it easier to try to clean up
            Hashtable<String, BufferedWriter> fqBatchWriters = new Hashtable<String, BufferedWriter>();


            //  ~38min for ~49M reads SE to read, reformat and separate, and write compressed
            //  Almost identical time and size to write uncompressed and then use command-line gzip
            //  but more manual/overhead if the gzip runs later
            //  (looks like gzip produce files 99.9% the size when run separately...  Not a meaningful gain)
            try
            {
                while (1==1) //read reading loop...
                {
                    fqRead = fqReader.getNextRead();
                    if (fqRead == null)
                    {
                        //done reading
                        break;
                    }
                    else
                    {
                        //have a read from the fq
                        //  trim /1 /2 /3 /4 if found
                        String readId = fqRead.getReadId();
                        String trimmedReadId = readId.replaceAll("/[1-4]$","");
                        if (readId.length() != trimmedReadId.length())
                        {
                            fqRead.setReadId(trimmedReadId);
                        }

                        //determine the batch id...
                        String readTitleLine = fqRead.getReadTitleLine();
                        String batchId = "__NOBATCH";
                        for (int i=0; i<batchInfoRegexs.size(); i++)
                        {
                            Matcher m = batchInfoRegexs.get(i).matcher(readTitleLine);
                            if (m.find())
                            {
                                String flowcellMatch = m.group("FLOWCELL");
                                if (flowcellMatch != null && flowcellMatch.length() > 0)
                                {
                                    //had this rolled outside the read/write loop, but the few % in extra overhead is worth not doubling the code
                                    if (batchSeparationTypeInt == 1) //flowcell-lane
                                    {
                                        String laneMatch = m.group("LANE");
                                        if (laneMatch != null && laneMatch.length() > 0)
                                        {
                                            //found a regex with a match -- move it to the top of the list
                                            if (i != 0)
                                            {
                                                Pattern matchedPattern = batchInfoRegexs.remove(i);
                                                batchInfoRegexs.add(0, matchedPattern);
                                            }
                                            batchId = "__batch_"+flowcellMatch+"_"+laneMatch;
                                            break;
                                        }
                                    }
                                    else //flowcell
                                    {
                                        //found a regex with a match -- move it to the top of the list
                                        if (i != 0)
                                        {
                                            Pattern matchedPattern = batchInfoRegexs.remove(i);
                                            batchInfoRegexs.add(0, matchedPattern);
                                        }
                                        batchId = "__batch_"+flowcellMatch;
                                        break;
                                    }
                                }
                            }
                        }

                        // open a file if necessary
                        if (!fqBatchWriters.containsKey(batchId))
                        {
                            String ofileName = ofileNamePrefix+batchId+"_read"+readNbr+".fq.gz";
                            if (!forceWrite && (new File(ofileName)).exists())
                            {
                                throw new IOException("Output file exists and will not be overwritten: "+ofileName);
                            }
                            BufferedWriter readOutWriter = new BufferedWriter(
                                                            new OutputStreamWriter(
                                                                new BufferedOutputStream(
                                                                    new GZIPOutputStream(
                                                                        new BufferedOutputStream(
                                                                            new FileOutputStream(ofileName))))));
                            fqBatchWriters.put(batchId, readOutWriter);
                            ofileNames.add(ofileName);
                        }

                        //we have a batch id and open file handle(s), so write the read
                        fqBatchWriters.get(batchId).write(fqRead.toString());
                    }
                } //...read reading loop

                //looks like we're done...
                fqReader.close();
                for (Enumeration<String> batchEnum = fqBatchWriters.keys(); batchEnum.hasMoreElements(); )
                {
                    fqBatchWriters.get(batchEnum.nextElement()).close();
                }
            }
            catch (Exception ex)
            {
                System.out.println("ERROR: An unexpected exception occurred");

                //try to clean up...
                try{ fqReader.close(); } catch (Exception ex2) {}
                if (fqBatchWriters != null)
                {
                    for (Enumeration<String> batchEnum = fqBatchWriters.keys(); batchEnum.hasMoreElements(); )
                    {
                        try{ fqBatchWriters.get(batchEnum.nextElement()).close(); } catch (Exception ex2) {}
                    }
                }
                if (ofileNames != null)
                {
                    for (int i=0; i<ofileNames.size(); i++)
                    {
                        try { (new File(ofileNames.get(i))).delete(); } catch (Exception ex2) {}
                    }
                }

                throw ex; //which sets a non-zero exit status
            }
        }
    }
}
