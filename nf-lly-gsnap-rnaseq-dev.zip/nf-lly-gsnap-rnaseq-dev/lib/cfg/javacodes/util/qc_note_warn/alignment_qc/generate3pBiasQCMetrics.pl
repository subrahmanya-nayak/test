#!/bin/env perl
#
#===============================================================================
#
#         FILE:  generate3pBiasQCMetrics.pl
#
#  DESCRIPTION:
#                Goal:  Wrapper and helper for generating 3p bias QC metrics
#                       
#
#        FILES:  ---
#         BUGS:  ---
#        NOTES:  ---
#       AUTHOR:  James E Scherschel (jes), <js@lilly.com>
#      COMPANY:  Eli Lilly & Co.
#      VERSION:  1.0
#      CREATED:  ---
#     REVISION:  ---
# Revision History:
#   0.02 John Calley 1/24/2020
#     --Moved java location to track recent HPC change
#   0.01 James Scherschel 7/12/2018
#     --Initial check-in...
#===============================================================================

use strict;
use warnings FATAL => 'all'; # FATAL => 'all';
use Getopt::Std;
use File::Basename;

use FindBin;


our %opts; #v/s:verbose/silent; r:results-root-dir; i:input-file; o:output-file; j:java-executable
getopts('vsr:i:o:j:', \%opts);


#defaults
my $verbose = 0;
my $resultsRootDir = '.';
my $ifile = './alignment_QC/sample_slope_density.txt';
my $ofile = './expression_qc/alignment/assay3pBiasQCMetrics.txt';
my $javaExecutable = '/usr/bin/java';
my $javaClassDir = $FindBin::Bin;


sub areValidArgs
{
    my $validArgs = (@ARGV == 0 and (0+(keys %opts))>0)?1:0;

    if ($validArgs == 1)
    {
        my $resultsRootDir = $resultsRootDir;
        if (exists $opts{'r'})
        {
            if (-d $opts{'r'})
            {
                if (-r $opts{'r'})
                {
                    $resultsRootDir = $opts{'r'};
                }
                else
                {
                    warn "Cannot read directory: $opts{'r'} \n";
                    $validArgs = 0;
                }
            }
            else
            {
                warn "Not a directory: $opts{'r'} \n";
                $validArgs = 0;
            }
        }

        if ($validArgs == 1)
        {
            if (exists $opts{'i'})
            {
                if ($opts{'i'} =~ /^\.\//)
                {
                    if (not -r $resultsRootDir.$opts{'i'})
                    {
                        warn "Cannot read specified input file: $resultsRootDir$opts{'i'}\n";
                        $validArgs = 0;
                    }
                }
                else
                {
                    if (not -r $opts{'i'})
                    {
                        warn "Cannot read specified input file: $opts{'i'}\n";
                        $validArgs = 0;
                    }
                }
            }
            else
            {
                if (not -r $resultsRootDir.'/'.$ifile)
                {
                    warn "Cannot read input file: ".$resultsRootDir.'/'.$ifile."\n";
                    $validArgs = 0;
                }
            }
        }

        if (exists $opts{'j'} and not -r $opts{'j'})
        {
            warn "Cannot find specified java executable: $opts{'j'}\n";
            $validArgs = 0;
        }
    }
    return $validArgs;
}


if (@ARGV != 0 or areValidArgs() != 1)
{
    die "\n".
        "SYNTAX:  perl $0 [-v] [-s] [-r <results-root-dir>] [-i <slope-density-file>] [-o <3p-bias-metrics-output-file>] [-j <java-executable>]\n".
        "\n".
        "        Options:\n".
        "            -s specifies \"silent\" ".(($verbose==0)?'(default: silent)':'')."\n".
        "            -v specifies \"verbose\" and supersedes -s ".(($verbose==1)?'(default: verbose)':'')."\n".
        "            -r results root directory (default: $resultsRootDir) \n".
        "            -i combined fastx file (default: $ifile) \n".
        "            -o output QC metrics file (default: $ofile) \n".
        "            -j java executable (default: $javaExecutable) \n".
        "\n".
        "        Notes:\n".
        "            At least one option must be set. \n".
        "            -i/-o will be treated as relative to <results-root-directory> if it matches /^\\.\\// \n".
        "\n";
}


#Applying params over defaults...
if (exists $opts{'r'}) { $resultsRootDir = $opts{'r'}; }
if ($resultsRootDir !~ /\/$/) { $resultsRootDir = $resultsRootDir.'/'; }
if (exists $opts{'i'}) { $ifile = $opts{'i'}; }
if ($ifile =~ /^\.\//) { $ifile = $resultsRootDir.$ifile; }
if (exists $opts{'o'}) { $ofile = $opts{'o'}; }
if ($ofile =~ /^\.\//) { $ofile = $resultsRootDir.$ofile; }
if (exists $opts{'j'}) { $javaExecutable = $opts{'j'}; }
if (exists $opts{'s'}) { $verbose = 0; }
if (exists $opts{'v'}) { $verbose = 1; }


#create directories and set permissions...
my $outputDir = dirname($ofile);
if (not -d $outputDir)
{
    my @nonexistentDirs = ($outputDir);
    while (not -d $nonexistentDirs[0])
    {
        unshift @nonexistentDirs, dirname($nonexistentDirs[0]);
    }
    shift @nonexistentDirs;
    foreach my $dirToCreate (@nonexistentDirs)
    {
        system "mkdir ".(($verbose == 1)?'-v':'')." $dirToCreate";
        system "chown ".(($verbose == 1)?'-v':'')." :bioinfo-unxgds $dirToCreate";
        system "chmod ".(($verbose == 1)?'-v':'')." 775 $dirToCreate";
    }
}
die("Output directory does not exist or is not writeable: $outputDir \n") if (not -d $outputDir or not -w $outputDir);


#call the java calculator
my $cmd = $javaExecutable.' -cp '.$javaClassDir.' Sample3pBiasQCMetricsCalculator '.$ifile.' QC_METRICS '.$ofile;
if ($verbose == 1) { print "Executing: $cmd \n"; }
system $cmd;


#final output file permissions set
system 'chown '.(($verbose == 1)?'-v ':'').':bioinfo-unxgds '.$ofile;
system 'chmod '.(($verbose == 1)?'-v ':'').'664 '.$ofile;





