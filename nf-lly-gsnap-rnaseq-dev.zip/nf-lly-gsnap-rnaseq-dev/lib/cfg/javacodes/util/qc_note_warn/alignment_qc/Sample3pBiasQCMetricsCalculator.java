import java.io.*;
import java.util.*;
import java.text.*;
import java.util.concurrent.Semaphore;
import java.awt.Point;


public class Sample3pBiasQCMetricsCalculator implements Runnable
{
    public static boolean DEBUG = true;
    private static String MODE_QC_METRICS = "QC_METRICS";
    private static String MODE_PAIRWISE_DIST = "PAIRWISE_DIST";


    //To hold the single in-memory copy of the sample slope density data for all calculations...
    private static ArrayList<String> sampleIds = new ArrayList<String>();
    private static HashMap<String,double[]> sampleToSlopes = new HashMap<String,double[]>();
    private static HashMap<String,double[]> sampleToDensities = new HashMap<String,double[]>();


    //for multi-threaded pairwise distance calculations
    private static int PD_THREAD_COUNT_LIMIT = 100;
    private static int pdThreadCount = 10; //default -- will be reduced to at most i threads.  For simplicity, pairs will be split ONLY by index i
    private static Semaphore pdThreadsSemaphore;
    private static int pdSampleCount=-1, pdNextIIdx=0, pdNextJIdx=1;
    private static BufferedWriter pdBW;
    private static synchronized void synchronizedWriteln(BufferedWriter bw, String line) throws Exception
    {
        bw.write(line);
        bw.newLine();
    }
    private static synchronized Point getNextPairIdxs()
    {
        Point idxPair = new Point(-1, -1); //"done" point
        if (pdSampleCount < 2)
        {
            System.out.println("Fewer than two samples!");
        }
        else if (pdNextIIdx == -1)
        {
            //nothing to do -- we're already done!
        }
        else
        {
            idxPair.setLocation(pdNextIIdx, pdNextJIdx++);
            if (pdNextJIdx >= pdSampleCount)
            {
                pdNextIIdx++;
                if (pdNextIIdx >= (pdSampleCount-1))
                {
                    pdNextIIdx = pdNextJIdx = -1;
                }
                else
                {
                    pdNextJIdx = pdNextIIdx+1;
                }
            }
        }
        return(idxPair);
    }

    private static void SyntaxExit()
    {
        System.out.println("SYNTAX: java Sample3pBiasQCMetricsCalculator <sample-slope-density-file> <mode> (<3p-bias-QC-metrics> | (<output-file-prefix> [parallel-thread-count]))");
        System.out.println("        The sample slope density file is typically <results-root-dir>/alignment_QC/sample_slope_density.txt ");
        System.out.println("        The two valid modes are: "+MODE_QC_METRICS+" and "+MODE_PAIRWISE_DIST);
        System.out.println("        In "+MODE_QC_METRICS+" mode, per \"sample\" from the sample slope density file, the following are calculated:");
        System.out.println("            calculates the mean slope, stddev of the slope (about the calculated mean), stddev of the slope (about fixed mean=0),");
        System.out.println("            skewness, and, between the actual data and normal(0, stddev about 0), the mean SSE and absolute area between.");
        System.out.println("            3p-bias-QC-metrics would typically be <results-root-dir>/expression_qc/alignment/assay3pBiasQCMetrics.txt");
        System.out.println("        In "+MODE_PAIRWISE_DIST+" mode, two files will be written:");
        System.out.println("            <output-file-prefix>_idx2id.txt and <output-file-prefix>_pairwise-distance.txt");
        System.out.println("            The distance metric reported is the estimated absolute area between the pair of curves.");
        System.out.println("            The default parallel-thread-count is "+pdThreadCount);
        System.out.println();
        System.exit(0);
    }

    public static void main(String[] args) throws Exception
    {
        if (args.length < 3 ||
            !(MODE_QC_METRICS.equals(args[1]) || MODE_PAIRWISE_DIST.equals(args[1])) ||
            (MODE_QC_METRICS.equals(args[1]) && args.length != 3) ||
            (MODE_PAIRWISE_DIST.equals(args[1]) && args.length > 4) )
        {
            SyntaxExit();
        }
        String ssdFile = args[0];
        String mode = args[1];
        String metricsFile = null, outputFilePrefix = null;
        if (MODE_QC_METRICS.equals(mode))
        {
            metricsFile = args[2];
        }
        else if (MODE_PAIRWISE_DIST.equals(mode))
        {
            outputFilePrefix = args[2];
            if (args.length >= 4)
            {
                pdThreadCount = Integer.parseInt(args[3]);
                if (pdThreadCount > PD_THREAD_COUNT_LIMIT)
                {
                    pdThreadCount = PD_THREAD_COUNT_LIMIT;
                    System.out.println("Pairwise distance thread count truncated to "+pdThreadCount);
                }
            }
        }


        //Load data for ALL samples into memory
        // This is janky, but it's about as tight as I see being able to make it
        if (DEBUG) { System.out.println("Loading all sample slope density data from "+ssdFile+" ..."); }
        {
            BufferedReader br = new BufferedReader(new FileReader(ssdFile));
            int lineNbr = 0;
            String line = br.readLine(); lineNbr++;
            if (!"sample\tslopes\tdensity".equals(line))
            {
                System.out.println("Unexpected header line: "+line);
                System.exit(0);
            }
            ArrayList<String[]> sampleLineFields = new ArrayList<String[]>();
            String currentSampleId = null;
            while ((line = br.readLine()) != null)
            {
                lineNbr++;
                if (line.length() > 0)
                {
                    String[] lineFields = line.split("\t");
                    if (lineFields.length != 3)
                    {
                        System.out.println("Unexpected format on line #"+lineNbr+": "+line);
                        System.exit(0);
                    }
                    if (lineFields[0].equals(currentSampleId))
                    {
                        sampleLineFields.add(lineFields);
                    }
                    else
                    {
                        if (sampleLineFields.size() > 0)
                        {
                            //should have a full set of slopes and densities for the sample
                            sampleIds.add(currentSampleId);
                            // convert the line fields to the pair of double[]
                            int slopeCount = sampleLineFields.size();
                            if (slopeCount < 3)
                            {
                                System.out.println("Only found "+slopeCount+" slope"+((slopeCount==1)?"":"s")+" for sample "+currentSampleId+" (near line #"+lineNbr+")");
                                System.exit(0);
                            }
                            double[] slopes = new double[slopeCount];
                            double[] densities = new double[slopeCount];
                            for (int i=0; i<slopeCount; i++)
                            {
                                slopes[i] = Double.parseDouble(sampleLineFields.get(i)[1]);
                                densities[i] = Double.parseDouble(sampleLineFields.get(i)[2]);
                            }
                            sampleToSlopes.put(currentSampleId, slopes);
                            sampleToDensities.put(currentSampleId, densities);
                        }
                        sampleLineFields.clear();
                        //update current and add this first line
                        currentSampleId = lineFields[0];
                        sampleLineFields.add(lineFields);
                    }
                }
            }
            br.close();
            //handle the last sample?
            if (sampleLineFields.size() > 0)
            {
                //should have a full set of slopes and densities for the sample
                sampleIds.add(currentSampleId);
                // convert the line fields to the pair of double[]
                int slopeCount = sampleLineFields.size();
                if (slopeCount < 3)
                {
                    System.out.println("Only found "+slopeCount+" slope"+((slopeCount==1)?"":"s")+" for sample "+currentSampleId+" (near line #"+lineNbr+")");
                    System.exit(0);
                }
                double[] slopes = new double[slopeCount];
                double[] densities = new double[slopeCount];
                for (int i=0; i<slopeCount; i++)
                {
                    slopes[i] = Double.parseDouble(sampleLineFields.get(i)[1]);
                    densities[i] = Double.parseDouble(sampleLineFields.get(i)[2]);
                }
                sampleToSlopes.put(currentSampleId, slopes);
                sampleToDensities.put(currentSampleId, densities);
            }
        }
        if (DEBUG) { System.out.println("Loaded all sample slope density data (for "+sampleIds.size()+" sample"+((sampleIds.size() == 1)?"":"s")+") from "+ssdFile); }


        if (MODE_QC_METRICS.equals(mode))
        {
            //mean slope, stddev of the slope (about the calculated mean), stddev of the slope (about fixed mean=0), skewness
            // AND, between the actual data and normal(0, stddev about 0), the mean SSE and absolute area
            if (DEBUG) { System.out.println("Calculating QC metrics and writing to "+metricsFile+" ..."); }
            {
                BufferedWriter bw = new BufferedWriter(new FileWriter(metricsFile, false));
                bw.write("AssayID\tMeanSlope\tStdDev\tStdDevAboutZero\tSkewness\tSkewnessAboutZero\tMeanSSEFromNormalCenteredAtZero\tMaxAbsDiffFromNormalCenteredAtZero\tAbsAreaDiffFromNormalCenteredAtZero");
                bw.newLine();
                DecimalFormat df2 = new DecimalFormat("0.00####");
                for (int i=0; i<sampleIds.size(); i++)
                {
                    String sampleId = sampleIds.get(i);
                    double[] slopes = sampleToSlopes.get(sampleId);
                    double[] densities = sampleToDensities.get(sampleId);
                    int slopeCount = slopes.length;

                    //weighted mean
                    double meanSlope = 0.0;
                    double cummDensity = 0.0; //this is 1.000 +/-, so, really, this is overkill...
                    for (int j=0; j<slopeCount; j++)
                    {
                        meanSlope += densities[j]*slopes[j];
                        cummDensity += densities[j];
                    }
                    meanSlope /= cummDensity;

                    //weighted stddev (about the mean and about zero)
                    double stddev = 0.0;
                    double stddevAbout0 = 0.0;
                    for (int j=0; j<slopeCount; j++)
                    {
                        stddev += densities[j]*Math.pow(slopes[j]-meanSlope,2);
                        stddevAbout0 += densities[j]*slopes[j]*slopes[j];
                    }
                    stddev = Math.pow(stddev / ((slopeCount-1)*cummDensity/slopeCount), 0.5);
                    stddevAbout0 = Math.pow(stddevAbout0 / ((slopeCount-1)*cummDensity/slopeCount), 0.5);

                    //skewness (i.e., Pearson's moment coefficient of skewness)
                    double skewness = 0.0;
                    double skewnessAbout0 = 0.0;
                    for (int j=0; j<slopeCount; j++)
                    {
                        skewness += densities[j]*Math.pow(slopes[j]-meanSlope,3);
                        skewnessAbout0 += densities[j]*Math.pow(slopes[j],3);
                    }
                    skewness = skewness/cummDensity/Math.pow(stddev,3);
                    skewnessAbout0 = skewnessAbout0/cummDensity/Math.pow(stddevAbout0,3);

                    //normal dist data...
                    // pseudo-scale AUC to one like the densities for the sample's slopes
                    double normScale = (1.0/Math.sqrt(2*Math.PI*stddevAbout0*stddevAbout0));
                    double[] normalDistSlopeDensities = new double[slopeCount];
                    double varianceAbout0 = stddevAbout0*stddevAbout0;
                    for (int j=0; j<slopeCount; j++)
                    {
                        normalDistSlopeDensities[j] = normScale*Math.exp(-Math.pow(slopes[j],2) / (2*varianceAbout0));
                    }

                    //mean SSE
                    double meanSSE = 0.0;
                    for (int j=0; j<slopeCount; j++)
                    {
                        meanSSE += Math.pow(densities[j]-normalDistSlopeDensities[j],2);
                    }
                    meanSSE /= slopeCount;

                    //maxAbsDiff
                    double maxAbsDiff = 0.0;
                    for (int j=0; j<slopeCount; j++)
                    {
                        double absDiff = Math.abs(densities[j]-normalDistSlopeDensities[j]);
                        maxAbsDiff = (maxAbsDiff>absDiff)?maxAbsDiff:absDiff;
                    }

                    //area between curves
                    double areaFromNormal = calculateAreaBetweenCurves(slopes, densities, slopes, normalDistSlopeDensities);

                    bw.write(sampleId+"\t"+df2.format(meanSlope)+"\t"+df2.format(stddev)+"\t"+df2.format(stddevAbout0)+"\t"+
                             df2.format(skewness)+"\t"+df2.format(skewnessAbout0)+"\t"+df2.format(meanSSE)+"\t"+df2.format(maxAbsDiff)+"\t"+
                             df2.format(areaFromNormal));
                    bw.newLine();
                }
                bw.close();
                if (DEBUG) { System.out.println("Wrote "+metricsFile); }
            }
        }

        if (MODE_PAIRWISE_DIST.equals(mode))
        {
            //we don't really need this, but it does no harm and seems reasonable...
            if (pdThreadCount >= sampleIds.size()/2)
            {
                pdThreadCount = sampleIds.size()/2;
                if (DEBUG) { System.out.println("Reduced parallel thread count (based on sample count) to "+pdThreadCount); }
            }

            String idxToIdFile = outputFilePrefix+"_idx2id.txt";
            if (DEBUG) { System.out.println("Writing index-to-id mapping to "+idxToIdFile+" ..."); }
            BufferedWriter bw = new BufferedWriter(new FileWriter(idxToIdFile, false));
            bw.write("Index\tAssayID");
            bw.newLine();
            for (int i=0; i<sampleIds.size(); i++)
            {
                String sampleId = sampleIds.get(i);
                bw.write(i+"\t"+sampleId);
                bw.newLine();
            }
            bw.close();
            if (DEBUG) { System.out.println("Wrote "+idxToIdFile); }

            String pairwiseFile = outputFilePrefix+"_pairwise-distance.txt";
            if (DEBUG) { System.out.println("Writing pairwise curve area differences to "+pairwiseFile+" ..."); }
            pdBW = new BufferedWriter(new FileWriter(pairwiseFile, false));
            synchronizedWriteln(pdBW, "Idx1\tIdx2\tAbsAreaDiff");  //not strictly needed, but let's keep all the writes synch'ed

            //prep and kick the work to the worker threads
            Thread[] pdThreads = new Thread[pdThreadCount];
            pdThreadsSemaphore = new Semaphore(1-pdThreadCount);
            pdSampleCount = sampleIds.size();
            for (int i=0; i<pdThreadCount; i++)
            {
                Sample3pBiasQCMetricsCalculator runnable = new Sample3pBiasQCMetricsCalculator();
                String threadName = "PD Thread "+i;
                pdThreads[i] = new Thread(runnable, threadName);
                pdThreads[i].start();
                if (DEBUG) { System.out.println("Started worked thread: "+threadName); }
            }

            //wait till done
            pdThreadsSemaphore.acquire();
            pdBW.close();

            if (DEBUG) { System.out.println("Wrote "+pairwiseFile); }
        }
    }


    public void run()
    {
        DecimalFormat df2 = new DecimalFormat("0.00####");
        Point idxPair = getNextPairIdxs();
        while (idxPair.getX() != -1)
        {
            int i = (int)idxPair.getX();
            int j = (int)idxPair.getY();

            String sampleIdA = sampleIds.get(i);
            double[] slopesA = sampleToSlopes.get(sampleIdA);
            double[] densitiesA = sampleToDensities.get(sampleIdA);

            String sampleIdB = sampleIds.get(j);
            double[] slopesB = sampleToSlopes.get(sampleIdB);
            double[] densitiesB = sampleToDensities.get(sampleIdB);

            double areaDiff = calculateAreaBetweenCurves(slopesA, densitiesA, slopesB, densitiesB);
            try
            {
                synchronizedWriteln(pdBW, i+"\t"+j+"\t"+areaDiff);
            }
            catch (Exception ex)
            {
                System.out.println("Synchronized writeln failed!");
                ex.printStackTrace();
            }
            idxPair = getNextPairIdxs();
        }
        pdThreadsSemaphore.release();
    }


    public static double calculateAreaBetweenCurves(double[] xa, double[] ya, double[] xb, double[] yb)
    {
        double cummAreaBetween = 0.0;

        //require that xa and xb are sorted in ascending order
        // they need not be the same length and are assumed NOT to have the same x values
        if (xa == null || xa.length<2)
        {
            System.out.println("xa is null or of length less than two!");
            System.exit(0);
        }
        if (xb == null || xb.length<2)
        {
            System.out.println("xb is null or of length less than two!");
            System.exit(0);
        }
        for (int i=1; i<xa.length; i++)
        {
            if (xa[i-1] >= xa[i])
            {
                System.out.println("xa was not sorted ascending!");
                System.exit(0);
            }
        }
        for (int i=1; i<xb.length; i++)
        {
            if (xb[i-1] >= xb[i])
            {
                System.out.println("xb was not sorted ascending!");
                System.exit(0);
            }
        }

        //Calculate the area using linear interpolation/extrapolation and trapezoids
        // for simplicity and efficiency, find all unique x values and perform any/all
        // necessary interpolation/extrapolation first
        // We're working with relatively small sets of points, so let's keep this simple
        double[] mergedX = Arrays.copyOf(xa, xa.length+xb.length);
        {
            System.arraycopy(xb, 0, mergedX, xa.length, xb.length);
            Arrays.sort(mergedX);
            int uniqueCount = 1;
            for (int i=1; i<mergedX.length; i++)
            {
                if (mergedX[i] != mergedX[i-1])
                {
                    uniqueCount++;
                }
            }
            double[] uniqueX = new double[uniqueCount];
            double lastUniqueValueAdded = Double.NEGATIVE_INFINITY;
            int uniqueXIdx = 0;
            for (int i=0; i<mergedX.length; i++)
            {
                if (mergedX[i] > lastUniqueValueAdded)
                {
                    uniqueX[uniqueXIdx++] = (lastUniqueValueAdded = mergedX[i]);
                }
            }
            mergedX = uniqueX;
        }

        //replace ya and yb with their directly comparable forms
        double[] newYa = polate(mergedX, xa, ya);
        double[] newYb = polate(mergedX, xb, yb);

        //calculate and tally trapezoid area diffs
        for (int i=1; i<mergedX.length; i++)
        {
            double width = mergedX[i]-mergedX[i-1];
            //THIS IS APPROXIMATE
            // There should be a check for the two curves crossing one another
            // and the trapezoids should be split (at the x of the intersection)
            // into a pair of regions
            //BUT the trapezoids are narrow enough that the effect is trivial in this application
            cummAreaBetween += Math.abs((width*(newYa[i]+newYa[i-1])/2)-(width*(newYb[i]+newYb[i-1])/2));
        }

        return cummAreaBetween;
    }


    public static double[] polate(double[] newX, double[] x, double[] y)
    {
        double[] newY = new double[newX.length];

        //extrapolate first...
        double m, b;
        // left
        int newLeftBoundIdx = 0;
        m = (y[1]-y[0])/(x[1]-x[0]);
        b = y[0] - m*x[0];
        for (int i=0; i<newX.length; i++)
        {
            if (newX[i] < x[0])
            {
                newY[i] = m*newX[i]+b;
                newY[i] = (newY[i]<0)?0:newY[i]; //force ge zero
            }
            else
            {
                newLeftBoundIdx = i;
                break;
            }
        }
        // right
        int newRightBoundIdx = newX.length-1;
        m = (y[y.length-1]-y[y.length-2])/(x[x.length-1]-x[x.length-2]);
        b = y[y.length-1] - m*x[x.length-1];
        for (int i=newX.length-1; i>=0; i--)
        {
            if (newX[i] > x[x.length-1])
            {
                newY[i] = m*newX[i]+b;
                newY[i] = (newY[i]<0)?0:newY[i]; //force ge zero
            }
            else
            {
                newRightBoundIdx = i;
                break;
            }
        }

        //now interpolate
        int idx=0;
        for (int newIdx=newLeftBoundIdx; newIdx<=newRightBoundIdx; newIdx++)
        {
            while (x[idx] < newX[newIdx])
            {
                idx++;
            }
            if (x[idx] == newX[newIdx])
            {
                newY[newIdx] = y[idx];
            }
            else
            {
                m = (y[idx]-y[idx-1]) / (x[idx]-x[idx-1]);
                b = y[idx] - m*x[idx];
                newY[newIdx] = m*newX[newIdx]+b;
                newY[newIdx] = (newY[newIdx]<0)?0:newY[newIdx]; //force ge zero
            }
        }

        return newY;
    }
}

