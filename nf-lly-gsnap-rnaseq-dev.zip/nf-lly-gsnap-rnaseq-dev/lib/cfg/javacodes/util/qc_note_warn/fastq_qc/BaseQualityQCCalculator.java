import java.io.*;
import java.util.*;
import java.text.*;

/*
    Goal:  To calculate (and output to file) normalized base/quality values, simple metrics, and model fit parameters intended to be useful for automated base
           quality QC...  Performed in Java (vs Perl like most of the NGS pipeline) for model fitting performance.

    This is some pretty icky hack-and-slash code, but it does the job reasonably well.
*/

public class BaseQualityQCCalculator implements Runnable
{
    public static boolean DEBUG = false;
    public static double PRECISION = 1e-4;
    public static int ITERATIONS = 30; //restarts
    public static int ROUNDS = 50;     //subdivisions per restart

    private static void syntaxExit()
    {
        System.out.println("SYNTAX: java BaseQualityQCCalculator <inputFile> <outputFile> <concurrentThreadCount> <minAssayIdx> <maxAssayIdx> ");
        //System.out.println("        Expects a tab-delimited input file including column headers: Sample, cycle, ALL_mean, A_count, C_count, G_count, T_count, N_count");
        String[] requiredHeaderFields = CombinedFastxReader.requiredHeaderFields;
        System.out.print("        Expects a tab-delimited input file including column headers: "+requiredHeaderFields[0]);
        for (int i=1; i<requiredHeaderFields.length; i++)
        {
            System.out.print(", "+requiredHeaderFields[i]);
        }
        System.out.println();
        System.out.println("          If a \"Location\" column header is present in the input, \"Location\" will be included in the output and Location+Sample will be treated as a composite key.");
        System.out.println("          Notes: \"Sample\" is a misnomer; it's actually an assay id.  The input file would typically be <results-root-dir>/fastq_QC/combined_fastx.txt");
        System.out.println("        Output file includes: ");
        System.out.println("                  (Location,) assayId, assayIdx, maxBaseNumber, min/median/mean/max Quality/NormQualityAbsDelta, ");
        System.out.println("                  fractionalAreaUnderMaxQuality, fractionalAreaUnder20, fractionalAreaUnder10, meanBaseQualityReadIC");
        System.out.println("                  6-parameter curve fit (ku, xu, y0, y1, kd, xd), and curve fit SSE");
        System.out.println("            The 6-parameter curve is of the form:");
        System.out.println("                                y=A*B*C");
        System.out.println("                    initial rise: A =1/(1+EXP(-ku*(x-xu)))");
        System.out.println("              linear degradation: B =(y1-y0)*x+y0");
        System.out.println("                      final fall: C =1-1/(1+EXP(-kd*(x-xd)))");
        System.out.println("            The curve is fit to normalized-quality-vs-normalized-base-number.  The linear degradation is based on a line connecting (0,y0) to (1,y1) ");
        System.out.println("        Use -1 for minAssayIdx/maxAssayIdx to specify no limit");
        System.out.println("        Specifying a too-large max-assay-index causes neither warnings nor errors, but too large a min is a problem.");
        System.out.println();
        System.exit(0);
    }

    private static BufferedWriter bw;
    private static synchronized void synchronizedWriteln(BufferedWriter bw, String line) throws Exception
    {
        bw.write(line);
        bw.newLine();
    }
    private static void synchronizedWriteln(BufferedWriter bw, StringBuffer line) throws Exception
    {
        synchronizedWriteln(bw, line.toString());
        line.setLength(0);
    }

    public static void main(String[] args) throws Exception
    {
        if (args.length != 5)
        {
            syntaxExit();
        }
        String ifile = args[0];
        int concurrentThreadCount = Integer.parseInt(args[2]);
        int minIdxToConsider = Integer.parseInt(args[3]);
        int maxIdxToConsider = Integer.parseInt(args[4]);
        String ofile = args[1];

        //open the input file
        CombinedFastxReader cfr = new CombinedFastxReader(ifile);
        CombinedFastxReader.DEBUG = DEBUG;
        cfr.moveNextAssay(); //move to the first (idx=0)

        //skip to the first index of interest?
        if (minIdxToConsider > 0)
        {
            int maxAssayIdxSeen = -1;
            while (cfr.moveNextAssay() < minIdxToConsider && cfr.getCurrentAssayIdx() != -1)
            {
                //note and skip...
                maxAssayIdxSeen = cfr.getCurrentAssayIdx();
            }
            if (cfr.getCurrentAssayIdx() == -1)
            {
                System.out.println("ERROR: Specified minimum assay index to consider ("+minIdxToConsider+") was less than the maximum index seen (maxAssayIdxSeen).");
                System.exit(0);
            }
        }

        //open output files and writer headers...
        //  appends will happen indirectly via synchronized static methods on this class for thread-safety
        bw = new BufferedWriter(new FileWriter(ofile, false));
        synchronizedWriteln(bw,
            ((cfr.hasLocationField())?"Location\t":"")+
            "assayId\tassayIdx\tmaxBaseNumber"+
            // min/median/mean/max Quality/NormQualityDelta/NormQualityAbsDelta
            "\tminQuality\tmedianQuality\tmeanQuality\tmaxQuality"+
            "\tminNormQualityAbsDelta\tmedianNormQualityAbsDelta\tmeanNormQualityAbsDelta\tmaxNormQualityAbsDelta"+
            "\tfractionalAreaUnderMaxQuality\tfractionalAreaUnder20\tfractionalAreaUnder10\tmeanBaseQualityReadIC"+
            "\tku\txu\ty0\ty1\tkd\txd\tSSE");

        //fetch data blocks (as String[][]) and throw to worker threads
        Thread[] concurrentThreads = new Thread[concurrentThreadCount];
        boolean done = false;
        while (!done)
        {
            boolean atLeastOneActiveThread = false;
            for (int i=0; i<concurrentThreads.length; i++)
            {
                if (concurrentThreads[i] != null && concurrentThreads[i].getState() == Thread.State.TERMINATED)
                {
                    if (DEBUG) { System.out.println("Thread completed: "+concurrentThreads[i].getName()); }
                    concurrentThreads[i] = null;
                }
                if (concurrentThreads[i] == null)
                {
                    int currentAssayIdx = cfr.getCurrentAssayIdx();
                    if (currentAssayIdx == -1)
                    {
                        //eof from the cfr
                    }
                    else
                    {
                        if (maxIdxToConsider == -1 || currentAssayIdx <= maxIdxToConsider)
                        {
                            String[][] cfrData = cfr.getCurrentRequiredFieldsData();
                            String currentAssayId = cfr.getCurrentAssayId();
                            BaseQualityQCCalculator bqqcc = new BaseQualityQCCalculator(currentAssayIdx, currentAssayId, cfrData);
                            String threadName = currentAssayIdx+"_"+currentAssayId;
                            concurrentThreads[i] = new Thread(bqqcc, threadName);
                            if (DEBUG) { System.out.println("Starting thread: "+threadName); }
                            concurrentThreads[i].start();
                            atLeastOneActiveThread = true;
                            cfr.moveNextAssay();
                        }
                    }
                }
                else
                {
                    //not null'ed out for having terminated, so presume it's active 
                    atLeastOneActiveThread = true;
                }
            }
            done = !atLeastOneActiveThread;
            if (!done)
            {
                Thread.sleep(1000); //sleep 1s
            }
        }

        //all done -- clean-up
        cfr.close();
        bw.close();
    }

    private int cfrAssayIdx;
    private String cfrAssayId;
    private String[][] cfrData;
    public BaseQualityQCCalculator(int cfrAssayIdx, String cfrAssayId, String[][] cfrData)
    {
        this.cfrAssayIdx = cfrAssayIdx;
        this.cfrAssayId = cfrAssayId;
        this.cfrData = cfrData;
    }

    private static int getMax(int[] values)
    {
        int result = Integer.MIN_VALUE;
        for (int i=0; i<values.length; i++)
        {
            if (result < values[i])
            {
                result = values[i];
            }
        }
        return result;
    }

    private static double[] getMinMedianMeanMax(double[] origValues)
    {
        double[] values = new double[origValues.length];
        System.arraycopy(origValues, 0, values, 0, values.length);
        Arrays.sort(values);
        double median;
        if (values.length % 2 == 0)
        {
            median = (values[values.length/2-1]+values[values.length/2])/2;
        }
        else
        {
            median = values[values.length/2];
        }
        double mean = 0;
        for (int i=0; i<values.length; i++)
        {
            mean += values[i];
        }
        mean /= values.length;
        return new double[] {values[0], median, mean, values[values.length-1]};
    }

    public void run()
    {
        //data are available in String form in cfrData member...
        //  Sample, cycle, ALL_mean, A_count, C_count, G_count, T_count, N_count
        DecimalFormat df2 = new DecimalFormat("0.00####");
        DecimalFormat df6 = new DecimalFormat("0.000000");
        StringBuffer line = new StringBuffer();

        //convert to arrays of doubles
        int[] baseNumbers = new int[cfrData.length];             //ie cycle
        double[] meanBaseQualities = new double[cfrData.length]; //ie ALL_mean
        for (int i=0; i<cfrData.length; i++)
        {
            baseNumbers[i]       = Integer.parseInt(cfrData[i][1]);
            meanBaseQualities[i] = Double.parseDouble(cfrData[i][2]);
        }

        /*
                  <ofile>
                    Includes: (Location,) assayId, assayIdx, maxBaseNumber,
                              min/median/mean/max Quality/NormQualityAbsDelta
                              fractionalAreaUnderMaxQuality, fractionalAreaUnder20, fractionalAreaUnder10,
                              6-parameters and SSE for curve fit
        */
        // (Location,) assayId, assayIdx, maxBaseNumber
        double maxBaseNumber = getMax(baseNumbers);
        line.append(cfrAssayId+"\t"+cfrAssayIdx+"\t"+((int)maxBaseNumber));
        // min/median/mean/max Quality
        double[] meanQualityMinMedianMeanMax = getMinMedianMeanMax(meanBaseQualities);
        for (int i=0; i<4; i++)
        {
            line.append("\t"+df6.format(meanQualityMinMedianMeanMax[i]));
        }
        // min/median/mean/max NormQualityAbsDelta
        double maxBaseQuality = meanQualityMinMedianMeanMax[3];
        double[] normBaseQuality = new double[meanBaseQualities.length];
        double[] normBaseQualityAbsDelta = new double[normBaseQuality.length-1];
        if (maxBaseQuality > 0)
        {
            for (int i=0; i<meanBaseQualities.length; i++)
            {
                normBaseQuality[i] = meanBaseQualities[i]/maxBaseQuality;
            }
            for (int i=0; i<normBaseQuality.length-1; i++)
            {
                normBaseQualityAbsDelta[i] = Math.abs(normBaseQuality[i+1]-normBaseQuality[i]);
            }
        }
        double[] normBaseQualityAbsDeltaMMMM = getMinMedianMeanMax(normBaseQualityAbsDelta);
        for (int i=0; i<4; i++)
        {
            line.append("\t"+df6.format(normBaseQualityAbsDeltaMMMM[i]));
        }
        normBaseQualityAbsDelta = null;
        // fractionalAreaUnderMaxQuality, fractionalAreaUnder20, fractionalAreaUnder10, meanBaseQualityReadIC
        double fractionalAreaUnderMaxQuality = 0.0, fractionalAreaUnder20 = 0.0, fractionalAreaUnder10 = 0.0, meanBaseQualityReadIC = 0.0;
        if (maxBaseQuality > 0)
        {
            for (int i=0; i<meanBaseQualities.length-1; i++)
            {
                double width = baseNumbers[i+1]-baseNumbers[i];

                //under max
                fractionalAreaUnderMaxQuality += width * (normBaseQuality[i+1]+normBaseQuality[i])/2;

                //under 20
                double threshold = 20.0;
                if (meanBaseQualities[i+1] >= threshold && meanBaseQualities[i] >= threshold)
                {
                    //both ge threshold -- simple case
                    fractionalAreaUnder20 += width; // * 1.0
                }
                else
                {
                    //one end or both are less than threshold
                    if (meanBaseQualities[i+1] <= threshold && meanBaseQualities[i] <= threshold)
                    {
                        //both le threshold -- another simple case
                        fractionalAreaUnder20 += width * (meanBaseQualities[i+1]+meanBaseQualities[i])/threshold/2;
                    }
                    else
                    {
                        //one above and one below threshold  :-/
                        // add as for both le threshold and subtract off the excess
                        //  add
                        fractionalAreaUnder20 += width * (meanBaseQualities[i+1]+meanBaseQualities[i])/threshold/2;
                        //  subtract
                        double[] minMax = new double[] {meanBaseQualities[i+1], meanBaseQualities[i]};
                        Arrays.sort(minMax);
                        double fractionalWidthAbove20 = 1.0 - (threshold-minMax[0])/(minMax[1]-minMax[0]);
                        fractionalAreaUnder20 -= fractionalWidthAbove20*width * (minMax[1]-threshold) /threshold/2;
                    }
                }

                //under 10
                threshold = 10.0;
                if (meanBaseQualities[i+1] >= threshold && meanBaseQualities[i] >= threshold)
                {
                    //both ge threshold -- simple case
                    fractionalAreaUnder10 += width; // * 1.0
                }
                else
                {
                    //one end or both are less than threshold
                    if (meanBaseQualities[i+1] <= threshold && meanBaseQualities[i] <= threshold)
                    {
                        //both le threshold -- another simple case
                        fractionalAreaUnder10 += width * (meanBaseQualities[i+1]+meanBaseQualities[i])/threshold/2;
                    }
                    else
                    {
                        //one above and one below threshold  :-/
                        // add as for both le threshold and subtract off the excess
                        //  add
                        fractionalAreaUnder10 += width * (meanBaseQualities[i+1]+meanBaseQualities[i])/threshold/2;
                        //  subtract
                        double[] minMax = new double[] {meanBaseQualities[i+1], meanBaseQualities[i]};
                        Arrays.sort(minMax);
                        double fractionalWidthAbove10 = 1.0 - (threshold-minMax[0])/(minMax[1]-minMax[0]);
                        fractionalAreaUnder10 -= fractionalWidthAbove10*width * (minMax[1]-threshold) /threshold/2;
                    }
                }
            }

            fractionalAreaUnderMaxQuality /= (maxBaseNumber-1); //presume min is one
            fractionalAreaUnder20 /= (maxBaseNumber-1);
            fractionalAreaUnder10 /= (maxBaseNumber-1);

            double rlog4 = 1.0/Math.log(4);
            for (int i=0; i<meanBaseQualities.length; i++)
            {
                //meanBaseQualityReadIC
                if (meanBaseQualities[i] > 0.0)
                {
                    double alpha = Math.pow(10.0, -meanBaseQualities[i]/10.0);
                    double pCorrect = 1.0-alpha;
                    double pOneOtherNucleotide = alpha/3.0;
                    double ieCorrect = -(1.0-alpha)*Math.log(1.0-alpha)*rlog4;
                    double ieOtherNucleotide = 3*(-pOneOtherNucleotide*Math.log(pOneOtherNucleotide)*rlog4);
                    meanBaseQualityReadIC += 1.0 - (ieCorrect + ieOtherNucleotide);
                }
            }
        }
        line.append("\t"+df6.format(fractionalAreaUnderMaxQuality));
        line.append("\t"+df6.format(fractionalAreaUnder20));
        line.append("\t"+df6.format(fractionalAreaUnder10));
        line.append("\t"+df6.format(meanBaseQualityReadIC));

        //prep for curve fit param optimization...
        MultiparametricFunction mpf = new NormalizedBaseQualityModel();
        double[] initialParameters = mpf.getDefaultInitialParameters();
        double[][] parameterBounds = mpf.getParameterBounds();
        double[] yValues = normBaseQuality;
        double[] xValues = new double[baseNumbers.length];
        for (int i=0; i<baseNumbers.length; i++)
        {
            xValues[i] = baseNumbers[i]/maxBaseNumber;
        }

        //fit
        //    MultiparametricFunction mpf, double[] initialParameters, double[][] parameterBounds, double[] xValues, double[] yValues,
        //    double precision, int rounds, int iterationsPerRound
        BeesOptimizer optimizer = new BeesOptimizer();
        double[] fitResult = optimizer.fit(mpf, initialParameters, parameterBounds, xValues, yValues, PRECISION, ITERATIONS, ROUNDS);

        //report
        //    recall that the fit result is {SSE, {the fit params}}
        for (int i=1; i<fitResult.length; i++)
        {
            line.append("\t"+df6.format(fitResult[i]));
        }
        line.append("\t"+df6.format(fitResult[0]));
        try
        {
            synchronizedWriteln(bw, line);
        }
        catch (Exception ex)
        {
            throw new RuntimeException(ex);
        }
    }

}



