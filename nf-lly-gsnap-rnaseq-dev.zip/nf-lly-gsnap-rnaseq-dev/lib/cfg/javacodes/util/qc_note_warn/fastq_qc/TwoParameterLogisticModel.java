
public class TwoParameterLogisticModel implements MultiparametricFunction
{
    //MultiparametricFunction:
    /*
        The model:
            if k=0
                y = 0.5
            if k>0
                y = 1/(1+EXP(-k*(x-xm)))
            if k<0
                y = 1 - 1/(1+EXP(-k*(x-xm)))
    */
    public double[][] getParameterBounds()
    {
        double[][] parameterBounds = new double[][] {
                                                        {-100.0, 100.0},    //0 k
                                                        {-1.0, 2.0},        //1 xm
                                                    };
        return parameterBounds;
    }

    public double[] getDefaultInitialParameters()
    {
        return new double[] { 0.0, 0.5 };
    }

    public double[] estimateInitialParameters(double[] xValues, double[] yValues)
    {
        double[] initialParameters = getDefaultInitialParameters();

        if (xValues == null || yValues == null || xValues.length != yValues.length)
        {
            throw new IllegalArgumentException("x and y vectors must both be specified and of equal length");
        }
        for (int i=0; i<xValues.length; i++)
        {
            if (xValues[i]<0 || xValues[i]>1 || yValues[i]<0 || yValues[i]>1)
            {
                throw new IllegalArgumentException("x and y values are required to be in [0.0, 1.0]");
            }
            if (i>0 && xValues[i]<=xValues[i-1])
            {
                throw new IllegalArgumentException("x values are required to monotonically increase");
            }
        }

        int n = xValues.length;
        double sumX = 0.0, sumY = 0.0, sumXY = 0.0, sumXX = 0.0;
        for (int i=0; i<xValues.length; i++)
        {
            sumX += xValues[i];
            sumY += yValues[i];
            sumXY += xValues[i]*yValues[i];
            sumXX += xValues[i]*xValues[i];
        }
        //slope and intercept...
        double denom = n*sumXX-sumX*sumX;
        if (denom == 0.0)
        {
            //leave the default initial parameters in place
        }
        else
        {
            double slope = (n*sumXY-sumX*sumY)/denom;
            if (slope == 0.0)
            {
                initialParameters[0] = 0.0;
                initialParameters[1] = (xValues[n-1]+xValues[0])/2.0;
            }
            else
            {
                double yIntercept = (sumY*sumXX-sumX*sumXY)/denom;
                double xOneHalf = (0.5-yIntercept)/slope;
                initialParameters[0] = (slope > 0)?(slope):(-slope);
                initialParameters[1] = xOneHalf;

                double[][] parameterBounds = getParameterBounds();
                for (int i=0; i<parameterBounds.length; i++)
                {
                    if (initialParameters[i] < parameterBounds[i][0])
                    {
                        initialParameters[i] = parameterBounds[i][0];
                    }
                    else if (initialParameters[i] > parameterBounds[i][1])
                    {
                        initialParameters[i] = parameterBounds[i][1];
                    }
                }
            }
        }

        return initialParameters;
    }

    public double[] evaluate(double[] parameters, double[] xValues)
    {
        if (parameters.length != 2)
        {
            throw new IllegalArgumentException("Unexpected number of parameters -- Received "+parameters.length+"; expected 2");
        }

        double k,xm;
        k = parameters[0];
        xm = parameters[1];

        double[] results = new double[xValues.length];
        if (parameters[0] > 0)
        {
            for (int i=0; i<xValues.length; i++)
            {
                double x = xValues[i];
                results[i] = 1.0/(1.0+Math.exp(-k*(x-xm)));
            }
        }
        else
        {
            if (parameters[0] < 0)
            {
                for (int i=0; i<xValues.length; i++)
                {
                    double x = xValues[i];
                    results[i] = 1.0 - 1.0/(1.0+Math.exp(-k*(x-xm)));
                }
            }
            else // (parameters[0] == 0)
            {
                for (int i=0; i<xValues.length; i++)
                {
                    results[i] = 0.5;
                }
            }
        }

        return results;
    }
}
