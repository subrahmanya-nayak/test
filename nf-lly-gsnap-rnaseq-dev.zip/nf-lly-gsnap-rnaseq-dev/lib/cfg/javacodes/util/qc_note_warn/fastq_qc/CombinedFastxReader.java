import java.io.*;
import java.util.*;

/*
    Would love to grab an off-the-shelf "dataset" object to load delimited data into, but
    I'd spend as long looking for one (and a heck of a lot more sorting out its quirks?)
    as writing just what's needed for this case.  :-(
*/

public class CombinedFastxReader
{
    public static boolean DEBUG = false;

    public static String[] requiredHeaderFields = "Sample, cycle, ALL_mean, A_count, C_count, G_count, T_count, N_count".split(", ");
    public Hashtable<String, Integer> fieldHeaderToIdx;

    public static void main(String[] args) throws Exception
    {
        if (args.length != 1)
        {
            System.out.println("SYNTAX: java CombinedFastxReader <ifile>");
            System.out.println("        This is strictly a test method to verify the parsing functionality embedded in this class.");
            System.out.println("        The input file would typically be <results-root-dir>/fastq_QC/combined_fastx.txt");
            System.exit(0);
        }

        DEBUG = true;
        CombinedFastxReader cfr = new CombinedFastxReader(args[0]);
        System.out.println("Current idx: "+cfr.getCurrentAssayIdx());
        System.out.println("Moving to idx "+cfr.moveNextAssay());
        System.out.println("Current AssayID: "+cfr.getCurrentAssayId());
        System.out.println("Current record count: "+cfr.getCurrentAssayIdRecordCount());

        String[][] currentRequiredFieldsData = cfr.getCurrentRequiredFieldsData();
        System.out.println("Head 10 rows:");
        for (int r=0; r<10 && r<currentRequiredFieldsData.length; r++)
        {
            String[] currentRow = currentRequiredFieldsData[r];
            for (int c=0; c<currentRow.length; c++)
            {
                if (c>0) { System.out.print("\t"); }
                System.out.print(currentRow[c]);
            }
            System.out.println();
        }

        System.out.println("Moving to idx "+cfr.moveNextAssay());
        System.out.println("Current AssayID: "+cfr.getCurrentAssayId());
        System.out.println("Current record count: "+cfr.getCurrentAssayIdRecordCount());
        System.out.println("Moving to idx "+cfr.moveNextAssay());
        System.out.println("Current AssayID: "+cfr.getCurrentAssayId());
        System.out.println("Current record count: "+cfr.getCurrentAssayIdRecordCount());
        int assayCount = 3;
        int maxAssayIdx = -1;
        String lastAssayID = null;
        int lastRecordCount = -1;
        while (cfr.moveNextAssay() != -1)
        {
            assayCount++;
            maxAssayIdx = cfr.getCurrentAssayIdx();
            lastAssayID = cfr.getCurrentAssayId();
            lastRecordCount = cfr.getCurrentAssayIdRecordCount();
        }
        System.out.println("Last idx: "+maxAssayIdx);
        System.out.println("Last AssayID: "+lastAssayID);
        System.out.println("Last record count: "+lastRecordCount);
        System.out.println("Saw "+assayCount+" assays in "+cfr.getReadLineCount()+" lines.");
    }

    private boolean hasLocationFieldFlag = false;
    public boolean hasLocationField()
    {
        return hasLocationFieldFlag;
    }

    private BufferedReader br;
    private int requiredFieldCount = -1;
    public CombinedFastxReader(String ifile) throws Exception
    {
        this.br = new BufferedReader(new FileReader(ifile));

        fieldHeaderToIdx = new Hashtable<String, Integer>();
        for (int i=0; i<requiredHeaderFields.length; i++)
        {
            fieldHeaderToIdx.put(requiredHeaderFields[i], -1);
        }

        String headerLine = br.readLine();
        if (DEBUG) { System.out.println("Read header line: "+headerLine); }
        String[] fieldNames = headerLine.split("\t");
        for (int i=0; i<fieldNames.length; i++)
        {
            if (fieldHeaderToIdx.containsKey(fieldNames[i]))
            {
                if (DEBUG) { System.out.println("Found field "+fieldNames[i]+" at column offset "+i); }
                fieldHeaderToIdx.put(fieldNames[i], i);
                requiredFieldCount = i+1;
            }
            else
            {
                if ("Location".equals(fieldNames[i]))
                {
                    if (DEBUG) { System.out.println("Found field "+fieldNames[i]+" at column offset "+i); }
                    fieldHeaderToIdx.put(fieldNames[i], i);
                    requiredFieldCount = i+1;
                }
            }
        }
        hasLocationFieldFlag = (fieldHeaderToIdx.containsKey("Location"));

        boolean foundAllRequiredFields = true;
        for (int i=0; i<requiredHeaderFields.length; i++)
        {
            if ((int)(fieldHeaderToIdx.get(requiredHeaderFields[i])) == -1)
            {
                System.out.println("Failed to find required field: "+requiredHeaderFields[i]);
                foundAllRequiredFields = false;
            }
        }
        if (!foundAllRequiredFields)
        {
            throw new RuntimeException("Bad input file!");
        }

        
    }


    private ArrayList<String[]> currentBuffer = new ArrayList<String[]>(500);
    private String lookAheadLine = null;
    private boolean eof = false;

    private int currentIdx = -1;
    public int getCurrentAssayIdx()
    {
        return currentIdx;
    }

    private String currentAssayId = null;
    public String getCurrentAssayId()
    {
        return currentAssayId;
    }

    public int getCurrentAssayIdRecordCount()
    {
        return currentBuffer.size();
    }

    private int lineNbr = 1; //already read the header line...
    public int getReadLineCount()
    {
        return lineNbr;
    }

    public void close() throws Exception
    {
        eof = true;
        currentIdx = -1;
        currentAssayId = null;
        if (currentBuffer != null) { currentBuffer.clear(); }
        currentBuffer = null;
        if (br != null) { br.close(); }
        br = null;
    }

    public int moveNextAssay() throws Exception
    {
        if (eof)
        {
            close();
            return currentIdx;
        }
        if (lookAheadLine == null)
        {
            //first fetch
            String line = br.readLine(); lineNbr++;
            if (line == null)
            {
                lineNbr--; //last read was past eof
                eof = true;
                return currentIdx;
            }

            currentIdx++;
            String[] fields = line.split("\t");
            if (fields.length < requiredFieldCount)
            {
                throw new Exception("Bad input file: Too few columns on line "+lineNbr+"!");
            }
            if (hasLocationFieldFlag)
            {
                currentAssayId = fields[(int)(fieldHeaderToIdx.get("Location"))] + "\t" + fields[(int)(fieldHeaderToIdx.get("Sample"))];
            }
            else
            {
                currentAssayId = fields[(int)(fieldHeaderToIdx.get("Sample"))];
            }
            currentBuffer.add(fields);

            do
            {
                line = br.readLine(); lineNbr++;
                while ("".equals(line))
                {
                    line = br.readLine(); lineNbr++;
                }
                if (line == null)
                {
                    lineNbr--; //last read was past eof
                    eof = true;
                    lookAheadLine = null;
                }
                else
                {
                    fields = line.split("\t");
                    if (fields.length < requiredFieldCount)
                    {
                        throw new Exception("Bad input file: Too few columns on line "+lineNbr+"!");
                    }
                    String newLineAssayId = null;
                    if (hasLocationFieldFlag)
                    {
                        newLineAssayId = fields[(int)(fieldHeaderToIdx.get("Location"))] + "\t" + fields[(int)(fieldHeaderToIdx.get("Sample"))];
                    }
                    else
                    {
                        newLineAssayId = fields[(int)(fieldHeaderToIdx.get("Sample"))];
                    }
                    if (currentAssayId.equals(newLineAssayId))
                    {
                        currentBuffer.add(fields);
                    }
                    else
                    {
                        lookAheadLine = line;
                    }
                }
            } while (lookAheadLine == null && !eof);
        }
        else
        {
            //some fetch after the first one
            currentBuffer.clear();
            String line = lookAheadLine;
            lookAheadLine = null;

            currentIdx++;
            String[] fields = line.split("\t");
            if (hasLocationFieldFlag)
            {
                currentAssayId = fields[(int)(fieldHeaderToIdx.get("Location"))] + "\t" + fields[(int)(fieldHeaderToIdx.get("Sample"))];
            }
            else
            {
                currentAssayId = fields[(int)(fieldHeaderToIdx.get("Sample"))];
            }
            currentBuffer.add(fields);

            do
            {
                line = br.readLine(); lineNbr++;
                while ("".equals(line))
                {
                    line = br.readLine(); lineNbr++;
                }
                if (line == null)
                {
                    lineNbr--; //last read was past eof
                    eof = true;
                    lookAheadLine = null;
                }
                else
                {
                    fields = line.split("\t");
                    if (fields.length < requiredFieldCount)
                    {
                        throw new Exception("Bad input file: Too few columns on line "+lineNbr+"!");
                    }
                    String newLineAssayId = null;
                    if (hasLocationFieldFlag)
                    {
                        newLineAssayId = fields[(int)(fieldHeaderToIdx.get("Location"))] + "\t" + fields[(int)(fieldHeaderToIdx.get("Sample"))];
                    }
                    else
                    {
                        newLineAssayId = fields[(int)(fieldHeaderToIdx.get("Sample"))];
                    }
                    if (currentAssayId.equals(newLineAssayId))
                    {
                        currentBuffer.add(fields);
                    }
                    else
                    {
                        lookAheadLine = line;
                    }
                }
            } while (lookAheadLine == null && !eof);
        }
        return currentIdx;
    }

    public String[][] getCurrentRequiredFieldsData()
    {
        String[][] currentRequiredFieldsData = new String[currentBuffer.size()][requiredHeaderFields.length];
        for (int r=0; r<currentBuffer.size(); r++)
        {
            for (int c=0; c<requiredHeaderFields.length; c++)
            {
                currentRequiredFieldsData[r][c] = (currentBuffer.get(r))[(int)(fieldHeaderToIdx.get(requiredHeaderFields[c]))];
            }
        }
        return currentRequiredFieldsData;
    }

}
































