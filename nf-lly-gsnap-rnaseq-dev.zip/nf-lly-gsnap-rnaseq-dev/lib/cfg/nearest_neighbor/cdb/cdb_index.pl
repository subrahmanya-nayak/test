#!/usr/bin/env perl
use strict;
use warnings FATAL => 'all';

#Revision History:
#  John Calley v 0.04 May-6-2020
#    --Removed all of the KyotoCabinet stuff.
#  John Calley v 0.03 Jul-23-2013
#     --Added comments about multi-valued keys in the usage statement.
#  John Calley v 0.02 Jul-18-2013
#     --I had no idea that I last visited this sooo long ago!
#     --Deprecated the compression stuff since I never managed to find a case
#     where it helped significantly and at the moment it is not working. Not
#     sure why.
#     --Added more to the indirect cdb index.
#     --Added ability to create KyotoCabinet indices (with tremendous help
#     from Adam West).
#        Type kchashmg for basic command line access to KC indices.
#  John Calley v 0.01 Oct-26-2010
#     -Initial attempt at this.
#


#The obvious strategy of compressing just the data portion of a cdb file is
#not very helpful at least for reasonably small key values.
#Compression overhead data:
#    For a sample CDB file of size 3.5MB
#      With bzip2 compression the size is 3.2MB
#      With gzip default compression the size is 2.9MB
#      With default except Minimal=>1, size is 2.9MB
#           ditto plus TextFlag        size is 2.9MB
#           ditto plus Level=>1                3.0
#                      Level=>2                2.9
#                      Level=>3                2.9
#                      Level=>4                2.9
#                      Level=>5                2.9
#                      Level=>6                2.9
#                      Level=>7                2.9
#                      Level=>8                2.9
#                      Level=>9                2.9
#          ditto plus Strategy=>Z_FILTERED     3.0
#                     Strategy=>Z_HUFFMAN_ONLY 3.1
#                     Strategy=>Z_RLE          3.1
#                     Strategy=>Z_FIXED        3.2
# Zlib seems better but not working at the moment (7/18/13). I'm not sure if I
# never got it working (3 years ago) or if I broke it somehow.
# ********* NEED TO SWITCH TO Compress::Snappy
# I downloaded and tried smaz_compress a compression algorithm for short texts
# (see ~/dev/SMAZ_Compression). On my sample data it increased the size of the
# text significantly. This is due to it using a constant compression table
# which is optimized for English.
# 
#
use Getopt::Std;
use Compress::Raw::Zlib;
use File::Temp qw(tempfile);
use Cwd;

our ($opt_o, $opt_k, $opt_t);

my $usage = <<"END_USAGE";
$0 -o out  [-t] [-k #] [fns]

-o out     Output file for cdb index. Required.
           Extension determines indexing method as follows:
                .cdb    --standard, uncompressed cdb index with the
                          value in the index file.
                .icdb   --Indirect cdb. The cdb index is offsets into the 
                          original file.
                .zcdb   --Value fields are compressed with zlib. Note that
                          this is rarely (if ever) worth doing because the values are
                          rarely big enough for significant compression. Might
                          be possible to use custom dictionaries to improve
                          this.
[-k #]     Key column. By default the key is expected to be in the
           first column. This allows you to specify a different (1 based)
           column.
-t         First line of each file is a title line. Keep the first
           one but remove all subsequent ones. If not specified all
           lines will be indexed for every file.

Read the indicated tab delimited text file(s) and index them via the method 
specified by the output file extension.

If no files are specified, read from stdin.

#Method specific notes:
    For method icdb a single file must be specified on the command line and the
    output file must be the same name with the addition of a .icdb extension.


    Multiple values are supported by cdb indices. If only one is requested
    (i.e., by means of tie) the first value encountered during indexing will
    be returned.

END_USAGE

if (!getopts('o:tk:')) {
    die "$usage\n\n Illegal arguments.\n";
}
if (!$opt_o) {
    die "$usage\n-o argument is required.\n";
}

$opt_k ||= 1;

my $method;
if ($opt_o =~ m/\.([^.]+)$/) {
    $method = $1;
} else {
    die  "$usage\n"
       . "-o argument must specify indexing method via a legal extension.\n";
}

if ($method eq 'icdb') {
    if ($#ARGV != 0) {
        die "$usage\nWith method icdb a single input file must be given.\n";
    } else {
        my $fn = $ARGV[0];
        if ($opt_o ne "$fn.icdb") {
            die "$usage\nWith method icdb -o argument must be identical to "
              . "input file name with .icdb extension\n";
        }
    }
} elsif ($method ne 'cdb' and $method ne 'zcdb') {
    die "$usage\n-o argument must specify extension corresponding to one of "
      . "the legal indexing methods.\n";
}

my $ofh;
my $ofd = $opt_o;
$ofd =~ s/[^\/]*$//;
$ofd ||= cwd();
my ($tfh, $tfn) = tempfile(UNLINK=>1, DIR => $ofd);
open $ofh, "|cdbmake $opt_o $tfn"
   or die "Unable to open cdbmake process for output ($!). Stopped";

my @fns = @ARGV;
if (!@fns) {
    @fns = ('-');
}

my $d  = new Compress::Raw::Zlib::Deflate()
   or die "Unable to create deflation object ($!). Stopped";
my $first_fn = 1;
foreach my $fn (@fns) {
    #warn "attempting to read $fn\n";
    my $fh;
    if ($fn eq '-') {
        $fh = *STDIN;
    } else {
        open $fh, '<', $fn
           or die "Unable to open file $fn for reading ($!).  Stopped"
    }
    my $first_ln = 1;
    my $loc = tell($fh);
    LINE:
    while (my $line = <$fh>) {
        chomp $line;
        if ($first_ln and $opt_t and !$first_fn) {
            $first_ln = 0;
            next LINE;
        }
        my @sp = split(/\t/, $line);
        my $key = $sp[$opt_k-1];
        my $data = join("\t", @sp[0..$opt_k-2], @sp[$opt_k..$#sp]);
        if ($method eq 'zcdb') {
            my $cdata = '';
            my $status = $d->deflate($data,$cdata);
            if ($status != Z_OK) {
                warn "Problem with deflation: $status\n";
            }
            $status = $d->flush($cdata, Z_FULL_FLUSH);
            if ($status != Z_OK) {
                warn "Problem with flush: $status\n";
            }
            $data = $cdata;
            #warn "Original=", length($data), " Changed=", length($cdata), "\n";
            $status = $d->deflateReset();
            if ($status != Z_OK) {
                warn "Problem with reset: $status\n";
            }
        } elsif ($method eq 'icdb') {
            $data = $loc;
        }
        print {$ofh} '+'. length($key) . ',' . length($data) .':' . "${key}->${data}\n";
        $loc = tell($fh);
    }
    $first_fn = 0;
    close $fh;
}
if ($ofh) {
    #needed for CDB indices.
    print {$ofh} "\n";
    close $ofh;
}

exit;
