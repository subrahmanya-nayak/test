#------------------
# Make cluster cmd
#------------------
#For calculation
source(paste(PACKAGE, 'Cluster/NN.R', sep=''))
Directory <- ''
PROJECT_NOTE <- 'NN'
file.cluster <- paste(Directory, PROJECT_NOTE, '_', 'cluster', '.cmd', sep='')
write.table(clusterLine, file=file.cluster, quote=FALSE, sep='', eol='\n', row.names=FALSE, col.names=FALSE)

