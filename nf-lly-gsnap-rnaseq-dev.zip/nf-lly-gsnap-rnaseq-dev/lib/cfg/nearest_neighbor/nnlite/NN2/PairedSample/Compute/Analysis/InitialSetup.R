#-------------
# dir setting
#-------------
dir.data.pro <- paste(dir.table, 'DataPro', '/', sep='')        #Processed data file
dir.create(dir.data.pro)

#---------------------------------
# ref and alternative calculation
#---------------------------------
v.name.sh <- strbar(INPUT, split='\\.')
ext.name.sh <- v.name.sh[length(v.name.sh)]
if (ext.name.sh=='txt'|ext.name.sh=='TXT'|ext.name.sh=='quant'|ext.name.sh=='QUANT')
{
  sh <- read.table(file=INPUT, sep='\t', header=header.1)
  sh <- fact.char(sh)
}
if (ext.name.sh=='csv') sh <- read.csv2(file=INPUT, header=header.1)
n <- nrow(sh)
source(paste(PACKAGE, 'PairedSample/Compute/Analysis/SortTable.R', sep='')) 
SCORE=rep(0,n)
REMARK=rep('',n)
if (col.warning<100) source(paste(PACKAGE, 'PairedSample/Compute/Analysis/Indel.R', sep='')) 
source(paste(PACKAGE, 'PairedSample/Compute/Analysis/addTable.R', sep='')) 

sh <- fact.char(sh)
if (WriteTab)
{
#####write file with stat info
file.table <- paste(dir.data.pro, name.1, '_', method.quality, '.csv', sep='')
write.csv(sh, file=file.table, row.names=FALSE)
#####
}


