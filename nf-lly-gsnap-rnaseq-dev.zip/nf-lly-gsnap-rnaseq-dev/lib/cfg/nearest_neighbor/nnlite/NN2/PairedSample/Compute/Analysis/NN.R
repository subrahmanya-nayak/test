#-------------
# dir setting
#-------------
dir.data.pro <- paste(dir.table, 'DataPro', '/', sep='')        #Processed data file
dir.NN <- paste(dir.table, 'NN', '/', sep='')
dir.create(dir.NN, showWarnings = FALSE)
dir.M <- paste(dir.NN, 'MORE', '/', sep='')
dir.create(dir.M, showWarnings = FALSE)
thd <- Threshold
thd.angle <- round(thd/pi*180)

#file.table <- paste(dir.data.pro, NAME.RT, '_', 'combined', '_', method.quality,  '.csv', sep='')
#sh.p=read.csv2(file.table)
sh.p=sh.p
source(paste(PACKAGE, 'PairedSample/Compute/Analysis/TrTabP.R', sep=''))                  # filtering the table
chr.a <- unique(sh.p.tc[,1])
n.tc <- nrow(sh.p.tc)

#--------
# Weight
#--------
if (WEIGHT=='Equal') w <- rep(1, n.tc)

#-------------------------
# Calculate all distances
#-------------------------
names.1 <- paste(names.read, '_', 1, sep='')
names.2 <- paste(names.read, '_', 2, sep='')
DIST <- Dist.Quant(sh.p.tc[,names.1], sh.p.tc[,names.2], thd=Dist.Thd, method=Dist.Method)
Dist <- data.frame(sh.p.tc[,1:2], DIST, w)
names(Dist)=c('CHR', 'POS', Dist.Method, 'WEIGHT')
Dist <- fact.char(Dist)

if (WriteDist)
{
file.tab <- paste(dir.M, NAME.RT, '_', variant.type, '_', thd, '_', 'NN', '_', 'V', '.csv', sep='')
write.csv(Dist, file.tab, row.names=FALSE)
}

w <- w/sum(w)
DIST.AVG <- data.frame(matrix(0,1,ncol(DIST)))
DIST.AVG[1,] <- apply(DIST*w,2,sum)
id.avg.0 <- which(DIST.AVG[1,] < epsilon)          
if (length(id.avg.0)>0) if (NAME[1]!=NAME[2]) DIST.AVG[1,id.avg.0] = DIST.AVG[1,id.avg.0] + epsilon          # If different sample has zero distance, add a small distance.

NAME_1 <- NAME[1]
NAME_2 <- NAME[2]
THRESHOLD <- thd.angle   
PLATFORM <- method.NGS
VARIANT <- variant.type
THRESHOLD <- thd.angle   
SIZE <- n.tc
report.nn <- data.frame(NAME_1, NAME_2, PLATFORM, VARIANT, THRESHOLD, SIZE, DIST.AVG, stringsAsFactors=FALSE, check.names=FALSE)
names(report.nn)[(ncol(report.nn)-ncol(DIST)+1):ncol(report.nn)] <- Dist.Method

if (WriteReport)
{
file.tab <- paste(dir.NN, NAME.RT, '_', variant.type, '_', thd, '_', 'NN', '.csv', sep='')
write.csv(report.nn, file.tab, row.names=FALSE)
}
