#-------------
# dir setting
#-------------
dir.data.pro <- paste(dir.table, 'DataPro', '/', sep='')        #Processed data file

sh.N <- sh.pro[[1]]
sh.T <- sh.pro[[2]]

n.N <- nrow(sh.N)
n.T <- nrow(sh.T)
id.N <- 1:n.N
id.T <- 1:n.T
  
chr.a <- unique(c(sh.T[,1], sh.N[,1]))
id.mth <- match(chr.order, chr.a)
chr.a <- chr.order[!is.na(id.mth)]

POS.unsorted <- unique(rbind(sh.T[,1:2], sh.N[,1:2]))

if (POSITION=='Pairwise') pos.use <- POS.unsorted else 
{
  v.name.sh <- strbar(POSITION, split='\\.')
  ext.name.sh <- v.name.sh[length(v.name.sh)]
  if (ext.name.sh=='txt'|ext.name.sh=='TXT'|ext.name.sh=='quant'|ext.name.sh=='QUANT')
  {
    pos.use <- read.table(file=POSITION, sep='\t', header=header.pos)
    pos.use <- fact.char(pos.use)
  }
  if (ext.name.sh=='csv') pos.use <- read.csv2(file=POSITION, header=header.pos)
}

for (i in 1:length(chr.a))
{
  chr.1 <- chr.a[i]
  id.chr <- which(POS.unsorted[,1]==chr.1)
  id.use <- which(pos.use[,1]==chr.1)
  POS.unsorted[id.chr,2] = sort(POS.unsorted[id.chr,2])
  id.chr.use <- which(!is.na(match(POS.unsorted[id.chr,2], pos.use[id.use, 2])))
  if (i==1) POS=POS.unsorted[id.chr[id.chr.use],] else POS=rbind(POS, POS.unsorted[id.chr[id.chr.use], ])
}

names.read <- names(sh.N)[col.start:col.end]
r.names<- c(names.read, 'SCORE', 'REMARK')
num.col <- length(r.names)

n.p <- nrow(POS)
VariantID <- rep('', n.p)
sh.p <- data.frame(POS, matrix(NA, n.p, (2*num.col)), VariantID)    #Define final sh.p

if (col.ID<100)                     #if SNPs information exists
{
  VariantID[id.N] <- sh.N[,col.ID]
  VariantID[id.T] <- sh.T[,col.ID]
}  


for (i in 1:length(chr.a))
{
  chr.1 <- chr.a[i]
  id.chr <- which(POS[,1]==chr.1)

  id.chr.N <- which(sh.N[,1]==chr.1)
  id.chr.c.N <- match(sh.N[id.chr.N, 2], POS[id.chr, 2])
  id.N.1 <- id.chr[id.chr.c.N]

  id.chr.T <- which(sh.T[,1]==chr.1)
  id.chr.c.T <- match(sh.T[id.chr.T, 2], POS[id.chr, 2])
  id.T.1 <- id.chr[id.chr.c.T] 
  if (length(!is.na(id.chr.c.N))>0) 
  {
    sh.p[fna(id.N.1), (2+num.col+1):(2+2*num.col)] <- sh.N[id.chr.N[which(!is.na(id.chr.c.N))], r.names]
    if (col.ID<100) VariantID[id.N.1] <- sh.N[id.chr.N[which(!is.na(id.chr.c.N))], col.ID]
  }
  if (length(!is.na(id.chr.c.T))>0) 
  {
    sh.p[fna(id.T.1), (2+1):(2+num.col)] <- sh.T[id.chr.T[which(!is.na(id.chr.c.T))], r.names]
    if (col.ID<100) VariantID[id.T.1] <- sh.T[id.chr.T[which(!is.na(id.chr.c.T))], col.ID]
  }
}

names(sh.p)[1:2]=c('chr', 'pos')
names(sh.p)[(2+1):(2+2*num.col)] <- paste(rep(r.names,2), '_', rep(1:2, each=num.col), sep='')

#--------------------------------
# Truncate on selected positions
#--------------------------------
id <- which(apply(sh.p[, paste('SCORE', '_', 1:2, sep='')], 1, function(x){sum(x>0)})==2)      #both coverage must be greater than 0
sh.p <- sh.p[id,]

sh.p <- fact.char(sh.p)

if (WriteTab)
{
#####write combined table
file.table <- paste(dir.data.pro, NAME.RT, '_', 'combined', '_', method.quality, '.csv', sep='')
write.csv(sh.p, file.table, row.names=FALSE)
#####
}
