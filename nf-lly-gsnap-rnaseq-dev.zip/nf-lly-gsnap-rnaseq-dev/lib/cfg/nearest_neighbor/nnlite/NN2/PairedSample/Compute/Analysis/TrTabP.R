#--------------------
# filtering
#--------------------
name.SCORE.1 <- paste('SCORE', 1,  sep='_')
name.SCORE.2 <- paste('SCORE', 2,  sep='_')
if (variant.type=='All')
{
  id.t.1 <- which(sh.p[, name.SCORE.1]<thd)
  id.t.2 <- which(sh.p[, name.SCORE.2]<thd)
}

if (variant.type=='SNPs')
{
  id.t.1 <- which(sh.p[, name.SCORE.1]<thd | str.space(sh.p[,'VariantID'])=='')
  id.t.2 <- which(sh.p[, name.SCORE.2]<thd | str.space(sh.p[,'VariantID'])=='')
} 
  
if (variant.type=='Novel')
{
  id.t.1 <- which(sh.p[, name.SCORE.1]<thd | str.space(sh.p[,'VariantID'])!='')
  id.t.2 <- which(sh.p[, name.SCORE.2]<thd | str.space(sh.p[,'VariantID'])!='')
} 

id.t <- unique(c(id.t.1, id.t.2))

if (length(id.t)>0) sh.p.tc <- sh.p[-id.t, ] else sh.p.tc <- sh.p

