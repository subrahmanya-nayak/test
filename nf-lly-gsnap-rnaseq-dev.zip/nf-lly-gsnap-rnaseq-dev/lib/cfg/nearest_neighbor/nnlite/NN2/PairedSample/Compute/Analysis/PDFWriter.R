#-------------
# dir setting
#-------------
thd <- Threshold
thd.angle <- round(thd/pi*180)
if (show.loh.A[j]==1) LOH.lab <- 'LOH' else LOH.lab <- 'RAW' 
dir.pic.1 <- paste(OUTPUT.N, '/', LOH.lab, '_', thd.angle, '/', sep='')   #normal pic folder
dir.pic.2 <- paste(OUTPUT.T, '/', LOH.lab, '_', thd.angle, '/', sep='')   #Tumor pic folder
dir.pic.p <- paste(OUTPUT, '/', LOH.lab, '_', thd.angle, '/', sep='')  #Paired pic folder
 

#-------------
# chr list
#-------------
dir.data.pro <- paste(dir.table, 'DataPro', '/', sep='')        #Processed data file
file.table <- paste(dir.data.pro, NAME, '_', 'combined', '_', method.quality,  '.csv', sep='')
sh.p=read.csv2(file.table)
chr.a <- unique(sh.p[,1])

#---------------------
# document parameters
#---------------------
doc.class <- '\\documentclass[12pt]{article}'
package <- c('graphicx', 'lscape')
doc.package <- paste('\\usepackage', '{', package, '}', sep='')
doc.style <- '\\pagestyle{empty}'

#---------
# content
#---------
m.1 <- method.NGS
file.pic.sum.1 <- getDirComplete(WD, paste(dir.pic.1, 'A', '_', NAME.N,  '_', variant.type, '_', m.1, '_', LOH.lab, '.', pic.format, sep=''))
file.pic.sum.2 <- getDirComplete(WD, paste(dir.pic.2, 'A', '_', NAME.T,  '_', variant.type, '_', m.1, '_', LOH.lab, '.', pic.format, sep=''))
file.pic.sum.p <- getDirComplete(WD, paste(dir.pic.p, 'A', '_', NAME,  '_', variant.type, '_', m.1, '_', LOH.lab, '.', pic.format, sep=''))
file.pic.sum <- c(file.pic.sum.1, file.pic.sum.2, file.pic.sum.p)
doc.content <- '\\begin{landscape}'
doc.content <- c(doc.content, latex.pic(file.pic.sum, width=format.num(tex.height*3/5, digit.right=2), height=tex.width, angle=270))
doc.content <- c(doc.content, '\\end{landscape}')
doc.content <- c(doc.content, '\\newpage')

nc.pic <- 2                               #for chromosome picture
nr.pic <- 3
n.per <- nc.pic                           #now each row is for one type of analysis
n.page <- floor(length(chr.a)/n.per)
if (n.page*n.per < length(chr.a)) n.page <- n.page+1 
for (i in 1:n.page)
{ 
  if (i<n.page) 
  {  
    chr.1 <- chr.a[(i-1)*n.per+(1:n.per)]
    file.pic.chr.1=file.pic.chr.2=file.pic.chr.p=rep('',length(chr.1))
    for (j in 1:length(chr.1)) 
    {
      file.pic.chr.1[j]=getDirComplete(WD, paste(dir.pic.1, NAME.N, '_', variant.type, '_', m.1, '_', chr.1[j], '_', LOH.lab, '.', pic.format, sep=''))
      file.pic.chr.2[j]=getDirComplete(WD, paste(dir.pic.2, NAME.T, '_', variant.type, '_', m.1, '_', chr.1[j], '_', LOH.lab, '.', pic.format, sep=''))
      file.pic.chr.p[j]=getDirComplete(WD, paste(dir.pic.p, NAME, '_', variant.type, '_', m.1, '_', chr.1[j], '_', LOH.lab, '.', pic.format, sep=''))
    }
    file.pic.chr <- c(file.pic.chr.1, file.pic.chr.2, file.pic.chr.p)
    doc.content <- c(doc.content, '\\begin{landscape}')
    doc.content <- c(doc.content, latex.pic(file.pic.chr, width=tex.height/2, height=tex.width/2, m=nc.pic, angle=270, space=''))
    doc.content <- c(doc.content, '\\end{landscape}')
    doc.content <- c(doc.content, '\\newpage')
  }
  if (i==n.page)
  {
    chr.1 <- chr.a[((i-1)*n.per+1):length(chr.a)]
    file.pic.chr.1=file.pic.chr.2=file.pic.chr.p=rep('',length(chr.1))
    for (j in 1:length(chr.1)) 
    {
      file.pic.chr.1[j]=getDirComplete(WD, paste(dir.pic.1, NAME.N, '_', variant.type, '_', m.1, '_', chr.1[j], '_', LOH.lab, '.', pic.format, sep=''))
      file.pic.chr.2[j]=getDirComplete(WD, paste(dir.pic.2, NAME.T,'_', variant.type, '_', m.1, '_', chr.1[j], '_', LOH.lab, '.', pic.format, sep=''))
      file.pic.chr.p[j]=getDirComplete(WD, paste(dir.pic.p, NAME, '_', variant.type, '_', m.1, '_', chr.1[j], '_', LOH.lab, '.', pic.format, sep=''))
    }
    file.pic.chr <- c(file.pic.chr.1, file.pic.chr.2, file.pic.chr.p)
    doc.content <- c(doc.content, '\\begin{landscape}')
    doc.content <- c(doc.content, latex.pic(file.pic.chr, width=tex.height/2, height=tex.width/2, m=nc.pic, angle=270, space=''))
    doc.content <- c(doc.content, '\\end{landscape}')
  }
}

pdf.tex <- c(doc.class, doc.style, doc.package, '\\begin{document}', doc.content, '\\end{document}')
file.tex <- paste(PDF,  NAME,  '_', variant.type, '_', m.1, '_', LOH.lab, '.tex', sep='')
write(pdf.tex, file.tex)

