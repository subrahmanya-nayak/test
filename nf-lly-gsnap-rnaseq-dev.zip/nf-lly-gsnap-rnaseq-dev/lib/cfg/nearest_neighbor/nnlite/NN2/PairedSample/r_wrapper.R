#minimal_analysis_wrapper
#  John Calley 9/17/14
#    -Need to make some major modifications because the behavior of reading
#     large number of small files very fast was causing Isilon to fail (or at
#     least this was a prime suspect for a while. Not sure that I believe it)
#    -Took the opportunity to clean up a some other cruft.
#  John Calley 9/1/14
#    First attempt to put a minimal wrapper around Xiwen's NN analysis to
#    make it easier to call it more flexibly. This is hacked out of Xiwen's 
#    Analysis_One.T script and includes parts of his Analysis.R as well.
#
# First argument is '/' terminated path to directory containing 
# Xiwen's scripts.
# Arg2 is path to file containing aligned, filtered quant files in the form
# that Xiwen's Pairing.R creates in his set-up. We bypass a lot of stuff by
# just providing it directly.
# Arg3 is path to output file
#  
#
#---------------
# Cluster Input
#---------------
##   Analysis_One takes a whole lot of positional command line arguments that
##   are always constant for my analysis, so I just set them as constants
##   here:  (some of this is probably no longer necessary)
BUILD <- 3
WEIGHT <- "Equal"
method.NGS <- "BGIe"
variant.type <- "All"
Threshold <- 0
pic.format <- "jpg"
indel.del  <- 20
indel.word <- "indel"
col.warning <- 100
col.ref     <- 6  #refbase column
col.ID <- 100
col.start <- 7  #Start of A/G/C/T count columns
col.end <- 10   #Last of A/G/C/T count columns
nucleotides <- c("A", "G", "T", "C");
header.input <-  unlist(strsplit("F-F", split='-'))

#wrapper takes names and file paths on its command line that Analysis_One
#expected to have in globals. Set this up here.
#Also, note that I switched to trailingOnly for commandArgs
args <- unlist(strsplit(unlist(commandArgs(TRUE)), " "))
PACKAGE <- args[1]
COMPARE.FN <- args[2]  #Path to file containing concatenated input pairs of datasets
num_comparisons <- as.numeric(args[3])  #Number of comparisons

#We aren't actually using these directories with the current
#calling methods but other stuff expects them to be around.
#Put them in /tmp and remove them at finish.
STORE.RT <- paste("/tmp/", Sys.getpid(), ".STORE",sep='')
OUTPUT.FN <- args[4]


#-------------
# dir setting
#-------------
#OUTPUT <- OUTPUT.RT
STORE <- STORE.RT
#I've eliminated as much of Xiwen's unnecessary directory creation as I can. I
#can't eliminate the following, for now, because one of the sourced scripts
#wants this there (though it doesn't use it for anything). I added the
#showWarnings=FALSE here (and in NN.R) so as to at least remove the warnings.
dir.create(STORE, recursive = TRUE, showWarnings = FALSE)
dir.table <- paste(STORE, 'Table', '/', sep='') 
dir.create(dir.table, showWarnings = FALSE)
###

#-----------------------
# Predefined functions
#-----------------------
source(paste(PACKAGE, 'Toolbox/general.R', sep=''))
sourceDir(paste(PACKAGE, 'Toolbox/', sep=''))


#Read the COMPARE.FN file to create a list of paths to quant files


#----------------
# General Input
#----------------
method.quality <- 'coverage'                           
Read.Thd <- 6                                                # Third allele number threshold
Dist.Thd <- 0                                                # Threshold in the distance
Dist.Method <- c('Manh', 'KL', 'HE', 'Chi2')                 # Distance metrics
epsilon <- 1e-10                                             # If zero distance between different sample then add a small value
WriteTab <- FALSE                                            # If tables are generated
WriteDist <- FALSE                                           # If distance table is generated
WriteReport <- FALSE                                         # If the final table is generated
PlotDist <- FALSE                                            # If pictures are generated
PlotDiag <- FALSE                                            # If diagnosis plot (correlation) is generated
chr.order <- paste('chr', c(1:22, 'X', 'Y'), sep='')
header = rep(TRUE,2)
for (i in 1:2) if (header.input[i]=='F') header[i]=FALSE
header.pos <- TRUE

#-----------------
# plot parameters
#-----------------
dp.min=0
dp.max=1
cex.min.gw=0.2                        #Genome wide
cex.max.gw=0.2
lty <- 1:4         
col <- c('blue', 'purple', 'red', 'darkgrey')
pch <- 1:4
width=16   
height = width/2 
res=100

###begin the work
Report <- data.frame(matrix(NA,num_comparisons,10))
colnames(Report) <- c("NAME_1","NAME_2","PLATFORM","VARIANT",
                      "THRESHOLD","SIZE","Manh","KL","HE","Chi2")

###Read our input file as follows:
###   Read 1 line, this tells us the number of data lines and the names of the
###   two samples we are comparing. Then read the indicated number of
###   lines to create the sh.p table
all_input_data = file(COMPARE.FN)
open(all_input_data)
set_num <- 1;
data_classes = c('character', 'integer', rep('integer',12), 'character')
while (1) {
    spec = unlist(strsplit(readLines(all_input_data,1), split="\t"));
    num_lines = as.numeric(spec[1])
    
    #Xiwen's code wants the same name info in two different variables
    name.a = spec[2:3]
    NAME   = name.a
    #print(NAME)
    sh.p = read.table(all_input_data, nrows = num_lines - 1, header = TRUE, sep = "\t", 
                      as.is=TRUE, comment.char = "", fill = TRUE, 
                      colClasses = data_classes)
    #Xiwen wants names.read set as follows:
    names.read = c("V7", "V8", "V9", "V10");
    source(paste(PACKAGE, 'PairedSample/Compute/Analysis/NN.R', sep=''))     #NN calculation 
    Dist=Dist

    Report[set_num,]=report.nn
    set_num <- set_num + 1
    if (set_num > num_comparisons) {
        break
    }

}
write.table(Report,file=OUTPUT.FN,quote=FALSE,sep="\t",row.names=FALSE)
close(all_input_data)
unlink(STORE, recursive = TRUE)
warnings()
quit();
