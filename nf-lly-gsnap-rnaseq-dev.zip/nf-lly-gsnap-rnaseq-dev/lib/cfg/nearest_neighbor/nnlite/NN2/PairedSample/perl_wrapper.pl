#!/usr/bin/env perl
#===============================================================================
#
#         FILE:  perl_wrapper.pl
#
#        USAGE:  ./perl_wrapper.pl
#
#  DESCRIPTION:  perl wrapper makes it a bit easier to call r_wrapper.R from
#  the comman line or from other scripts by handling location informaion and
#  re-formatting the input data.
#
#      OPTIONS:  ---
# REQUIREMENTS:  ---
#         BUGS:  ---
#        NOTES:  ---
#       AUTHOR:  John Calley
#      VERSION:  0.01
#      CREATED:  09/22/14 10:39:18 EDT
#     REVISION:  ---
#     REVISION HISTORY:
#   0.05 John Calley 10/14/22
#     --Really hate this hard-coded R binary path here. Changed to a more
#     modern R that is available in our AWS installation.
#   0.04 Corey James 07/18/18
#     -- changed regex substitution for $r_package_home to remove /lrlhps.. or
#     /.lrlhps... due to RHEL6 & RHEL7 testing and split environments. Should be
#     ok to leave for future.
#   0.03 John Calley 10/17/14
#     --If there are no valid pairs to send to R don't try to call it.
#   0.02 John Calley 9/29/14
#     --Fixed a problem miscounting what I was sending to R when one of the
#     inputs had too few rows.
#===============================================================================

use strict;
use warnings FATAL => 'all';

use FindBin;
use Getopt::Std;
use File::Temp qw(tempdir);
use File::Path qw(mkpath);
use List::Util qw(sum);

#my $r_bin = '/lrlhps/apps/R/R-3.4.1/bin/R';
my $r_bin = '/usr/local/R/4.1.2/bin/R';
(my $r_package_home = $FindBin::Bin) =~ s/[^\/]+$//;
my $r_wrap = "$FindBin::Bin/r_wrapper.R";

my $def_wd = "/node/scratch";
my $def_min_reads = 6;
my $def_min_shared_positions = 10;

our ($opt_o, $opt_w, $opt_m, $opt_s, $opt_e);

my $usage = <<"END_USAGE";
$0 -o fn -e fn [-w dn] [-m #] [-s #] fn1 fn2
-o fn    --Output file location. Required.
[-e fn]  --Output file for skipped comparisons.
[-w dn]  --Directory to place temporary files. Default is $def_wd.
[-m #]   --Minimum number of reads for a position to be used. Default value is
           $def_min_reads (which is what Xiwen used). Any count for a base
           less than this value will be set to 0 and will not participate in
           the total depth or the allele count.
[-s #]   --Minimum required number of shared positions for it a distance to
           be calculated. The default is $def_min_shared_positions.

fn1      File containing 1 or more concatenated quant files with an added
         initial column giving the assay id. No title line.
         Each concatenated quant file begins with a line that looks like the
         following:
         ->START <name> REPEAT <number>
         Where <name> is the assay/sample id and <number> is the number of
         times to repeat the quant data to match with the data in file #2.
fn2      See above. Quant files to compare with those in fn1.

         The number of assays in file #1 must match the number in file #2.

Reformat the input quant files as needed so that they can be read by
r_wrapper.R.  Run r_wrapper.R to generate distances.
The result of this script is identical to the result of Xiwen's Pairing.R
script, so we can skip it and all preceding scripts.
END_USAGE


if (!getopts('o:w:m:s:e:' or $#ARGV != 1)) {
    die $usage;
}
if (!$opt_o) {
    die "$usage\n\n-o is required.\n";
}

my $fn1 = shift;
my $fn2 = shift;

#Create path to output file if needed.
if ($opt_o =~ m/\//) {
    (my $odn = $opt_o) =~ s/\/[^\/]*$//;
    mkpath($odn);
}

if (!defined $opt_m) {
    $opt_m = $def_min_reads;
}
my $min_shared_positions = $opt_s || $def_min_shared_positions;

my $wd_loc = $opt_w || $def_wd;
my $wdn = tempdir(DIR => $wd_loc, CLEANUP=>1);

#Read all the input. Create a sorted list of positions and count how many
#assays we have in each input file.

my %all_pos;
my %fn2assays;
my %data;

foreach my $fn ($fn1, $fn2) {
    open my $fh, '<', $fn
        or die "Unable to open file $fn for reading ($!). Stopped";
    while (my $line = <$fh>) {
        chomp $line;
        if ($line =~ m/^->START\s+(\S+)\s+(\d+)/) {
            my ($asy, $rep) = ($1, $2);
            push  @{$fn2assays{$fn}}, ($asy) x $rep;
        } else {
            my ($asy, $chr, $pos, $warn, $depth, $alleles,
                $ref, $a_cnt, $g_cnt, $t_cnt, $c_cnt, $com)
               = split(/\t/, $line);
            next if ($depth < $opt_m);
            $alleles = 0;
            #Xiwen 0's any count < min_count(6) and then checks for multiple alleles, etc
            foreach my $tmp_cnt ($a_cnt, $g_cnt, $t_cnt, $c_cnt) {
                if ($tmp_cnt < $opt_m) {
                    $tmp_cnt = 0;
                } else {
                    $alleles++;
                }
            }
            next if ($alleles > 2);
            my $total_cnt = sum($a_cnt, $g_cnt, $t_cnt, $c_cnt);
            next if ($total_cnt < $opt_m);

            $all_pos{$chr}{$pos} = 1;
            $data{$asy}{$chr}{$pos} =
                [$a_cnt, $g_cnt, $t_cnt, $c_cnt, $total_cnt];
        }
    }
}



my @ordered_chr = sort keys %all_pos;

my $wfh;

my $r_ifn = "$wdn/r_input.txt";
open my $ofh, '>', $r_ifn
    or die "Unable to open file $r_ifn for writing ($!). Stopped";
my @titles = qw(chr pos
                V7_1 V8_1 V9_1 V10_1 SCORE_1 REMARK_1
                V7_2 V8_2 V9_2 V10_2 SCORE_2 REMARK_2
                VariantID);

my @assay1_lst = @{$fn2assays{$fn1}};
my @assay2_lst = @{$fn2assays{$fn2}};
my $num_asy1 = scalar @assay1_lst;
my $num_asy2 = scalar @assay2_lst;
if (!$num_asy1 or !$num_asy2 or $num_asy1 != $num_asy2) {
    die "The number of assays in file 1 must match the number in file 2. We "
      . "got $num_asy1 in $fn1 and $num_asy2 in $fn2. Stopped";
}


my $asy1 = shift @assay1_lst;
my $pair_count = 0;
while (my $asy2 = shift @assay2_lst) {
    my @lines;
    foreach my $chr (@ordered_chr) {
        foreach my $pos (sort {$a<=>$b} keys %{$all_pos{$chr}}) {
            my $asy1_data_lref = $data{$asy1}{$chr}{$pos};
            my $asy2_data_lref = $data{$asy2}{$chr}{$pos};
            if ($asy1_data_lref and $asy2_data_lref) {
                push @lines, join("\t", $chr, $pos,
                                        @$asy1_data_lref, '',
                                        @$asy2_data_lref, '',
                                    1);
            }
        }
    }
    my $num_lines = scalar @lines;
    if (scalar $num_lines > $min_shared_positions) {
        $pair_count++;
        print {$ofh} join("\t", $num_lines+1, $asy1, $asy2), "\n";
        print {$ofh} join("\t", @titles), "\n";
        foreach my $line (@lines) {
            print {$ofh} "$line\n";
        }
    } elsif ($opt_e) {
        if (!$wfh) {
            open $wfh, '>', $opt_e
                or die "Unable to open file $opt_e for writing ($!). Stopped";
        }
        print {$wfh} "Skipping $asy1 x $asy2 $num_lines shared positions "
                   . "< $min_shared_positions\n";
    }
    if (@assay1_lst) {
        $asy1 = shift @assay1_lst;
    }
}
close $ofh;
close $wfh if ($wfh);

if ($pair_count) {
    my $cmd = "$r_bin --slave --args $r_package_home $r_ifn $pair_count $opt_o <$r_wrap";
    (system( $cmd) == 0)
       or die "Unable to execute $cmd. ($!) Stopped";
}
exit;
