#----------------------------
# Nearest Neighbor Package
#----------------------------
#WD                --- Working directory, where you want to store your input and output
#PACKAGE:          --- NN package directory, must be full directory
#BUILD:            --- Need Basic computations?  1=Initial, 2=Plot pictures, 3=Initial + Plot.
#NAME:             --- Pairwise sample names separate by "---"
#INPUT1:           --- first sample path, can be a vector
#INPUT2:           --- second sample path, not use for one sample study, can be a vector
#OUTPUT:           --- Output directory, w.r.t working directory, containing figures.
#REPORT:           --- Report directory, w.r.t working directory, containing reports.
#STORE:            --- Intermediate calculation, data directory, w.r.t working directory
#POSITION:         --- Position file with or without weight (if without use equal weight). Pairwise = use pairwise common positions
#WEIGHT:           --- Equal = 'equal weight', Input = use the weight in POSITION file
#method.NGS:       --- NGS platform
#variant.type:     --- Type of variant used in the analysis, either 'All', 'SNPs' or 'Novel' 
#Threshold:        --- Coverage Threshold in the analysis. 0 = no threshold
#pic.format        --- 'eps' = eps output file, 'jpg' = jpg output file.  Note that eps will generate for too much data. 

BUILD <- 3
WEIGHT <- 'Equal'
method.NGS <- 'BGIe'
variant.type <- 'All'
Threshold <- 0 
pic.format <- 'jpg'
indel.del <- 20
indel.word <- 'indel'
col.warning <- 100                                             # Warning column, leave 100 if no warning
col.ref <- 6                                                 # Reference column
col.ID <- 100                                                # ID SNPs id column
col.start <- 7                                               # Reads start column following 'nucleotides'
col.end <- 10  
nucleotides <- 'A_G_T_C'

#------------
# Start 
#------------ 
source(paste(PACKAGE, 'Cluster/NN.R', sep=''))                 #Generate line only
#source(paste(PACKAGE, 'Cluster/Cluster.R', sep=''))           #Generate line and then write as cmd file
