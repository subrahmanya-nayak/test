#-------------------
# sort by position
#-------------------
sort.gen <- function(tab, colchr=1, colpos=2, chrorder=paste('chr', c(1:22, 'X', 'Y'), sep=''))
{
  chr.a <- unique(tab[,colchr])
  id.mth <- match(chrorder, chr.a)
  chr.a <- chrorder[!is.na(id.mth)]
  id.a <- 1:nrow(tab)
  st=1
  for (chr.1 in chr.a)
  {   
    id.1 <- which(tab[,colchr]==chr.1)
    id.a[st:(st+length(id.1)-1)]=id.1[order(tab[id.1, colpos])]
    st <- st+length(id.1)
  }
  tab[id.a,]
}

#----------------------
# SNP-NGS converter
#----------------------
#if not match with nucleotides, then treat as missing, this program can be generally use for other matching counting process
SNPtoNGS <- function(G, nucleotides=c('A', 'G', 'T', 'C'), per=60)
{
  counts <- rep(0, length(nucleotides))
  geno = unlist(strsplit(G, split=''))
  id <- fna( match(geno, nucleotides) )
  if (length(id)==length(geno)) counts[id] = counts[id]+60 else counts = rep(NA,length(nucleotides)) 
  counts
}
