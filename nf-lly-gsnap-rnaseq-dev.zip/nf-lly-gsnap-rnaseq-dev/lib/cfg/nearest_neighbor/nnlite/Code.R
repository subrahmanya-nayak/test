###1. Get parameters
params <- read.table("Params.txt", header=FALSE, stringsAsFactors=FALSE, check.names=FALSE)[,1]
PKG <- params[1]
QUAN <- params[2]
ETHN <- params[3]
POSI <- params[4]
METH <- params[5]

TAG <- "_quant.txt"

###load functions
source(paste(PKG, "general.R", sep=""))
###

###2. prepare
QUAN = checkDir(QUAN)
if (ETHN!="SKIP" & ETHN!="Skip") {
    ETHN = checkDir(ETHN)
}

files=list.files(QUAN)
quanf=files[which(grepl(TAG, files))]
quanfiles <- paste(QUAN, quanf, sep="")
fileList <- "list_quan.txt"
write.table(quanfiles, file=fileList, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)

if (ETHN!="SKIP" & ETHN!="Skip") {  
    files=list.files(ETHN)
    ethnf=files[which(grepl(TAG, files))]
    ethnfiles <- paste(ETHN, ethnf, sep="")
    fileList <- "list_ethn.txt"
    write.table(ethnfiles, file=fileList, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE)
}

STORE <- paste('./', 'TEMP/', sep='')
dir.create(STORE)
QUANT1 <- paste(STORE, 'Quant1/', sep='')
dir.create(QUANT1)
QUANT2 <- paste(STORE, 'Quant2/', sep='')
dir.create(QUANT2)
LIST <- paste(STORE, 'List/', sep='')
dir.create(LIST)

quanname <- quanf
for (i in 1:length(quanf)) quanname[i]=unlist(strsplit(quanf[i], "_quant.txt"))
list.input <- paste(QUANT1, quanname, '.txt', sep='')
write.table(list.input, file=paste(LIST, 'List1.txt', sep=''), row.names=FALSE, col.names=FALSE, quote=FALSE)


if (ETHN!="SKIP" & ETHN!="Skip") {  
    ethnname <- ethnf
    for (i in 1:length(ethnf)) ethnname[i]=unlist(strsplit(ethnf[i], "_quant.txt"))
    list.input <- paste(QUANT2, ethnname, '.txt', sep='')
    write.table(list.input, file=paste(LIST, 'List2.txt', sep=''), row.names=FALSE, col.names=FALSE, quote=FALSE)
}

###3. make prepare.cmd
if (ETHN!="SKIP" & ETHN!="Skip") {  
    K <- max(length(quanf), length(ethnf))
    cmd=rep("", K)
    for (i in 1:K) {
        cmd[i]=paste("/lrlhps/apps/R/R-2.14.1/bin/R --no-save --args", PKG, "Two list_quan.txt list_ethn.txt", POSI,  i,  paste("< ", PKG, "MK_SAMPLE_NonTabix.R", sep=""), sep=" ")
    } 
    write.table(cmd, file="PRE.cmd", quote=FALSE, sep="\t", row.names=FALSE, col.names=FALSE)
} else {
    K <- length(quanf)
    cmd=rep("", K)
    for (i in 1:K) {
        cmd[i]=paste("/lrlhps/apps/R/R-2.14.1/bin/R --no-save --args", PKG, "One list_quan.txt", POSI,  i,  paste("< ", PKG, "MK_SAMPLE_NonTabix.R", sep=""), sep=" ")
    } 
    write.table(cmd, file="PRE.cmd", quote=FALSE, sep="\t", row.names=FALSE, col.names=FALSE)
}
system('/lrlhps/apps/qblastem/qarray -f PRE.cmd -qo "-l cluster=brainiac -l mem_free=2G"')

###4. Conduct NN for quanfile
system(paste("/lrlhps/apps/R/R-2.14.1/bin/R --no-save --args ", PKG, " One Setting < ", PKG, "Interface_NN.R", sep=""))
system('/lrlhps/apps/qblastem/qarray -f NN2_cluster.cmd -qo "-l cluster=brainiac -l mem_free=2G"') 
system(paste('/lrlhps/apps/R/R-2.14.1/bin/R --no-save --args', PKG, 'One Merge', METH, 'No', paste('< ', PKG, 'Interface_NN.R', sep=''), sep=' '))
###

###5. Ethnicity Check 
if (ETHN!="SKIP" & ETHN!="Skip") {  
    system(paste('/lrlhps/apps/R/R-2.14.1/bin/R --no-save --args ', PKG, ' Paired Setting < ', PKG, 'Interface_Ethnicity.R', sep=''))
    system('/lrlhps/apps/qblastem/qarray -f Ethnicity_cluster.cmd -qo "-l cluster=brainiac -l mem_free=2G"')
    system(paste('/lrlhps/apps/R/R-2.14.1/bin/R --no-save --args', PKG, 'Paired Merge', METH, 'No', paste('< ', PKG, 'Interface_Ethnicity.R', sep=''), sep=' '))
}
###

###6. Finalize output
source(paste(PKG, "Finalize.R", sep=""))

