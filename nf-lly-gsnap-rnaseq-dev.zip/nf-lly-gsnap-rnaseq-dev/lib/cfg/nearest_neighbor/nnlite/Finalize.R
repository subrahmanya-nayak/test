#-----------
# Summarize
#-----------
Tab = read.csv(file="./REPORT/NN2_Distance_All_0_NN.csv", header=TRUE, stringsAsFactors=FALSE, check.names=FALSE)
Methods <- unlist(strsplit(METH, split="_"))
items <- c("NAME_1", "NAME_2", "SIZE", Methods)
Tab = Tab[,items]
write.table(Tab, file=paste("NN1", "_", METH, ".txt", sep=""), sep="\t", row.names=FALSE)

for (i in 1:length(Methods)) {
    vname <- unique(Tab[,1])
    M <- matrix(NA, length(vname), length(vname), dimnames=list(vname, vname))
    for (j in 1:length(vname)) {
        id <- which(Tab[,1]==vname[j])
        M[j,] = Tab[id[match(vname, Tab[id, 2])], Methods[i]]  
    }
    Tab2D = MDS.2D.Tab(M, label.a=vname)
    write.table(Tab2D, file=paste("NN1_2D", "_", Methods[i], ".txt", sep=""), sep="\t", row.names=FALSE)
    Tab3D = MDS.3D.Tab(M, label.a=vname)
    write.table(Tab3D, file=paste("NN1_3D", "_", Methods[i], ".txt", sep=""), sep="\t", row.names=FALSE)
}

if (ETHN!="SKIP" & ETHN!="Skip") {  
    Tab = read.csv(file="./REPORT/Ethnicity_Distance_All_0_NN.csv", header=TRUE, stringsAsFactors=FALSE, check.names=FALSE)
    Methods <- unlist(strsplit(METH, split="_"))
    items <- c("NAME_1", "NAME_2", "SIZE", Methods)
    Tab = Tab[,items]
    write.table(Tab, file=paste("NN2", "_", METH, ".txt", sep=""), sep="\t", row.names=FALSE)
}

#----
# rm 
#----
system("rm list*")
system("rm *.cmd")
system("rm Params.txt")
system("rm -r OUTPUT")
system("rm -r REPORT")
system("rm -r TEMP")