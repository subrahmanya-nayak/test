package meta_data;
#
#===============================================================================
#
#         FILE:  meta_data.pm
#
#  DESCRIPTION:  Read basic meta_data
#                Default get_meta reads from primary sources
#                (egs, assay2info.txt, meta_data.txt, ...)
#                get_meta_with_design returns data from design_file.txt
#                if available (returns 1), otherwise (returns 0) via get_meta
#
#        FILES:  ---
#         BUGS:  ---
#        NOTES:  ---
#       AUTHOR:  John Calley (jnc), <calley_john_n@lilly.com>
#      COMPANY:  Eli Lilly & Co.
#      VERSION:  1.0
#      CREATED:  2/19/15
#     REVISION:  ---
# Revision History:
#   0.65 John Calley 10/30/23
#     --get_qc_results was not correctly setting sample.exclude to T if all of
#     the assays were excluded in the case where there was only a single
#     assay. It waw only checking this situation when there ewas more than one
#     assay. No idea why this was so. Removed the check that there was more
#     than one assay and all is well.
#   0.64 John Calley 2/3/23
#     --Updated warning about missing genome alias to mention
#     genome_aliases.txt file
#   0.63 John Calley 11/4/22
#     --Moved the genome_aliases out to a file instead of hard-coded here.
#     --Removed a misleading usage of FindBin. We find the projects module
#     because it's in the same location as this module so is already in @INC.
#     FindBin is the location of the calling script, not this module. Need to
#     use the __FILE__ and __PACKAGE__ hack to find location of this module.
#   0.62 John Calley 11/4/22
#     --Added short names for reference genomes in the new 'calley_annotation'
#     directory for AWS move. Need to change this name to a more generic one.
#   0.61 John Calley 1/21/22
#    --Added interpretation of DNANexus derived project-data.json files to
#    derive aligned genome information. Current form of this is pretty fragile
#    (depending on pretty-print format from jq being exactly as expected).
#   0.60 John Calley 6/4/21
#    --Fixed a typo in the fix below
#   0.59 John Calley 6/3/21
#    --Allowed 'Unique.Total' as well as Unique/Total in RPM file. I bet R is
#    doing this.
#   0.58 John Calley 6/2/21
#   --Added several genome aliases
#   0.57 John Calley 6/1/21
#   --We seem to have an epidemic of assay2sample.txt files with " around the
#   assay and sample ids. Wish we could stop this from happening but for the
#   moment just modified get_assay2sample to remove all " characters.
#   --More informative error messages in edit_metadata_file
#   0.56 John Calley 5/26/20
#   --slightly improved an error message
#   0.55 John Calley 10/28/19
#     --No longer a fatal error to not have meta_data/meta_data.txt. We get
#     lots of meta_data from other places.
#   0.54 John Calley 1/24/19
#     --Made it a fatal error to have two identical columns in meta_data.txt.
#     Ideally we ought to check across all metadata sources but we're not
#     doing that yet.
#   0.53 John Calley 1/3/19
#     ---Added sample.detected_genes in the get_auto_meta_data for miRSeq and
#     RNASeq. Note that this is pretty time consuming. 14sec for a 263MB
#     simplistic_sample_level_rpm file. It is likely worthwhile for us to
#     compute this (and other auto values) and cache them in a supplementary
#     meta data file. Not doing this now.
#   0.52 John Calley 12/11/18
#     --Added several genome paths to the genome aliases.
#     --Now will only read project data gsnap config to find aligned genomes
#     if they are not already defined.
#     --read_study_metadata_files had clearly never been tested. Now works.
#   0.51 John Calley 11/29/18
#     --Minor modification to limit warning messages when study.id is empty.
#   0.50 John Calley 7/30/18
#     --Added write_meta. Since this is used by pipeline setup scripts it
#     needs to be able to set metadata in the absence of knowing the study id.
#     To accomodate this I am now allowing the special id '*' to set metadata
#     for the study without knowing the study name. We may want to enable this
#     functionality for assay and sample ids at some point in the future. For
#     now it is only legal for study level metadata files
#     (meta_data/meta_data_study_<tag>.txt).
#     --Added automatic reading of meta_data/meta_data_study_<tag>.txt files
#     for study level metadata (as we've been doing for a while for sample and
#     assay).
#   0.49 John Calley 2/23/18
#     --Moved get_project_type from here to the projects module but we still
#     export it from here so that existing scripts don't break.
#   0.48 John Calley 1/30/18
#     --We were exporting a non-existent function. Removed it.
#   0.47 John Calley 10/18/17
#     --Added project type of RepSeq
#   0.46 John Calley 9/21/17
#     --Added short name for Pig genome
#   0.45 James Scherschel 9/19/17
#     --Added project type DNA_chip and renamed project type snp6 to DNA_chip:snp6
#     --Added checks for invalid sample and assay ids...  Used warn rather than carp
#       for read-ability
#   0.44 John Calley 8/24/17
#     --Removed some dead code
#     --Modified the edit_meta_data procedure so that it keeps the original
#     permissions for all editted meta_data files.
#   0.43 John Calley 7/24/17
#     --Protected set_assay_pool and set_assay_library from being called if
#     %a2m is not passed into get_meta.
#     --Made an attempt to make set_assay_pool return identical results if
#     called more than once. Not fully tested.
#   0.42 John Calley 7/19/17
#     --Fixed a serious problem that was setting large numbers of
#     assay_excludes to 'T' because sample.exclude_reason was not false (but
#     could be '.').
#   0.41 John Calley 7/19/17
#      --Fixed a problem that led to 'Odd number of elements in hash' error
#      when get_meta_with_design called get_meta.
#   0.40 John Calley 7/18/17
#      --Added a verbose flag to get_meta and get_meta_with_design and many
#      other routines. By default they now suppress warnings. To turn them on
#      set verbose to 1.
#   0.39 John Calley 7/17/17
#      --Added another genome path for mouse_38_plus short name.
#   0.38 John Calley 7/17/17
#      --Improved error message when we have missing assays or samples so as
#      to identify the relevant results directory.
#   0.37 John Calley 7/17/17
#      --Reordered check_meta_content for assay and sample so sample comes
#      first as this is more likely to be informative.
#   0.36 John Calley 7/17/17
#      --Special cased getting rid of Excel added "" quoting for
#      sample.misc_attributes.
#   0.35 John Calley 7/17/17
#      --Added stripping of enclosing quotes on reading meta_data.txt and
#      meta_data_{assay,sample}.*.txt. In the latter also added stripping of
#      leading and trailing blanks.
#   0.34 James Scherschel 7/14/17
#      --Combined edit_sample_metadata_file and write_metadata_file into
#        edit_metadata_files with handling for multiple partial metadata files
#   0.33 John Calley 7/14/17
#      --Made sure that sample.library and sample.pool don't get into the final meta data. Both
#        of these may be in the initial sample meta data but are just used to guide the creation
#        of assay level data.
#   0.32 John Calley 7/13/17
#      --Fixed a typo.
#   0.31 John Calley 7/13/17
#      --When there are multiple read lengths use the max rather than the
#      second. The second used to be the max but somehow that's no longer
#      necessarily true.
#   0.30 John Calley 7/13/17
#      --Fixed a serious bug in reading QC results (%s2a mapping wasn't being
#      passed in properly).
#      --Fixed some places we were setting assay.warn instead of
#      assay.warning.
#   0.29 John Calley 7/13/17
#      --We were allowing an assay.library of '.' to be set in the incoming
#      meta data. Checked for this.
#   0.28 John Calley 7/13/17
#      --Fixed missing import.
#      --Fixed a typo in RNA count reading
#   0.27 John Calley 7/13/17
#      --Added RiboP genome path to genome aliases
#      --Fixed a problem in set_mir_count_totals
#   0.26 John Calley 7/12/17
#      --Absence of QC_results is now a warning rather than fatal.
#   0.25 John Calley 7/12/17
#     --Added get_project_type
#     --Replaced old read_assay2info with new get_assay2sample which will
#     return an assay2sample hash from assay2sample.txt first and
#     assay2info.txt only if it can't find assay2sample.txt.
#     --Removed very old tolerance for meta data files being directly in the
#     results directory instead of being in a meta_data sub-directory. This is
#     now fatal.
#     --get_meta now acts by calling clearly separated tasks to get different
#     kinds of meta data: get_assay2sample, get_basic_meta_data,
#     get_auto_meta_data, and get_qc_results.
#     --Moved a lot of automatic meta data from make_design_file to here and
#     removed all of it from make_design_file so we no longer have any
#     duplication of this.
#     --Removed some duplicative QC checks on reading data (sex_inference,
#     ancestry, 3p, etc).
#     --With the above changes, calling get_meta has become significantly
#     slower. For most purposes it is probably better to call
#     get_meta_with_design which will be much faster as long as a design_file
#     exists.
#     --Note that we may decide to cache some of this inference by creating AUTO
#     metadata files if this becomes a problem.
#   0.24 James Scherschel 7/7/17
#     --Added handling to merge sample and assay metadata from
#       /^meta_data_sample(_\.+)?\.txt$/ and /^meta_data_assay(_\.+)?\.txt$/
#       into what's available from assay2info.txt, meta_data.txt, etc
#       and to warn if conflicts occur
#   0.23 James Scherschel 5/2/17
#     --Modified comment line in read_inferred_sex
#   0.22 James Scherschel 3/29/17
#     --Added sub to pull assay.read_length from fq2attributes.txt
#   0.21 John  Calley 3/22/17
#     --Removed some out-of-date misleading comments.
#     --Changed a lot of warn's to carp to be more useful
#     --Added a new optional argument to get_meta_with_design to specify that
#       the design_file may be a sample level design file so assay.id is not
#       required.
#   0.20 John  Calley 3/9/17
#     --Fixed a typo that was causing us to complain about missing 3p bias
#     files when they weren't supposed to be there.
#   0.19 John  Calley 3/8/17
#     --Added std_text to standardize text in a consistent way before trying
#     to convert it into MESH codes.
#   0.18 James Scherschel 1/16/17
#     --Updates for the addition of expression_qc directory
#     --Ensuring trailing whitespace is trimmed in cleanup_mesh
#     --Shared logic for assay-vs-sample metadata column subsetting
#       between get_meta and get_meta_with_design
#   0.17 John Calley 1/13/17
#     --Added a little utility to clean up MESH code descriptions called
#     cleanup_mesh.
#   0.16 John Calley 1/9/17
#     --We were stripping leading/trailing blanks when we read the design_file
#     but not when we read meta_data.txt. Added it for meta_data.txt. Really
#     should be doing more rigorous stdization for tissue and disease
#     somewhere, maybe not here...
#   0.15 John Calley 1/5/17
#     --Added some better documentation to make_assay2meta.
#   0.14 John Calley 12/13/16
#     --Added optional argument to get_meta to allow meta_data to exclude
#     QC_results. This allows us to see warnings and excludes that are in
#     meta_data.txt independently of those in QC_results.txt.
#   0.13 John Calley 10/27/16
#     --Made it no longer be a fatal error for 3p_bias data to be missing.
#     This is fine for exome data and we sometimes use this to read meta data
#     from exome general_QC directories.
#   0.12 John Calley 10/10/16
#     --Changed read_meta to read_metadata_file to make clear(er) that it is
#     dealing with the file meta_data.txt and that file only. Also, changed it
#     so that it does read in the assay level data that gets put there
#     --Made it illegal for a meta_data.txt file to contain an assay.id field
#     to enforce the fact that only sample invariant meta data can be in this
#     file.
#     --This sub was only reading fields with name prefixes of 'study.' or
#     'sample', now it will read any field, so it now reports assay level data
#     (and anything we may add in the future).
#     --Exported read_metadata_file
#     --Added and exported edit_sample_metadata_file and
#     write_sample_metadata_file.
#   0.11 John Calley 10/3/16
#     --We were checking for 'Y' for exclude and warning, it should be 'T'.
#     Fixed this in read_qc_results.
#     --Fixed a logic error in read_qc_results that resulted in clobbering
#     some warning/exclude reasons.
#     --Also, modified things so that if we have a sample level
#     warning/exclude that is not at the assay level, we add it.
#   0.10 James Scherschel 9/28/16
#     --Removed assumption that all samples in assay2info would have metadata
#       Added check/warning for samples with no metadata
#       Added more information to warning and error messages
#   0.09 James Scherschel 9/27/16
#     --Corrected handling of string in regex
#   0.08 James Scherschel 9/27/16
#     --Added more error avoidance/detection for short/blank lines and
#     informative warnings
#   0.07 James Scherschel 8/30/16
#     --Added sub to read exclusion/warning QC annotations from QC_results.txt
#     and added method to distinguish pulling metadata from primary vs design
#   0.06 John Calley 11/19/15
#     --Added the 'study.' fields to the sample2meta results.
#   0.05 John Calley 8/21/15
#     --Added confess on no results directory for get_meta.
#   0.04 John Calley 7/30/15
#     --Added meta_status to return the most recent modification date of the
#     file(s) used to generate the returned meta_data and the file status.
#   0.03 John Calley 7/16/15
#     --Added the ability to optionally request assay level meta data. Only
#     available if design file exists.
#   0.02 John Calley 5/15/15
#     --Removed leading and trailing blanks from meta data just to lower the
#     impact of this frequent issue.
#===============================================================================

require Exporter;
@ISA       = qw(Exporter);
@EXPORT    = qw();
@EXPORT_OK = qw(
  get_assay2sample
  get_meta
  get_meta_with_design
  make_assay2meta
  meta_status
  edit_metadata_files
  write_meta
  cleanup_mesh
  std_text
  get_project_type
);

use strict;
use warnings;
use List::Util qw(min sum max);
use Carp qw(carp confess croak cluck);
use POSIX qw(strftime);
use File::Copy qw(move copy);
use File::Path qw(make_path);
use File::Basename;
use File::Temp qw(tempfile);
use projects qw(get_project_type);

####Set up some package level globals
my @little_words;
my %little_words;

my %type2req;

my %genome_aliases;

BEGIN {

    #Ugly hack to get location of this module and
    #my $genome_aliases_file = __FILE__;
    #my $package = __PACKAGE__  . '.pm';
    #$genome_aliases_file =~ s/$package/genome_aliases.txt/;
    my $genome_aliases_file = 'genome_aliases.txt';
 #We want MESH codes to look consistent.
 #    D###### - <text>( | D###### - <text>)*
 #    where <text is in title case.
 #   We'd also like to make sure that all MESH codes are valid and the text is
 #   a reasonable match. We're not doing that here
    @little_words =
      qw(a an the and but or as at but by for from in into of off on onto per to with);
    foreach my $wd (@little_words) {
        $little_words{$wd} = 1;
    }

    #A small start at making some of this more data driven
    %type2req = (
        RNASeq => {
            pooling       => 1,
            library       => 1,
            report_genome => 1,
        },
        RiboProfiling => {
            pooling       => 1,
            library       => 1,
            report_genome => 1,
        },
        miRSeq => {
            pooling       => 1,
            library       => 1,
            report_genome => 1,
        },
        exome => {
            pooling => 0,
            report_genome => 1,
        },
        snp6 => {},
    );

    open my $fh, '<', $genome_aliases_file
        or die "Unable to open file $genome_aliases_file for reading ($!). Stopped";
    while (my $line = <$fh>) {
        next if ($line =~ m/^#/);
        $line =~ s/\R$//;
        my ($alias, $name) = split(/\t/, $line);
        $genome_aliases{$name} = $alias;
    }
    close $fh;



}

sub cleanup_mesh {
    my $in_str = shift @_;

    return $in_str if (!$in_str or $in_str eq '.' or $in_str eq 'Normal');

#trim leading and trailing whitespace
# leading whitespace was already being handled, so this only really has potential to
# affect trailing whitespace on the last "text"
    $in_str =~ s/^\s+//;
    $in_str =~ s/\s+$//;

    my @clean;
    foreach my $item (split(/\s*\|\s*/, $in_str)) {
        if ($item =~ m/(D[0-9]{6})\s*-\s*(.*)/) {
            my ($code, $text) = ($1, $2);
            my @words = split(/\s+/, lc($text));
            foreach my $i (0 .. $#words) {
                if (!$little_words{ $words[$i] }) {
                    $words[$i] = ucfirst($words[$i]);
                }
            }
            $words[0] = ucfirst($words[0]);
            push @clean, join(' ', $code, '-', @words);
        }
        else {
            #die "$item is badly formed. Stopped";
            push @clean, $item;
        }
    }

    return join(' | ', @clean);
}

#We are trying to turn uncontrolled english text into standard MESH codes.
#This is a very painful manual process. to make this a bit easier, this
#routine does some basic standardization of the english text to remove some
#meaningless differences and allow us to sometimes look up previous MESH
#assignments.
#We:
#    Replace some English spellings with American spellings
#    Deal with T-Cell vs T Cell, etc.
#    Lower case everything
#    Remove some common and meaningless puctuation
#    Remove leading and trailing and consecutive blanks
my %spelling_std;

BEGIN {
    %spelling_std = (
        oesophagus => 'esophagous',
        leukaemia  => 'leukemia',
        't cell'   => 't-cell',
        'b cell'   => 'b-cell',
        tumour     => 'tumor',
    );
}

sub std_text {
    my $in_text = shift;

    $in_text = lc($in_text);
    $in_text =~ s/['"]//g;
    $in_text =~ s/[_;,:]/ /g;
    $in_text =~ s/\s+/ /g;
    $in_text =~ s/^\s+|\s+$//g;

    #We could compile this into a singl RE for speed but I'm feeling lazy
    #right now.
    while (my ($in, $out) = each %spelling_std) {
        $in_text =~ s/\b$in\b/$out/g;
    }

    return $in_text;
}

#There are several automatically generated meta data items that we pull out of
#pipeline results
#    Exactly what automatic meta data we have depends on the project type and,
#    in some cases, which parts of pipelines have been run.
#    Note that $a2m_href is optional if we don't want assay level data.
sub get_auto_meta_data {
    my ($results_dn, $project_type, $a2s_href, $s2a_href, $s2m_href,
        $a2m_href, $verbose)
      = @_;

    #If we have ancestry data read it.
    my $pas_fn =
      "$results_dn/expression_qc/ancestry/ancestry_results_status.txt";
    my $par_fn = "$results_dn/expression_qc/ancestry/structure.outfile.txt";
    if (-s $pas_fn and -s $par_fn) {
        read_predicted_ancestry($pas_fn, $par_fn, $s2m_href, $s2a_href,
            $verbose);
    }

    #Inferred Sex
    my $is_fn =
      "$results_dn/expression_qc/sex/sample_level_sex_inference.txt";
    if (-s $is_fn) {
        read_inferred_sex($is_fn, $s2m_href, $s2a_href, $verbose);
    }

    #3p bias
    my $s3pb_fn = "$results_dn/alignment_QC/sample_3p_bias_report.txt";
    if (-s $s3pb_fn) {
        read_3p_bias($s3pb_fn, $s2m_href, $s2m_href, $s2a_href, $verbose);
    }

    #Read pairing and length
    my $fq2attr_fn = "$results_dn/fq2attributes.txt";
    my $a2fq_fn    = "$results_dn/sample2fq.txt";
    if (-s $fq2attr_fn and -s $a2fq_fn and $a2m_href) {
        read_fq2attributes($a2fq_fn, $fq2attr_fn, $a2m_href, $verbose);
    }

    #Gene count totals
    my $gc_fn;
    if ($project_type eq 'RNASeq') {
        $gc_fn = "$results_dn/raw_counts/gene_count_totals.txt";
    }
    elsif ($project_type eq 'RiboProfiling') {
        $gc_fn = "$results_dn/xscript_raw_counts/gene_count_totals.txt";
    }
    elsif ($project_type eq 'miRSeq') {
        $gc_fn = "$results_dn/raw_counts/miR_count_totals.txt";
    }
    if ($gc_fn and -s $gc_fn and $a2m_href) {
        my %all_keys;
        if ($project_type eq 'RNASeq' or $project_type eq 'RiboProfiling') {
            set_rna_gene_count_totals($gc_fn, $a2m_href, $a2s_href);
        }
        elsif ($project_type eq 'miRSeq') {
            set_mir_count_totals($gc_fn, $a2m_href, $a2s_href);
        }

    }

    #Set sample.genes_detected. Currently only for projects with 
    #simplistic_sample_level_rpm (RNASeq and miRSeq).
    #Should also be defined for Exome, and RiboP at some point.
    #As with much of this auto stuff, we could cache it in a file.
    my $rpm_fn = "$results_dn/raw_counts/simplistic_sample_level_rpm.txt";
    if (-s $rpm_fn) {
        my $min_rpm = 1;  #A gene is 'detected' if RPM is >= $min_rpm
        open my $fh, '<', $rpm_fn
            or die "Unable to open file $rpm_fn for reading ($!). Stopped";
        my $title_ln = <$fh>;
        $title_ln =~ s/\R$//;
        my @titles = split(/\t/, $title_ln);
        my $first_smpl_col;
        my $max_col;
        my $cnt_class_col;
        foreach my $i (0..$#titles) {
            if ($titles[$i] eq 'Unique/Total' or $titles[$i] eq 'Unique.Total') {
                $cnt_class_col = $i;
            } elsif ($titles[$i] eq 'Max') {
                $max_col = $i;
            } elsif ($titles[$i] eq 'Total') {
                $first_smpl_col = $i+1;
                last;
            }
        }
        my %counts;
        if (!defined $first_smpl_col or !defined $cnt_class_col) {
            warn "Unexpected file format for $rpm_fn.\n";
        } else {
            while (my $line = <$fh>) {
                $line =~ s/\R$//;
                my @sp = split(/\t/, $line);
                next if ($sp[$cnt_class_col] eq 'Unique' or $sp[0] eq 'TotalReads');
                next if ($sp[$max_col] < $min_rpm);
                foreach my $i ($first_smpl_col..$#sp) {
                    if ($sp[$i] >= $min_rpm) {
                        $counts{$titles[$i]}++;
                    }
                }
            }
            foreach my $smpl (keys %$s2a_href) {
                $s2m_href->{$smpl}{'sample.detected_genes'} = $counts{$smpl}||0;
            }

        }
    }

    #Illumina machine/flowcell/lane/run and optional library
    my $a2i_fn       = "$results_dn/meta_data/assay2info.txt";
    my $have_library = 0;
    if (-s $a2i_fn and $a2m_href) {
        $have_library = read_assay2info_meta($a2i_fn, $a2m_href);
    }

    #If this is an RNASeq we look for alignment_QC_combined_aln_stats.txt. If
    #this file contains columns of the form 'ReadsMapped(.*)Pct we place these
    #int the sample meta data. They are Multiorganism project percentages
    #(usually mouse and human for a xenograft project).
    my $aln_stat_fn = "$results_dn/alignment_QC/combined_aln_stats.txt";
    if ($project_type eq 'RNASeq' and -s $aln_stat_fn) {
        read_rna_combined_aln_stats_meta($aln_stat_fn, $s2m_href, $a2s_href);
    }
    elsif ($project_type eq 'exome') {

        #For exome projects we look in the BAM stats files, but these exist
        #even in pure mouse projects and for them we can't tell which organism is
        #which. To do the right thing, we just read this if the entire project
        #is a human project which we determine by seeing if all the
        #sample.taxon values are equal to 9606 (human).
        read_human_exome_aln_stats($results_dn, $s2m_href, $s2a_href);
    }

    if ($type2req{$project_type}{report_genome}) {
        #If no samples have aligned_genome_paths, attempt to fill in from
        #project_data
        my $genome_paths_exists = 0;
        foreach my $smpl (keys %$s2a_href) {
            if ($s2m_href->{$smpl}{'study.aligned_genome_paths'}) {
                $genome_paths_exists = 1;
                last;
            }
        }
        if (!$genome_paths_exists) {
            get_aligned_genome($results_dn, $s2m_href, $s2a_href, $verbose);
        }
    }
}

#Given %a2s and %s2m from get_meta, return an index from assay to meta data.
#This is a duplication of all sample level meta_data under each assay id.
sub make_assay2meta {
    my ($a2s_href, $s2m_href, $a2m_href, $verbose) = @_;

    foreach my $asy (keys %$a2s_href) {
        my $smpl = $a2s_href->{$asy};
        if (!$smpl) {
            warn "WARNING: No sample for assay $asy -- skipping assay\n"
              if ($verbose);
            next;
        }

        #Make a copy so we don't depend on the continued existence of %s2m
        my %meta_copy = %{ $s2m_href->{$smpl} || {} };
        $a2m_href->{$asy} = \%meta_copy;
    }
}

#Attempt to read a file called 'design_file.txt' in the indicated directory,
#If it does not exist, look for meta_data source files and fill in all the
#data from them. This is much more time-consuming than just reading the design
#file, so calling this procedure makes sense unless there have been changes to
#meta_data (in which case make_design_file should be run).
#
#Data is returned in the referenced hashes:
#       %a2s        --assay id 2 sample id
#       %s2m        --sample id to meta data
#       %a2m        --assay to assay specific meta data. Optional.
#    The final argument is an optional set of
#    key value pair optional arguments.
#    Currently there are only a few optional arguments
#       sample_level => 1    --The design file is at the sample level. If not
#                              specified, assay.id is a required field in the design_file.
#       verbose      =>  1   --report warnings
#                    =>  0   --report only fatal errors (default).
#Returns 1 if design_file.txt was found (else returns 0)
sub get_meta_with_design {
    my ($rdn, $a2s_href, $s2m_href, $a2m_href, @optional_args) = @_;
    my %opt_args = @optional_args;
    $opt_args{sample_level} //= 0;
    $opt_args{verbose}      //= 0;

    my $foundDesignFile = 0;

    #First we try to find a design file. If we have it, we can get everything
    #we need in one place. If we don't have it, we need to patch it together
    #from assay2info and meta_data.txt.

    if (!$rdn or !-d $rdn) {
        confess "missing dn";
    }
    my $design_fn = "$rdn/design_file.txt";
    if (-s $design_fn) {
        read_design($design_fn, $a2s_href, $s2m_href, $a2m_href,
            $opt_args{sample_level}, $opt_args{verbose});
        $foundDesignFile = 1;
    }
    else {
        get_meta($rdn, $a2s_href, $s2m_href, $a2m_href, 'verbose',
            $opt_args{verbose});
    }

    return $foundDesignFile;
}

#
#Meta data comes from several basic sources:
#    assay2sample mapping             --assay2sample.txt (or assay2info.txt)
#                                       Call get_assay2sample
#    Basic, mostly sample level data, human derived
#                                     --meta_data.txt
#    Sample and assay meta-data which may be human derived or may come from
#    other automated sources external to the pipeline
#                                    --meta_data_sample*.txt and
#                                      meta_data_assay*.txt
#                                    --Call get_basic_meta_data to read these
#                                      sources
#    Pipeline derived, 'automatic' meta-data
#                                    --This comes from reading a variety of
#                                    pipeline generated files and differs
#                                    depending upon which pipeline has been
#                                    run.
#                                    Call get_auto_meta to get this.
#    QC data                         --Some comes from the basic meta-data
#                                      sources above, usually because it is
#                                      based on information from a vendor or a
#                                      publication
#                                      Most comes from interpretting the
#                                      QC_results.txt file.
#                                      Call get_qc_results to interpret the
#                                      QC_results.txt file.
#get_meta combines all of the above sources into a single set of sample (and
#optionally assay) level meta data.
#Data is returned in the referenced hashes:
#       %a2s        --assay id 2 sample id
#       %s2m        --sample id to meta data
#       %a2m        --assay to assay specific meta data. Optional.
#    The final argument is an optional set of
#    key value pair optional arguments.
#    Currently there are only one a few optional arguments
#       exclude_qc => 1      --0, the default, means do read the QC_results
#                              file, 1 means do not include QC_results.
#                              Note that this refers to the pipeline QC
#                              results, from QC_results.txt. QC results in the
#                              basic metadata will still be returned.
#       verbose      =>  1   --report warnings
#                    =>  0   --report only fatal errors (default).
#
sub get_meta {
    my ($rdn, $a2s_href, $s2m_href, $a2m_href, @optional_args) = @_;

    my %opt_args = @optional_args;
    $opt_args{exclude_qc} //= 0;
    my $verbose = $opt_args{verbose} // 0;

    if (!$rdn or !-d $rdn) {
        confess "missing results directory";
    }

    my $project_type = projects::get_project_type($rdn);

    get_assay2sample($rdn, $a2s_href, $verbose);

    #It's convenient to also have a sample2assay mapping
    my %s2a = ();
    foreach my $a (keys %{$a2s_href}) {
        if (not exists $s2a{ $a2s_href->{$a} }) {
            $s2a{ $a2s_href->{$a} } = [];
        }
        push @{ $s2a{ $a2s_href->{$a} } }, $a;
    }
    my $s2a_href = \%s2a;

    #        get_aligned_genome($rdn, $s2m_href, $s2a_href, $verbose);

    #Get copies of all_assay and all_sample ids that should exist here, before
    #we have possibly autovivified things into existence later.
    my @all_assays = keys %$a2s_href;

    #warn "NumAssay =", (scalar @all_assays), "\n";
    my @all_samples = keys %$s2a_href;

    #warn "NumSmpl =", (scalar @all_samples), "\n";

    get_basic_meta_data($rdn, $a2s_href, $s2a_href, $s2m_href, $a2m_href,
        $verbose);
    check_meta_content('Sample', "After basic sample level metadata in $rdn",
        \@all_samples, $s2m_href, $verbose);
    if ($a2m_href and %$a2m_href) {
        check_meta_content('Assay',
            "After basic assay level metadata in $rdn",
            \@all_assays, $a2m_href, $verbose);
    }

    get_auto_meta_data($rdn, $project_type, $a2s_href, $s2a_href, $s2m_href,
        $a2m_href, $verbose);
    check_meta_content('Sample',
        "After automatic sample level metadata in $rdn",
        \@all_samples, $s2m_href, $verbose);
    if ($a2m_href and %$a2m_href) {
        check_meta_content('Assay',
            "After automatic assay level metadata in $rdn",
            \@all_assays, $a2m_href, $verbose);
    }

    if (!$opt_args{exclude_qc}) {
        get_qc_results($rdn, $s2m_href, $a2m_href, $s2a_href, $verbose);
        check_meta_content('Sample', "After sample level QC_results in $rdn",
            \@all_samples, $s2m_href, $verbose);
        if ($a2m_href and %$a2m_href) {
            check_meta_content('Assay',
                "After assay level QC_results in $rdn",
                \@all_assays, $a2m_href, $verbose);
        }
    }

#Set up assay.library, as follows:
# There are 4 possible sources of library information. One and only one should
# be defined.
#   - For older meta_data files it may be defined as assay.library in the
#    meta_data.
#   - For newer meta_data files it may be defined as sample.library.
#   - When there is more than one library per sample it must be defined in
#    assay2info.
#   -If it is not defined in any of these places it will be set to the
#   sample id.
    if ($type2req{$project_type}{library} and $a2m_href and %$a2m_href) {
        set_assay_library($s2m_href, $a2m_href, $a2s_href);
    }

    #Set up assay.pool from one of several sources (assay2pool.txt,
    #sample.pool, or from flowcell and lane information.
    if ($type2req{$project_type}{pooling} and $a2m_href and %$a2m_href) {
        set_assay_pool($rdn, $s2m_href, $a2m_href, $a2s_href, $verbose);
    }
}

#Look in meta_data/ for:
#  meta_data.txt
#  Check for meta_data_sample*.txt and meta_data_assay*.txt
#and fill in what we can from these sources.
#  Mapping from sample2assay is required so that assay level metadata provided
#  at the sample level can be recorded by assay.
#  Mapping from assay2sample allows us to check for bad mappings in input
#  files.
#Data is returned in the referenced hashes:
#       %s2m        --sample id to meta data
#       %a2m        --assay to assay specific meta data. Optional.
sub get_basic_meta_data {
    my ($rdn, $a2s_href, $s2a_href, $s2m_href, $a2m_href, $verbose) = @_;

    if (!$rdn or !-d $rdn) {
        confess "missing dn";
    }

    #The sample level metadata file (meta_data.txt) can have assay_level meta
    #data in it. This is only legal if the assay level meta data is the same
    #for all assays associated with a sample. It is illegal to have different
    #metadata for different assays for the same sample in this file. It is
    #also illegal to have an assay.id entry in this file (which would make it
    #look like this worked.
    #Note that this file has Study, Sample, and Assay level meta data in it
    #(all sample invariant).  For the moment study level meta data is actually
    #stored as sample level.
    my $m_fn = "$rdn/meta_data/meta_data.txt";

    my %combo_s2m;

#assay.id is disallowed in metadata.txt, so no need to check for invalid assay ids here
    read_metadata_file($m_fn, \%combo_s2m, $s2a_href, $verbose);

    #Go through combo_s2m and move any assay level meta data into the assay
    #level hash and sample/study level into the sample hash.
    foreach my $smpl (keys %combo_s2m) {
        my @all_assays = @{ $s2a_href->{$smpl} || [] };
        foreach my $key (keys %{ $combo_s2m{$smpl} }) {
            if ($key =~ m/^assay\./) {
                foreach my $asy (@all_assays) {
                    $a2m_href->{$asy}{$key} = $combo_s2m{$smpl}{$key};
                }
            }
            else {    #sample and study
                $s2m_href->{$smpl}{$key} = $combo_s2m{$smpl}{$key};
            }
        }
    }

    #Check for meta_data_sample*.txt
    my $smpl_meta_dn = "$rdn/meta_data/";
    read_sample_metadata_files($smpl_meta_dn, $a2s_href, $s2m_href,
        $s2a_href, $verbose);
    read_study_metadata_files($smpl_meta_dn, $s2m_href, $verbose);

    #Check for meta_data_assay*.txt
    if ($a2m_href) {
        my $asy_meta_dn = "$rdn/meta_data/";
        read_assay_metadata_files($asy_meta_dn, $a2s_href, $a2m_href,
            $s2a_href, $verbose);
    }
}

#Return the latest -M modification time of the file(s) used to return meta data.
#Return -1 if there are no meta data files.
#Second return is the identity of the files that will be used for meta data.
#####NOTE: This is getting somewhat out of date. Do we really need it anymore?
#If so, does it really need to correctly id all the automatic sources? It
#doesn't at this writing...
sub meta_status {
    my ($rdn) = @_;

    #First we try to find a design file. If we have it, we can get everything
    #we need in one place. If we don't have it, we need to patch it together
    #from assay2info, meta_data.txt, and the other sources...

    my $design_fn = "$rdn/design_file.txt";
    if (-s $design_fn) {
        return (-M $design_fn, 'design_file');
    }
    else {
        my @mod_times;
        my @has;

        my $a_fn = "$rdn/meta_data/assay2info.txt";
        if (-s $a_fn) {
            push @mod_times, (-M $a_fn);
            push @has, 'assay2info';
        }

        my $fq2attr_fn = "$rdn/fq2attributes.txt";
        if (-s $fq2attr_fn) {
            push @mod_times, (-M $fq2attr_fn);
            push @has, 'fq2attributes';
        }
        my $a2fq_fn = "$rdn/sample2fq.txt";
        if (-s $a2fq_fn) {
            push @mod_times, (-M $a2fq_fn);
            push @has, 'assay2fq';
        }

        my $m_fn = "$rdn/meta_data.txt";
        if (-s $m_fn) {
            push @mod_times, (-M $m_fn);
            push @has, 'meta_data';
        }
        else {
            $m_fn = "$rdn/meta_data/meta_data.txt";
            if (-s $m_fn) {
                push @mod_times, (-M $m_fn);
                push @has, 'meta_data';
            }
        }

        #Check for meta_data_sample*.txt and meta_data_assay*.txt
        my $meta_dn = "$rdn/meta_data/";
        if (opendir(DH, $meta_dn)) {
            my @files = readdir(DH);
            @files = sort { $a cmp $b } @files;
            closedir(DH);

            foreach my $fn (@files) {
                if ($fn =~ /^(meta_data_sample(_.+)?)\.txt$/) {
                    my $hasValue = $1;
                    $fn = $meta_dn . $fn;
                    if (-s $fn) {
                        push @mod_times, (-M $fn);
                        push @has, $hasValue;
                    }
                }
            }

            foreach my $fn (@files) {
                if ($fn =~ /^(meta_data_assay(_.+)?)\.txt$/) {
                    my $hasValue = $1;
                    $fn = $meta_dn . $fn;
                    if (-s $fn) {
                        push @mod_times, (-M $fn);
                        push @has, $hasValue;
                    }
                }
            }
        }

        my $qc_fn = "$rdn/meta_data/QC_results.txt";
        if (-s $qc_fn) {
            push @mod_times, (-M $qc_fn);
            push @has, 'QC_results';
        }

        my $pas_fn =
          "$rdn/expression_qc/ancestry/ancestry_results_status.txt";
        my $par_fn = "$rdn/expression_qc/ancestry/structure.outfile.txt";
        if (-s $pas_fn and -s $par_fn) {
            push @mod_times, (-M $pas_fn);
            push @has, 'predicted_ancestry_status';
            push @mod_times, (-M $par_fn);
            push @has, 'predicted_ancestry_results';
        }

        my $si_fn = "$rdn/expression_qc/sex/sample_level_sex_inference.txt";
        if (-s $si_fn) {
            push @mod_times, (-M $si_fn);
            push @has, 'sex_inferred';
        }

        my $s3pb_fn = "$rdn/alignment_QC/sample_3p_bias_report.txt";
        if (-s $s3pb_fn) {
            push @mod_times, (-M $s3pb_fn);
            push @has, 'sample_3p_bias';
        }

        if (@mod_times) {
            return ((min @mod_times), join(',', @has));
        }
        else {
            return (-1, 'no_meta_data');
        }
    }
}

#We need a single definitive source of assay2sample mapping. Historically this
#was given in the assay2info.txt file along with some illumina specific assay
#level meta data. Then we started often providing it in an assay2sample.txt
#file which sometimes has a header line and sometimes does not.
#Here we look first for meta_data/assay2sample.txt. If we can't find it, we
#look for meta_data/assay2info.txt and just read the first two columns.
sub get_assay2sample {
    my ($rdn, $href, $verbose) = @_;

    my $fn1       = "$rdn/meta_data/assay2sample.txt";
    my $fn2       = "$rdn/meta_data/assay2info.txt";
    my $have_data = 0;
    if (-s $fn1) {
        open my $fh, '<', $fn1
          or die "ERROR: Unable to open file $fn1 for reading ($!). Stopped";
        my $ln_cnt = 0;
      LINE:
        while (my $line = <$fh>) {
            $ln_cnt++;
            if ($ln_cnt == 1 and $line =~ m/^AssayID\tSampleID\t/) {

                #Ignore optional header line if it looks just right.
                next LINE;
            }
            $line =~ s/\s+$//;
            next LINE if (!$line);
            $line =~ s/"//g;
            my ($asy, $smpl) = split(/\t/, $line);
            if ($asy and $smpl) {
                $href->{$asy} = $smpl;
                $have_data = 1;
            }
            else {
                die
"Missing assay or sample id on line $ln_cnt in $fn1. Stopped";
            }
        }
        close $fh;
    }
    elsif (-s $fn2) {
        warn
"Reading assay2sample information from assay2info.txt. Should be provided in assay2sample.txt instead.\n"
          if ($verbose);
        open my $fh, '<', $fn2
          or die "ERROR: Unable to open file $fn2 for reading ($!). Stopped";
        my $ln_cnt = 0;
      LINE:
        while (my $line = <$fh>) {
            $ln_cnt++;
            if ($ln_cnt == 1) {
                if ($line !~ m/^AssayID\tSampleID\t/) {

                    #For this file, the header line is required
                    die
"Expected header line with AssayID and SampleID in $fn2. Stopped";
                }
                else {
                    next LINE;
                }
            }
            $line =~ s/\s+$//;
            next LINE if (!$line);
            my ($asy, $smpl) = split(/\t/, $line);
            if ($asy and $smpl) {
                $href->{$asy} = $smpl;
                $have_data = 1;
            }
            else {
                die
"Missing assay or sample id on line $ln_cnt in $fn2. Stopped";
            }
        }
        close $fh;
    }

    if (!$have_data) {
        die
"Unable to retrieve assay2sample mapping from results directory $rdn. Stopped";
    }
}

#Read the assay level meta data from assay2info
#We ignore the assay2sample information. We've already got that.
#Return true iff we have library IDs as the optional 7th column.
sub read_assay2info_meta {
    my ($fn, $a2m_href) = @_;
    open my $fh, '<', $fn
      or die "Unable to open file $fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    $title_str =~ s/\s+$//;
    my $exp = "AssayID\tSampleID\tMachineID\tRunNum\tFlowCellID\tLaneNum";
    if ($title_str !~ m/^$exp/i) {
        die "File $fn did not have expected title line.\n"
          . "Expected: $exp\nGot:$title_str\n";
    }
    my $has_lib        = 0;
    my $has_lib_header = 0;
    if ($title_str =~ m/\tLibraryID$/i) {
        $has_lib_header = 1;
    }
    while (my $line = <$fh>) {
        $line =~ s/\s+$//;
        next if (!$line);
        my ($id, $smpl, $mach, $run, $fc, $ln, $lib) = split(/\t/, $line);

        if (!defined $fc or !defined $ln) {
            die "No lane or flowcell defined for line: $line.\n";
        }
        $a2m_href->{$id}{'assay.machine'}     = $mach;
        $a2m_href->{$id}{'assay.flow_cell'}   = $fc;
        $a2m_href->{$id}{'assay.lane'}        = $ln;
        $a2m_href->{$id}{'assay.machine_run'} = $run;
        if ($has_lib_header and $lib and $lib ne '.') {
            $a2m_href->{$id}{'assay.library'} = $lib;
            $has_lib = 1;
        }
    }
    close $fh;
    return $has_lib;
}

sub subdivide_cols {
    my @titles     = @_;
    my %a_meta2col = ();
    my %s_meta2col = ();
    my $smpl_col;
    my $assay_col;
    my $max_col = 0;

    foreach my $i (0 .. $#titles) {
        if ($titles[$i] eq 'sample.id') {
            $smpl_col = $i;
            $max_col  = $i;
        }
        elsif ($titles[$i] eq 'assay.id') {
            $assay_col = $i;
            $max_col   = $i;
        }
        elsif ($titles[$i] =~ m/^sample\./) {
            $s_meta2col{ $titles[$i] } = $i;
        }
        elsif ($titles[$i] =~ m/^study\./) {
            $s_meta2col{ $titles[$i] } = $i;
        }
        elsif ($titles[$i] =~ m/^assay\./) {
            $a_meta2col{ $titles[$i] } = $i;
        }
    }
    return (\%a_meta2col, \%s_meta2col, $smpl_col, $assay_col, $max_col);
}

#assay2meta_href is optional to gather assay level information.
sub read_design {
    my ($fn, $a2s_href, $s2m_href, $a2m_href, $smpl_level, $verbose) = @_;

    open my $fh, '<', $fn
      or die "ERROR: Unable to open file $fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    $title_str =~ s/\s+$//;
    my @titles = split(/\t/, $title_str);

    my @subdividedCols = subdivide_cols(@titles);
    my %a_meta2col     = %{ $subdividedCols[0] };
    my %s_meta2col     = %{ $subdividedCols[1] };
    my $smpl_col       = $subdividedCols[2];
    my $assay_col      = $subdividedCols[3];
    my $max_col        = $subdividedCols[4];

    if (!defined $smpl_col) {
        carp
"WARNING: No sample.id defined in design file $fn -- skipping design file\n"
          if ($verbose);
        return;
    }
    if (!$smpl_level and !defined $assay_col) {
        carp
"WARNING: No assay.id defined in design file $fn -- skipping design file\n"
          if ($verbose);
        return;
    }
    my $lineNbr = 1;
    while (my $line = <$fh>) {
        $lineNbr++;
        $line =~ s/\s+$//;
        if ($line eq '') { next; }
        my @sp = split(/\t/, $line);

        if (@sp <= $max_col) {
            carp "WARNING: Skipping short line at line #"
              . $lineNbr . " of "
              . $fn . "\n"
              if ($verbose);
            next;
        }

        my $smpl = $sp[$smpl_col];
        my $assay;
        if (defined $assay_col) {
            $assay = $sp[$assay_col];
        }
        else {
            $assay = $smpl;
        }
        foreach my $meta (keys %s_meta2col) {
            my $tmp = $sp[ $s_meta2col{$meta} ] || '';
            $tmp =~ s/^\s+|\s+$//g;
            $s2m_href->{$smpl}{$meta} = $tmp;
        }
        if ($a2m_href) {
            foreach my $meta (keys %a_meta2col) {
                my $tmp = $sp[ $a_meta2col{$meta} ];
                $tmp =~ s/^\s+|\s+$//g;
                $a2m_href->{$assay}{$meta} = $tmp;
            }

            #add an assay.sample field
            #Commented out the below because this isn't what we do elsewhere.
            #We rely on the %a2s hash for this. If we're going to do this we
            #should do it in get_meta too. We want meta data derived from both
            #sources to be the same. I'm commenting it out to try to flush any
            #dependencies out of the woodwork (7/11/17)
            #$a2m_href->{$assay}{sample} = $smpl;
        }
        $a2s_href->{$assay} = $smpl;
    }
    close $fh;
}

#Read the contents of the meta_data.txt file. This can be data at the sample
#level, at the study level, and even at the assay level as long as it is
#sample invariant. Note that to enforce sample invariance it is illegal to
#have an assay.id field.
sub read_metadata_file {
    my ($fn, $s2m_href, $s2a_href, $verbose) = @_;

    return if (!-s $fn); #might be setting meta_data via alternative files.
    open my $fh, '<', $fn
      or die "ERROR: Unable to open file $fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    $title_str =~ s/\s+$//;
    my @titles = split(/\t/, $title_str);
    my %s_meta2col;
    my $smpl_col;
    my $max_col = 0;
    foreach my $i (0 .. $#titles) {

        if ($titles[$i] eq 'sample.id') {
            if (defined $smpl_col) {
                die "Two columns labelled sample.id in $fn. Stopped";
            }
            $smpl_col = $i;
            $max_col  = $i;
        }
        elsif ($titles[$i] eq 'assay.id') {
            die
              "Illegal to have an assay id defined in sample level meta data."
              . "File is $fn. Stopped";
        }
        else {
            if (defined $s_meta2col{$titles[$i]}) {
                die "Two columns labelled $titles[$i] in $fn. Stopped";
            }
            $s_meta2col{ $titles[$i] } = $i;
        }
    }
    if (!defined $smpl_col) {
        carp
"WARNING: No sample.id defined in metadata file $fn -- skipping metadata file\n"
          if ($verbose);
        return;
    }
    my $lineNbr = 1;
    while (my $line = <$fh>) {
        $lineNbr++;
        $line =~ s/\s+$//;
        if ($line eq '') { next; }
        my @sp = split(/\t/, $line);

        if (@sp <= $max_col) {
            carp "WARNING: Skipping short line at line #"
              . $lineNbr . " of "
              . $fn . "\n"
              if ($verbose);
            next;
        }

        my $smpl = $sp[$smpl_col];
        if (not exists $s2a_href->{$smpl}) {
            warn
"ERROR: Unrecognized sample id at line #$lineNbr of $fn: $smpl \n";
        }
        foreach my $meta (keys %s_meta2col) {
            my $tmp = $sp[ $s_meta2col{$meta} ] || '';
            $tmp =~ s/^"(.*)"$/$1/;
            $tmp =~ s/^\s+|\s+$//g;
            if ($meta eq 'sample.misc_attributes') {

                #Get rid of Excel quote doubling as a special case for this
                #field.
                $tmp =~ s/\b([^=]+)=""([^"]*)""/$1="$2"/g;
            }
            $s2m_href->{$smpl}{$meta} = $tmp;
        }
    }
    close $fh;
}

#Arguments:
#    -result_directory
#    -meta_data file tag  As in file_name "meta_data_<level>_<tag>.txt"
#    -hash ref. First key is level (sample,assay,study), second key is entity
#     id (sample id, assay id, study id (or for study, the special id STUDY),
#         %meta{<LEVEL>}{<ID>}{<FIELD_NAME>} = <VALUE>
#     will result in the creation of a file called
#     meta_data/meta_data_<LEVEL>_<tag>.txt with a column called
#     <FIELD_NAME> and a row containing <VALUE>.
#     If level is 'sample' the <ID> will be in a column called 'sample.id',
#     ditto for assay and study (assay.id and study.id). The special id '*'
#     is allowed to match any id in the project.
#This procedure will create one or more meta data files in the
#<results>/meta_data directory. This is assumed to be an initial creation of
#the file(s).
sub write_meta {
    my ($rdn, $meta_tag_name, $meta_href) = @_;

    my $meta_dir = "$rdn/meta_data";
    if (!-d $meta_dir) {
        make_path($meta_dir)
          or die "Unable to make_path $meta_dir ($!). Stopped";
    }

    foreach my $level (keys %$meta_href) {
        my %all_fields;
        foreach my $id (keys %{ $meta_href->{$level} }) {
            @all_fields{ keys %{ $meta_href->{$level}{$id} } } = ();
        }
        my @all_col_heads = sort keys %all_fields;
        my $ofn = "$meta_dir/meta_data_${level}_${meta_tag_name}.txt";
        open my $ofh, '>', $ofn
          or die "Unable to open file $ofn for writing ($!). Stopped";
        print {$ofh} join("\t", "$level.id", @all_col_heads), "\n";
        foreach my $id (keys %{ $meta_href->{$level} }) {
            print {$ofh} join("\t",
                $id,
                map { $meta_href->{$level}{$id}{$_} || '.' } @all_col_heads),
              "\n";
        }
        close $ofh;
    }
}

#Modeled after edit_sample_metadata_file (and write_sample_metadata_file) and
# extends them to allow multiple partial metadata files.  Attempts to apply
# edits (deltas) to however whichever partial metadata files are affected
#Edits are applied to minimize the impact on "diff" results (ie, the
# ordered set of columns and the ordered list of rows are preserved in each file
# if possible.)
#
#NOTE: This is EDIT ONLY.  The addition of new metadata is disallowed.
#      Editing the assay-to-sample is expressly disallowed!
#      Currently, editing, eg, sample.* via assay.id is completely allowed.
#
#mode:
#   'preflight' to make sure that edits will be possible
#   'doit' to make the edits and create new meta_data*.txt file(s).
#The old meta_data*.txt file(s) will preserved with a name of:
#    .../meta_data/meta_data*.txt_<time_stamp>.bak
#    The time stamp may be passed in or, if empty, will be set to the current
#    date and time (formatted as YYYYmmdd-HHMMSS for easy sorting, eg 20170712-134502)
# edits_href is a hash reference with the structure:
#      {$id_type}{$id}{$meta_data_field} = $new_value
#      id_type must currently either be sample.id or assay.id
# issues_lref is a reference to a list that will contain strings describing
# problems (if any).
#To do this as safely as possible, call once in preflight mode. If there are
#no issues, call again in doit mode.
#Issues may be acumulated across multiple calls to the procedure.
sub edit_metadata_files {
    my ($mode, $rdn, $ts, $edits_href, $issues_lref) = @_;
    my $meta_dn = "$rdn/meta_data";

    ### Argument tests ###
    # avoid file I/O until we know it's worth going that far...
    my @local_issues = ();
    if ($mode ne 'preflight' and $mode ne 'doit') {
        push @local_issues, "Unrecognized mode: $mode";
    }
    if (!-d $rdn) {
        push @local_issues, "Invalid results directory: $rdn";
    }
    elsif (!-r $rdn) {
        push @local_issues, "Cannot read results directory: $rdn";
    }
    elsif (!-d $meta_dn) {
        push @local_issues, "Invalid meta_data directory: $meta_dn";
    }
    else {
        if (!-r $meta_dn) {
            push @local_issues, "Cannot read meta_data directory: $meta_dn";
        }
        if (!-w $meta_dn) {
            push @local_issues,
"Cannot create temp/backup files in meta_data directory: $meta_dn";
        }
    }
    if (!$edits_href) {
        push @local_issues, "No edits to apply!";
    }
    else {
        my ($bad_id_type_count, $bad_id_type_report_limit) = (0, 10);
        foreach my $id_type (sort { $a cmp $b } keys %{$edits_href}) {
            if ($id_type ne 'sample.id' and $id_type ne 'assay.id') {
                $bad_id_type_count++;
                if ($bad_id_type_count > $bad_id_type_report_limit) {
                    push @local_issues,
"Reached limit of unrecognized id_type values to report";
                    last;
                }
                else {
                    push @local_issues,
                      "Unrecognized id_type in \$edits_href: $id_type";
                }
            }
        }

 #explicitly disallow updates to the assay-to-sample(/sample-to-assay) mapping
        my $possible_remap = 0;
        if (exists $edits_href->{'sample.id'}) {
            foreach my $id (keys %{ $edits_href->{'sample.id'} }) {
                if (exists $edits_href->{'sample.id'}->{$id}->{'assay.id'}) {
                    $possible_remap = 1;
                    last;
                }
            }
        }
        if (!$possible_remap and exists $edits_href->{'assay.id'}) {
            foreach my $id (keys %{ $edits_href->{'assay.id'} }) {
                if (exists $edits_href->{'assay.id'}->{$id}->{'sample.id'}) {
                    $possible_remap = 1;
                    last;
                }
            }
        }
        if ($possible_remap) {
            push @local_issues,
              "Possible attempt to change assay-to-sample mapping";
        }
    }
    if (@local_issues) {
        push @$issues_lref, @local_issues;
        return;
    }

    ### Metadata files to consider ###
    # Directory check only...
    my $metadata_files_regex = '^meta_data(_(sample|assay)(_.+)?)?\.txt$';
    my @metadata_files       = ();
    opendir my $dh, $meta_dn
      or die
      "ERROR: Unable to open meta_data directory $meta_dn ($!). Stopped";
    my @files = readdir($dh);
    @files = sort {
        if   ((lc($a) cmp lc($b)) == 0) { return ($a cmp $b); }
        else                            { return (lc($a) cmp lc($b)); }
    } @files;
    closedir $dh;
    foreach my $file (@files) {
        if ($file =~ $metadata_files_regex) {

            #warn in the case of empty/non-readable files?
            if (!-s "$meta_dn/$file") { next; }
            if (!-r "$meta_dn/$file") { next; }
            push @metadata_files, $file;
        }
    }

    ### Metadata fields of interest -- grouped by the relevant id type (as specified in $edits_href) ... ###
# Two goals here:
#  Need to be able to identify files that have relevant idtype/attribute pairs
#  AND want to be able to identify id_types/attrs that aren't currently present in any user metadata file
    my %edits_idtype2filecount =
      ();    #How many files found existant for each idtype?
    my %edits_idtype2attr2filecount =
      ();    #And how many places is each idtype/attr pair found?
    foreach my $id_type (keys %{$edits_href}) {
        $edits_idtype2filecount{$id_type}      = 0;
        $edits_idtype2attr2filecount{$id_type} = {};
        foreach my $id (keys %{ $edits_href->{$id_type} }) {
            foreach my $attr (keys %{ $edits_href->{$id_type}->{$id} }) {
                $edits_idtype2attr2filecount{$id_type}->{$attr} = 0;
            }
        }
    }

    ### Check metadata files for columns of interest ###
    # Now we start incurring file I/O...
    my %origfile2attr2idx = ();
    my %origfile2header   = ();
    foreach my $file (@metadata_files) {
        open my $fh, '<', "$meta_dn/$file"
          or die
"ERROR: Unable to open metadata file $meta_dn/$file for reading ($!). Stopped";
        my $titles = <$fh>;
        $titles =~ s/\s+$//;    #chomp
        close $fh;
        my @sp = split(/\t/, $titles);

        my %file_attr2idx = ();
        my @idtypes       = ();
        for (my $j = 0 ; $j < @sp ; $j++) {
            $file_attr2idx{ $sp[$j] } = $j;
            if (exists $edits_idtype2filecount{ $sp[$j] }) {
                push @idtypes, $sp[$j];
            }
        }
        my $interest = 0;
        foreach my $idtype (@idtypes) {
            foreach my $title (@sp) {
                if (exists $edits_idtype2attr2filecount{$idtype}->{$title}) {
                    if ($interest == 0) {
                        $edits_idtype2filecount{$idtype}++;
                    }
                    $edits_idtype2attr2filecount{$idtype}->{$title}++;
                    $interest = 1;
                }
            }
        }
        if ($interest == 1) {
            $origfile2attr2idx{$file} = \%file_attr2idx;
            $origfile2header{$file}   = $titles;
        }
    }

# simple checks that the edits are for valid attributes in the set of files checked...
    if (0 + (keys %edits_idtype2filecount) == 0) {
        push @local_issues,
"None of the edits were applicable to non-empty read-able meta_data*.txt files in $meta_dn";
    }
    else {
        foreach my $id_type (keys %edits_idtype2filecount) {
            if ($edits_idtype2filecount{$id_type} == 0) {
                push @local_issues,
"None of the edited metadata fields for $id_type were present in the non-empty read-able meta_data*.txt files in $meta_dn";
            }
            else {
                foreach
                  my $title (keys %{ $edits_idtype2attr2filecount{$id_type} })
                {
                    if ($edits_idtype2attr2filecount{$id_type}->{$title} == 0)
                    {
                        push @local_issues,
"Edited metadata field $title was not found with $id_type in any of the non-empty read-able meta_data*.txt files in $meta_dn";
                    }
                }
            }
        }
    }
    if (@local_issues) {
        push @$issues_lref, @local_issues;
        return;
    }

    if (!$ts) {
        my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
          localtime(time);
        $ts = sprintf(
            "%04d%02d%02d-%02d%02d%02d",
            $year + 1900,
            $mon + 1, $mday, $hour, $min, $sec
        );
    }

    #Fetch the assay-to-sample mapping to obtain assay and sample id lists
    my %a2s = ();
    get_assay2sample($rdn, \%a2s);
    my %smpl_ids = ();
    foreach my $asy (keys %a2s) {
        $smpl_ids{ $a2s{$asy} } = 1;
    }

    #need to ensure that all edits have been applied to SOMEwhere
    # and check that the edits don't include new ids
    my %edits_idtype2id2attr_apply_count = ();
    foreach my $id_type (keys %{$edits_href}) {
        $edits_idtype2id2attr_apply_count{$id_type} = {};
        foreach my $id (keys %{ $edits_href->{$id_type} }) {
            if ($id_type eq 'sample.id') {
                if (not exists $smpl_ids{$id}) {
                    push @local_issues,
                      "Unrecognized sample.id in edits: $rdn:$id";
                }
            }
            elsif ($id_type eq 'assay.id') {
                if (not exists $a2s{$id}) {
                    push @local_issues, "Unrecognized assay.id in edits: $rdn:$id";
                }
            }
            $edits_idtype2id2attr_apply_count{$id_type}->{$id} = {};
            foreach my $attr (keys %{ $edits_href->{$id_type}->{$id} }) {
                $edits_idtype2id2attr_apply_count{$id_type}->{$id}->{$attr} =
                  0;
            }
        }
    }
    if (@local_issues) {
        push @$issues_lref, @local_issues;
        return;
    }

    #read original and write temp metadata...
    my %origfile2tmpfile = ();
    foreach my $origfile (keys %origfile2attr2idx) {

        #open the temp file...
        my $fntemplate = "${origfile}_${ts}_XXXXXXXX";
        my ($tfh, $tfn) = tempfile(
            $fntemplate,
            DIR    => $meta_dn,
            SUFFIX => '.tmp',
            UNLINK => 1
        );
        $origfile2tmpfile{$origfile} = $tfn;

        #open the original metadata file
        open my $fh, '<', "$meta_dn/$origfile"
          or die
"ERROR: Unable to open metadata file $meta_dn/$origfile for reading ($!). Stopped";

        #stream the original (with edits) to the temp...
        my $titles = <$fh>;
        $titles =~ s/\s+$//;    #chomp
        print {$tfh} $titles, "\n";
        if ($titles ne $origfile2header{$origfile}) {
            die "ERROR: $origfile header line changed mid-edit!  Stopped";
        }
        my $column_count = 0 + (keys %{ $origfile2attr2idx{$origfile} });
        while (my $line = <$fh>) {

            $line =~ s/\s+$//;
            my @sp = split(/\t/, $line);
            while (@sp < $column_count) {
                push @sp, '.';
            }

            #apply any applicable edits (and note that they've been applied)
            foreach my $id_type (keys %{$edits_href}) {
                if (exists $origfile2attr2idx{$origfile}->{$id_type}) {
                    my $id = $sp[ $origfile2attr2idx{$origfile}->{$id_type} ];
                    if (exists $edits_href->{$id_type}->{$id}) {
                        foreach
                          my $attr (keys %{ $edits_href->{$id_type}->{$id} })
                        {
                            if (exists $origfile2attr2idx{$origfile}->{$attr})
                            {
                                $sp[ $origfile2attr2idx{$origfile}->{$attr} ]
                                  = $edits_href->{$id_type}->{$id}->{$attr};
                                $edits_idtype2id2attr_apply_count{$id_type}
                                  ->{$id}->{$attr}++;
                            }
                        }
                    }
                }
            }

            #write the (updated) record to the temp file
            print {$tfh} join("\t", @sp), "\n";
        }
        close $fh;
        close $tfh;
    }

    #verify that all the edits could be applied
    my ($not_applied_count, $not_applied_report_limit) = (0, 10);
    foreach my $id_type (keys %{$edits_href}) {
        foreach my $id (keys %{ $edits_href->{$id_type} }) {
            foreach my $attr (keys %{ $edits_href->{$id_type}->{$id} }) {
                if ($edits_idtype2id2attr_apply_count{$id_type}->{$id}
                    ->{$attr} == 0)
                {
                    $not_applied_count++;
                    if ($not_applied_count > $not_applied_report_limit) {
                        push @local_issues,
                          "Reached limit of unapplied edits to report";
                        last;
                    }
                    else {
                        push @local_issues,
"Could not apply edit: {$id_type}->{$id}->{$attr} = "
                          . $edits_href->{$id_type}->{$id}->{$attr};
                    }
                }
            }
            if ($not_applied_count > $not_applied_report_limit) { last; }
        }
        if ($not_applied_count > $not_applied_report_limit) { last; }
    }
    if (@local_issues) {
        push @$issues_lref, @local_issues;
        return;
    }

    #cutover if appropriate
    if ($mode eq 'doit') {
        foreach my $origfile (keys %origfile2tmpfile) {
            my $bakfile = "$meta_dn/${origfile}_${ts}.bak";
            my $mode    = (stat("$meta_dn/$origfile"))[2];
            move("$meta_dn/$origfile",         $bakfile);
            move($origfile2tmpfile{$origfile}, "$meta_dn/$origfile");

            #Restore original permissions
            chmod $mode, "$meta_dn/$origfile";
        }
    }
}

sub read_fq2attributes {
    my ($a2fq_fn, $fq2attr_fn, $href, $verbose) = @_;

    if ($href) {
        my ($fh, $fn);

        my %fq2a = ();    #for traversal
        $fn = $a2fq_fn;
        open $fh, '<', $fn
          or die "ERROR: Unable to open file $fn for reading ($!). Stopped";
        my $lineNbr = 0;
        while (my $line = <$fh>) {
            $lineNbr++;
            $line =~ s/\s+$//;
            if ($line eq '') { next; }
            my @sp = split(/\t/, $line);
            if (@sp < 2) {
                warn "WARNING: Skipping short line at line #"
                  . $lineNbr . " of "
                  . $fn . "\n"
                  if ($verbose);
                next;
            }
            my $asy = $sp[0];
            for (my $i = 1 ; $i < @sp ; $i++) {
                my $fq = $sp[$i];
                if (exists $fq2a{$fq} and $fq2a{$fq} ne $asy) {
                    warn
"WARNING: Assay/FastQ pair remapped on line #$lineNbr of $fn\n"
                      if ($verbose);
                }
                $fq2a{$fq} = $asy;
            }

            $href->{$asy}{'assay.read_pairing'} =
              ((@sp > 2) ? "paired" : "single");
        }
        close $fh;

        $fn = $fq2attr_fn;
        open $fh, '<', $fn
          or die "ERROR: Unable to open file $fn for reading ($!). Stopped";
        my $title_str = <$fh>;
        $title_str =~ s/\s+$//;
        my $expectedHeaderHead = "^FastQPath\tReadLength\t";
        warn
"WARNING: Unexpected header line in $fn (\"$title_str\" !~ /$expectedHeaderHead/)\n"
          if ($title_str !~ $expectedHeaderHead and $verbose);
        $lineNbr = 1;

        while (my $line = <$fh>) {
            $lineNbr++;
            $line =~ s/\s+$//;
            if ($line eq '') { next; }
            my @sp = split(/\t/, $line);
            if (@sp < 2) {
                warn "WARNING: Skipping short line at line #"
                  . $lineNbr . " of "
                  . $fn . "\n"
                  if ($verbose);
                next;
            }
            my ($fq, $len) = ($sp[0], $sp[1]);

          #If we have a min-max read length, just chose the max length for the
            if ($len =~ m/(\d+)-(\d+)/) {
                $len = max($1, $2);
            }

            if (not exists $fq2a{$fq}) {
                warn
"WARNING: Unrecognized FastQ $fq at line #$lineNbr of $fn -- skipping...\n"
                  if ($verbose);
            }
            else {
                my $other_len = $href->{ $fq2a{$fq} }{'assay.read_length'};
                if (!$other_len or $len > $other_len) {
                    $href->{ $fq2a{$fq} }{'assay.read_length'} = $len;
                }
            }
        }
        close $fh;
    }
}

#assay2meta_href is optional to gather assay level information.
#if assay2meta_href is provided, QC results MUST be loaded AFTER all assay-level hashes have been created
sub get_qc_results {
    my ($rdn, $s2m_href, $a2m_href, $s2a_href, $verbose) = @_;

    my $fn = "$rdn/meta_data/QC_results.txt";
    if (!-s $fn) {
        warn "No QC results available in $fn. This may be a problem.\n"
          if ($verbose);
        return;
    }
    open my $fh, '<', $fn
      or die "ERROR: Unable to open file $fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    $title_str =~ s/\s+$//;
    my @titles = split(/\t/, $title_str);

    #expect columns: sample,batch,action,reason(,...)
    my %s_meta2col;
    my ($smpl_col, $assay_col, $action_col, $reason_col);
    my $max_col = 0;
    foreach my $i (0 .. $#titles) {
        $titles[$i] =~ s/\s+$//;
        $titles[$i] =~ s/^\s+//;
        $titles[$i] = lc($titles[$i]);
        if ($titles[$i] eq 'sample') {
            $smpl_col = $i;
            $max_col  = $i;
        }
        elsif ($titles[$i] eq 'batch') {
            carp
"WARNING: \"Batch\" column header is deprecated.  Use \"Assay\" instead in $fn\n"
              if ($verbose);
            $assay_col = $i;
            $max_col   = $i;
        }
        elsif ($titles[$i] eq 'assay') {
            $assay_col = $i;
            $max_col   = $i;
        }
        elsif ($titles[$i] eq 'action') {
            $action_col = $i;
            $max_col    = $i;
        }
        elsif ($titles[$i] eq 'reason') {
            $reason_col = $i;
            $max_col    = $i;
        }
    }
    if (!defined $smpl_col) {
        carp
"WARNING: No sample.id (\"sample\") defined in QC file $fn -- skipping QC results\n"
          if ($verbose);
        return;
    }
    if (!defined $assay_col) {
        carp
"WARNING: No assay.id (\"batch\") defined in QC file $fn -- skipping QC results\n"
          if ($verbose);
        return;
    }
    if (!defined $action_col) {
        carp
"WARNING: No warn/exclude (\"action\") defined in QC file $fn -- skipping QC results\n"
          if ($verbose);
        return;
    }

    my $lineNbr = 1;
    while (my $line = <$fh>) {
        $lineNbr++;
        $line =~ s/\s+$//;
        if ($line eq '') { next; }
        my @sp = split(/\t/, $line);

        if (@sp <= $max_col) {
            carp "WARNING: Skipping short line at line #"
              . $lineNbr . " of "
              . $fn . "\n"
              if ($verbose);
            next;
        }

        my $smpl   = $sp[$smpl_col];
        my $assay  = $sp[$assay_col];
        my $action = $sp[$action_col];
        my $reason = (!defined $reason_col) ? '.' : $sp[$reason_col];

        if ($action eq 'exclude' or $action eq 'warn') {
            $action = ($action eq 'warn') ? 'warning' : $action;

            #three valid cases:  *,* S,* S,A
            if ($smpl eq '*') {
                if ($assay ne '*') {
                    die
"ERROR: assay.id specified with sample.id=\"*\" in QC file $fn . Stopped\n";
                }
                else {
                    foreach my $s (keys %{$s2a_href}) {
                        $s2m_href->{$s}{ 'sample.' . $action } = 'T';
                        if (
                            exists $s2m_href->{$s}
                            { 'sample.' . $action . '_reason' })
                        {
                            if ($s2m_href->{$s}
                                { 'sample.' . $action . '_reason' } ne '.'
                                and $s2m_href->{$s}
                                { 'sample.' . $action . '_reason' } ne '')
                            {
                                if ($s2m_href->{$s}
                                    { 'sample.' . $action . '_reason' } !~
                                    m/\Q$reason/)
                                {
                                    $s2m_href->{$s}
                                      { 'sample.' . $action . '_reason' } .=
                                      '|' . $reason;
                                }
                            }
                            else {
                                $s2m_href->{$s}
                                  { 'sample.' . $action . '_reason' } =
                                  'Study-level: ' . $reason;
                            }
                        }
                        else {
                            $s2m_href->{$s}{ 'sample.' . $action . '_reason' }
                              = 'Study-level: ' . $reason;
                        }
                        if ($a2m_href) {
                            foreach my $a (@{ $s2a_href->{$s} }) {
                                $a2m_href->{$a}{ 'assay.' . $action } = 'T';
                                if (
                                    exists $a2m_href->{$a}
                                    { 'assay.' . $action . '_reason' })
                                {
                                    if ($a2m_href->{$a}
                                        { 'assay.' . $action . '_reason' } ne
                                        '.'
                                        and $a2m_href->{$a}
                                        { 'assay.' . $action . '_reason' } ne
                                        '')
                                    {
                                        if (
                                            $a2m_href->{$a}{
                                                    'assay.'
                                                  . $action
                                                  . '_reason'
                                            } !~ m/\Q$reason/
                                          )
                                        {
                                            $a2m_href->{$a}{ 'assay.'
                                                  . $action
                                                  . '_reason' } .=
                                              '|' . $reason;
                                        }
                                    }
                                    else {
                                        $a2m_href->{$a}
                                          { 'assay.' . $action . '_reason' }
                                          = 'Study-level: ' . $reason;
                                    }
                                }
                                else {
                                    $a2m_href->{$a}
                                      { 'assay.' . $action . '_reason' } =
                                      'Study-level: ' . $reason;
                                }
                            }
                        }
                    }
                }
            }
            else {
                #sample specified
                if ($assay eq '*') {
                    $s2m_href->{$smpl}{ 'sample.' . $action } = 'T';
                    if (
                        exists $s2m_href->{$smpl}
                        { 'sample.' . $action . '_reason' })
                    {
                        if ($s2m_href->{$smpl}
                            { 'sample.' . $action . '_reason' } ne '.'
                            and $s2m_href->{$smpl}
                            { 'sample.' . $action . '_reason' } ne '')
                        {
                            if ($s2m_href->{$smpl}
                                { 'sample.' . $action . '_reason' } !~
                                m/\Q$reason/)
                            {
                                $s2m_href->{$smpl}
                                  { 'sample.' . $action . '_reason' } .=
                                  '|' . $reason;
                            }
                        }
                        else {
                            $s2m_href->{$smpl}
                              { 'sample.' . $action . '_reason' } = $reason;
                        }
                    }
                    else {
                        $s2m_href->{$smpl}{ 'sample.' . $action . '_reason' }
                          = $reason;
                    }
                }
                else {
                    if ($a2m_href and %$a2m_href) {
                        $a2m_href->{$assay}{ 'assay.' . $action } = 'T';
                        if (
                            exists $a2m_href->{$assay}
                            { 'assay.' . $action . '_reason' })
                        {
                            if ($a2m_href->{$assay}
                                { 'assay.' . $action . '_reason' } ne '.'
                                and $a2m_href->{$assay}
                                { 'assay.' . $action . '_reason' } ne '')
                            {
                                if ($a2m_href->{$assay}
                                    { 'assay.' . $action . '_reason' } !~
                                    m/\Q$reason/)
                                {
                                    $a2m_href->{$assay}
                                      { 'assay.' . $action . '_reason' } .=
                                      '|' . $reason;
                                }
                            }
                            else {
                                $a2m_href->{$assay}
                                  { 'assay.' . $action . '_reason' } =
                                  $reason;
                            }
                        }
                        else {
                            $a2m_href->{$assay}
                              { 'assay.' . $action . '_reason' } = $reason;
                        }
                    }
                }
            }
        }
    }
    close $fh;

    #If all the assays from a sample are excluded we need to exclude the
    #sample.
    foreach my $s (keys %{$s2a_href}) {
        if (not exists $s2m_href->{$s}{'sample.exclude'}
            or $s2m_href->{$s}{'sample.exclude'} ne 'T')
        {
            my $assayCount = 0 + @{ $s2a_href->{$s} };
            my $assayExcludeCount = 0;
            foreach my $a (@{ $s2a_href->{$s} }) {
                if (exists $a2m_href->{$a}{'assay.exclude'}
                    and $a2m_href->{$a}{'assay.exclude'} eq 'T')
                {
                    $assayExcludeCount++;
                }
            }
            if ($assayExcludeCount == $assayCount) {
                $s2m_href->{$s}{'sample.exclude'} = 'T';
                my $reason = 'All assays for sample are excluded';
                if (exists $s2m_href->{$s}{'sample.exclude_reason'}) {
                    if ($s2m_href->{$s}{'sample.exclude_reason'} ne '.'
                        and
                        $s2m_href->{$s}{'sample.exclude_reason'} ne '')
                    {
                        if ($s2m_href->{$s}{'sample.exclude_reason'} !~
                            m/\Q$reason/)
                        {
                            $s2m_href->{$s}{'sample.exclude_reason'} .=
                              '|' . $reason;
                        }
                    }
                    else {
                        $s2m_href->{$s}{'sample.exclude_reason'} =
                          $reason;
                    }
                }
                else {
                    $s2m_href->{$s}{'sample.exclude_reason'} = $reason;
                }
            }
        }
    }

    #If a sample has a warning or exclude that is not at the assay level, we
    #need to add it.
    foreach my $s (keys %{$s2a_href}) {
        my $s_exclude = $s2m_href->{$s}{'sample.exclude'} || '';
        $s_exclude = '' if ($s_exclude ne 'T');
        my $s_warn = $s2m_href->{$s}{'sample.warning'} || '';
        $s_warn = '' if ($s_warn ne 'T');
        if ($s_exclude eq 'T' or $s_warn eq 'T') {
            my $s_warn_reason =
              $s2m_href->{$s}{'sample.warning_reason'} || '';
            $s_warn_reason = '' if ($s_warn_reason eq '.');
            my $s_exclude_reason =
              $s2m_href->{$s}{'sample.exclude_reason'} || '';
            $s_exclude_reason = '' if ($s_exclude_reason eq '.');
            foreach my $assay (@{ $s2a_href->{$s} }) {
                if ($s_exclude) {
                    if (    $a2m_href->{$assay}{'assay.exclude_reason'}
                        and $a2m_href->{$assay}{'assay.exclude_reason'} ne
                        '.')
                    {
                        if ($a2m_href->{$assay}{'assay.exclude_reason'} !~
                            m/\Q$s_exclude_reason/)
                        {
                            $a2m_href->{$assay}{'assay.exclude_reason'} .=
                              '|' . $s_exclude_reason;
                        }
                    }
                    else {
                        $a2m_href->{$assay}{'assay.exclude_reason'} =
                          $s_exclude_reason;
                    }
                    $a2m_href->{$assay}{'assay.exclude'} = 'T';
                }

                if ($s_warn) {
                    if (    $a2m_href->{$assay}{'assay.warning_reason'}
                        and $a2m_href->{$assay}{'assay.warning_reason'} ne
                        '.')
                    {
                        if ($a2m_href->{$assay}{'assay.warning_reason'} !~
                            m/\Q$s_warn_reason/)
                        {
                            $a2m_href->{$assay}{'assay.warning_reason'} .=
                              '|' . $s_warn_reason;
                        }
                    }
                    else {
                        $a2m_href->{$assay}{'assay.warning_reason'} =
                          $s_warn_reason;
                    }
                    $a2m_href->{$assay}{'assay.warning'} = 'T';
                }
            }
        }
    }
}

sub read_predicted_ancestry {
    my ($pas_fn, $par_fn, $s2m_href, $s2a_href, $verbose) = @_;

    open my $fh, '<', $pas_fn
      or die "ERROR: Unable to open file $pas_fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    $title_str =~ s/\s+$//;
    my @titles = split(/\t/, $title_str);
    close $fh;

    #expect: ^SUCCEEDED\tMean value of alpha         = \d+\.\d+
    if (@titles < 1 or $titles[0] ne 'SUCCEEDED') {
        return;
    }

    open $fh, '<', $par_fn
      or die "ERROR: Unable to open file $par_fn for reading ($!). Stopped";
    $title_str = <$fh>;
    $title_str =~ s/\s+$//;
    @titles = split(/\t/, $title_str);

    #expect columns: SampleLabel,MissingPercent,uAFR,EUR,AMR,SAS,EAS,BestMatch
    my ($smpl_col, $afr_col, $eur_col, $amr_col, $sas_col, $eas_col);
    my $max_col = 0;
    foreach my $i (0 .. $#titles) {
        if ($titles[$i] eq 'SampleLabel') {
            $smpl_col = $i;
            $max_col  = $i;
        }
        elsif ($titles[$i] eq 'uAFR') {
            $afr_col = $i;
            $max_col = $i;
        }
        elsif ($titles[$i] eq 'EUR') {
            $eur_col = $i;
            $max_col = $i;
        }
        elsif ($titles[$i] eq 'AMR') {
            $amr_col = $i;
            $max_col = $i;
        }
        elsif ($titles[$i] eq 'SAS') {
            $sas_col = $i;
            $max_col = $i;
        }
        elsif ($titles[$i] eq 'EAS') {
            $eas_col = $i;
            $max_col = $i;
        }
    }
    if (!defined $smpl_col) {
        carp
"WARNING: No sample.id (\"sample\") defined in predicted ancestry file $par_fn -- skipping ancestry\n"
          if ($verbose);
        return;
    }
    if (!defined $amr_col) {
        carp
"WARNING: No sample.ethnicity_predicted_admixed_american (\"AMR\") defined in predicted ancestry file $par_fn -- skipping ancestry\n"
          if ($verbose);
        return;
    }
    if (!defined $afr_col) {
        carp
"WARNING: No sample.ethnicity_predicted_african (\"uAFR\") defined in predicted ancestry file $par_fn -- skipping ancestry\n"
          if ($verbose);
        return;
    }
    if (!defined $eas_col) {
        carp
"WARNING: No sample.ethnicity_predicted_east_asian (\"EAS\") defined in predicted ancestry file $par_fn -- skipping ancestry\n"
          if ($verbose);
        return;
    }
    if (!defined $eur_col) {
        carp
"WARNING: No sample.ethnicity_predicted_european (\"EUR\") defined in predicted ancestry file $par_fn -- skipping ancestry\n"
          if ($verbose);
        return;
    }
    if (!defined $sas_col) {
        carp
"WARNING: No sample.ethnicity_predicted_south_asian (\"SAS\") defined in predicted ancestry file $par_fn -- skipping ancestry\n"
          if ($verbose);
        return;
    }

    my $lineNbr = 1;
    while (my $line = <$fh>) {
        $lineNbr++;
        $line =~ s/\s+$//;
        if ($line eq '') { next; }
        my @sp = split(/\t/, $line);

        if (@sp <= $max_col) {
            carp "WARNING: Skipping short line at line #"
              . $lineNbr . " of "
              . $par_fn . "\n"
              if ($verbose);
            next;
        }

        my $smpl = $sp[$smpl_col];
        if (not exists $s2a_href->{$smpl}) {
            warn
"ERROR: Unrecognized sample.id on line #$lineNbr of $par_fn: $smpl \n";
        }
        $s2m_href->{$smpl}{'sample.ethnicity_predicted_admixed_american'} =
          $sp[$amr_col];
        $s2m_href->{$smpl}{'sample.ethnicity_predicted_african'} =
          $sp[$afr_col];
        $s2m_href->{$smpl}{'sample.ethnicity_predicted_east_asian'} =
          $sp[$eas_col];
        $s2m_href->{$smpl}{'sample.ethnicity_predicted_european'} =
          $sp[$eur_col];
        $s2m_href->{$smpl}{'sample.ethnicity_predicted_south_asian'} =
          $sp[$sas_col];
    }
    close $fh;
}

sub read_inferred_sex {
    my ($fn, $s2m_href, $s2a_href, $verbose) = @_;

    open my $fh, '<', $fn
      or die "ERROR: Unable to open file $fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    $title_str =~ s/\s+$//;
    my @titles = split(/\t/, $title_str);

  #expect "evidence" columns but only care about SampleID and InferredSex here
    my ($smpl_col, $sex_col);
    my $max_col = 0;
    foreach my $i (0 .. $#titles) {
        if ($titles[$i] eq 'SampleID') {
            $smpl_col = $i;
            $max_col  = $i;
        }
        elsif ($titles[$i] eq 'InferredSex') {
            $sex_col = $i;
            $max_col = $i;
        }
    }
    if (!defined $smpl_col) {
        carp
"WARNING: No sample.id (\"SampleID\") defined in inferred sex file $fn -- skipping sex\n"
          if ($verbose);
        return;
    }
    if (!defined $sex_col) {
        carp
"WARNING: No sample.sex_inferred (\"InferredSex\") defined in inferred sex file $fn -- skipping sex\n"
          if ($verbose);
        return;
    }

    my $lineNbr = 1;
    while (my $line = <$fh>) {
        $lineNbr++;
        $line =~ s/\s+$//;
        if ($line eq '') { next; }
        my @sp = split(/\t/, $line);

        if (@sp <= $max_col) {
            carp "WARNING: Skipping short line at line #"
              . $lineNbr . " of "
              . $fn . "\n"
              if ($verbose);
            next;
        }

        my $smpl = $sp[$smpl_col];
        if (not exists $s2a_href->{$smpl}) {
            warn
"ERROR: Unrecognized sample.id on line #$lineNbr of $fn: $smpl \n";
        }
        $s2m_href->{$smpl}{'sample.sex_inferred'} = $sp[$sex_col];
    }
    close $fh;
}

sub read_3p_bias {
    my ($fn, $s2m_href, $s2a_href, $verbose) = @_;

    if (!-s $fn) {
        carp "No 3p bias defined for this project at $fn. This may be fine.\n"
          if ($verbose);
        return;
    }
    open my $fh, '<', $fn
      or die "ERROR: Unable to open file $fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    $title_str =~ s/\s+$//;
    my @titles = split(/\t/, $title_str);

    #expect columns: Assay,MostCommonSlope
    my ($smpl_col, $mcs_col);
    my $max_col = 0;
    foreach my $i (0 .. $#titles) {
        if ($titles[$i] eq 'Assay') {
            $smpl_col = $i;
            $max_col  = $i;
        }
        elsif ($titles[$i] eq 'MostCommonSlope') {
            $mcs_col = $i;
            $max_col = $i;
        }
    }
    if (!defined $smpl_col) {
        carp
"WARNING: No sample.id (\"sample\") defined in sample-level 3p bias file $fn -- skipping 3p bias\n"
          if ($verbose);
        return;
    }
    if (!defined $mcs_col) {
        carp
"WARNING: No sample.3pbias defined in sample-level 3p bias file $fn -- skipping 3p bias\n"
          if ($verbose);
        return;
    }

    my $lineNbr = 1;
    while (my $line = <$fh>) {
        $lineNbr++;
        $line =~ s/\s+$//;
        if ($line eq '') { next; }
        my @sp = split(/\t/, $line);

        if (@sp <= $max_col) {
            carp "WARNING: Skipping short line at line #"
              . $lineNbr . " of "
              . $fn . "\n"
              if ($verbose);
            next;
        }

        my $smpl = $sp[$smpl_col];
        if (not exists $s2a_href->{$smpl}) {
            warn
"ERROR: Unrecognized sample.id on line #$lineNbr of $fn: $smpl \n";
        }
        $s2m_href->{$smpl}{'sample.3pbias'} = $sp[$mcs_col];
    }
    close $fh;
}

#Check for meta_data_sample*.txt
sub read_sample_metadata_files {
    my ($meta_dn, $a2s_href, $s2m_href, $s2a_href, $verbose) = @_;
    my $smpl_meta_fn_regex     = '^meta_data_sample(_.+)?\.txt$';
    my $smpl_valid_attrs_regex = '^(sample\.|study\.)';
    my $key_attr               = 'sample.id';
    read_metadata_subset_files($meta_dn, $smpl_meta_fn_regex,
        $smpl_valid_attrs_regex, $a2s_href, $key_attr, $s2m_href, $s2a_href,
        $verbose);
}

#Study level metadata is not really first class. We store it in the sample
#level metadata hash. Probably at some point we should change this!
#Due to this complexity I'm electing to do the processing here rather than try
#to do it via read_metadata_subset_files.
sub read_study_metadata_files {
    my ($meta_dn, $s2m_href, $verbose) = @_;

    foreach my $fn (glob("$meta_dn/meta_data_study_*.txt")) {
        open my $fh, '<', $fn
          or die "Unable to open file $fn for reading ($!). Stopped";
        my $title_ln = <$fh>;
        $title_ln =~ s/\R$//;
        my @titles = split(/\t/, $title_ln);
        my $id_col;
        foreach my $i (0 .. $#titles) {
            if ($titles[$i] eq 'study.id') {
                $id_col = $i;
                last;
            }
        }
        if (!defined $id_col) {
            die "No column study.id defined in $fn. Stopped";
        }
        my %study_meta;
        while (my $line = <$fh>) {
            $line =~ s/\R$//;
            my @sp = split(/\t/, $line);
            my $id = $sp[$id_col];
            foreach my $i (0 .. $#titles) {
                if ($i != $id_col) {
                    $study_meta{$id}{$titles[$i]} = $sp[$i];
                }
            }
        }

        #Now we have to deal with the fact that study level metadata is stored
        #at the sample level.
        #Special study id '*' matches any study id. Any other study ID needs
        #to match that already in the sample metadata.
        foreach my $smpl (keys %$s2m_href) {
            my $smpl_study_id = $s2m_href->{$smpl}{'study.id'} || '';
            foreach my $study_id (keys %study_meta) {
                if ($study_id eq '*' or $study_id eq $smpl_study_id) {
                    foreach my $field (keys %{ $study_meta{$study_id} }) {
                        $s2m_href->{$smpl}{$field} = $study_meta{$study_id}{$field};
                    }
                }
            }
        }
    }
}

sub read_assay_metadata_files {

    #Check for meta_data_assay*.txt
    my ($meta_dn, $a2s_href, $a2m_href, $s2a_href, $verbose) = @_;
    my $asy_meta_fn_regex     = '^meta_data_assay(_.+)?\.txt$';
    my $asy_valid_attrs_regex = '^(assay\.|sample\.id$)';
    my $key_attr              = 'assay.id';
    read_metadata_subset_files($meta_dn, $asy_meta_fn_regex,
        $asy_valid_attrs_regex, $a2s_href, $key_attr, $a2m_href, $s2a_href,
        $verbose);
}

sub read_metadata_subset_files {

#considered doing something convoluted to allow multiple levels to be parsed and divided amongst multiple
# hashes but decided that this was more than sufficiently convoluted ...
    my ($meta_dn, $meta_fn_regex, $valid_attrs_regex, $a2s_href, $key_attr,
        $hash_href, $s2a_href, $verbose)
      = @_;
    $meta_dn = $meta_dn . (($meta_dn !~ /\/$/) ? '/' : '');

    opendir(DH, $meta_dn)
      or die("Could not read file listing from $meta_dn ($!). Stopped");
    my @files = readdir(DH);
    @files = sort { $a cmp $b } @files;
    closedir(DH);

    foreach my $fn (@files) {
        if ($fn !~ $meta_fn_regex) { next; }
        $fn = $meta_dn . $fn;
        open my $fh, '<', $fn
          or die "ERROR: Unable to open file $fn for reading ($!). Stopped";

        #parse header row...
        my $title_str = <$fh>;
        $title_str =~ s/\s+$//;
        my @titles = split(/\t/, $title_str);

        my ($key_idx, $sampleIdIdx, $assayIdIdx, $lastRequiredIdx) =
          (-1, -1, -1, -1);
        my $col_count = 0 + @titles;
        for (my $i = 0 ; $i < @titles ; $i++) {
            if ($titles[$i] eq $key_attr) {
                if ($key_idx == -1) {
                    $key_idx         = $i;
                    $lastRequiredIdx = $i;
                }
                else {
                    die
"ERROR: Found more than one $key_attr column in $fn . Stopped";
                }
            }
            if ($titles[$i] !~ $valid_attrs_regex) {
                die "ERROR: Invalid attribute ($titles[$i]) in column #"
                  . ($i + 1)
                  . " of $fn . Stopped";
            }
            if ($titles[$i] eq 'sample.id') {
                $sampleIdIdx     = $i;
                $lastRequiredIdx = $i;
            }
            if ($titles[$i] eq 'assay.id') {
                $assayIdIdx      = $i;
                $lastRequiredIdx = $i;
            }
        }
        if ($key_idx == -1) {
            die "ERROR: Failed to find $key_attr column in $fn . Stopped";
        }

        my $lineNbr = 1;
        while (my $line = <$fh>) {
            $lineNbr++;
            $line =~ s/\s+$//;
            if ($line eq '') { next; }

            my @sp = split(/\t/, $line);
            if (@sp <= $lastRequiredIdx) {
                carp "WARNING: Skipping short line at line #"
                  . $lineNbr . " of "
                  . $fn . "\n"
                  if ($verbose);
                next;
            }

#check for new sample.id, assay.id, and assay-to-sample mappings (relative to a2s)
            if ($sampleIdIdx >= 0) {
                if (not exists $s2a_href->{ $sp[$sampleIdIdx] }) {
                    die
"ERROR:  Unrecognized sample.id ( $sp[$sampleIdIdx] ) on line #$lineNbr of $fn . Stopped";
                }
            }
            if ($assayIdIdx >= 0) {
                if (not exists $a2s_href->{ $sp[$assayIdIdx] }) {
                    die
"ERROR:  Unrecognized assay.id ( $sp[$assayIdIdx] ) on line #$lineNbr of $fn . Stopped";
                }
            }
            if ($sampleIdIdx >= 0 and $assayIdIdx >= 0) {
                if ($a2s_href->{ $sp[$assayIdIdx] } ne $sp[$sampleIdIdx]) {
                    die
"ERROR:  Unrecognized assay-to-sample mapping for assay.id = $sp[$assayIdIdx] ( $a2s_href->{$sp[$assayIdIdx]} ne $sp[$sampleIdIdx] ) on line #$lineNbr of $fn . Stopped";
                }
            }

            if (not exists $hash_href->{ $sp[$key_idx] }) {
                $hash_href->{ $sp[$key_idx] } = {};
            }
            for (my $i = 0 ; $i < @sp and $i < $col_count ; $i++) {
                if ($i == $key_idx) { next; }
                if ($sp[$i] eq '' or $sp[$i] eq '.') { next; }
                if (    exists $hash_href->{ $sp[$key_idx] }->{ $titles[$i] }
                    and $hash_href->{ $sp[$key_idx] }->{ $titles[$i] } ne ''
                    and $hash_href->{ $sp[$key_idx] }->{ $titles[$i] } ne '.'
                    and $hash_href->{ $sp[$key_idx] }->{ $titles[$i] } ne
                    $sp[$i])
                {
                    die
"ERROR:  Attribute $titles[$i] conflict for $key_attr = $sp[$key_idx] on line #$lineNbr of $fn ( $hash_href->{$sp[$key_idx]}->{$titles[$i]} ne $sp[$i]).  Stopped";
                }
                my $tmp = $sp[$i];
                $tmp =~ s/^"(.*)"$/$1/;
                $tmp =~ s/^\s+|\s+$//g;
                $hash_href->{ $sp[$key_idx] }->{ $titles[$i] } = $tmp;
            }
        }
        close $fh;
    }
}

#When we generate files based on the content of other files we often need to
#check if the input files are newer than the output files.
sub out_of_date_files {
    my ($in_file_lst, $out_file_lst) = @_;

    #If any of the output files do not exist, or if any of them are older than
    #any of the newer files we are out of date.
    my $no_out = 0;
    my $oldest_out;
    foreach my $fn (@$out_file_lst) {
        if (-s $fn) {
            my $age = -M _;
            if (!defined $oldest_out or $age > $oldest_out) {
                $oldest_out = $age;
            }
        }
        else {
            $no_out = 1;
        }
    }

    if ($no_out) {

        #at least one of the output files is missing, so we are definitely out
        #of date.
        return 1;
    }

    my $newest_in;
    foreach my $fn (@$in_file_lst) {
        if (-s $fn) {
            my $age = -M _;
            if (!defined $newest_in or $age < $newest_in) {
                $newest_in = $age;
            }
        }
    }
    if ($oldest_out < $newest_in) {
        return 1;
    }
    else {
        return 0;
    }
}

#If the passed in file exists, change its name to a time stamped back-up
sub make_backup {
    my $fn = shift;

    if (!-e $fn) {

        #nothing to do
        return;
    }

    my ($name, $path) = fileparse($fn);
    my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) =
      localtime(time);
    my $now = sprintf(
        "%04d%02d%02d-%02d%02d%02d",
        $year + 1900,
        $mon + 1, $mday, $hour, $min, $sec
    );
    my $new_name = "${name}${now}.bak";
    move($fn, "$path/$new_name");
}

sub set_rna_gene_count_totals {
    my ($fn, $asy_href, $a2s_href) = @_;

    open my $fh, '<', $fn
      or die "Unable to open file $fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    my $lineNbr   = 1;
    while (my $line = <$fh>) {
        $lineNbr++;
        next if ($line !~ m/^Location x Type/);
        chomp $line;
        my ($class, $type, $assay, $count) = split(/\t/, $line);
        if (not exists $a2s_href->{$assay}) {
            warn
"ERROR: Unrecognized assay.id on line #$lineNbr of $fn: $assay \n";
        }

        my $location;
        my $gene_type;
        my ($raw_loc, $raw_gene_type) = split(/\s+x\s+/, $type);
        if (!$raw_gene_type and $type =~ m/-/) {

            #Not consistent about separating with a ' x '. Rats!
            #Not 100% confident that we never see this with protein-coding, so
            #make this safe.
            $type =~ s/protein-coding/protein_coding/;
            ($raw_loc, $raw_gene_type) = split(/-/, $type);
            $raw_gene_type =~ s/protein_coding/protein-coding/;
        }
        if (    $type ne 'Other_Category'
            and $type ne 'Total_Counts'
            and $raw_gene_type)
        {
            if ($type eq 'Other_Category') {
                $location = 'mixed_location';
            }
            elsif ($raw_loc eq 'chrM') {
                $location = 'mitochondrial';
            }
            elsif ($raw_loc =~ m/chrM/) {
                $location = 'mixed_location';
            }
            else {
                $location = 'nuclear';
            }
            if ($type eq 'Other_Category') {
                $gene_type = 'mixed_counts';
            }
            elsif ($raw_gene_type eq 'rRNA') {
                $gene_type = 'rrna_counts';
            }
            elsif ($raw_gene_type =~ m/rRNA/) {
                $gene_type = 'mixed_counts';
            }
            else {
                $gene_type = 'non_rrna_counts';
            }
        }
        elsif ($type eq 'Other_Category') {
            $location  = 'mixed_location';
            $gene_type = 'mixed_counts';
        }
        elsif ($type ne 'Total_Counts') {
            die "Unable to get raw_gene_type out of $type. Stopped";
        }
        if ($location and $gene_type) {
            my $key = "assay.${location}_$gene_type";
            $asy_href->{$assay}{$key} += $count;
        }
    }
    close $fh;
}

sub set_mir_count_totals {
    my ($fn, $asy_href, $a2s_href) = @_;

    open my $fh, '<', $fn
      or die "Unable to open file $fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    my $lineNbr   = 1;
    while (my $line = <$fh>) {
        chomp $line;
        my ($assay, $count) = split(/\t/, $line);
        if (not exists $a2s_href->{$assay}) {
            warn
"ERROR: Unrecognized assay.id on line #$lineNbr of $fn: $assay \n";
        }

        $asy_href->{$assay}{'assay.miR_counts'} += $count;
    }
    close $fh;
}
1;

#Check that we have identical ID content in the set of IDs (assay or sample)
#and the hash of meta data. Complain if this is not true.
#('Sample', 'After basic sample level metadata', \@all_samples, $s2m_href)
sub check_meta_content {
    my ($level, $message, $all_ids_lref, $meta_href, $verbose) = @_;

    my %all_ids;
    foreach my $id (@$all_ids_lref) {
        $all_ids{$id} = 1;
    }

    #If we have incoming meta data for a non-existent assay or sample that
    #clearly needs to be fatal.
    my $fatal_count = 0;
    foreach my $id (keys %$meta_href) {
        if (!$all_ids{$id}) {
            if (++$fatal_count < 5) {
                carp
"$level meta_data for non-existent id $id appeared $message\n"
                  if ($verbose);
            }
            else {
                last;
            }
        }
    }
    if ($fatal_count) {
        croak
"$fatal_count errors due to non-existent $level ids $message. Stopped";
    }

    #Less clear is whether it is fatal to have an ID with no meta-data. For
    #the moment, at least, we'll make that be fatal as well.
    foreach my $id (@$all_ids_lref) {
        if (!$meta_href->{$id}) {
            if (++$fatal_count < 5) {
                carp "Missing meta_data for $level $id $message\n"
                  if ($verbose);
            }
            else {
                last;
            }
        }
    }
    if ($fatal_count) {
        croak
"$fatal_count errors due to lack of meta data for $level ids $message. Stopped";
    }
}

#Read combined_aln_stats file for RNASeq projects and add read mapping meta
#data.
sub read_rna_combined_aln_stats_meta {
    my ($aln_stat_fn, $s2m_href, $a2s_href) = @_;

    open my $fh, '<', $aln_stat_fn
      or die "Unable to open file $aln_stat_fn for reading ($!). Stopped";
    my $title_str = <$fh>;
    my $lineNbr   = 1;
    my %col2org;
    my @cols;
    my @orgs;
    $title_str =~ s/\R$//;
    my @titles = split(/\t/, $title_str);

    foreach my $i (0 .. $#titles) {

        if ($titles[$i] =~ m/^ReadsMapped(.*)$/) {
            next if ($titles[$i] =~ m/Pct/);
            push @cols, $i;
            push @orgs, lc($1);
            $col2org{$i} = $1;
        }
    }
    if (@cols) {
        my %sample_counts;
        while (my $line = <$fh>) {
            $lineNbr++;
            $line =~ s/\R$//;
            my @sp = split(/\t/, $line);
            my $asy = $sp[0];
            if (not exists $a2s_href->{$asy}) {
                warn
"ERROR: Unrecognized assay.id on line #$lineNbr of $aln_stat_fn: $asy \n";
            }
            my $smpl = $a2s_href->{$asy};
            foreach my $i (0 .. $#cols) {
                my $col = $cols[$i];
                my $org = $orgs[$i];
                $sample_counts{$smpl}{$org} += $sp[$col];
            }
        }
        foreach my $smpl (keys %sample_counts) {
            my $total = sum(values %{ $sample_counts{$smpl} });
            foreach my $org (keys %{ $sample_counts{$smpl} }) {
                $s2m_href->{$smpl}{"sample.pct_${org}_reads"} =
                  sprintf("%.2f", 100 * $sample_counts{$smpl}{$org} / $total);
            }
        }
    }
}

#For exome projects we look in the BAM stats files, but these exist
#even pure mouse projects and for them we can't tell which organism is
#which. To do the right thing, we just read this if the entire project
#is a human project which we determine by seeing if all the
#sample.taxon values are equal to 9606 (human).
sub read_human_exome_aln_stats {
    my ($rdn, $s2m_href, $s2a_href) = @_;

    #First check to see if sample.taxon is always 9606 (human). Return if this
    #is not true.
    foreach my $smpl (keys %$s2m_href) {
        if (    $s2m_href->{'sample.taxon'}
            and $s2m_href->{'sample.taxon'} != 9606)
        {
            return;
        }
    }

    #Now go read the bam stats files and set mouse/human pct
    foreach my $fn (glob("$rdn/../bam/*-calibrated.bamStats.txt")) {
        (my $smpl = $fn) =~ s/.*\///;
        $smpl =~ s/-calibrated.bamStats.txt//;
        if (not exists $s2a_href->{$smpl}) {
            warn
"ERROR: Unrecognized sample.id extracted from file name $fn: $smpl \n";
        }
        my $cnt_line = 0;
        open my $fh, '<', $fn
          or die "Unable to open file $fn for reading ($!). Stopped";
        my ($human_pct, $mouse_pct);
        while (my $line = <$fh>) {
            last if (++$cnt_line > 20);
            if ($line =~ m/^TotalHuman\t(\d+)\t(\S+)/) {
                $human_pct = $2;
            }
            elsif ($line =~ m/^TotalHuman\(or Main Org\)\t(\d+)\t(\S+)/) {
                $human_pct = $2;
            }
            elsif ($line =~ m/^TotalMouse\t(\d+)\t(\S+)/) {
                $mouse_pct = $2;
            }
        }
        close $fh;
        if (defined $human_pct and defined $mouse_pct) {
            $s2m_href->{$smpl}{'sample.pct_mouse_reads'} = $mouse_pct;
            $s2m_href->{$smpl}{'sample.pct_human_reads'} = $human_pct;
        }
    }
}

#Read the project_data gsnap config files to figure out what genome or genomes we aligned
#to. Report that as study.aligned_genome_paths. If possible, also report a
#short human readable name in study.aligned_genomes.
#Also look through project_data_withnames.json files to capture DNANexus run
#projects aligned genomes.
sub get_aligned_genome {
    my ($rdn, $s2m_href, $s2a_href, $verbose) = @_;

    my @gsnap_cfg = glob("$rdn/project_data/*_gsnap.cfg");
    my %genomes;
    foreach my $fn (@gsnap_cfg) {
        next if ($fn =~ m/optityper/);
        my $ref_str = `grep '^ref_genome: ' $fn`;
        if ($ref_str =~ m/ref_genome:\s+(\S+)/) {
            $genomes{$1} = 1;
        }
    }

    my @proj_json = glob("$rdn/project_data/*project_data*.json");
    foreach my $fn (@proj_json) {
        #warn "F=$fn\n";
        my $ref_str = `cat $fn|jq '.'|grep genome_id`;
        foreach my $id ($ref_str =~ m/"genome_id":\s+"([^"]+)"/g) {
            if ($id ne 'ref_genome_plus') {
                #Skip contentless ID that we get from RNA projects
                $genomes{$id} = 1;
            }
        }
        $ref_str = `cat $fn|jq '.'|grep -A1 index_targz|tail -1`;
        #warn "R=$ref_str\n";
        foreach my $id ($ref_str =~ m/,\s*(\S+)"/g) {
            #    warn "ID=$id\n";
            $genomes{$id} = 1;
        }
    }
    if (%genomes) {
        my $full_paths = join(';', sort keys %genomes);
        my %short_names;
        foreach my $path (keys %genomes) {
            my $short = $genome_aliases{$path} || '.';
            if ($short eq '.') {
                warn "No short name for genome_path $path. "
                  . "Consider adding this to lib/genome_aliases.txt.\n"
                  if ($verbose);
            } else {
                $short_names{$short} = 1;
            }
        }
        my $short_names = join(';', sort keys %short_names);
        # warn "FP=$full_paths\nSN=$short_names\n";
        foreach my $smpl (keys %$s2a_href) {
            if (not exists $s2m_href->{$smpl}) {
                $s2m_href->{$smpl} = {};
            }
            $s2m_href->{$smpl}{'study.aligned_genome_paths'} = $full_paths;
            $s2m_href->{$smpl}{'study.aligned_genomes'}      = $short_names;
        }
    }
}

#Set up assay.library, as follows:
# There are 4 possible sources of library information. One and only one should
# be defined (but we don't really check this).
#   - For older meta_data files it may be defined as assay.library in the
#    meta_data.
#   - For newer meta_data files it may be defined as sample.library.
#   - When there is more than one library per sample it must be defined in
#    assay2info.
#   -If it is not defined in any of these places it will be set to the
#   sample id.
sub set_assay_library {
    my ($s2m_href, $a2m_href, $a2s_href) = @_;

    my $have_it = 0;

    ##First look in the sample level meta data to see if we have
    #sample.library defined. If so, we'll keep this to fill in any that might
    #be missing. We also back fill with just the sample id.
    my %smpl2lib;
    foreach my $smpl (keys %$s2m_href) {
        $smpl2lib{$smpl} = $s2m_href->{$smpl}{'sample.library'} || $smpl;

        #We don't want this in the final metadata
        delete $s2m_href->{$smpl}{'sample.library'};
    }

    #Now go through all the assays looking for assay.library. If we have it
    #it could have been previously set by assay2info, or it could have come in
    #from the sample level file meta_data.txt, or it could have come in via
    #meta_data_assay*.txt. We don't care, we just want to find it.

    foreach my $asy (keys %$a2m_href) {
        if (  !$a2m_href->{$asy}{'assay.library'}
            or $a2m_href->{$asy}{'assay.library'} eq '.')
        {
            my $smpl = $a2s_href->{$asy};
            my $lib  = $smpl2lib{$smpl};
            if (!$lib or $lib eq '.') {
                croak
"No sample id or assay.library defined in any way for assay $asy. Stopped";
            }
            $a2m_href->{$asy}{'assay.library'} = $lib;
        }
    }
}

#If we have the assay2pool.txt file we use that and ignore any other
#information.  If this file does not exist and we have sample level pool
#information in the meta_data, we attempt to use this to infer full assay2pool
#mappings. This can be ambiguous. If it is, we fail and require assay2pool to
#be provided.  If there is no pool information in the meta_data and no
#assay2pool.txt file, we create pools that correspond to each unique batch.
sub set_assay_pool {
    my ($rdn, $s2m_href, $a2m_href, $a2s_href, $verbose) = @_;

    #Check to see if sample.pool is defined. We just check one sample.
    my $ex_smpl      = (keys %$s2m_href)[0];
    my $ex_pool      = $s2m_href->{$ex_smpl}{'sample.pool'};
    my $pool_defined = ($ex_pool and $ex_pool ne '.');
    my $fn           = "$rdn/meta_data/assay2pool.txt";
    if (-s $fn) {
        if ($pool_defined) {
            warn "sample.pool defined in meta data and $fn also provided. "
              . "Sample.pool will be ignored.\n"
              if ($verbose);
        }
        open my $fh, '<', $fn
          or die "Unable to open file $fn for reading ($!). Stopped";
        my $title_str = <$fh>;
        $title_str =~ s/\s+$//;
        my $exp = "AssayID\tPoolID";
        if ($title_str !~ m/^$exp/i) {
            die "File $fn did not have expected title line.\n"
              . "Expected: $exp\nGot:$title_str\n";
        }
        while (my $line = <$fh>) {
            $line =~ s/\s+$//;
            my ($assay_id, $pool_id) = split(/\t/, $line);
            if (!$a2s_href->{$assay_id}) {
                die "Assay $assay_id in $fn is not a legal assay id. Stopped";
            }
            $a2m_href->{$assay_id}{'assay.pool'} = $pool_id;
        }
        close $fh;
    }
    elsif (!$pool_defined) {

        #No assay2pool.txt file exists and sample.pool also does not exist.
        #Fall back on auto generation based on batch.
        my %fcl2pool;
        my $pool_cnt = 1;
        foreach my $assay_id (sort keys %$a2m_href) {
            my $r = $a2m_href->{$assay_id};
            if (    $r->{'assay.flow_cell'}
                and $r->{'assay.flow_cell'} ne '.'
                and $r->{'assay.lane'}
                and $r->{'assay.lane'} ne '.')
            {
                if (!$fcl2pool{ $r->{'assay.flow_cell'} }
                    { $r->{'assay.lane'} })
                {
                    $fcl2pool{ $r->{'assay.flow_cell'} }{ $r->{'assay.lane'} }
                      = $pool_cnt++;
                }
            }
        }
        foreach my $assay_id (sort keys %$a2m_href) {
            my $r = $a2m_href->{$assay_id};
            if (    $r->{'assay.flow_cell'}
                and $r->{'assay.flow_cell'} ne '.'
                and $r->{'assay.lane'}
                and $r->{'assay.lane'} ne '.')
            {
                $r->{'assay.pool'} = 'pool'
                  . $fcl2pool{ $r->{'assay.flow_cell'} }
                  { $r->{'assay.lane'} };
            }
        }
    }
    else {
   #We've got pool information, check it for conisistency, and disambiguate if
   #necessary. Go through all the assays, and add the pools that they may be
   #in. At the end, every assay should be in a single pool. If it isn't we've
   #got a problem. Currently we require that we have flow cell and lane
   #information for every assay. Ultimately we may need to relax this.
        my %batch2pools;
        my %batch2samples;
        my %sample2batches;
      ASSAY:
        foreach my $assay_id (sort keys %$a2m_href) {
            my $r = $a2m_href->{$assay_id};
            if (  !$r->{'assay.flow_cell'}
                or $r->{'assay.flow_cell'} eq '.'
                or !$r->{'assay.lane'}
                or $r->{'assay.lane'} eq '.')
            {
                die
"No flow cell and/or lane information for $assay_id. Cannot "
                  . "procede without this. Stopped";
            }
            my $sample_id = $a2s_href->{$assay_id};
            if (!$s2m_href->{$sample_id}) {

                #can't assign pools to assays with no sample info.
                #This is a fatal error anyway. Something is wrong somewhere.
                die "No sample information for assay $assay_id. Stopped";
            }

            #standardize pool names. No spaces, all lowercase
            my $pool_set_str = lc($s2m_href->{$sample_id}{'sample.pool'});
            $pool_set_str =~ s/\s+//g;
            my $batch_id = "$r->{'assay.flow_cell'}_$r->{'assay.lane'}";
            $batch2samples{$batch_id}{$sample_id}  = 1;
            $sample2batches{$sample_id}{$batch_id} = 1;
            my $DEBUG = 0;

            my @new_pools = split(/[;,]/, $pool_set_str);
            if ($DEBUG) {
                warn "new pools for $sample_id are @new_pools\n";
            }
            if (!@new_pools) {
                die "No assay.pool defined for sample $sample_id. Stopped";
            }
            if (!$batch2pools{$batch_id}) {

                #initialize
                foreach my $pool (@new_pools) {
                    $batch2pools{$batch_id}{$pool} = 1;
                    warn "initializing b2p $batch_id to $pool\n" if ($DEBUG);
                }
            }
            else {
                #Set pools for this batch to the intersection of the two sets.
                my %new;
                @new{@new_pools} = ();
                my @old_pools = sort keys %{ $batch2pools{$batch_id} };
                warn "old pools for batch $batch_id are @old_pools\n"
                  if ($DEBUG);
                foreach my $pool (@new_pools, @old_pools) {
                    if (exists $new{$pool} and $batch2pools{$batch_id}{$pool})
                    {
                        $batch2pools{$batch_id}{$pool} = 1;
                    }
                    else {
                        delete $batch2pools{$batch_id}{$pool};
                    }
                }
                my @final_pools = sort keys %{ $batch2pools{$batch_id} };
                warn "final pools for batch $batch_id are @final_pools\n"
                  if ($DEBUG);
                if (!keys %{ $batch2pools{$batch_id} }) {
                    die
"Pooling inconsistency: Batch $batch_id required to be in "
                      . "inconsistent pool sets. old=@old_pools new=@new_pools Stopped";
                }
            }
        }

     #Now we may have cases where some batches can still be in more than one
     #pool. Sometimes we can resolve this and sometimes we cannot. We can
     #resolve it if all other batches for a sample have a single pool, so that
     #there is only one remaining pool possibility for this batch. If this is
     #the case, take care of it, otherwise die with an approriate error
     #message.
        foreach my $batch_id (keys %batch2pools) {
            next if (scalar keys %{ $batch2pools{$batch_id} } == 1);

        #Look at the samples which contain this batch. If all other batches
        #are assigned to pools and removing their pools from the set of pools
        #available reduces us to a single possibility, we can assign that pool
        #to this batch and we are good.

         #Compute the intersection of the available pools for all samples with
         #this batch. If this is empty, we've got an inconsistency, if this is
         #exactly one pool, we're good. If it is more than one pool, we need
         #help.
            my %possible_pools;
            @possible_pools{ keys %{ $batch2pools{$batch_id} } } = ();
            foreach my $sample (keys %{ $batch2samples{$batch_id} }) {
                my @all_batches = keys %{ $sample2batches{$sample} };
                foreach my $test_batch (@all_batches) {
                    next if ($test_batch eq $batch_id);

                #If the test batch is in a single pool, our batch cannot be in
                #that pool, so remove it from our possibilities.
                    my @test_pools = keys %{ $batch2pools{$test_batch} };
                    if (scalar @test_pools == 1) {
                        delete $possible_pools{ $test_pools[0] };
                    }
                }
            }

            #Now if there is exactly one possible pool, we're good, otherwise
            #we've got a problem.
            my @possible_pools = keys %possible_pools;
            if (scalar @possible_pools == 1) {
                $batch2pools{$batch_id} = {};
                $batch2pools{$batch_id}{ $possible_pools[0] } = 1;
            }
            elsif (!@possible_pools) {
                die
                  "Inconsistency in pool assignment. Not possible to assign "
                  . "$batch_id to a pool. Stopped";
            }
            else {
                die
"Batch $batch_id has multiple possible pools (@possible_pools). It is not "
                  . "possible to automatically disambiguate this. Please create "
                  . "assay2pool.txt file and re-run.\n";
            }
        }

        #If we survive this, go through all the assays and assign pools.
        foreach my $assay_id (keys %$a2m_href) {
            my $r        = $a2m_href->{$assay_id};
            my $batch_id = "$r->{'assay.flow_cell'}_$r->{'assay.lane'}";
            $r->{'assay.pool'} = (keys %{ $batch2pools{$batch_id} })[0];
        }
    }

    #We also need to delete 'sample.pool' from the sample metadata.  It's
    #currently not allowed in the final design file. Perhaps we should
    #change this?
    foreach my $smpl (keys %$s2m_href) {
        delete $s2m_href->{$smpl}{'sample.pool'};
    }

    #Now we've got our pool assignments via one of the three methods.
    #Something still could be wrong (like the assay2pool.txt file could be
    #bad). Do a simple sanity check that the set of samples in a pool is the
    #same for all flowcell and lane combos. If it isn't, something is badly
    #wrong.
    my %pools_info;
    foreach my $asy (keys %$a2m_href) {
        my $r = $a2m_href->{$asy};
        next
          if ( !$r->{'assay.pool'}
            or !$r->{'assay.flow_cell'}
            or !$r->{'assay.lane'});
        my $sample   = $a2s_href->{$asy};
        my $batch_id = "$r->{'assay.flow_cell'}_$r->{'assay.lane'}";
        $pools_info{ $r->{'assay.pool'} }{$batch_id}{$sample} = 1;
    }
    my $all_pools_ok = 1;
    foreach my $pool (keys %pools_info) {
        my $r = $pools_info{$pool};
        my %smpls;
        my $max = 0;
        foreach my $fc_l (keys %$r) {
            foreach my $smpl (keys %{ $r->{$fc_l} }) {
                $smpls{$smpl}++;
                if ($smpls{$smpl} > $max) {
                    $max = $smpls{$smpl};
                }
            }
        }
        my $ok = 1;
        foreach my $smpl (keys %smpls) {
            if ($smpls{$smpl} != $max) {
                warn
"Sample $smpl in pool $pool is not in all flowcell lane combos.\n"
                  if ($verbose);
                $ok = 0;
            }
        }
        if ($ok) {
            my $num_smpls = scalar keys %smpls;

#warn "Pool $pool has $num_smpls identical samples in $max flowcell lane combos.\n";
        }
        else {
            warn "Pool $pool is incorrect.\n" if ($verbose);
            $all_pools_ok = 0;
        }
    }
    if (!$all_pools_ok) {
        die "Problems with pool membership.\n";
    }
    else {
        warn "Pooling sanity check is OK.\n" if ($verbose);
    }
}

