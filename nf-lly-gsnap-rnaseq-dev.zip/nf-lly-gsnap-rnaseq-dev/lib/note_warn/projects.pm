package projects;
#
#===============================================================================
#
#         FILE:  projects.pm
#
#  DESCRIPTION:  Some simple utilities for selecting projects and samples
#                from the projects files in
#                /lrlhps/genomics/prod/genome_projects
#
#        FILES:  ---
#         BUGS:  ---
#        NOTES:  ---
#       AUTHOR:  John Calley (jnc), <calley_john_n@lilly.com>
#      COMPANY:  Eli Lilly & Co.
#      VERSION:  1.0
#      CREATED:  3/22/17
#     REVISION:  ---
# Revision History:
#  0.33 John Calley 10/10/2023
#     --Added spaceranger2.1.0
#  0.32 John Calley 9/29/2023
#     --Added cellranger7.2.0 results to testing. Needs to be a more flexible
#     test to allow wild careds. hopefully we will transition to new tool
#     written by Richard Du soon that will replace this...
#  0.31 John Calley 6/23/2023
#     --Added a new test DirExistPattern to standards supported testing to
#     enable definition of the StandardAnalyses:PairwiseComparison standard.
#  0.30 James Scherschel 6/14/2023
#     --No clue why the switch to uuids created headaches for me on hpc and aws
#     but temp fix #1 is using python instead of the perl mod
#  0.29 John Calley 6/13/23
#     --Switched to using UUIDs to guarantee manifest file uniqueness instead
#     of tempfile to guarantee uniqueness between AWS and Isilon file systems
#     --Removed a useless and misleading 'use lib'. Remember that FindBin
#     returns the location of the original perl script executed, not this
#     module.
#  0.28 John Calley 3/21/23
#     --File_size_ands_mod_date now returns 'unavailable' rather than '', when
#     unavailable.
#  0.27 John Calley 3/17/23
#     --Suppressed a nuisance warning message
#  0.26 John Calley 9/9/22
#     --Added SingleCellPostProcessing to standards supported
#  0.25 John Calley 4/19/22
#     --Added suggestion to try newgrp to permissions related error message. 
#  0.24 John Calley 3/18/22
#     --Added SQANTI3 standard
#     --Added cellranger_arc to cellRanger standard
#     --Added autorecognition of RNA/ATAC and RNASeq:LR projects
#  0.23 John Calley 1/19/22
#     --Moved the Standards Supported definitions and utilities here so they
#     can be more conveniently re-used. Really need to add reading them from
#     a more accessible external file at some point.
#  0.22 John Calley 10/22/21
#    --Added recognition of LegacyExome projects (by presence of vcf
#    directory)
#  0.21 John Calley 4/28/21
#    --Added recognition of newer Exome projects.
#  0.20 John Calley 10/9/20
#    --Added auto recognition of TSO_500 projects
#  0.19 John Calley 12/16/19
#    --Added to the ways to identify repSeq projects to recognize Oxford OAS
#    projects
#  0.18 John Calley 6/10/19
#    --Fixed a typo in an error message
#  0.17 John Calley 3/9/19
#     --Changed get_project_type to recognize newer AnalysisRNASeq projects
#  0.16 John Calley 1/4/19
#     --Updated some comments
#     --Fixed a bug that was preventing standards supported from being
#     returned by select_projects
#     --Added sample_cnt, status, and standards to the return hash from select_projects
#  0.15 John Calley 7/17/18
#     --Modified write_manifest so that it will not allow a project name to be
#     written which contains special characters.
#  0.14 John Calley 7/16/18
#     --We were just looking for QC_results.txt to exist and be non-zero in
#     size. We now require that it have at least two lines because sometimes
#     people put in just a header line as a template.
#  0.13 John Calley 7/10/18
#     --read_manifest was returning an array reference if an entry had
#     multiple comma separated values and a scalar if there was only one. This 
#     caused problems in calling scripts. It now always returns a scalar
#     which may be a set of comma separated values.
#     --write_manifest now requires a result dn as an argument and will write
#     the actual manifest file in the global manifests directory and put a
#     symlink to it into the results directory. 
#     --Manifest files now contain Location which has the full path of
#     the results directory (but might eventually point to the cloud).
#     --Removed checking on manifest file read and write that fields were
#     'legal'.
#  0.13 John Calley 4/30/18
#     --Added names parameters to select_projects
#     --select_projects now uses the sample types in all_projects rather than 
#       calling get_meta on each project.
#     --Added support for selecting projects based on supported_standards to
#     select_projects.
#  0.12 John Calley 4/4/18
#     --Fixed a problem in get_project_status that was incorrectly reporting
#     no_metadata.
#  0.11 John Calley 2/27/18
#    --Added get_project_by_location, read_manifest, and write_manifest.
#    --Removed default project type of external. If we can't infer it, it must
#    be set in the manifest.
#  0.10 John Calley 2/26/18
#    --Added ChinaRNASeq and AnalysisRNASeq to the project types that
#    get_project_type can recognize.
#  0.09 John Calley 2/26/18
#    --Changed the default project_type to External since there's really
#    nothing we can depend on for these projects.
#  0.08 John Calley 2/23/18
#    --Moved get_project_type from meta_data to this module since it makes
#    more sense here.
#    --Change exome project type to Exome to match usage elsewhere.
#  0.07 John Calley 2/9/18
#    --Added change_all_projects
#  0.06 John Calley 8/17/17
#    --Adapted to be more robust to wonky metadata.
#  0.05 John Calley 8/9/17
#     --Removed lower-casing of organism and sets in the results. We still
#     lower-case to check for inclusion so as to be more forgiving.
#  0.04 John Calley 8/9/17
#     --Made some variable names better.
#     --Removed lower-casing of project type. We still lower-case when
#     comparing to the list of those we want, but we return the un-lowercased
#     version to make downstream analyses easier.
#  0.03 John Calley 7/27/17
#     --Rewrite to target all_projects rather than individual files.
#  0.02 John Calley 7/19/17
#     --We were lower casing project names. This seems hostile, removed this.
#     --Set verbose to a default value of 0 to avoid warnings.
#===============================================================================

require Exporter;
@ISA       = qw(Exporter);
@EXPORT    = qw();
@EXPORT_OK = qw(
  change_all_projects
  select_projects
  get_project_by_location
  get_project_type
  @project_status_types
  get_project_status
  %legal_manifest_fields
  read_manifest
  write_manifest
  standards_definitions
  get_standards
  print_standards
);

use strict;
use warnings;
use Carp;
use POSIX qw(asctime);
use Cwd qw(abs_path);
use File::Temp qw(tempfile);
#We know we can find the meta_data.pm module because it is in the same
#directory as this module
use meta_data qw(get_meta_with_design);

#This is more of a pain because we need to use lib a relative path from the
#current location
#use lib do {
#    use Cwd 'abs_path';
#    my ($dir) = __FILE__ =~ m{^(.*)/};  # $dir = path of current file
#    abs_path("$dir/lib/perl5");            # path of '../lib' relative to $dir
#};
#use Data::UUID;

#Default location of all_projects.txt file.
my $proj_fn = '/lrlhps/genomics/prod/genome_projects/all_projects.txt';

#Change so that select_projects uses a different all_projects file from the
#default.
sub change_all_projects {
   $proj_fn = shift @_;
}

#All manifest files are stored in one central location that is readable by
#anyone and writeable by any member of the genomics group. This is done so
#that basic project metadata can be made readable by all but we can still
#properly protect the underlying project data. This is becoming an increasing
#problem as we have more clinical data sets with particular sets of users with
#different kinds of access. We can no longer assume that any one user can see
#all projects.
#So, when a manifest file is created it is written to this central location
#and it contains the location of the results directory as 'Location:'
#The results directory contains a symlink to the actual manifest file so we
#can easily access it from the results directory. The all projects file is
#populated by reading manifest files in this central location.
my $manifest_directory = '.';

#Given a results directory, return a hash with basic project info
#Has contents will be names according to all_projects2.0 as much as possible
#(because it's still under development).
sub get_project_by_location {
    my ($dn) = @_;

    $dn = abs_path($dn);
    if (!$dn or !-d $dn) {
        return {};
    }
    my %results;
    open my $fh, '<', $proj_fn
        or die "Unable to open file $proj_fn for reading ($!). Stopped";

    my $title_ln = <$fh>;
    $title_ln =~ s/\R$//;
    my @titles = split(/\t/, $title_ln);
    my @rest_titles = @titles[6..$#titles];
    LINE:
    while (my $line = <$fh>) {
        $line =~ s/\s+$//;
        next LINE if (!$line);
        next LINE if ($line =~ m/^#/);
        my ($ptype, $org, $p_name, $loc, $stds, $smpls, @rest)
           = split(/\t/, $line);
        if (abs_path($loc) eq $dn) {
            %results = (
                ProjectType => $ptype,
                Organism    => $org,
                ProjectName => $p_name,
                Location    => $loc,
                StandardsSupported => $stds,
                NumSamples   => $smpls,
            );
            foreach my $i (0..$#rest) {
                if ($rest_titles[$i]) {
                    $results{$rest_titles[$i]} = $rest[$i]||'';
                }
            }
            last LINE;
        }
    }
    return \%results;
}


#Positional arguments:
#   project_types: 'all' or a comma delimited list of types where the types are those
#                   in the project file (i.e., RNASeq, DNA_chip, Exome, etc). Case is
#                   not important.
#                   A null value is equivalent to 'all'.
#   organisms:     'all' or a comma delimited list of organism names. Case is not
#                  important. A null value is equivalent to 'all'.
#   sets:          'all' (or null) or a comma delimited list of set names. Case is not
#                  important. If a set list is given, membership in any of the sets
#                  is enough to include the project.
#   sample_types:  'all' (or null) or a comma delimited list of sample.type
#                  values. A project will be included in the list if it has at
#                  least one sample with the one of the indicated types.
#   names:         'all' (or null) or a comma delimted list of project names. Case
#                  is not important.
#   verbose        If 0 no progress info. If 1 summary stats reported to
#                  stderr. If 2 more detailed info reported to stderr
#Named arguments:
#    As above except with a leading '-'.
#    -project_types, -organisms,-sets, -sample_types, -names, -verbose
#    And one additional argument (not available positionally.
#    -supported_standards    -Comma delimited set of standards supported.
# Result will be a hash reference with the following structure:
#    $hash_ref->{project_type}{organism}{project_name} {
#          sets:      <comma delimited set list>
#          location:  <path to the results directory>
#          types:     <comma delimited set of sample types in this project>
#                     Empty unless sample_type was requested.
#          standards: comma delimted list of standardes supported.
#          sample_cnt: Sample count
#          status:    project status
#    }
sub select_projects {
    my ($p_types, $p_orgs, $p_sets, $s_types, $p_names, $verbose, $supported_standards);
    
    if ($_[0] =~ m/^-/) {
       #Named arguments
        my %parms = @_;
        $p_types = $parms{'-project_types'} || 'all';
        $p_orgs  = $parms{'-organisms'} || 'all';
        $p_sets  = $parms{'-project_sets'} || 'all';
        $s_types = $parms{'-sample_types'} || 'all';
        $p_names = $parms{'-project_names'} || 'all';
        $verbose = $parms{'-verbose'} || 0;
        $supported_standards = $parms{'-supported_standards'} || 'all';
    } else {
        #positional arguments
        ($p_types, $p_orgs, $p_sets, $s_types, $p_names, $verbose) = @_;;
        $p_types ||= 'all';
        $p_orgs  ||= 'all';
        $p_sets  ||= 'all';
        $s_types ||= 'all';
        $p_names ||= 'all';
        $verbose ||= 0;
        #can't set supported standards positionally
        $supported_standards = 'all';
    }

    if ($p_types eq 'all') {
        $p_types = '';
    }
    my %keep_proj_types;
    if ($p_types) {
        foreach my $t (split(/,\s*/, $p_types)) {
            $keep_proj_types{lc($t)} = 1;
        }
    }

    if ($p_orgs eq 'all') {
        $p_orgs = '';
    }
    my %keep_orgs;
    if ($p_orgs) {
        foreach my $t (split(/,\s*/, $p_orgs)) {
            $keep_orgs{lc($t)} = 1;
        }
    }

    if ($p_sets eq 'all') {
        $p_sets = '';
    }
    my %keep_sets;
    if ($p_sets) {
        foreach my $t (split(/,\s*/, $p_sets)) {
            $keep_sets{lc($t)} = 1;
        }
    }

    if ($s_types eq 'all') {
        $s_types = '';
    }
    my %keep_smpl_types;
    if ($s_types) {
        foreach my $t (split(/,\s*/, $s_types)) {
            $keep_smpl_types{lc($t)} = 1;
        }
    }
    $p_names = $p_names;
    if ($p_names eq 'all') {
        $p_names = '';
    }
    my %keep_names;
    if ($p_names) {
        foreach my $t (split(/,\s*/, $p_names)) {
            $keep_names{$t} = 1;
        }
    }
    if ($supported_standards eq 'all') {
        $supported_standards = '';
    }
    my %keep_standards;
    if ($supported_standards) {
        foreach my $t (split(/,\s*/, $supported_standards)) {
            $keep_standards{$t} = 1;
        }
    }

    my %counts;
    my %results;
    open my $fh, '<', $proj_fn
        or die "Unable to open file $proj_fn for reading ($!). Stopped";

    my $title_str = <$fh>;
    LINE:
    while (my $line = <$fh>) {
        $line =~ s/\R$//;
        next LINE if (!$line);
        if ($line =~ m/^#/) {
            $counts{'unusable_project'}++;
            next LINE;
        }
        my ($type, $org, $name, $dn, $sets, $stds, $smpl_cnt, $start_date, $last_date, $p_stat, $access, $s_types) =
              split(/\t/, $line);
        if (!$name) {
            $counts{empty_project_name}++;
            next LINE;
        }
        #warn "Type=$type From $p_types\n";
        if (%keep_proj_types and !$keep_proj_types{lc($type)}) {
            $counts{discard_project_type}++;
            if ($verbose >= 2) {
                warn "$type $org $name discarded based on wrong project type.\n";
            }
            next LINE;
        }
        if (%keep_orgs and !$keep_orgs{lc($org)}) {
            $counts{discard_organism}++;
            if ($verbose >= 2) {
                warn
                  "$type $org $name discarded based on wrong organism.\n";
            }
            next LINE;
        }
        if (%keep_sets) {
            my $keep = 0;
            foreach my $set (split(/,\s*/, $sets)) {
                if ($keep_sets{lc($set)}) {
                    $keep = 1;
                    last;
                }
            }
            if (!$keep) {
                $counts{discard_set}++;
                if ($verbose >= 2) {
                    warn "$type $org $name discarded based on lack of desired set membership.\n";
                }
                next LINE;
            }
        }
        if (%keep_names and !$keep_names{$name}) {
            $counts{discard_name}++;
            if ($verbose >= 2) {
                warn "$type $org $name discarded based on lack of project name.\n";
            }
            next LINE;
        }
        if ($s_types and %keep_smpl_types) {
            my $keep = 0;
            foreach my $stype (split(/,\s*/, $s_types)) {
                if ($keep_smpl_types{$stype}) {
                    $keep = 1;
                    last;
                }
            }
            if (!$keep) {
                $counts{discard_sample_type}++;
                if ($verbose >= 2) {
                    warn "$type $org $name discarded based on lack of any samples of desired types.\n";
                }
                next LINE;
            }
        }
        if (%keep_standards) {
            my $keep = 0;
            foreach my $std (split(/,\s*/, $stds)) {
                if ($keep_standards{$std}) {
                    $keep = 1;
                    last;
                }
            }
            if (!$keep) {
                $counts{discard_supported_standards}++;
                if ($verbose >= 2) {
                    warn "$type $org $name discarded based on lack of support for required standards.\n";
                }
                next LINE;
            }
        }

        $counts{keep}++;
        $results{$type}{$org}{$name} = {
            sets      => $sets,
            location  => $dn,
            types     => $s_types,
            standards => $stds,
            sample_cnt =>$smpl_cnt,
            status    => $p_stat,
          };
    }    #line

    if ($verbose) {
        warn "Project Totals:\n";
        foreach my $key (keys %counts) {
            warn "$key\t$counts{$key}\n";
        }
    }
    return \%results;
}

#Given a project results directory, infer the project type by looking for the
#presence of key files.
sub get_project_type {
    my $results_dn = shift;

    my $type = 'RNASeq';
    # if (-s "$results_dn/xscript_raw_counts/sample_combined_counts.txt") {
    #     $type = 'RiboProfiling';
    # } elsif (-s  "$results_dn/raw_counts/combined_miR_level_counts.txt") {
    #     $type = 'miRSeq';
    # } elsif (-d "$results_dn/vcf") {
    #     $type = 'LegacyExome';
    # } elsif (-d "$results_dn/../../finalvcf" or -d "$results_dn/variants") {
    #     $type = 'Exome';
    # } elsif (-d "$results_dn/PICNIC") {
    #     $type = 'DNA_chip:snp6';
    # } elsif (-d "$results_dn/TSO_QC") {
    #     $type = 'TSO_500';
    # } elsif (-d "$results_dn/SQANTI3") {
    #     $type = 'RNASeq:LR';
    # } elsif (-d "$results_dn/cellranger_arc2.01_results") {
    #     $type = 'RNA/ATAC';
    # } elsif (-d "$results_dn/genotype_calls") {
    #     $type = 'DNA_chip';
    # } elsif (-s "$results_dn/raw_counts/gene_count_totals.txt") {
    #     $type = 'RNASeq';
    #     if (!-d "$results_dn/aligned_bam") {
    #         if (-s "$results_dn/make_analysis_directories.txt"
	# 	     or -s "$results_dn/project_data/make_analysis_directories.txt"
	# 	) {
    #             ###Some Analysis projects are missing this file.
    #             $type = 'AnalysisRNASeq';
    #         } else {
    #             $type = 'ChinaRNASeq';
    #         }
    #     }
    # } elsif (  -d "$results_dn/raw_anarci_imgt" 
    #         or -d "$results_dn/raw_anarci_chothia"
    #         or -d "$results_dn/raw_anarci_aho"
    #         or -d "$results_dn/summary_reports_imgt"
    #         or -d "$results_dn/summary_reports_chothia"
    #         or -d "$results_dn/summary_reports_aho"
    #          ) {
    #     $type = 'RepSeq';
    # }  elsif (!-d "$results_dn/aligned_bam") {
    #     #Newer AnalysisRNASeq projects don't have the gene_count_totals file
    #     #so we catch them here.
    #     if (   -s "$results_dn/make_analysis_directories.txt"
    #         or -s "$results_dn/project_data/make_analysis_directories.txt") {
    #         $type = 'AnalysisRNASeq';
    #     }
    # }

    return $type;
}

#All possible project statuses that can be returned by get_project_status
my @project_status_types = (
            'status_summary',
            'meta_data_status',
            'meta_data_mod_date',
            'QC_results_status',
            'QC_results_mod_date',
            'design_file_status',
            'design_file_mod_date',
            'sup_aln_status',
        );
#Return projects status for the status types that are set to true in
#$types_href. Return statuses will be in $stats_href.
sub get_project_status {
    my ($type, $dn, $stats_href, $types_href) = @_;

    if ($types_href->{sup_aln_status}) {
        my $sup_aln_status = 'NA';
        my $sup_dn = "$dn/supplementary_alignments";
        $sup_aln_status = 'supplementary_alignments_missing';
        if (-d $sup_dn) {
            $sup_aln_status = 'supplementary_alignments_dir_exists';
            if (-d  "$sup_dn/undermapped_reads") {
                $sup_aln_status = 'undermapped_reads_dir_exists';
                if (-d  "$sup_dn/optityper") {
                    $sup_aln_status = 'optityper_dir_exists';
                }
            }
        }
        $stats_href->{sup_aln_status} = $sup_aln_status;
    }

    my $summary_status = 'NoMetaData';
    my ($dsf_size, $dsf_date) = file_size_and_mod_date("$dn/design_file.txt");
    if ($dsf_size) {
        $stats_href->{design_file_status} = 'Exists' if ($types_href->{design_file_status});
        $stats_href->{design_file_mod_date} = $dsf_date if ($types_href->{design_file_mod_date});
    }
    #We look for all sample level data files and report success if any exist
    #and our date is the latest mod date.
    my ($biggest_smf_size, $latest_smf_time) = (0,0);
    my $latest_smf='';
    foreach my $smf ("$dn/meta_data/meta_data.txt", glob("$dn/meta_data/meta_data_sample*.txt")) {
        my ($size, $mod_time) = (-s $smf, -M _);
        $biggest_smf_size = $size if ($size and $size > $biggest_smf_size);
        if ($mod_time and  $mod_time > $latest_smf_time) {
            $latest_smf_time = $mod_time;
            $latest_smf = $smf;
        }
    }
    my ($smf_size, $smf_date) = file_size_and_mod_date($latest_smf);
    if ($biggest_smf_size) {
        $stats_href->{meta_data_status} = 'Exists' if ($types_href->{meta_data_status});
        $stats_href->{meta_data_mod_date} = $smf_date if ($types_href->{meta_data_mod_date});
    }
    my $qc_fn = "$dn/meta_data/QC_results.txt";
    my ($qcf_size, $qcf_date) = file_size_and_mod_date($qc_fn);
    if ($qcf_size) {
        my $line_cnt = `wc -l $qc_fn`;
        $line_cnt =~ s/ .*//;
        if ($line_cnt and $line_cnt >= 2) {
            #Avoid counting a QC_results file that just has a header line
            $stats_href->{QC_results_status} = 'Exists' if ($types_href->{QC_results_status});
            $stats_href->{QC_results_mod_date} = $qcf_date if ($types_href->{QC_results_mod_date});
        }
    }
    if ($dsf_size) {
        if ($biggest_smf_size) {
            if ($qcf_size) {
                $summary_status = 'Metadata/QC/DesignComplete';
            } else {
                $summary_status = 'Metadata_No_QC';
            }
        } elsif ($qcf_size) {
            $summary_status = 'QC_No_Metadata';
        } else {
            $summary_status = 'No_QC_No_Metadata';
        }
    } else {
        if ($biggest_smf_size) {
            if ($qcf_size) {
                $summary_status = 'Metadata_QC_No_Design';
            } else {
                $summary_status = 'Metadata_No_QC_No_Design';
            }
        } elsif ($qcf_size) {
            $summary_status = 'QC_No_Metadata_No_Design';
        } else {
            $summary_status = 'No_QC_No_Metadata_No_Design';
        }
    }
    $stats_href->{status_summary} = $summary_status if ($types_href->{status_summary});
}

sub file_size_and_mod_date {
    my $path = shift;

    my ($size, $mod_secs) = (stat($path))[7,9];
    if ($size) {
        my $mod_date = asctime(localtime($mod_secs));
        $mod_date =~ s/\R$//;
        return ($size, $mod_date);
    } else {
        return (0, 'unavailable');
    }
}

###For the moment,at least, we are no longer checking that manifest fields are
#legal at read or write. We're thinking about using the manifest file for a
#lot more information so I think that being restrictive about this will
#probably be a bad idea.
my %legal_manifest_fields = (
    DateFirstTouched     => 1,
    DateLastTouched      => 1,
    NumSamples           => 1,
    Organism             => 1,
    ProjectName          => 1,
    ProjectStatus        => 1,
    ProjectType          => 1,
    SampleTypes          => 1,
    Sets                 => 1,
    StandardsSupported   => 1,
    Access               => 1,
    Location             => 1,
);

#Manifest file should always be <results_dn>/manifest.txt
#If you pass in a directory the file name will be this. If you pass in a file
#name we will use that instead.
sub read_manifest {
    my ($fdn, $href) = @_;

    my $fn;
    if (-d $fdn) {
        $fn = "$fdn/manifest.txt";
    } else {
        $fn = $fdn;
    }
    if (!-s $fn) {
        return;
    }
    open my $fh, '<', $fn
        or die "Unable to open file $fn for reading ($!). Stopped";
    LINE:
    while (my $line = <$fh>) {
        $line =~ s/\R$//;
        if ($line =~ m/^([^:]+):\s+(.+)$/) {
            my ($key, $val) = ($1, $2);
            #next LINE if (!$legal_manifest_fields{$key});
            $val =~ s/^\s+|\s+$//g;
            $href->{$key} = $val;
        }
    }
    close $fh;
}

#Manifest file should always be located in $manifest_directory and pointed to
#by a symlink at <results_dn>/manifest.txt
#Manifest file names are guaranteed to be unique via File::Temp
sub write_manifest {
    my ($rdn, $href) = @_;

    if (!-d $rdn) {
        die "write_manifest must be passed a valid results directory. Got $rdn. Stopped";
    }
    $rdn = abs_path($rdn);

    #Do we have the permissions we need?
    if (!-w $rdn) {
        die "Unable to write to results directory $rdn\nUnable to create manifest file link. Possibly you need to use newgrp to change your current group?\nStopped";
    }
    if (!-w $manifest_directory) {
        die "Unable to write to manifests directory $manifest_directory. Stopped";
    }

    my $link_nm = "$rdn/manifest.txt";
    my $ofn;
    if (-l $link_nm) {
        #We already have the symlink in place. Re-use the existing manifest
        #file.
        $ofn = readlink($link_nm);
    } elsif (-f $link_nm) {
        #We've got a file in this location. We'll need to delete it to make
        #room for the symlink
        unlink $link_nm;
    }

    if (!$ofn) {
        ##Not really a temp file. We're just using this to guarantee uniqueness.
        #my ($tfh, $tfn) =  tempfile('manifest_XXXXXXXX', UNLINK=>0, DIR => $manifest_directory, suffix => '.txt'); 
        #close $tfh;
        #$ofn = $tfn;

        #my $ug = Data::UUID->new();
        #my $uuid = $ug->create();
        #$ofn = $manifest_directory . '/manifest_' . $ug->to_string($uuid) . '.txt';

        my $uuid = `(echo 'from uuid import uuid4'; echo 'print(uuid4())') | python`;
        chomp($uuid);
        $ofn = $manifest_directory . '/manifest_' . $uuid . '.txt';
    }



    $href->{'Location'} = $rdn;

    open my $ofh, '>', $ofn
        or die "Unable to open file $ofn for writing ($!). Stopped";

    foreach my $key (sort keys %$href) {
        #next if (!$legal_manifest_fields{$key});
        my $pname = $href->{ProjectName}||'';
        (my $safe_pname = $pname) =~ tr/A-Za-z0-9_-/_/c;
        if ($pname ne $safe_pname) {
            warn "Suggested project name $pname contains illegal characters. Replaced with $safe_pname.\n";
            $href->{ProjectName} = $safe_pname;
        }
        if (ref $href->{$key} eq 'ARRAY') {
            print {$ofh} "$key:\t", join(', ', sort @{$href->{$key}}), "\n";
        } else {
            print {$ofh} "$key:\t$href->{$key}\n";
        }
    }
    close $ofh;
    chmod 0664, $ofn;

    unlink($link_nm);
    symlink($ofn, $link_nm);
}


########Standards Supported Definitions and utilities
#NOTE: Intent is to read these from an external file at some point

#'test' entries names must start with 'test'. If there is more than one they
#are ANDed. Some tests like OrDirExist have an internal 'OR'.
my %standards_definitions = (
    GeneSampleRPM => {
        test1 => ['ProjectTypeNot', 'miRSeq'],
        test2 => ['FileExist', 'raw_counts/simplistic_sample_level_rpm.txt'],
        description => 'Gene Simplistic Sample Level RPM',
    },
    TargettedGeneSampleRPM => {
        test1 => ['FileExist', 'raw_counts_targetted/simplistic_sample_level_rpm.txt'],
        description => 'TargettedGeneRPMCounts',
    },
    miRSampleRPM => {
        test1 => ['ProjectType', 'miRSeq'],
        test2 => ['FileExist', 'raw_counts/simplistic_sample_level_rpm.txt'],
        description => 'miR Simplistic Sample Level RPM',
    },
    'StandardAnalyses:PairwiseComparison' => {
        #There are sub-directories in some analyses directories which come from
        #the older Xi/Simone Rollup script so we have to look for the specific
        #pattern shown here of alphanumeric name followed by numeric date.
        #Some may also have a status but it is not always present, so we just
        #anchor at the beginning of the directory name.
        #This will test one directory pattern. First arg is a glob that will
        #select directories to test, second is a regex that will do the
        #detailed test
        test1 => ['DirExistPattern', 'analyses/*', '\/analyses\/[A-Za-z0-9_]+-[0-9]{8}'],
    },
    SingleCellCounts => {
        test2 => ['FileExist', 'raw_counts/single_cell_counts.txt'],
        description => 'Standard Single Cell Counts',
    },
    SpliceCounts => {
        test => ['DirExist', 'raw_counts/splices'],
        description => 'Assay level raw splice counts',
    },
    SingleCellPostProcessing => {
        test => ['DirExist', 'single_cell_postprocessing'],
        description => 'Single Cell PostProcessing (MTX, clustering, cell types, and projections)',
    },
    SQANTI3 => {
        test => ['DirExist', 'SQANTI3'],
        description => 'SQANTI3 Isoform analyses',
    },
    FusionData => {
        test => ['DirExist', 'fusion/raw_fusions'],
        description => 'Assay level raw fusion data',
    },
    HLAI_Genotypes => {
        test => ['FileExist', 'supplementary_alignments/optitype_genotypes.txt'],
        description => 'Optityper derived MHC class I genotype predictions',
    },
    RepeatRPM => {
        test => ['FileExist', 'raw_counts/simplistic_sample_level_repeat_class_RPM.txt',],
        description => 'Class, Family, and Name level Repeat RPM expression',
    },
    DesignFile => {
        test => ['FileExist', 'design_file.txt'],
        description => 'Design file',
    },
    miR_level_counts => {
        test => ['FileExist', 'raw_counts/combined_miR_level_counts.txt'],
        description => 'Raw mature miR level counts',
    },
    genotype_calls => {
        test => ['DirExist', 'genotype_calls'],
        description => 'Assay level genotype calls in VCF',
    },
    exome_vcf => {
        test => ['DirExist', '../../finalvcf'],
        description => 'Sample level Exome pipeline variant calls',
    },
    CumRiboPCounts => {
        test =>['FileExist', 'xscript_raw_counts'],
        description => 'Cumulative counts of ribosomal protected regions over transcripts',
    },
    CDR_Counts => {
        test => ['OrFileExist', 
            'raw_counts/sample_imgt_cdr_counts.txt',
            'raw_counts/sample_chothia_cdr_counts.txt',
            'raw_counts/sample_aho_cdr_counts.txt',
        ],
        description => 'Sample level Ab and/or TCR CDR counts',
    },
    RepSeqSummaries => {
        test => ['OrDirExist', 
            'summary_reports_imgt',
            'summary_reports_aho',
            'summary_reports_chothia',
        ],
        description => 'Ab and/or TCR alignment information',
    },
    Supp_CDR_Counts => {
        test => ['OrFileExist', 
            'supplementary_alignments/raw_counts/sample_aho_cdr_counts.txt',
            'supplementary_alignments/raw_counts/sample_imgt_cdr_counts.txt',
            'supplementary_alignments/raw_counts/sample_chothia_cdr_counts.txt',
        ],
        description => 'Sample level Ab or TCR CDR counts from whole transcriptome RNASeq',
    },
    Supp_RepSeqSummaries => {
        test => ['OrDirExist', 
            'supplementary_alignments/summary_reports_imgt',
            'supplementary_alignments/summary_reports_aho',
            'supplementary_alignments/summary_reports_chothia',
        ],
        description => 'Ab and/or TCR alignment information from whole transcriptome RNASeq',
    },
    CellRanger => {
        test => ['OrDirExist', 
                 'cellranger3.1_results/Summaries',
                 'cellranger7.2.0_results/Summaries',
                 'cellranger6.1.2_results/Summaries',
                 'spaceranger1.3.0_results/Summaries',
                 'spaceranger2.1.0_results/Summaries',
                 'cellranger-atac1.2_results/Summaries',
                 'cellranger_arc2.01_results/Summaries'],
        description => 'CellRanger, CellRanger-ARC, CellRanger-ATAC, or SpaceRanger',
    },
);

sub print_standards {
    print "StandardName\tDescription\n";
    foreach my $std (sort keys %standards_definitions) {
        print "$std\t$standards_definitions{description}\n";
    }
}

sub get_standards {
    my ($proj_type, $res_dn) = @_;

    my %stds_supported;
    foreach my $std (keys %standards_definitions) {
        my $passed = 0;
        my $tested = 0;
        foreach my $key (keys %{$standards_definitions{$std}}) {
            next if ($key !~ m/^test/);
            my ($test, @args) = @{$standards_definitions{$std}{$key}};
            $tested++;
            if ($test eq 'FileExist') {
                my $ok = 1;
                #We pass the test if all the files exist.
                foreach my $fn (@args) {
                    if (!-s "$res_dn/$fn") {
                        $ok = 0;
                        last;
                    }
                }
                if ($ok) {
                    $passed++;
                }
            }
            elsif ($test eq 'OrFileExist') {
                my $ok = 0;
                #We pass the test if any of the files exist.
                foreach my $fn (@args) {
                    if (-s "$res_dn/$fn") {
                        $ok = 1;
                        last;
                    }
                }
                if ($ok) {
                    $passed++;
                }
            }
            elsif ($test eq 'DirExist') {
                my $ok = 1;
                #We pass the test if all the directories exist.
                foreach my $dn (@args) {
                    if (!-d "$res_dn/$dn") {
                        $ok = 0;
                        last;
                    }
                }
                if ($ok) {
                    $passed++;
                }
            } elsif ($test eq 'DirExistPattern') {
                my $ok = 0;
                #Test for a single directory that matches a regex
                my ($glob, $reg_ex) = @args;
                foreach my $dn (glob("$res_dn/$glob")) {
                    #  warn "Testing dn $dn with RE $reg_ex\n";
                    if ($dn =~ m/$reg_ex/) {
                        $ok = 1;
                        #    warn "MATCH\n";
                        last;
                    } else {
                        #warn "NoMatch\n";
                    }
                }
                if ($ok) {
                    $passed++;
                }
            } elsif ($test eq 'ProjectType') {
                #Currently only test one argument, should AND all arguemnts..
                #warn "proj_type $proj_type and $args[0]\n";
                if ($proj_type and $proj_type =~ m/$args[0]/) {
                    $passed++;
                }
            } elsif ($test eq 'ProjectTypeNot') {
                #Currently only test one argument, should AND all arguemnts..
                if (!$proj_type or $proj_type !~ m/$args[0]/) {
                    $passed++;
                }
            }
            elsif ($test eq 'OrDirExist') {
                my $ok = 0;
                #We pass the test if any of the directories exist.
                foreach my $dn (@args) {
                    if (-d "$res_dn/$dn") {
                        $ok = 1;
                        last;
                    }
                }
                if ($ok) {
                    $passed++;
                }
            }
            else {
                die "Don't know how to do test $test. Stopped($res_dn)";
            }
        }
        if ($tested and $tested == $passed) {
            #warn "tested=$tested passed = $passed for $std\n";
            $stds_supported{$std} = 1;
        }
    }
    return join(', ', sort keys %stds_supported);
}



1;
