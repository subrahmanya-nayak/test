import pandas as pd
from Bio import Entrez

# Configure Entrez with your email
Entrez.email = "your_email@example.com"  # Replace with your email

def fetch_gene_symbol(nm_id):
    """Fetch the HGNC gene symbol for a given NM_ identifier."""
    try:
        handle = Entrez.efetch(db="nucleotide", id=nm_id, rettype="gb", retmode="text")
        record = handle.read()
        handle.close()
        for line in record.split("\n"):
            if line.startswith("  /gene="):
                return line.split("=")[1].strip().strip('"')
    except Exception as e:
        print(f"Error fetching {nm_id}: {e}")
    return None

# Load the abundance.tsv file
df = pd.read_csv("abundance.tsv", sep="\t")

# Map NM_ identifiers to HGNC symbols
df["HGNC_symbol"] = df["target_id"].apply(fetch_gene_symbol)

# Fill missing symbols with "Unknown"
df["HGNC_symbol"].fillna("Unknown", inplace=True)

# Combine TPM or estimated counts for rows with the same HGNC symbol
# You can modify the aggregation function (e.g., "mean", "sum", "max") as needed.
aggregated = df.groupby("HGNC_symbol").agg({
    "tpm": "sum",         # Summing TPM values (or use 'mean' for average, 'max' for max value)
    "est_counts": "sum",  # Summing estimated counts
    "length": "first",    # Keep the first length as an example
    "eff_length": "first" # Keep the first effective length as an example
}).reset_index()

# Save the result to a new file
aggregated.to_csv("aggregated_abundance.tsv", sep="\t", index=False)
print("Aggregation complete. Saved to aggregated_abundance.tsv.")

